// Kombo ateşi: ekran kartında çalışan gerçek zamanlı ateş gölgelendiricisi.
// Tahtanın çerçevesi boyunca, türbülans gürültüsüyle yukarı doğru dalgalanan kesintisiz alevler çizer.
import { Mesh, Geometry, Shader } from '../lib/pixi.min.mjs';

const vertex = `
  in vec2 aPosition;
  in vec2 aUV;
  out vec2 vUV;
  uniform mat3 uProjectionMatrix;
  uniform mat3 uWorldTransformMatrix;
  uniform mat3 uTransformMatrix;
  void main() {
    mat3 mvp = uProjectionMatrix * uWorldTransformMatrix * uTransformMatrix;
    gl_Position = vec4((mvp * vec3(aPosition, 1.0)).xy, 0.0, 1.0);
    vUV = aUV;
  }
`;

const fragment = `
  in vec2 vUV;
  uniform float uTime;
  uniform vec2 uSize;
  uniform vec4 uRect;
  uniform float uCell;
  uniform float uIntensity;
  uniform float uIgnite;
  uniform float uHeat;
  uniform float uPulse;

  float hash(vec2 p) {
    p = fract(p * vec2(123.34, 456.21));
    p += dot(p, p + 45.32);
    return fract(p.x * p.y);
  }
  float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(mix(hash(i), hash(i + vec2(1.0, 0.0)), u.x),
               mix(hash(i + vec2(0.0, 1.0)), hash(i + vec2(1.0, 1.0)), u.x), u.y);
  }
  float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 5; i++) { v += a * noise(p); p *= 2.03; a *= 0.5; }
    return v;
  }
  float sdRoundRect(vec2 p, vec2 c, vec2 h, float r) {
    vec2 q = abs(p - c) - h + r;
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
  }

  void main() {
    vec2 p = vUV * uSize;
    vec2 q = p / uCell;
    float t = uTime;
    vec2 c = uRect.xy + uRect.zw * 0.5;
    // Alanı bükerek kıvrılan, organik alev dilleri: dikey uzatılmış türbülans yukarı akar
    vec2 w = vec2(fbm(q * 0.8 + vec2(0.0, t * 0.9)), fbm(q * 0.8 + vec2(5.2, t * 1.15)));
    float n1 = fbm(vec2(q.x * 2.1 + w.x * 1.2, q.y * 0.75 + t * 2.6));
    float n2 = fbm(vec2(q.x * 4.2 + 7.3 + w.y, q.y * 1.6 + t * 4.6));
    float turb = clamp((n1 * 0.62 + n2 * 0.38 - 0.5) * 1.9 + 0.5, 0.0, 1.0);   // daha belirgin tepeler ve boşluklar
    vec2 hs = uRect.zw * 0.5;
    float rr = uCell * 0.22;
    float sd0 = sdRoundRect(p, c, hs, rr);
    vec2 g = vec2(sdRoundRect(p + vec2(1.0, 0.0), c, hs, rr) - sd0, sdRoundRect(p + vec2(0.0, 1.0), c, hs, rr) - sd0);
    float up = -g.y / max(length(g), 1e-4);           // üst kenarda 1, altta -1, yanlarda 0
    float regionH = 0.95 + (0.12 - 0.3 * uHeat) * max(up, 0.0) - 0.62 * max(-up, 0.0);   // üstte puan çubuğu, altta parçalar kapanmasın
    float wig = (turb - 0.5) * uCell * 0.45;          // alev tabanı dalgalansın
    float d = sd0 < 0.0 ? -sd0 * 6.0 : max(0.0, sd0 + wig);  // tahtanın içine yalnız ince bir yalaz taşar (oyun görünür)
    float height = uCell * (0.55 + 1.55 * turb) * regionH * (1.0 + 0.5 * uHeat + 0.55 * uPulse) * uIntensity;
    float f = clamp(1.0 - d / max(height, 1.0), 0.0, 1.0);
    // Tutuşma: ateş alt ortadan başlar, iki yandan çerçeve boyunca yukarı koşar
    vec2 rel = (p - c) / (uRect.zw * 0.5);
    float ang = abs(atan(rel.x, rel.y));
    float edge = uIgnite * 3.45;
    float lit = 1.0 - smoothstep(edge - 0.3, edge, ang);
    float front = exp(-pow((ang - edge + 0.12) / 0.16, 2.0)) * step(uIgnite, 0.99); // koşan ateşin ucu parlak
    f *= lit;
    // Dipte kesintisiz yatak, uçlara doğru ayrık alev dilleri
    float tip = clamp(d / max(height, 1.0) * 1.6, 0.0, 1.0);
    f *= mix(smoothstep(0.05, 0.45, turb + 0.15), smoothstep(0.3, 0.62, turb), tip);
    f = min(1.0, f + front * 0.6 * clamp(1.0 - abs(sd0) / (uCell * 0.8), 0.0, 1.0));
    float heat = pow(f, 1.45);
    // Renk: koyu kızıl → turuncu → sarı → beyaz çekirdek (kombo yükseldikçe çekirdek mavi-beyaza döner)
    vec3 col = mix(vec3(0.42, 0.02, 0.0), vec3(1.0, 0.27, 0.02), smoothstep(0.0, 0.34, heat));
    col = mix(col, vec3(1.0, 0.62, 0.08), smoothstep(0.3, 0.62, heat));
    col = mix(col, vec3(1.0, 0.86, 0.42), smoothstep(0.66, 0.92, heat));
    col = mix(col, mix(vec3(1.0, 0.96, 0.82), vec3(0.62, 0.86, 1.0), uHeat), smoothstep(0.95, 1.0, heat));
    float a = smoothstep(0.03, 0.3, heat) * uIntensity;
    // Alev uçlarının üstünde soluk duman (koyulaştırır), tahtanın çevresinde sıcak ışık halesi
    float sm = fbm(vec2(q.x * 1.1, q.y * 0.8 + t * 1.2) + w * 1.5);
    float band = clamp(1.0 - abs(d - height * 1.05) / (uCell * 1.1), 0.0, 1.0) * step(0.0, sd0);
    float smoke = band * smoothstep(0.42, 0.78, sm) * 0.32 * uIntensity * lit * (1.0 - a);
    float glow = exp(-abs(sd0) / (uCell * (0.8 + 0.4 * uHeat))) * (0.16 + 0.12 * uPulse) * uIntensity * lit * (0.85 + 0.15 * sin(t * 7.0));
    vec3 rgb = col * a + vec3(1.0, 0.36, 0.06) * glow;
    // Alevler yarı toplamalı (parlar), duman normal karışımla koyulaştırır
    gl_FragColor = vec4(rgb, a * 0.8 + smoke);
  }
`;

// Tahtayı saran ateş katmanı. layout() ile tahta konumuna oturur, update() ile canlanır.
export function createFire() {
  const geometry = new Geometry({
    attributes: {
      aPosition: [0, 0, 1, 0, 1, 1, 0, 1],
      aUV: [0, 0, 1, 0, 1, 1, 0, 1],
    },
    indexBuffer: [0, 1, 2, 0, 2, 3],
  });
  const shader = Shader.from({
    gl: { vertex, fragment },
    resources: {
      fireUniforms: {
        uTime: { value: 0, type: 'f32' },
        uSize: { value: [1, 1], type: 'vec2<f32>' },
        uRect: { value: [0, 0, 1, 1], type: 'vec4<f32>' },
        uCell: { value: 40, type: 'f32' },
        uIntensity: { value: 0, type: 'f32' },
        uIgnite: { value: 1, type: 'f32' },
        uHeat: { value: 0, type: 'f32' },
        uPulse: { value: 0, type: 'f32' },
      },
    },
  });
  const mesh = new Mesh({ geometry, shader });
  mesh.blendMode = 'normal';   // ön çarpımlı renk: alevler parlar, duman koyulaştırır
  mesh.visible = false;
  const u = shader.resources.fireUniforms.uniforms;
  return {
    mesh,
    // bx, by: tahtanın sol üstü; size: tahta kenarı; cell: hücre boyu
    layout(bx, by, size, cell) {
      const m = cell * 2.1;
      mesh.position.set(bx - m, by - m * 1.35);
      mesh.scale.set(size + m * 2, size + m * 2.35);
      u.uSize = [size + m * 2, size + m * 2.35];
      u.uRect = [m, m * 1.35, size, size];
      u.uCell = cell;
    },
    // ignite: 0→1 tutuşma ilerlemesi, heat: kombo ısısı (0..1), pulse: yeni kombo parlaması
    update(time, intensity, ignite = 1, heat = 0, pulse = 0) {
      u.uTime = time;
      u.uIntensity = intensity;
      u.uIgnite = ignite;
      u.uHeat = heat;
      u.uPulse = pulse;
      mesh.visible = intensity > 0.01;
    },
  };
}
