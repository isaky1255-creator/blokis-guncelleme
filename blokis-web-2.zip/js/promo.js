// Tanıtım videosu katmanı (yalnız ?promo ile yüklenir): parmak imleci, sahne yazıları, kapanış kartı.
// Kayıt aracı (tools/video/kaydet.mjs) bu fonksiyonları sahne sırasına göre çağırır.

const css = `
#pHand { position: fixed; left: 0; top: 0; width: 64px; height: 64px; z-index: 9998; pointer-events: none; opacity: 0;
  transform: translate(-22px, -6px); transition: opacity .15s; filter: drop-shadow(0 6px 10px rgba(0,0,0,.45)); }
#pHand.on { opacity: 1; }
#pHand svg { width: 100%; height: 100%; transition: transform .12s; transform-origin: 30% 10%; }
#pHand.down svg { transform: scale(.86); }
#hud .top { visibility: hidden; }
#home .home-top { visibility: hidden; }
#pCap.bottom { top: auto; bottom: 9%; }
/* Tahta ile parçalar arası (sonsuz modda üstte büyük skor var) */
#pCap.mid { top: 63.5%; }
#toast { display: none !important; }
/* Reels güvenli alanı: yazı üstten %13,5'te; görünürken altındaki hedef/süre paneli saklanır */
#goalBar, #progress, .side-btn { transition: opacity .25s; }
body.pcap-on #goalBar, body.pcap-on #progress, body.pcap-on .side-btn { opacity: 0 !important; }
/* Ortada büyük açılış yazısı: sonra küçülerek üste kayar (top + scale geçişi) */
#pCap { transition: top .55s cubic-bezier(.5,0,.15,1), transform .55s cubic-bezier(.5,0,.15,1); transform-origin: 50% 0; }
#pCap.center { top: 33%; transform: scale(1.34); }
#pCap.center.s-b { transform: scale(1.12); }
#pCap .cap.big { max-width: 250px; white-space: normal; transition: transform .55s cubic-bezier(.5,0,.15,1); transform-origin: 50% 0; }
#pCap.s-b .cap.big { max-width: none; }
#pCap:not(.center) .cap.big { transform: scale(.82); }
.skip-hint, .tut-tip, .tut-hand { display: none !important; }
#pCap { position: fixed; left: 0; right: 0; top: 13.5%; z-index: 9997; pointer-events: none; text-align: center; padding: 0 18px; }
#pCap .cap { display: inline-block; font: 900 31px/1.1 var(--font); white-space: nowrap; color: #fff; letter-spacing: .2px;
  -webkit-text-stroke: 7px #1a1450; paint-order: stroke fill; text-shadow: 0 6px 0 rgba(10,8,40,.55);
  animation: capIn .42s cubic-bezier(.2,1.6,.4,1) both; }
#pCap .cap em { font-style: normal; color: #ffd84a; }
#pCap .cap.out { animation: capOut .22s ease-in both; }
@keyframes capIn { from { transform: scale(.4) rotate(-4deg); opacity: 0; } to { transform: none; opacity: 1; } }
@keyframes capOut { to { transform: scale(.85); opacity: 0; } }
/* Kinetik yazı stilleri: #pCap.s-a (kelime kelime), .s-b (bant), .s-c (harf yağmuru). Parlama yok. */
#pCap.s-a .cap, #pCap.s-b .cap, #pCap.s-c .cap { animation: none; }
#pCap .w, #pCap .ch { display: inline-block; white-space: pre; }
#pCap .w { margin: 0 .09em; }
#pCap .hl { color: #ffd84a; }
#pCap.s-a .w { animation: aIn .52s cubic-bezier(.2,1.55,.35,1) calc(var(--i) * 75ms) both; }
#pCap.s-a .w.hl { animation: aIn .52s cubic-bezier(.2,1.55,.35,1) calc(var(--i) * 75ms) both, aPop .42s ease-out calc(var(--i) * 75ms + .5s) both; }
#pCap.s-a .cap.out .w { animation: aOut .26s ease-in calc(var(--i) * 35ms) both; }
@keyframes aIn { 0% { transform: translateY(46px) scale(.55) rotate(-7deg); opacity: 0; } 55% { opacity: 1; } 100% { transform: none; opacity: 1; } }
@keyframes aPop { 45% { transform: scale(1.2) rotate(-3deg); } 100% { transform: none; } }
@keyframes aOut { to { transform: translateY(-34px) scale(.75); opacity: 0; } }
#pCap.s-b .cap { -webkit-text-stroke: 0; text-shadow: none; padding: 9px 18px 11px; border-radius: 18px; background: rgba(18, 14, 64, .86);
  box-shadow: 0 10px 24px rgba(0, 0, 30, .35); animation: bIn .34s cubic-bezier(.3,.9,.3,1) both; font-size: 23px; white-space: nowrap; }
#pCap.s-b .w { animation: bW .42s cubic-bezier(.2,1.3,.4,1) calc(.12s + var(--i) * 60ms) both; }
#pCap.s-b .w.hl { color: #1a1450; background: #ffd84a; padding: 0 8px 2px; margin: 0 2px; border-radius: 9px; transform-origin: 50% 60%;
  animation: bW .42s cubic-bezier(.2,1.3,.4,1) calc(.12s + var(--i) * 60ms) both, bTag .3s ease-out calc(.5s + var(--i) * 60ms) both; }
#pCap.s-b .cap.out { animation: bOut .24s ease-in both; }
@keyframes bIn { from { clip-path: inset(0 100% 0 0 round 18px); } to { clip-path: inset(0 0 0 0 round 18px); } }
@keyframes bW { from { transform: translateY(26px); opacity: 0; } to { transform: none; opacity: 1; } }
@keyframes bTag { from { transform: rotate(0) scale(1); } 60% { transform: rotate(-3deg) scale(1.08); } to { transform: rotate(-2deg); } }
@keyframes bOut { from { clip-path: inset(0 0 0 0 round 18px); opacity: 1; } to { clip-path: inset(0 0 0 100% round 18px); opacity: .6; } }
#pCap.s-c .ch { animation: cIn .46s cubic-bezier(.2,1.4,.4,1) calc(var(--i) * 28ms) both; }
#pCap.s-c .hl .ch { animation: cIn .46s cubic-bezier(.2,1.4,.4,1) calc(var(--i) * 28ms) both, cWob .5s ease-in-out calc(var(--i) * 28ms + .55s) both; }
#pCap.s-c .cap.out .ch { animation: cOut .28s ease-in calc(var(--i) * 12ms) both; }
@keyframes cIn { 0% { transform: translateY(-38px) scale(1.5); filter: blur(5px); opacity: 0; } 60% { filter: blur(0); opacity: 1; } 100% { transform: none; filter: none; opacity: 1; } }
@keyframes cWob { 30% { transform: translateY(-6px) rotate(-6deg); } 65% { transform: translateY(0) rotate(4deg); } 100% { transform: none; } }
@keyframes cOut { to { transform: translateY(-26px) rotate(12deg); opacity: 0; } }
#pEnd { position: fixed; inset: 0; z-index: 9999; display: none; place-items: center; text-align: center;
  background: radial-gradient(120% 80% at 50% 38%, #3a3fb0 0%, #1d2070 45%, #0d0f3c 100%); }
#pEnd.on { display: grid; }
@keyframes endIn { from { opacity: 0; } }
#pEnd .in { width: 100%; padding: 0 26px; }
#pEnd img { width: 86%; max-width: 330px; animation: logoIn .7s cubic-bezier(.2,1.5,.4,1) .15s both; filter: drop-shadow(0 10px 18px rgba(0,0,30,.5)); }
@keyframes logoIn { from { transform: scale(.3) translateY(40px); opacity: 0; } }
#pEnd .t1 { margin-top: 18px; font: 900 25px/1.2 var(--font); color: #fff; -webkit-text-stroke: 6px #14104a; paint-order: stroke fill;
  animation: up .5s ease-out .55s both; }
#pEnd .t1 em { font-style: normal; color: #ffd84a; }
#pEnd .t1.kin { animation: none; }
#pEnd .t1.kin .w { display: inline-block; animation: aIn .52s cubic-bezier(.2,1.55,.35,1) calc(.55s + var(--i) * 90ms) both; }
#pEnd .t1.kin .w.hl { color: #ffd84a; animation: aIn .52s cubic-bezier(.2,1.55,.35,1) calc(.55s + var(--i) * 90ms) both, aPop .42s ease-out calc(1.1s + var(--i) * 90ms) both; }
#pEnd .t2 { margin-top: 10px; font: 800 15px/1.35 var(--font); color: #c9cdf8; animation: up .5s ease-out .75s both; }
#pEnd .badge { display: inline-flex; align-items: center; gap: 10px; margin-top: 26px; padding: 13px 26px; border-radius: 18px;
  background: linear-gradient(180deg, #6ee08a, #1fa64b); box-shadow: 0 6px 0 #157a36, 0 14px 26px rgba(0,0,0,.35);
  font: 900 21px/1 var(--font); color: #fff; letter-spacing: .4px; animation: up .5s ease-out .95s both, pulse 1.1s ease-in-out 1.6s infinite; }
#pEnd .badge small { display: block; font-size: 11px; font-weight: 800; opacity: .9; letter-spacing: 1.2px; margin-bottom: 3px; }
@keyframes up { from { transform: translateY(26px); opacity: 0; } }
@keyframes pulse { 50% { transform: scale(1.06); } }
#pEnd .spark { position: absolute; width: 8px; height: 8px; border-radius: 50%; background: #fff; opacity: 0;
  animation: tw 2.2s ease-in-out infinite; box-shadow: 0 0 12px 4px rgba(255,230,140,.8); }
@keyframes tw { 30% { opacity: .9; transform: scale(1.4); } 60% { opacity: 0; transform: scale(.4); } }
/* Tepsi parçalarının üstünde 1-2-3 numaraları (bulmaca videosu) */
#pLab b { position: fixed; z-index: 9997; width: 38px; height: 38px; margin: -19px 0 0 -19px; border-radius: 50%; display: grid; place-items: center;
  background: #ffd84a; color: #1a1450; font: 900 22px/1 var(--font); box-shadow: 0 4px 0 #b8860b, 0 8px 14px rgba(0,0,30,.4);
  animation: labIn .4s cubic-bezier(.2,1.6,.4,1) calc(var(--i) * 120ms) both; }
#pLab b.no { animation: labNo .3s ease-in both; }
#pLab b.ok { background: #4fd36b; color: #fff; box-shadow: 0 4px 0 #157a36, 0 8px 14px rgba(0,0,30,.4); animation: labOk .5s ease-out both; }
@keyframes labIn { from { transform: scale(0); } }
@keyframes labNo { to { transform: scale(.4); opacity: 0; } }
@keyframes labOk { 40% { transform: scale(1.35); } }
#pFlash { position: fixed; inset: 0; z-index: 9996; background: #fff; opacity: 0; pointer-events: none; }
#pFlash.go { animation: fl .35s ease-out; }
@keyframes fl { from { opacity: .85; } to { opacity: 0; } }
`;
const st = document.createElement('style');
st.textContent = css;
document.head.appendChild(st);

const hand = document.createElement('div');
hand.id = 'pHand';
hand.innerHTML = `<svg viewBox="0 0 64 64"><path d="M22 6c2.8 0 5 2.2 5 5v17l2-.4V22c0-2.6 2-4.6 4.6-4.6S38 19.4 38 22v6l1.6-.2v-3c0-2.5 2-4.5 4.5-4.5s4.5 2 4.5 4.5v4l1-.1c2.6-.3 4.9 1.7 4.9 4.3v9.4c0 9.6-7.8 17.4-17.4 17.4h-3.6c-5.6 0-10.8-2.8-14-7.4L11 40.8c-1.5-2.2-1-5.2 1.1-6.8 2.1-1.5 5-1.2 6.6.8l-1.7-23.8C17 8.3 19.2 6 22 6z" fill="#fff" stroke="#1a1450" stroke-width="3.2" stroke-linejoin="round"/></svg>`;
document.body.appendChild(hand);
const cap = document.createElement('div');
cap.id = 'pCap';
cap.className = 's-a';   // varsayılan yazı stili: kelime kelime (2026-10 reklam)
document.body.appendChild(cap);
const lab = document.createElement('div');
lab.id = 'pLab';
document.body.appendChild(lab);
const flash = document.createElement('div');
flash.id = 'pFlash';
document.body.appendChild(flash);
const end = document.createElement('div');
end.id = 'pEnd';
end.innerHTML = `<div class="in"><img src="img/logo.png" alt=""><div class="t1 kin"><span class="w" style="--i:0">Blokları</span> <span class="w" style="--i:1">yerleştir,</span> <span class="w hl" style="--i:2">patlat!</span></div>
  <div class="t2">180 bölüm · Blok Kaçışı · Özel bölümler · Ada inşası</div>
  <div class="badge"><span><small>APP STORE · GOOGLE PLAY</small>ÜCRETSİZ İNDİR</span></div></div>`;
for (let i = 0; i < 14; i++) {
  const s = document.createElement('i');
  s.className = 'spark';
  s.style.left = `${8 + ((i * 37) % 84)}%`;
  s.style.top = `${10 + ((i * 53) % 80)}%`;
  s.style.animationDelay = `${(i * 0.37) % 2.2}s`;
  end.appendChild(s);
}
document.body.appendChild(end);

// Parmak imleci gerçek dokunuşu izler
const move = (e) => { hand.style.left = `${e.clientX}px`; hand.style.top = `${e.clientY}px`; };
addEventListener('pointermove', move, true);
addEventListener('pointerdown', (e) => { move(e); hand.classList.add('down'); }, true);
addEventListener('pointerup', () => hand.classList.remove('down'), true);

// Yazıyı kelimelere (ya da harflere) böler; her parçaya sıra numarası (--i) verilir, vurgulu (<em>) kısımlar .hl olur
function splitCap(d, chars) {
  let i = 0;
  const frag = document.createDocumentFragment();
  const add = (text, hl) => {
    for (const part of text.split(/(\s+)/)) {
      if (!part) continue;
      if (/^\s+$/.test(part)) { frag.appendChild(document.createTextNode(' ')); continue; }
      const w = document.createElement('span');
      w.className = 'w' + (hl ? ' hl' : '');
      if (chars) for (const c of [...part]) { const s = document.createElement('span'); s.className = 'ch'; s.textContent = c; s.style.setProperty('--i', i++); w.appendChild(s); }
      else { w.textContent = part; w.style.setProperty('--i', i++); }
      frag.appendChild(w);
    }
  };
  for (const n of [...d.childNodes]) add(n.textContent, n.nodeType === 1 && n.tagName === 'EM');
  d.replaceChildren(frag);
}
window.__promoUI = {
  style(k) { cap.classList.remove('s-a', 's-b', 's-c'); if (k) cap.classList.add('s-' + k); },
  hand(on, x, y) { if (x !== undefined) { hand.style.left = `${x}px`; hand.style.top = `${y}px`; } hand.classList.toggle('on', on); },
  caption(html, pos = '') {
    cap.classList.toggle('bottom', pos === 'bottom');
    cap.classList.toggle('mid', pos === 'mid');
    if (pos === 'center' || cap.firstElementChild || !cap.classList.contains('center')) cap.classList.toggle('center', pos === 'center');
    const old = cap.firstElementChild;
    if (old) { old.classList.add('out'); setTimeout(() => old.remove(), 460); }
    document.body.classList.toggle('pcap-on', !!html);
    if (!html) { setTimeout(() => cap.classList.remove('center'), 460); return; }
    const d = document.createElement('div');
    d.className = 'cap' + (pos === 'center' ? ' big' : '');
    d.innerHTML = html;
    if (/s-[abc]/.test(cap.className)) splitCap(d, cap.classList.contains('s-c'));
    setTimeout(() => cap.appendChild(d), old ? 200 : 0);
  },
  toTop() { cap.classList.remove('center', 'bottom'); },
  // pts: [{x,y}] → numaralı rozetler; ok: doğru parçanın sırası (diğerleri kaybolur, doğru olan yeşil yanar); null: temizle
  labels(pts, ok) {
    if (pts === null) { lab.replaceChildren(); return; }
    if (ok !== undefined) { [...lab.children].forEach((b, i) => b.classList.add(i === ok ? 'ok' : 'no')); return; }
    lab.replaceChildren(...pts.map((p, i) => { const b = document.createElement('b'); b.textContent = i + 1; b.style.left = `${p.x}px`; b.style.top = `${p.y}px`; b.style.setProperty('--i', i); return b; }));
  },
  flash() { flash.classList.remove('go'); void flash.offsetWidth; flash.classList.add('go'); },
  endCard() { end.classList.add('on'); },
};
