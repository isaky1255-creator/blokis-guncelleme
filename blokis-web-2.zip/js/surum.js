// Oyunun web paketi sürümü. Canlı güncelleme (tools/canli-guncelle.sh) her pakette bunu bir artırır.
export const WEB_SURUM = 2;
