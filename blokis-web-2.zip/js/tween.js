// Küçük animasyon motoru: nesne özelliklerini zamanla değiştirir, Promise döndürür.

export const Ease = {
  linear: (t) => t,
  outQuad: (t) => 1 - (1 - t) * (1 - t),
  outCubic: (t) => 1 - (1 - t) ** 3,
  inQuad: (t) => t * t,
  inOutCubic: (t) => (t < 0.5 ? 4 * t * t * t : 1 - (-2 * t + 2) ** 3 / 2),
  outBack: (t) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * (t - 1) ** 3 + c1 * (t - 1) ** 2; },
  // Düşen taşlar için hafif sekme
  outBounce: (t) => {
    const n = 7.5625, d = 2.75;
    if (t < 1 / d) return n * t * t;
    if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75;
    if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375;
    return n * (t -= 2.625 / d) * t + 0.984375;
  },
  outSoftBounce: (t) => {
    // Daha yumuşak tek sekme: hızla iner, %6 geri sıçrar
    if (t < 0.7) { const u = t / 0.7; return u * u; }
    const u = (t - 0.7) / 0.3;
    return 1 - Math.sin(u * Math.PI) * 0.06;
  },
};

const active = [];

// props: { x: 10, alpha: 0, 'scale.x': 1.2 } gibi; noktalı yollar desteklenir
export function tween(obj, props, dur = 0.3, ease = Ease.outCubic, delay = 0) {
  return new Promise((resolve) => {
    const keys = Object.keys(props).map((k) => {
      const path = k.split('.');
      const target = path.slice(0, -1).reduce((o, p) => o[p], obj);
      const prop = path[path.length - 1];
      return { target, prop, to: props[k], from: null };
    });
    active.push({ keys, dur: Math.max(0.0001, dur), ease, t: -delay, resolve, obj });
  });
}

export const wait = (sec) => tween({}, {}, sec);

export function killTweens(obj) {
  for (let i = active.length - 1; i >= 0; i--) if (active[i].obj === obj) active.splice(i, 1);
}

// Nesnenin yalnız verilen özelliğini süren animasyonları durdurur (diğer özellikler sürer).
// Aynı özelliğe üst üste animasyon başlatılırsa eskisi yenisini ezmesin diye.
export function killTweenProp(obj, prop) {
  for (let i = active.length - 1; i >= 0; i--) {
    const tw = active[i];
    if (tw.obj !== obj) continue;
    const n = tw.keys.length;
    tw.keys = tw.keys.filter((k) => !(k.target === obj && k.prop === prop));
    if (n && !tw.keys.length) { active.splice(i, 1); tw.resolve(); }
  }
}
// Tahta kayınca (yükselen sıra) yoldaki animasyonların başlangıcı ve hedefi de aynı miktar kayar
export function shiftTweens(objs, prop, d) {
  for (const tw of active) {
    if (!objs.has(tw.obj)) continue;
    for (const k of tw.keys) if (k.prop === prop && k.target === tw.obj) { if (k.from !== null) k.from += d; k.to += d; }
  }
}

export function updateTweens(dt) {
  for (let i = active.length - 1; i >= 0; i--) {
    const tw = active[i];
    // Hedef nesne yok edildiyse animasyonu sessizce bitir (ör. konumu/ölçeği silinmiş bir yazı)
    if (tw.obj.destroyed || (tw.obj._observer && tw.obj._observer.destroyed)) {
      active.splice(i, 1);
      tw.resolve();
      continue;
    }
    tw.t += dt;
    if (tw.t < 0) continue;
    for (const k of tw.keys) if (k.from === null) k.from = k.target[k.prop];
    const f = Math.min(1, tw.t / tw.dur);
    const e = tw.ease(f);
    for (const k of tw.keys) k.target[k.prop] = k.from + (k.to - k.from) * e;
    if (f >= 1) {
      active.splice(i, 1);
      tw.resolve();
    }
  }
}
