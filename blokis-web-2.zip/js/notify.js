// Yerel bildirimler: oyundan çıkınca planlanır, oyuna dönünce silinir (oynarken bildirim gelmez).
// Canlar dolunca, günlük ödül hazır olunca ve birkaç gün oynanmazsa hatırlatır.
import { Store } from './platform.js';
import { Lives, dailyState } from './economy.js';

const plugin = () => (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform() && window.Capacitor.Plugins.LocalNotifications) || null;
const ID = { lives: 1, daily: 2, back: 3, back2: 4 };
const DAY = 864e5;
// Gün içinde belirli saat (yerel); geçmişte kalırsa ertesi güne kayar
function atHour(dayOffset, h) {
  const t = new Date();
  const d = new Date(t.getFullYear(), t.getMonth(), t.getDate() + dayOffset, h, 0, 0);
  return d.getTime() <= Date.now() + 60e3 ? new Date(d.getTime() + DAY) : d;
}

export const Notify = {
  get enabled() { return Store.get('notify', '1') === '1'; },
  toggle() {
    Store.set('notify', this.enabled ? '0' : '1');
    if (this.enabled) this.ask(true);
    return this.enabled;
  },
  // İzin: oyuncu oyunu biraz tanıdıktan sonra bir kez sorulur (force: ayarlardan açınca)
  async ask(force = false) {
    const P = plugin();
    if (!P || (!force && Store.get('notify_asked', '') === '1')) return;
    Store.set('notify_asked', '1');
    try {
      const st = await P.checkPermissions();
      if (st.display !== 'granted' && st.display !== 'denied') await P.requestPermissions();
    } catch { /* yok say */ }
  },
  async clear() {
    const P = plugin();
    if (!P) return;
    try { await P.cancel({ notifications: Object.values(ID).map((id) => ({ id })) }); } catch { /* yok say */ }
  },
  // Oyundan çıkarken: duruma göre bildirimleri yeniden kur
  async plan(level) {
    const P = plugin();
    if (!P) return;
    await this.clear();
    if (!this.enabled) return;
    try {
      if ((await P.checkPermissions()).display !== 'granted') return;
      const list = [];
      const lv = Lives.state();
      if (lv.refillAt && lv.refillAt > Date.now() + 60e3) {
        list.push({ id: ID.lives, title: 'Canların doldu! ❤️', body: 'Bütün canların hazır. Kaldığın yerden devam etmeye ne dersin?', schedule: { at: new Date(lv.refillAt) } });
      }
      // Günlük ödül: bugün toplanmadıysa akşam, toplandıysa yarın sabah
      list.push({ id: ID.daily, title: 'Günlük ödülün hazır 🎁', body: 'Serini bozma! Bugünün ödülünü toplamayı unutma.', schedule: { at: dailyState().canClaim ? atHour(0, 19) : atHour(1, 11) } });
      // Oyuna dönüş hatırlatmaları
      list.push({ id: ID.back, title: 'Bloklar seni bekliyor 🧩', body: `Bölüm ${level + 1} seni bekliyor. Bir tur daha?`, schedule: { at: atHour(2, 19) } });
      list.push({ id: ID.back2, title: 'Seni özledik! ✨', body: 'Yeni rekorlar ve ödüller seni bekliyor. Hemen bir bölüm oyna!', schedule: { at: atHour(5, 19) } });
      await P.schedule({ notifications: list });
    } catch (e) { console.warn('Bildirim kurulamadı', e); }
  },
};
