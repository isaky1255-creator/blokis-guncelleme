// Blokis logosu: harfler oyundaki pahlı bloklardan örülür. Ana ekran, simge ve
// açılış ekranı bu çizimi ortak kullanır.
import { renderTile, renderWood, renderIcon } from './tiles.js';

export const LOGO_COLORS = ['#ff3b55', '#1fd3f0', '#3ddc4a', '#a64dff'];
const FONT = '"Arial Rounded MT Bold", "SF Pro Rounded", ui-rounded, system-ui, sans-serif';

// Harf renkleri: [üst, alt] geçiş
const C = {
  red: ['#ff8a9a', '#e8193a'], orange: ['#ffc06a', '#f2690c'], green: ['#9ff28a', '#21a83c'],
  blue: ['#8ce4ff', '#1a7fe0'], purple: ['#d6a6ff', '#7b2bd9'],
};

// "Blokis" yazı logosu. size = harf yüksekliği (px). Saydam tuval döndürür.
// "i"nin noktası küçük, pahlı sarı bir blok (logonun imzası).
export function drawWordmark(size) {
  const probe = document.createElement('canvas').getContext('2d');
  probe.font = `900 ${size}px ${FONT}`;
  const xh = size * 0.56;           // küçük harf yüksekliği
  const items = [
    { t: 'B', c: C.red, rot: -0.07, dy: 0.02 },
    { t: 'l', c: C.orange, rot: 0.05, dy: -0.03 },
    { t: 'o', c: ['#fff2a0', '#f5a800'], rot: -0.04, dy: 0.0 },
    { t: 'k', c: C.green, rot: 0.06, dy: -0.02 },
    { t: 'ı', c: C.blue, rot: -0.05, dy: 0.02, dot: true }, // noktasız ı + blok nokta
    { t: 's', c: C.purple, rot: 0.07, dy: -0.01 },
  ];
  const sp = size * 0.02;
  for (const it of items) it.w = it.block ? it.block : probe.measureText(it.t).width;
  const sw = size * 0.2;            // dış lacivert kontur kalınlığı
  const depth = Math.round(size * 0.09);
  const pad = size * 0.35;
  const W = Math.ceil(items.reduce((a, it) => a + it.w + sp, -sp) + pad * 2);
  const H = Math.ceil(size * 1.25 + depth + pad * 2);
  const cv = document.createElement('canvas');
  cv.width = W; cv.height = H;
  const x = cv.getContext('2d');
  x.font = `900 ${size}px ${FONT}`;
  x.textBaseline = 'alphabetic';
  x.textAlign = 'center';
  x.lineJoin = 'round';
  const base = pad + size * 1.0;
  let cx = pad;
  for (const it of items) { it.cx = cx + it.w / 2; cx += it.w + sp; }
  const dotS = size * 0.24;
  const yellow = renderTile('#ffd21f', 128);

  // Her öğeyi kendi dönüşümüyle çizer. kind: 'path' (kontur/dolgu) veya 'fill'
  const each = (fn) => {
    for (const it of items) {
      x.save();
      x.translate(it.cx, base + it.dy * size);
      x.rotate(it.rot);
      fn(it);
      x.restore();
    }
  };
  const blockRect = (it) => [-it.block / 2, -it.block, it.block, it.block];
  const dotRect = () => [-dotS / 2, -xh - dotS * 1.25, dotS, dotS];
  const shapes = (it, stroke, fill, w, dy) => {
    x.lineWidth = w;
    x.strokeStyle = stroke;
    x.fillStyle = fill;
    const rects = [];
    if (it.block) rects.push(blockRect(it));
    if (it.dot) rects.push(dotRect());
    for (const [rx, ry, rw, rh] of rects) {
      x.beginPath();
      x.roundRect(rx, ry + dy, rw, rh, size * 0.05);
      if (w) x.stroke();
      x.fill();
    }
    if (it.t) {
      if (w) x.strokeText(it.t, 0, dy);
      x.fillText(it.t, 0, dy);
    }
  };
  // 1) Yumuşak gölge
  x.save();
  x.filter = `blur(${size * 0.07}px)`;
  each((it) => shapes(it, 'rgba(5,8,35,0.55)', 'rgba(5,8,35,0.55)', sw, depth + size * 0.07));
  x.restore();
  // 2) 3D derinlik
  for (let d = depth; d > 0; d -= 1) each((it) => shapes(it, '#0a113a', '#0a113a', sw, d));
  // 3) Lacivert dış kontur, 4) beyaz iç kontur
  each((it) => shapes(it, '#101b56', '#101b56', sw, 0));
  each((it) => shapes(it, '#ffffff', '#ffffff', sw * 0.42, 0));
  // 5) Dolgu: harfler renk geçişli, bloklar pahlı sarı blok
  each((it) => {
    if (it.t) {
      const g = x.createLinearGradient(0, -size * 0.75, 0, 0);
      g.addColorStop(0, it.c[0]);
      g.addColorStop(1, it.c[1]);
      x.fillStyle = g;
      x.fillText(it.t, 0, 0);
      // Üst yarıda parlak cila
      x.save();
      x.beginPath();
      x.rect(-it.w, -size, it.w * 2, size * 0.58);
      x.clip();
      x.fillStyle = 'rgba(255,255,255,0.32)';
      x.fillText(it.t, 0, 0);
      x.restore();
    }
    const rects = [];
    if (it.block) rects.push(blockRect(it));
    if (it.dot) rects.push(dotRect());
    for (const [rx, ry, rw, rh] of rects) {
      x.save();
      x.beginPath();
      x.roundRect(rx, ry, rw, rh, size * 0.05);
      x.clip();
      x.drawImage(yellow, rx, ry, rw, rh);
      x.restore();
    }
  });
  // 6) Parıltılar
  const spark = (sx, sy, r) => {
    x.fillStyle = '#ffffff';
    x.beginPath();
    for (let i = 0; i < 8; i++) {
      const rr = i % 2 ? r * 0.2 : r, a = (i / 8) * Math.PI * 2 - Math.PI / 2;
      x.lineTo(sx + Math.cos(a) * rr, sy + Math.sin(a) * rr);
    }
    x.fill();
  };
  const ii = items[4];
  spark(ii.cx + dotS * 0.75, base - xh - dotS * 1.6, size * 0.1);
  spark(items[2].cx - items[2].w * 0.22, base - xh * 0.72, size * 0.06);
  spark(items[0].cx - size * 0.28, base - size * 0.66, size * 0.07);
  return cv;
}

// Uygulama simgesi: mavi zemin, lacivert tahta, renkli bloklar, patlayan parlak bir satır
export function drawAppIcon(S) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  const bg = x.createLinearGradient(0, 0, 0, S);
  bg.addColorStop(0, '#4d64c4');
  bg.addColorStop(1, '#2a3a86');
  x.fillStyle = bg;
  x.fillRect(0, 0, S, S);
  // Hafif ışık
  const gl = x.createRadialGradient(S * 0.3, S * 0.2, 0, S * 0.3, S * 0.2, S * 0.8);
  gl.addColorStop(0, 'rgba(255,255,255,0.18)');
  gl.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = gl;
  x.fillRect(0, 0, S, S);
  // Tahta (4×4)
  const n = 4, cell = Math.round(S * 0.17), bw = n * cell, ox = (S - bw) / 2, oy = (S - bw) / 2 + S * 0.02;
  x.save();
  x.filter = `blur(${S * 0.025}px)`;
  x.fillStyle = 'rgba(5,10,40,0.5)';
  x.beginPath(); x.roundRect(ox - S * 0.03, oy - S * 0.01, bw + S * 0.06, bw + S * 0.06, S * 0.05); x.fill();
  x.restore();
  x.beginPath(); x.roundRect(ox - S * 0.03, oy - S * 0.03, bw + S * 0.06, bw + S * 0.06, S * 0.05);
  x.fillStyle = '#1d2350';
  x.fill();
  x.lineWidth = S * 0.012;
  x.strokeStyle = '#6e84e0';
  x.stroke();
  x.strokeStyle = '#2a3266';
  x.lineWidth = S * 0.006;
  for (let i = 1; i < n; i++) {
    x.beginPath(); x.moveTo(ox + i * cell, oy); x.lineTo(ox + i * cell, oy + bw); x.stroke();
    x.beginPath(); x.moveTo(ox, oy + i * cell); x.lineTo(ox + bw, oy + i * cell); x.stroke();
  }
  const T = {};
  const tile = (c) => (T[c] ??= renderTile(c, cell));
  const wood = renderWood(cell), gem = renderIcon('gem', cell);
  const layout = [
    ['#ff3b55', '#ff3b55', null, '#1fd3f0'],
    ['#ffd21f', '#ffd21f', '#ffd21f', '#ffd21f'], // patlayan satır
    ['#3ddc4a', 'gem', '#a64dff', '#1fd3f0'],
    ['#3ddc4a', '#3ddc4a', '#a64dff', null],
  ];
  layout.forEach((row, r) => row.forEach((c, k) => {
    if (!c) return;
    const px = ox + k * cell, py = oy + r * cell;
    if (c === 'gem') { x.drawImage(wood, px, py); x.drawImage(gem, px, py); } else x.drawImage(tile(c), px, py);
  }));
  // Patlayan satırın üstünde parlak ışın
  const by = oy + 1.5 * cell;
  const beam = x.createLinearGradient(0, by - cell, 0, by + cell);
  beam.addColorStop(0, 'rgba(255,255,255,0)');
  beam.addColorStop(0.5, 'rgba(255,255,255,0.75)');
  beam.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = beam;
  x.fillRect(ox - S * 0.08, by - cell, bw + S * 0.16, cell * 2);
  // Parıltılar
  const spark = (sx, sy, r) => {
    x.fillStyle = '#ffffff';
    x.beginPath();
    for (let i = 0; i < 8; i++) {
      const rr = i % 2 ? r * 0.18 : r, a = (i / 8) * Math.PI * 2 - Math.PI / 2;
      x.lineTo(sx + Math.cos(a) * rr, sy + Math.sin(a) * rr);
    }
    x.fill();
  };
  spark(ox - S * 0.02, by, S * 0.06);
  spark(ox + bw + S * 0.03, by - S * 0.03, S * 0.045);
  spark(ox + bw * 0.62, by - cell * 0.62, S * 0.03);
  return cv;
}
