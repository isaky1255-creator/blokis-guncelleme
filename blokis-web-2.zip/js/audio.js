// Ses: sade, kısa kayıtlı sesler (Pixabay; bkz. ses/KAYNAKLAR.txt) Web Audio ile düşük gecikmeyle
// çalınır. Her olay tek bir temiz ses; satır patlaması kısa bir parıltılı patlamadır, kombo arttıkça
// hafifçe tizleşir. Ateş moduna girişin kendi bonus sesi vardır.
// Efektler çok hafif bir yankıdan geçer, hepsi yumuşak bir sınırlayıcıda toplanır.
import { Store } from './platform.js';

const FILES = ['sd_tik', 'sd_al', 'sd_koy', 'sd_geri', 'sd_dagit', 'sd_nota', 'sd_patla', 'sd_ates', 'sd_elmas',
  'sd_odul', 'sd_tertemiz', 'sd_yildiz', 'sd_kazan', 'sd_kaybet', 'sd_dusen', 'sd_ufalan', 'muzik'];
// Kombo notaları: majör pentatonik içinde ölçülü adımlar (cırtlaklaşmasın diye en fazla 7 yarım ses)
const STEPS = [0, 2, 4, 5, 7];
// Patlama sesi kombo arttıkça yarımşar ses yükselir (en fazla 4 yarım ses, cırtlaklaşmasın)
const CLEAR_STEPS = [0, 1, 2, 3, 4];
const semi = (n) => Math.pow(2, n / 12);
const vary = (k = 0.03) => 1 + (Math.random() * 2 - 1) * k; // tekrarlarda makineli tüfek etkisini önler

let ac = null, sfxBus = null, musicBus = null, musicSrc = null;
const buf = {};
let sfxOn = Store.get('sfx', '1') === '1';
let musicOn = Store.get('music', '1') === '1';
let musicAllowed = false; // müzik açılış efektinden sonra başlar
let ducked = false;       // bir pencere açıkken müzik kısık
const MUSIC_VOL = 0.16, SFX_VOL = 0.32;   // efektler kısık (0,85 → 0,62 → 0,45 → 0,32; kullanıcı isteği)

async function load() {
  await Promise.all(FILES.map(async (n) => {
    try {
      const data = await (await fetch(`ses/${n}.m4a`)).arrayBuffer();
      buf[n] = await ac.decodeAudioData(data);
    } catch { /* yüklenemeyen ses sessiz geçer */ }
  }));
  if (musicOn && musicAllowed) startMusic();
}

// Kısa, yumuşak oda yankısı: üstel sönen, tizleri kısılmış gürültü
function reverbIR() {
  const sr = ac.sampleRate, len = Math.floor(sr * 0.9), pre = Math.floor(sr * 0.012);
  const ir = ac.createBuffer(2, len, sr);
  for (let ch = 0; ch < 2; ch++) {
    const d = ir.getChannelData(ch);
    let lp = 0;
    for (let i = pre; i < len; i++) {
      const t = (i - pre) / sr;
      lp += ((Math.random() * 2 - 1) - lp) * 0.35;
      d[i] = lp * Math.exp(-t / 0.22);
    }
  }
  return ir;
}

function ensure() {
  if (ac) return;
  const AC = window.AudioContext || window.webkitAudioContext;
  if (!AC) return;
  ac = new AC();
  // Yumuşak sınırlayıcı: üst üste binen seslerde patlamayı önler, pompalamaz
  const lim = ac.createDynamicsCompressor();
  lim.threshold.value = -4;
  lim.knee.value = 2;
  lim.ratio.value = 12;
  lim.attack.value = 0.002;
  lim.release.value = 0.12;
  lim.connect(ac.destination);
  sfxBus = ac.createGain();
  sfxBus.gain.value = sfxOn ? SFX_VOL : 0;
  sfxBus.connect(lim);
  const verb = ac.createConvolver();
  verb.buffer = reverbIR();
  const wet = ac.createGain();
  wet.gain.value = 0.06;
  sfxBus.connect(verb).connect(wet).connect(lim);
  musicBus = ac.createGain();
  musicBus.gain.value = musicOn ? MUSIC_VOL : 0;
  musicBus.connect(lim);
  load();
}

function startMusic(intro = false) {
  if (!ac || musicSrc || !buf.muzik) return;
  musicSrc = ac.createBufferSource();
  musicSrc.buffer = buf.muzik;
  musicSrc.loop = true;
  // Baştaki ve sondaki sessizliği atla ki döngüde boşluk olmasın
  const d = buf.muzik.getChannelData(0), sr = buf.muzik.sampleRate;
  let a = 0, b = d.length - 1;
  while (a < d.length && Math.abs(d[a]) < 0.01) a++;
  while (b > a && Math.abs(d[b]) < 0.01) b--;
  musicSrc.loopStart = a / sr;
  musicSrc.loopEnd = (b + 1) / sr;
  const now = ac.currentTime;
  let out = musicBus;
  if (intro) {
    // Açılış geçişi: müzik boğuk başlar, filtre açılarak tam parlaklığa çıkar
    const lp = ac.createBiquadFilter();
    lp.type = 'lowpass';
    lp.Q.value = 0.6;
    lp.frequency.setValueAtTime(380, now);
    lp.frequency.exponentialRampToValueAtTime(18000, now + 3.2);
    lp.connect(musicBus);
    out = lp;
  }
  musicSrc.connect(out);
  musicSrc.start(now, musicSrc.loopStart);
  // Eşit güç eğrisiyle yumuşak açılış (doğrusal artıştan daha doğal duyulur)
  const len = intro ? 3.0 : 1.6, target = musicOn ? MUSIC_VOL : 0;
  musicBus.gain.cancelScheduledValues(now);
  musicBus.gain.setValueAtTime(0, now);
  for (let i = 1; i <= 12; i++) musicBus.gain.linearRampToValueAtTime(target * Math.sin((i / 12) * Math.PI / 2), now + (len * i) / 12);
}
// Planlanmış ses değişikliklerini iptal edip yeni hedefe yumuşakça git
function musicTo(v, tc) {
  const now = ac.currentTime;
  musicBus.gain.cancelScheduledValues(now);
  musicBus.gain.setValueAtTime(musicBus.gain.value, now);
  musicBus.gain.setTargetAtTime(v, now, tc);
}
let introMusic = false; // müzik açılış çanına bağlanarak planlandı mı

function play(name, { vol = 1, rate = 1, delay = 0 } = {}) {
  if (window.__sfxLog && sfxOn) window.__sfxLog.push({ n: name, vol, rate, t: performance.now() + delay * 1000 });   // tanıtım videosu kaydı
  if (!ac || !sfxOn || !buf[name]) return;
  const s = ac.createBufferSource();
  s.buffer = buf[name];
  s.playbackRate.value = rate;
  const g = ac.createGain();
  g.gain.value = vol;
  s.connect(g).connect(sfxBus);
  s.start(ac.currentTime + delay);
}

// Süre gerilimi: sentezlenmiş kalp atışı ve saat tik-takı (dosya gerekmez)
function thump(at, f0, vol) {
  const o = ac.createOscillator(), g = ac.createGain(), lp = ac.createBiquadFilter();
  o.type = 'sine';
  o.frequency.setValueAtTime(f0, at);
  o.frequency.exponentialRampToValueAtTime(f0 * 0.55, at + 0.14);
  lp.type = 'lowpass'; lp.frequency.value = 260;
  g.gain.setValueAtTime(0.0001, at);
  g.gain.exponentialRampToValueAtTime(vol, at + 0.012);
  g.gain.exponentialRampToValueAtTime(0.0001, at + 0.22);
  o.connect(lp).connect(g).connect(sfxBus);
  o.start(at); o.stop(at + 0.25);
}
function click(at, f, vol) {
  const o = ac.createOscillator(), g = ac.createGain(), bp = ac.createBiquadFilter();
  o.type = 'triangle'; o.frequency.value = f;
  bp.type = 'bandpass'; bp.frequency.value = f; bp.Q.value = 6;
  g.gain.setValueAtTime(0.0001, at);
  g.gain.exponentialRampToValueAtTime(vol, at + 0.002);
  g.gain.exponentialRampToValueAtTime(0.0001, at + 0.05);
  o.connect(bp).connect(g).connect(sfxBus);
  o.start(at); o.stop(at + 0.06);
}
let tensionK = 0;
export const Sound = {
  // Süre azaldıkça: kalp atışı (lub-dub) yükselir, saat tik-tak eder, müzik hızlanıp tizleşir
  heartbeat(k = 0.5) {
    if (!ac || !sfxOn) return;
    const t = ac.currentTime + 0.01, v = 0.35 + 0.55 * k;
    thump(t, 95, v); thump(t + 0.17, 80, v * 0.7);
  },
  tick(tock = false, urgent = false) {
    if (!ac || !sfxOn) return;
    const t = ac.currentTime + 0.01;
    click(t, tock ? 1250 : 1750, urgent ? 0.55 : 0.32);
    click(t + 0.004, tock ? 2500 : 3500, urgent ? 0.18 : 0.1);
  },
  tension(k) {
    k = Math.max(0, Math.min(1, k));
    if (Math.abs(k - tensionK) < 0.02 && k !== 0) return;
    tensionK = k;
    if (musicSrc) musicSrc.playbackRate.setTargetAtTime(1 + 0.12 * k, ac.currentTime, 0.4);
  },
  // İlk dokunuşta ses motorunu başlat (tarayıcı ve iOS kuralı)
  unlock() {
    ensure();
    if (ac && ac.state === 'suspended') ac.resume();
  },
  suspend() { if (ac && ac.state === 'running') ac.suspend(); },
  resume() { if (ac && ac.state === 'suspended') ac.resume(); },
  get sfxOn() { return sfxOn; },
  get musicOn() { return musicOn; },
  toggleSfx() {
    sfxOn = !sfxOn;
    Store.set('sfx', sfxOn ? '1' : '0');
    if (sfxBus) sfxBus.gain.value = sfxOn ? SFX_VOL : 0;
    return sfxOn;
  },
  toggleMusic() {
    musicOn = !musicOn;
    Store.set('music', musicOn ? '1' : '0');
    if (musicBus) musicTo(musicOn ? MUSIC_VOL : 0, 0.15);
    if (musicOn) { musicAllowed = true; startMusic(); }
    return musicOn;
  },
  // Açılış efekti bittikten sonra müzik başlar (müzik açıksa)
  allowMusic() {
    musicAllowed = true;
    if (ac && musicOn && !introMusic) startMusic(true);
  },
  // Açılış: parçalar uçarken yükselen çok hafif, havadar bir süpürme (çan anında zirve yapar)
  introRise(sec) {
    if (!ac || !sfxOn) return;
    const now = ac.currentTime, sr = ac.sampleRate;
    const nb = ac.createBuffer(1, Math.floor(sr * (sec + 0.6)), sr);
    const d = nb.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = Math.random() * 2 - 1;
    const src = ac.createBufferSource();
    src.buffer = nb;
    const bp = ac.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.value = 1.4;
    bp.frequency.setValueAtTime(350, now);
    bp.frequency.exponentialRampToValueAtTime(5200, now + sec);
    const g = ac.createGain();
    g.gain.setValueAtTime(0.0001, now);
    g.gain.exponentialRampToValueAtTime(0.05, now + sec);
    g.gain.exponentialRampToValueAtTime(0.0001, now + sec + 0.5);
    src.connect(bp).connect(g).connect(sfxBus);
    src.start(now);
    src.stop(now + sec + 0.6);
  },
  // Açılış: logo parçaları oturdukça yükselen yumuşak pop'lar, logo tamamlanınca parıltılı çan
  introPiece(i) { play('sd_koy', { vol: 0.42, rate: semi([0, 2, 4, 7, 9, 12][i % 6] + (i >= 6 ? 2 : 0)) }); },
  introDone() {
    play('sd_tertemiz', { vol: 0.45 });
    play('sd_yildiz', { vol: 0.28, rate: semi(7), delay: 0.08 });
    // Müzik çanın kuyruğunun içinden, boğuktan açılarak girer (arada sessizlik kalmaz)
    if (!ac || !musicOn) return;
    introMusic = true;
    setTimeout(() => { musicAllowed = true; startMusic(true); }, 420);
  },
  // Popup açıkken müziği kıs
  duck(on) { ducked = on; if (musicBus && musicOn && musicSrc) musicTo(on ? MUSIC_VOL * 0.4 : MUSIC_VOL, 0.2); },

  pickup() { play('sd_koy', { vol: 0.38, rate: 1.35 * vary(0.02) }); },   // bırakmayla aynı ahşap ses, daha ince ve kısık
  back() { play('sd_geri', { vol: 0.5 }); },
  place() { play('sd_koy', { vol: 0.8, rate: vary(0.03) }); },
  // Satır patlaması: tek patlama sesi; kombo yükseldikçe hafifçe tizleşir, çok satırda biraz daha dolgun
  clear(lines, combo) {
    const step = CLEAR_STEPS[Math.min(Math.max(combo, 1) - 1, CLEAR_STEPS.length - 1)];
    play('sd_patla', { vol: Math.min(0.95, 0.75 + (lines - 1) * 0.08), rate: semi(step) });
  },
  pop() {},
  gem(i = 0) { play('sd_elmas', { vol: 0.5, rate: semi(STEPS[i % STEPS.length]) }); },
  // Ödül sesi yalnız büyük anlarda (3+ satır, rekor); 2 satırda akor yeterli
  praise(big) { if (big) play('sd_odul', { vol: 0.55 }); },
  perfect() { play('sd_tertemiz', { vol: 0.6 }); },
  deal() { play('sd_dagit', { vol: 0.3, rate: vary(0.03) }); },
  star(i) { play('sd_yildiz', { vol: 0.6, rate: semi([0, 4, 7][i] ?? 0) }); },
  win() { play('sd_kazan', { vol: 0.7 }); },
  lose() { play('sd_kaybet', { vol: 0.65 }); },
  // Bölüm başı: "yeni bölüm" sesi bir kez (özel bölümde sonuna çan eklenir: fallStart)
  start() { play('sd_dusen', { vol: 0.3 }); },   // giriş sesleri kayıtta gür: ayrıca kısık
  // Düşen blok bölümü açılışı: kendi giriş sesi; müzik o sırada kısılır
  fallStart() {
    // Normal bölümdeki "yeni bölüm" sesi bir kez + sonunda yumuşak çan (özel bölüm olduğu sesten anlaşılsın)
    play('sd_dusen', { vol: 0.45 });
    play('sd_tertemiz', { vol: 0.22, delay: 0.38 });
    if (musicBus && musicOn && musicSrc) { musicTo(MUSIC_VOL * 0.35, 0.15); setTimeout(() => { if (musicBus && musicOn && musicSrc) musicTo(ducked ? MUSIC_VOL * 0.4 : MUSIC_VOL, 0.6); }, 1750); }
  },
  click() { play('sd_tik', { vol: 0.32, rate: vary(0.02) }); },
  // Güçlendiriciler ve ödüller
  hammer() { play('sd_koy', { vol: 1, rate: 0.62 }); play('sd_geri', { vol: 0.5, rate: 0.8, delay: 0.02 }); },
  bomb() {
    play('sd_koy', { vol: 1, rate: 0.5 });
    play('sd_nota', { vol: 0.7, rate: semi(-12) });
    play('sd_patla', { vol: 0.45, rate: semi(-8), delay: 0.02 });
    play('sd_nota', { vol: 0.45, rate: semi(-5), delay: 0.06 });
  },
  // Nişangâh bir hücre kaydığında çok hafif tık; bomba yere oturunca tok ses
  aim() { play('sd_tik', { vol: 0.12, rate: 1.35 }); },
  land() { play('sd_koy', { vol: 0.7, rate: 0.62 }); },
  // Yenile: yükselen üç hafif ses (girdap)
  shuffle() { [0.85, 1, 1.18].forEach((r, i) => play('sd_al', { vol: 0.45 - i * 0.06, rate: r, delay: i * 0.07 })); },
  // Engel kırılması: buz tiz ve cam gibi, zincir tok ve metalik
  crumble() { play('sd_ufalan', { vol: 0.8, rate: vary(0.05) }); },   // Blok Kaçışı: blok kapıdan ufalanarak çıkar
  crack(ice) { play('sd_koy', { vol: 0.7, rate: ice ? 1.55 : 0.75 }); play('sd_tik', { vol: 0.45, rate: ice ? 1.8 : 0.7, delay: 0.02 }); },
  fire() { play('sd_ates', { vol: 0.6 }); },
  coin() { play('sd_elmas', { vol: 0.45, rate: semi(7) }); },
  chest() { play('sd_tertemiz', { vol: 0.6 }); play('sd_odul', { vol: 0.45, delay: 0.1 }); },
  confirm() { play('sd_tik', { vol: 0.3, rate: 1.1 }); },
};
