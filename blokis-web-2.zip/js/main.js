// Blok Ustası: 8×8 tahtaya parçaları sürükle, dolan satır ve sütunları patlat.
// İki mod: Bölümler (tahtadaki simgeleri topla) ve Sonsuz (en yüksek skor).
import { Application, Container, Sprite, Texture, Text, Rectangle, Graphics, BlurFilter, FillGradient, DisplacementFilter, RenderTexture } from '../lib/pixi.min.mjs';
import { renderTile, renderWood, renderRoyal, renderIcon, BASE, WORLDS, WORLD_SIZE, worldOf, worldIndex, paintScene, renderIce, renderChain, renderBombBlock, renderMoss, renderCage, renderNeed, renderDirt, renderTreasure, TREASURE, renderPower, renderRocket, renderTimerBomb, renderSymbolTile } from './tiles.js';
import { getLevel, getDaily, isSpecial, isSuperHard, isFalling, getFalling, isEscape, getEscape, TOTAL_LEVELS } from './levels.js';
import { tween, wait, Ease, updateTweens, killTweens, killTweenProp, shiftTweens } from './tween.js';
import { Store, Haptics, GameCenter, LB, RANK_PLATFORM } from './platform.js';
import { Ads } from './ads.js';
import { Notify } from './notify.js';
import { createFire } from './fire.js';
import { BOOSTERS, Wallet, DAILY, dailyState, claimDaily, CHEST_EVERY, levelCoins, openChest, Missions, MISSION_REWARD, DailyPuzzle, Lives, LIVES_MAX, Profile, AVATARS, Build } from './economy.js';
import { createIsland, BUILDINGS, BUILD_STEPS } from './island.js';
import { Sound } from './audio.js';
import { basla as canliGuncelleme } from './guncelle.js';
import { DIRS, initState as escInit, applyStep as escApplyStep, removeBlocks as escRemoveBlocks, shuffleColors as escShuffleColors } from './escape.js';

const $ = (id) => document.getElementById(id);
// Android'de ekran kartları zayıf olabiliyor: 3x ekranda (Redmi vb.) tuval 3,3 milyon piksel oluyordu.
// 2x'te fark gözle seçilmez, çizim yükü ~yarıya iner; kenar yumuşatma (MSAA) da Android'de kapalı.
const ANDROID = /Android/i.test(navigator.userAgent);
const DPR = Math.min(window.devicePixelRatio || 1, ANDROID ? 2 : 3);
const N = 8;
const ICON_KINDS = ['gem', 'star', 'heart', 'crown'];
// Sonsuz mod paleti: canlı ama birbiriyle uyumlu renkler
const PALETTE = ['#ff4757', '#ff8c1a', '#ffcf1a', '#2ed573', '#1e90ff', '#a55eea', '#17d1e6'];
// Renkli bloklar: desendeki '1' kırmızı, '2' mavi, '3' sarı; yalnız aynı renk parçayla patlar
const NEED_COLOR = { 1: 'c0', 2: 'c4', 3: 'c2' };
const colorHex = {};

const app = new Application();
// Tuval saydam açılır: Blok Kaçışı'nda 3D sahne bu tuvalin altında çizilir (normal ekranlarda arka plan katmanı her yeri kaplar)
// Temizleme rengi tam saydam siyah olmalı: iPhone'da saydam ama renkli temizleme alttaki 3D sahneye pus gibi biner (renkler solar)
await app.init({ preference: 'webgl', resizeTo: window, antialias: !ANDROID, resolution: DPR, autoDensity: true, backgroundColor: 0x000000, backgroundAlpha: 0 });
$('stage').appendChild(app.canvas);

// ---------- Parçalar ----------
function rotate(cells) {
  const maxY = Math.max(...cells.map((c) => c[1]));
  return norm(cells.map(([x, y]) => [maxY - y, x]));
}
function norm(cells) {
  const mx = Math.min(...cells.map((c) => c[0])), my = Math.min(...cells.map((c) => c[1]));
  return cells.map(([x, y]) => [x - mx, y - my]);
}
function rotations(cells, n = 4) {
  const out = [cells];
  for (let i = 1; i < n; i++) out.push(rotate(out[i - 1]));
  return out;
}
const rect = (w, h) => { const c = []; for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) c.push([x, y]); return c; };
const SHAPES = [];
const add = (cells, w) => SHAPES.push({ cells, w, n: cells.length });
add([[0, 0]], 1.5);
add(rect(2, 1), 2.5); add(rect(1, 2), 2.5);
add(rect(3, 1), 2.5); add(rect(1, 3), 2.5);
add(rect(4, 1), 1.6); add(rect(1, 4), 1.6);
add(rect(5, 1), 0.9); add(rect(1, 5), 0.9);
add(rect(2, 2), 3);
add(rect(3, 3), 1);
add(rect(3, 2), 1.2); add(rect(2, 3), 1.2);
for (const r of rotations([[0, 0], [0, 1], [1, 1]])) add(r, 1);
for (const r of rotations([[0, 0], [0, 1], [0, 2], [1, 2], [2, 2]])) add(r, 0.6);
for (const r of rotations([[0, 0], [0, 1], [0, 2], [1, 2]])) add(r, 0.5);
for (const r of rotations([[1, 0], [1, 1], [1, 2], [0, 2]])) add(r, 0.5);
for (const r of rotations([[0, 0], [1, 0], [2, 0], [1, 1]])) add(r, 0.6);
for (const r of rotations([[1, 0], [2, 0], [0, 1], [1, 1]], 2)) add(r, 0.6);
for (const r of rotations([[0, 0], [1, 0], [1, 1], [2, 1]], 2)) add(r, 0.6);
const TOTAL_W = SHAPES.reduce((s, x) => s + x.w, 0);
function randomShape() {
  let r = Math.random() * TOTAL_W;
  for (const s of SHAPES) { r -= s.w; if (r <= 0) return s; }
  return SHAPES[0];
}
const size = (cells) => [Math.max(...cells.map((c) => c[0])) + 1, Math.max(...cells.map((c) => c[1])) + 1];

// ---------- Durum ----------
let mode = 'endless';           // 'endless' | 'level'
let theme = BASE;
let runId = 0;                  // her yeni oyun/bölümde artar; gecikmeli pencereler eski tura aitse açılmaz
let placed = 0;                 // bu oyunda yerleştirilen parça sayısı
let levelN = 0, L = null;
let goals = [];                 // [{ icon, left, shown }]
let unlocked = Store.num('level', 0);
const starsOf = (n) => Store.num('stars_' + n, 0);
let grid = Array.from({ length: N }, () => Array(N).fill(null)); // açılıştan itibaren hazır
let tray = [null, null, null];
let score = 0, shownScore = 0;
let best = Store.num('best', 0);
let combo = 0, sinceClear = 0, streak = 0; // streak: art arda satır patlatan hamle sayısı
let revived = false;
let bdDone = null;                // inşa bitti penceresi bekleniyor: hangi yoldan kapanırsa kapansın (Tamam, perde, geri) akış biter
let coinsPaid = 0;                // sonsuz oyunda bu oyun için ödenmiş altın (devamdan sonra aynı puan iki kez ödenmez)
let paidRevives = 0;              // bu bölümde altınla kaç kez devam edildi (fiyat artar)
let over = false;
let busy = false;
let gamesPlayed = 0;
let gemCount = 0;

// ---------- Yerleşim ve dokular ----------
let W, H, safeT, safeB, cell, BX, BY, trayY;
const treasureTex = {};
let rocketTex = null;
const powerIconTex = {};
let tex = {}, flameTex, glowTex, sparkTex, beamTex, ringTex, iconTex = {};
let shardTex = {};
let puffTex; // patlama alevi ve duman için dolgun, yumuşak kenarlı bulut
let themeHex = 0x3d5be0;
const iconURL = {};
const bg = new Container();
const boardLayer = new Container();
const digLayer = new Container();   // hazine kazısı: toprak zemin ve gömülü hazineler (blokların altında)
const blockLayer = new Container();
const iconLayer = new Container();
const ghostLayer = new Container();
const hintLayer = new Container();   // neredeyse dolan satır/sütun parıltısı (blokların üstünde, simgelerin altında)
const trayLayer = new Container();
const dragLayer = new Container();
const fx = new Container();
const ovLayer = new Container(); // engel kaplamaları (buz, zincir, bomba sayacı)
const fireLayer = new Container(); // ateş modunun alevleri (gürültüyle bükülür)
app.stage.addChild(bg, boardLayer, digLayer, ghostLayer, blockLayer, ovLayer, hintLayer, iconLayer, fireLayer, trayLayer, dragLayer, fx);
// Kombo ateşi: gölgelendiriciyle çizilen kesintisiz alev çemberi (ayrı katmanda, sıfırlamada silinmez)
const fireShaderLayer = new Container();
app.stage.addChildAt(fireShaderLayer, app.stage.getChildIndex(fireLayer));
let fireFx = null, fireLevel = 0, fireIgnite = 1, firePulse = 0, fireHeat = 0, fireCombo = 0;
try { fireFx = createFire(); fireShaderLayer.addChild(fireFx.mesh); } catch (e) { console.warn('Ateş gölgelendiricisi açılamadı', e); }

function measure() {
  W = window.innerWidth;
  H = window.innerHeight;
  const cs = getComputedStyle($('safeProbe'));
  safeT = parseFloat(cs.paddingTop) || 0;
  safeB = parseFloat(cs.paddingBottom) || 0;
  BY = Math.round(safeT + 146); // üst bilgi alanı en fazla safeT+130 yer kaplar
  const boardSize = Math.min(W - 28, (H - safeT - safeB) * 0.56, H - safeB - BY - BAR_H - 150);
  cell = Math.max(20, Math.floor(boardSize / N));
  BX = Math.round((W - N * cell) / 2);
  placeTray();
}
// Bölüm modunda altta güçlendirici çubuğu var; parçalar tahta ile çubuk arasında ortalanır
const BAR_H = 104;
function placeTray() {
  const boardBottom = BY + N * cell;
  const bottom = H - safeB - (mode === 'level' ? BAR_H : 0);
  trayY = boardBottom + (bottom - boardBottom) / 2;
}

function glowCanvas(S) {
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const x = c.getContext('2d');
  const g = x.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.3, 'rgba(255,255,255,0.5)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g;
  x.fillRect(0, 0, S, S);
  return c;
}
function puffCanvas(S) {
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const x = c.getContext('2d');
  const g = x.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
  g.addColorStop(0, 'rgba(255,255,255,1)');
  g.addColorStop(0.5, 'rgba(255,255,255,0.88)');
  g.addColorStop(0.78, 'rgba(255,255,255,0.35)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g;
  x.fillRect(0, 0, S, S);
  return c;
}
// Alev: sarı çekirdekli, kırmızıya sönen damla biçimi (taban alttadır)
function flameCanvas() {
  const W = 64, H = 96, c = document.createElement('canvas');
  c.width = W; c.height = H;
  const x = c.getContext('2d');
  x.filter = 'blur(1.5px)';
  x.beginPath();
  x.moveTo(32, 5);
  x.bezierCurveTo(44, 30, 58, 48, 52, 68);
  x.bezierCurveTo(48, 86, 38, 92, 32, 92);
  x.bezierCurveTo(26, 92, 16, 86, 12, 68);
  x.bezierCurveTo(6, 48, 20, 30, 32, 5);
  x.closePath();
  const g = x.createRadialGradient(32, 70, 0, 32, 64, 50);
  g.addColorStop(0, 'rgba(255,255,225,1)');
  g.addColorStop(0.22, 'rgba(255,226,100,0.98)');
  g.addColorStop(0.5, 'rgba(255,128,30,0.85)');
  g.addColorStop(1, 'rgba(210,30,10,0)');
  x.fillStyle = g;
  x.fill();
  return c;
}
function sparkCanvas(S) {
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const x = c.getContext('2d');
  x.translate(S / 2, S / 2);
  x.fillStyle = '#fff';
  x.beginPath();
  for (let i = 0; i < 8; i++) {
    const r = i % 2 ? S * 0.1 : S * 0.5, a = (i / 8) * Math.PI * 2;
    x.lineTo(Math.cos(a) * r, Math.sin(a) * r);
  }
  x.fill();
  return c;
}
function ringCanvas(S) {
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const x = c.getContext('2d');
  x.filter = `blur(${S * 0.02}px)`;
  x.strokeStyle = '#ffffff';
  x.lineWidth = S * 0.05;
  x.beginPath(); x.arc(S / 2, S / 2, S * 0.43, 0, Math.PI * 2); x.stroke();
  return c;
}

// Bir bloğun dört çeyrek parçası (parçalanma animasyonu için)
function shards(key) {
  if (shardTex[key]) return shardTex[key];
  const t = tex[key], w = t.source.width / 2, h = t.source.height / 2;
  shardTex[key] = [[0, 0], [w, 0], [0, h], [w, h]].map(([x, y]) => new Texture({ source: t.source, frame: new Rectangle(x, y, w, h) }));
  return shardTex[key];
}

function beamCanvas() {
  const c = document.createElement('canvas');
  c.width = 8; c.height = 64;
  const x = c.getContext('2d');
  const g = x.createLinearGradient(0, 0, 0, 64);
  g.addColorStop(0, 'rgba(255,255,255,0)');
  g.addColorStop(0.5, 'rgba(255,255,255,1)');
  g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g;
  x.fillRect(0, 0, 8, 64);
  return c;
}

// İki rengi karıştır (önizleme için açık ton)
function mixHex(a, b, t) {
  const p = (h, i) => parseInt(h.slice(1 + i * 2, 3 + i * 2), 16);
  return '#' + [0, 1, 2].map((i) => Math.round(p(a, i) + (p(b, i) - p(a, i)) * t).toString(16).padStart(2, '0')).join('');
}

// Performans: bölüm girişinde her şeyi yeniden çizmek telefonda takılmaya yol açıyordu. Temaya bağlı olmayan
// dokular yalnız kare boyu değişince üretilir; tema rengine bağlı olanlar (block, hi) renge göre saklanır.
let texS = 0;
const themeTex = new Map();
function buildTextures() {
  const S = Math.round(cell * DPR);
  if (S === texS) { setThemeTextures(S); return; }
  texS = S;
  themeTex.clear();
  tex = {
    grey: Texture.from(renderTile('#6b6f80', S)),
    wood: Texture.from(renderWood(S)),
    white: Texture.from(renderTile('#ffffff', S)),
  };
  PALETTE.forEach((c, i) => { tex['c' + i] = Texture.from(renderTile(c, S)); colorHex['c' + i] = parseInt(c.slice(1), 16); });
  themeHex = parseInt(theme.block.slice(1), 16);
  colorHex.block = colorHex.hi = themeHex;
  colorHex.wood = 0xd8a466;
  tex.iceOv = Texture.from(renderIce(S));
  tex.iceCrack = Texture.from(renderIce(S, true));
  tex.chain2 = Texture.from(renderChain(S, 2));
  tex.chain1 = Texture.from(renderChain(S, 1));
  tex.bomb = Texture.from(renderTimerBomb(S, null));
  tex.moss = Texture.from(renderMoss(S));
  tex.cage = Texture.from(renderCage(S));
  colorHex.moss = 0x5fbf4a;
  for (const k of Object.values(NEED_COLOR)) { tex['need_' + k] = Texture.from(renderNeed(PALETTE[+k.slice(1)], S)); colorHex['need_' + k] = colorHex[k]; }
  tex.royal = Texture.from(renderRoyal(S));
  colorHex.royal = 0xb44cff;
  colorHex.bomb = 0xff8a2a;
  shardTex = {};
  ringTex = Texture.from(ringCanvas(256));
  glowTex = Texture.from(glowCanvas(128));
  puffTex = Texture.from(puffCanvas(128));
  flameTex = Texture.from(flameCanvas());
  sparkTex = Texture.from(sparkCanvas(64));
  beamTex = Texture.from(beamCanvas());
  for (const k of ICON_KINDS) {
    iconTex[k] = Texture.from(renderIcon(k, S));
    iconURL[k] = renderIcon(k, 120).toDataURL();
  }
  iconURL.line = lineIconCanvas(120).toDataURL();
  for (let i = 0; i < 3; i++) for (const n of [1, 2]) tex[`dirt${n}_${i}`] = Texture.from(renderDirt(S, n, i + 1));
  colorHex.dirt = 0xc18a45;
  for (const [k, hx] of [['rocket', 0x3a8cff], ['bomb', 0xff7a2a], ['bolt', 0xa85cff], ['prop', 0x2ee07a]]) { tex['pw_' + k] = Texture.from(renderPower(k, S, 'tile')); powerIconTex[k] = Texture.from(renderPower(k, S, 'icon')); colorHex['pw_' + k] = hx; }
  rocketTex = Texture.from(renderRocket(S));
  // Joker (çılgınlık parçası): gökkuşağı blok, her renkle birleşir
  {
    const cv = renderTile('#ffffff', S), x = cv.getContext('2d');
    const g = x.createLinearGradient(0, 0, S, S);
    ['#ff4757', '#ff8c1a', '#ffcf1a', '#2ed573', '#1e90ff', '#a55eea'].forEach((c, i, a) => g.addColorStop(i / (a.length - 1), c));
    x.globalCompositeOperation = 'multiply'; x.fillStyle = g; x.fillRect(0, 0, S, S);
    x.globalCompositeOperation = 'destination-in'; x.drawImage(renderTile('#ffffff', S), 0, 0);
    x.globalCompositeOperation = 'source-over'; x.fillStyle = 'rgba(255,255,255,0.95)';
    x.beginPath(); for (let i = 0; i < 10; i++) { const a = (i / 10) * Math.PI * 2 - Math.PI / 2, r = i % 2 ? S * 0.11 : S * 0.26; x.lineTo(S / 2 + Math.cos(a) * r, S / 2 + Math.sin(a) * r); } x.closePath(); x.fill();
    tex.joker = Texture.from(cv);
    colorHex.joker = 0xffffff;
  }
  for (const k of Object.keys(TREASURE)) {
    treasureTex[k] = Texture.from(renderTreasure(k, S, 'item'));
    treasureTex[k + '_hole'] = Texture.from(renderTreasure(k, S, 'hole'));
    iconURL['t_' + k] ??= renderTreasure(k, 120, 'icon').toDataURL();
  }
  setThemeTextures(S);
}
function setThemeTextures(S) {
  let t = themeTex.get(theme.block);
  if (!t) {
    t = { block: Texture.from(renderTile(theme.block, S)), hi: Texture.from(renderTile(mixHex(theme.block, '#ffffff', 0.38), S)) };
    themeTex.set(theme.block, t);
  }
  tex.block = t.block; tex.hi = t.hi;
  delete shardTex.block; delete shardTex.hi;   // parçalanma dokuları temanın rengine göre yeniden kesilsin
  themeHex = parseInt(theme.block.slice(1), 16);
  colorHex.block = colorHex.hi = themeHex;
}

function applyTheme(t) {
  theme = t;
  buildTextures();
  buildBackground();
  buildBoard();
  document.documentElement.style.setProperty('--bg', t.bg[0]);
  document.body.style.background = t.bg[1];
}

// Arka plan: temanın düz renk geçişi
let bokeh = [];
const bgCache = new Map();
function buildBackground() {
  bg.removeChildren();
  const key = [theme.bg[0], theme.bg[1], theme.block, theme.special ? 1 : 0, W, H, BY, cell, DPR].join('|');
  let t = bgCache.get(key);
  if (!t) { t = Texture.from(bgCanvas()); bgCache.set(key, t); }
  const sp = new Sprite(t);
  sp.width = W; sp.height = H;
  bg.addChild(sp);
  bokeh = [];
}
function bgCanvas() {
  const c = document.createElement('canvas');
  const k = 0.5;
  const cw = (c.width = Math.ceil(W * DPR * k)), ch = (c.height = Math.ceil(H * DPR * k));
  const x = c.getContext('2d');
  // Sade ve temiz: dünyanın renginde koyu geçiş, tahtanın arkasında hafif renkli ışıma,
  // üstte yumuşak ışık, kenarlarda kararma. Siluet yok (manzaralar haritada).
  const g = x.createLinearGradient(0, 0, 0, ch);
  // Dünyanın açık çerçeve renginden kendi rengine inen ferah geçiş (tahta koyu kaldığı için bloklar net)
  const fr = theme.frame || theme.bg[0];
  g.addColorStop(0, mixHex(fr, '#ffffff', 0.16));
  g.addColorStop(0.55, mixHex(fr, theme.bg[0], 0.35));
  g.addColorStop(1, theme.bg[0]);
  x.fillStyle = g;
  x.fillRect(0, 0, cw, ch);
  const by = ((BY + (N * cell) / 2) / H) * ch;
  const hg = x.createRadialGradient(cw / 2, by, 0, cw / 2, by, Math.max(cw, ch) * 0.62);
  const bc = hexToRgbStr(theme.block);
  hg.addColorStop(0, `rgba(${bc},0.16)`); hg.addColorStop(0.55, `rgba(${bc},0.05)`); hg.addColorStop(1, `rgba(${bc},0)`);
  x.fillStyle = hg;
  x.fillRect(0, 0, cw, ch);
  const lg = x.createRadialGradient(cw / 2, 0, 0, cw / 2, 0, cw * 0.95);
  lg.addColorStop(0, theme.special ? 'rgba(255,200,60,0.3)' : 'rgba(255,255,255,0.08)');
  lg.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = lg;
  x.fillRect(0, 0, cw, ch);
  const vg = x.createRadialGradient(cw / 2, ch * 0.45, Math.min(cw, ch) * 0.4, cw / 2, ch * 0.45, Math.max(cw, ch) * 0.78);
  vg.addColorStop(0, 'rgba(0,0,0,0)');
  vg.addColorStop(1, 'rgba(0,0,0,0.42)');
  x.fillStyle = vg;
  x.fillRect(0, 0, cw, ch);
  // İnce gren: geçişlerde bantlaşma olmasın
  const img = x.getImageData(0, 0, cw, ch), d = img.data;
  for (let i = 0; i < d.length; i += 4) { const n = (Math.random() - 0.5) * 6; d[i] += n; d[i + 1] += n; d[i + 2] += n; }
  x.putImageData(img, 0, 0);
  return c;
}
const hexToRgbStr = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16)).join(',');

// Tahta: koyu zemin, ince ızgara çizgileri, açık renkli çerçeve
const boardCache = new Map();
function buildBoard() {
  boardLayer.removeChildren();
  const pad = Math.max(3, Math.round(cell * 0.06));
  const pw = N * cell + pad * 2, ph = N * cell + pad * 2;
  const bkey = [theme.board, theme.frame, theme.line, cell, DPR].join('|');
  let bt = boardCache.get(bkey);
  if (!bt) { bt = Texture.from(boardCanvas(pad, pw, ph)); boardCache.set(bkey, bt); }
  const s = new Sprite(bt);
  s.scale.set(1 / DPR);
  s.position.set(BX - pad - 20, BY - pad - 20);
  boardLayer.addChild(s);
  // Çerçeve parıltısı: patlamada parlar, kombo sürerken nabız gibi atar (beyaz; renk tint ile verilir)
  const m = 36;
  const gkey = [pw, ph, DPR].join('|');
  let gt = boardCache.get(gkey);
  if (!gt) { gt = Texture.from(auraCanvas(m, pw, ph)); boardCache.set(gkey, gt); }
  if (fireFx) fireFx.layout(BX, BY, N * cell, cell);
  aura = new Sprite(gt);
  aura.scale.set(1 / DPR);
  aura.position.set(BX - pad - m, BY - pad - m);
  aura.blendMode = 'add';
  aura.alpha = 0;
  boardLayer.addChild(aura);
}
function boardCanvas(pad, pw, ph) {
  const c = document.createElement('canvas');
  c.width = Math.ceil((pw + 40) * DPR); c.height = Math.ceil((ph + 40) * DPR);
  const x = c.getContext('2d');
  x.scale(DPR, DPR);
  x.save();
  x.filter = 'blur(10px)';
  x.fillStyle = 'rgba(0,0,0,0.3)';
  x.beginPath(); x.roundRect(20, 26, pw, ph, 10); x.fill();
  x.restore();
  x.beginPath(); x.roundRect(20, 20, pw, ph, 10);
  x.fillStyle = theme.board;
  x.fill();
  x.lineWidth = 3;
  x.strokeStyle = theme.frame;
  x.stroke();
  x.strokeStyle = theme.line;
  x.lineWidth = 2;
  for (let i = 1; i < N; i++) {
    const o = 20 + pad + i * cell;
    x.beginPath(); x.moveTo(o, 20 + pad); x.lineTo(o, 20 + pad + N * cell); x.stroke();
    x.beginPath(); x.moveTo(20 + pad, o); x.lineTo(20 + pad + N * cell, o); x.stroke();
  }
  return c;
}
function auraCanvas(m, pw, ph) {
  const gc = document.createElement('canvas');
  gc.width = Math.ceil((pw + m * 2) * DPR); gc.height = Math.ceil((ph + m * 2) * DPR);
  const gx = gc.getContext('2d');
  gx.scale(DPR, DPR);
  gx.strokeStyle = '#ffffff';
  gx.filter = 'blur(9px)';
  gx.lineWidth = 10;
  gx.beginPath(); gx.roundRect(m, m, pw, ph, 12); gx.stroke();
  gx.filter = 'blur(2px)';
  gx.lineWidth = 3;
  gx.beginPath(); gx.roundRect(m, m, pw, ph, 10); gx.stroke();
  return gc;
}
let aura = null, auraBoost = 0, auraBase = 0;
const COMBO_HEX = [0x7df0ff, 0x7df0ff, 0x5ad8ff, 0x9b7bff, 0xe86bff, 0xffb020, 0xff5a4a];
function boardFlash(color, k) {
  auraBoost = Math.min(1.2, auraBoost + k);
  if (aura && combo < 2) aura.tint = colorHex[color] ?? themeHex;
}

// ---------- Bloklar ----------
const cx = (c) => BX + c * cell + cell / 2;
const cy = (r) => BY + r * cell + cell / 2;

function blockSprite(color) {
  const s = new Sprite(tex[color]);
  s.anchor.set(0.5);
  s.width = s.height = cell;
  return s;
}

function setBlock(r, c, color, animate = true, delay = 0, icon = null, obs = null) {
  const s = blockSprite(color);
  s.position.set(cx(c), cy(r));
  blockLayer.addChild(s);
  const b = { color, s, icon: null, is: null };
  if (icon) {
    b.icon = icon;
    b.is = new Sprite(iconTex[icon]);
    b.is.anchor.set(0.5);
    b.is.width = b.is.height = cell;
    b.is.position.copyFrom(s.position);
    iconLayer.addChild(b.is);
  }
  grid[r][c] = b;
  if (obs) addObstacle(b, r, c, obs);
  if (animate === 'slam') {
    // Parça yerine oturur: hafif büyükten küçülerek "tık" diye yerleşir
    for (const sp of [s, b.is].filter(Boolean)) {
      const k = sp.scale.x;
      sp.scale.set(k * 1.22);
      tween(sp.scale, { x: k, y: k }, 0.2, Ease.outBack, delay);
    }
  } else if (animate) {
    for (const sp of [s, b.is].filter(Boolean)) {
      const k = sp.scale.x;
      sp.scale.set(k * 0.7);
      tween(sp.scale, { x: k, y: k }, 0.28, Ease.outBack, delay);
    }
  }
}

// ---------- Engeller ----------
// Buz: 1 ek vuruş (önce buz kırılır). Zincir: 2 ek vuruş (halka halka kopar).
// Bomba: sayaç her hamlede azalır; satırı patlatılmadan sıfırlanırsa bölüm kaybedilir.
function bombText(n) {
  const t = new Text({ text: String(n), style: { fontFamily: 'ui-rounded, "SF Pro Rounded", system-ui', fontWeight: '900', fontSize: Math.round(cell * 0.42), fill: '#ffffff', stroke: { color: '#14161f', width: Math.max(3, cell * 0.09), join: 'round' } } });
  t.anchor.set(0.5);
  return t;
}
function addObstacle(b, r, c, obs) {
  if (obs.kind === 'bomb') {
    b.bomb = obs.timer;
    b.tx = bombText(obs.timer);
    b.tx.position.set(cx(c), cy(r) + cell * 0.06);
    ovLayer.addChild(b.tx);
    return;
  }
  b.kind = obs.kind;
  b.hp = obs.kind === 'chain' ? 2 : 1;
  b.ov = new Sprite(obs.kind === 'ice' ? tex.iceOv : obs.kind === 'cage' ? tex.cage : tex.chain2);
  b.ov.anchor.set(0.5);
  b.ov.width = b.ov.height = cell;
  b.ov.position.set(cx(c), cy(r));
  (obs.kind === 'cage' ? iconLayer : ovLayer).addChild(b.ov);
}
// Renkli blok yalnız aynı renk parçayla patlar; güçlendirici ve devam (renk dışı) her şeyi patlatır
const colorMatches = (need, color) => color === need || !(typeof color === 'string' && (color === 'block' || /^c\d$/.test(color)));
function needReject(b) {
  const k = b.s.scale.x, x0 = b.s.x;
  tween(b.s, { x: x0 + cell * 0.08 }, 0.05).then(() => tween(b.s, { x: x0 - cell * 0.08 }, 0.07)).then(() => tween(b.s, { x: x0 }, 0.06));
  b.s.tint = 0xffd0d0;
  setTimeout(() => { b.s.tint = 0xffffff; }, 220);
  tween(b.s.scale, { x: k * 1.08, y: k * 1.08 }, 0.08).then(() => tween(b.s.scale, { x: k, y: k }, 0.2, Ease.outBack));
  Haptics.light();
}
// Yosun: satır patlatılmayan hamleden sonra yanındaki rastgele bir boş kareye yayılır
function spreadMoss() {
  const cand = [];
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    if (!grid[r][c] || !grid[r][c].moss) continue;
    for (const [dr, dc] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const rr = r + dr, cc = c + dc;
      if (rr >= 0 && cc >= 0 && rr < N && cc < N && !grid[rr][cc]) cand.push([rr, cc, r, c]);
    }
  }
  if (!cand.length) return false;
  const [r, c, fr, fc] = cand[Math.floor(Math.random() * cand.length)];
  setBlock(r, c, 'moss', false);
  const b = grid[r][c];
  b.moss = true;
  const k = b.s.scale.x;
  b.s.scale.set(k * 0.2);
  b.s.position.set(cx(fc), cy(fr));
  tween(b.s, { x: cx(c), y: cy(r) }, 0.35, Ease.outCubic);
  tween(b.s.scale, { x: k, y: k }, 0.45, Ease.outBack);
  for (let i = 0; i < 5; i++) {
    const sp = new Sprite(sparkTex);
    sp.anchor.set(0.5); sp.tint = 0x9be86a;
    sp.width = sp.height = cell * (0.12 + Math.random() * 0.1);
    sp.position.set(cx(c), cy(r));
    fx.addChild(sp);
    const a = Math.random() * Math.PI * 2, v = cell * (2 + Math.random() * 2);
    parts.push({ s: sp, vx: Math.cos(a) * v, vy: Math.sin(a) * v - cell * 2, t: 0, life: 0.45 + Math.random() * 0.2, vr: 0, k0: sp.scale.x });
  }
  Sound.pop(0, 0.15);
  Haptics.light();
  return true;
}
// Engelin üst katını kır: kıymık efekti, ses ve titreşim; blok yerinde kalır
function hitObstacle(b) {
  b.hp--;
  const x = b.s.x, y = b.s.y;
  const ice = b.kind === 'ice', cage = b.kind === 'cage';
  for (let i = 0; i < (cage ? 9 : 6); i++) {
    const sp = new Sprite(ice ? tex.iceOv : sparkTex);
    sp.anchor.set(0.5);
    sp.width = sp.height = cell * (0.16 + Math.random() * 0.14);
    sp.position.set(x, y);
    if (!ice) sp.tint = cage ? 0xffc93a : 0xc9d0dc;
    fx.addChild(sp);
    const a = Math.random() * Math.PI * 2, v = cell * (4 + Math.random() * 4);
    parts.push({ s: sp, vx: Math.cos(a) * v, vy: Math.sin(a) * v - cell * 4, t: 0, life: 0.5 + Math.random() * 0.3, vr: (Math.random() - 0.5) * 14, k0: sp.scale.x });
  }
  Sound.crack(ice);
  Haptics.light();
  if (b.hp <= 0) {
    const ov = b.ov;
    b.ov = null;
    // Kafes: çubuklar açılır gibi büyüyüp kaybolur, simge serbest kalır
    if (cage) tween(ov.scale, { x: ov.scale.x * 1.35, y: ov.scale.y * 1.35 }, 0.22, Ease.outCubic);
    tween(ov, { alpha: 0 }, cage ? 0.24 : 0.18).then(() => ov.destroy());
    if (cage && b.is) { const k2 = b.is.scale.x; b.is.scale.set(k2 * 1.3); tween(b.is.scale, { x: k2, y: k2 }, 0.35, Ease.outBack); }
  } else {
    b.ov.texture = ice ? tex.iceCrack : tex.chain1;
    const k = b.ov.scale.x;
    b.ov.scale.set(k * 1.15);
    tween(b.ov.scale, { x: k, y: k }, 0.25, Ease.outBack);
  }
  const k = b.s.scale.x;
  tween(b.s.scale, { x: k * 0.9, y: k * 0.9 }, 0.06).then(() => tween(b.s.scale, { x: k, y: k }, 0.2, Ease.outBack));
}
function dropOverlays(b) {
  if (b.glow) { const g = b.glow; b.glow = null; tween(g, { alpha: 0 }, 0.15).then(() => g.destroy()); }
  if (b.ov) { const ov = b.ov; b.ov = null; tween(ov, { alpha: 0 }, 0.15).then(() => ov.destroy()); }
  if (b.tx) { const tx = b.tx; b.tx = null; tween(tx, { alpha: 0 }, 0.15).then(() => tx.destroy()); }
}
// Her hamlede bombaların sayacı azalır; true dönerse bir bomba patladı
function tickBombs() {
  let boom = false;
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    const b = grid[r][c];
    if (!b || b.bomb === undefined) continue;
    b.bomb--;
    b.tx.text = String(Math.max(0, b.bomb));
    b.tx.style.fill = b.bomb <= 3 ? '#ff5a5a' : '#ffffff';
    const k = b.tx.scale.x;
    b.tx.scale.set(k * 1.35);
    tween(b.tx.scale, { x: k, y: k }, 0.3, Ease.outBack);
    if (b.bomb <= 3 && b.bomb > 0) Haptics.warning();
    if (b.bomb <= 0) boom = true;
  }
  return boom;
}
async function explodeBombs() {
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    const b = grid[r][c];
    if (!b || b.bomb === undefined || b.bomb > 0) continue;
    shockwave(cx(c), cy(r), 'c1', 4);
  }
  shake = 1.2;
  screenFlash(0.55);
  Sound.bomb();
  Haptics.heavy();
  await wait(0.4);
}

// ---------- Tepsi (alttaki 3 parça) ----------
function pieceView(shape, color, unit) {
  const v = new Container();
  const [w, h] = size(shape.cells);
  for (const [x, y] of shape.cells) {
    const s = blockSprite(color);
    s.width = s.height = unit;
    s.position.set((x - w / 2 + 0.5) * unit, (y - h / 2 + 0.5) * unit);
    v.addChild(s);
  }
  return v;
}

const trayScale = () => Math.min(0.58, (W / 3 - 18) / (5 * cell));
const slotX = (i) => W * (0.5 + (i - 1) * 0.31);

function makeTrayPiece(i, shape, color, fromRight = false) {
  const p = { shape, color, i };
  p.view = pieceView(shape, color, cell);
  p.view.scale.set(trayScale());
  const fromCenter = fromRight === 'center';
  p.view.position.set(fromCenter ? W / 2 : fromRight ? W + 120 + i * 60 : slotX(i), trayY);
  p.view.eventMode = 'static';
  p.view.cursor = 'pointer';
  const hw = W * 0.155 / p.view.scale.x;
  p.view.hitArea = new Rectangle(-hw, -cell * 2.2, hw * 2, cell * 4.4);
  p.view.on('pointerdown', (e) => startDrag(p, e));
  trayLayer.addChild(p.view);
  tray[i] = p;
  if (fromCenter) {
    const k = p.view.scale.x;
    p.view.scale.set(k * 0.1);
    p.view.rotation = (i - 1) * 0.9;
    tween(p.view, { x: slotX(i), rotation: 0, 'scale.x': k, 'scale.y': k }, 0.5, Ease.outBack, i * 0.06);
  } else if (fromRight) tween(p.view, { x: slotX(i) }, 0.45, Ease.outBack, i * 0.07);
  return p;
}

// Dağıtıcının rastgeleliği: normalde Math.random, günlük bulmacada tarihe göre tohumlu
let rnd = Math.random;
const seededRnd = (seed) => { let s = seed % 233280; return () => (s = (s * 9301 + 49297) % 233280) / 233280; };

// ---------- Akıllı dağıtıcı ----------
// Üç parçanın üçü de (bir sırayla) tahtaya yerleştirilebilmeli. Bölümlerde satır açan, özellikle
// hedef simgeli satırları açan üçlüler öne çıkar; tahta doldukça büyük parçalar seyrekleşir.
const PERMS = [[0, 1, 2], [0, 2, 1], [1, 0, 2], [1, 2, 0], [2, 0, 1], [2, 1, 0]];

// Parça boyutuna göre ağırlık: tahta kalabalıksa 5-9 hücrelik parçalar azalır
function pickShape(fill) {
  const k = (sh) => (sh.n >= 6 ? Math.min(1, Math.max(0.15, 1.4 - fill * 2)) : sh.n >= 5 ? Math.min(1, Math.max(0.25, 1.5 - fill * 1.8)) : 1);
  let total = 0;
  for (const sh of SHAPES) total += sh.w * k(sh);
  let r = rnd() * total;
  for (const sh of SHAPES) { r -= sh.w * k(sh); if (r <= 0) return sh; }
  return SHAPES[0];
}

// Yerleşim puanı (sığmazsa -1): açılan satır, açılan simge ve kenara/bloğa yaslanma (düzenli oyun)
// Bellek ayırmadan çalışır (parça seçimi her dağıtımda on binlerce kez çağırır; eski hâli her çağrıda Set kuruyordu)
const _mine = new Int32Array(64);
let _stamp = 0;
function evalPlace(o, ic, cells, r0, c0) {
  for (const [x, y] of cells) { const r = r0 + y, c = c0 + x; if (r >= N || c >= N || o[r][c]) return -1; }
  const st = ++_stamp;
  for (const [x, y] of cells) _mine[(r0 + y) * N + c0 + x] = st;
  let lines = 0, icons = 0, touch = 0, rm = 0, cm = 0;
  for (const [x, y] of cells) {
    const r = r0 + y, c = c0 + x;
    if (!(rm & (1 << r))) {
      rm |= 1 << r;
      let full = true;
      for (let k = 0; k < N && full; k++) full = o[r][k] || _mine[r * N + k] === st;
      if (full) { lines++; for (let k = 0; k < N; k++) if (ic[r][k]) icons++; }
    }
    if (!(cm & (1 << c))) {
      cm |= 1 << c;
      let full = true;
      for (let k = 0; k < N && full; k++) full = o[k][c] || _mine[k * N + c] === st;
      if (full) { lines++; for (let k = 0; k < N; k++) if (ic[k][c]) icons++; }
    }
  }
  for (const [x, y] of cells) {
    const r0y = r0 + y, c0x = c0 + x;
    for (let d = 0; d < 4; d++) {
      const r = r0y + (d === 2 ? 1 : d === 3 ? -1 : 0), c = c0x + (d === 0 ? 1 : d === 1 ? -1 : 0);
      if (r < 0 || c < 0 || r >= N || c >= N || (o[r][c] && _mine[r * N + c] !== st)) touch++;
    }
  }
  return lines * 12 + icons * 30 + touch;
}

// Yerleştir ve dolan satırları sil (sanal tahtada)
function applyPlace(o, ic, cells, r0, c0) {
  const O = o.map((row) => row.slice()), I = ic.map((row) => row.slice());
  for (const [x, y] of cells) O[r0 + y][c0 + x] = true;
  const rows = [], cols = [];
  for (let r = 0; r < N; r++) if (O[r].every(Boolean)) rows.push(r);
  for (let c = 0; c < N; c++) if (O.every((row) => row[c])) cols.push(c);
  for (const r of rows) for (let c = 0; c < N; c++) { O[r][c] = false; I[r][c] = null; }
  for (const c of cols) for (let r = 0; r < N; r++) { O[r][c] = false; I[r][c] = null; }
  return [O, I];
}

// Üçlünün değeri: en iyi sıralamada toplam yerleşim puanı. Her parça şu anki tahtaya tek başına
// sığmalı ve üçü bir sırayla art arda yerleştirilebilmeli; değilse -1
function tripleValue(shapes, o, ic, base = null) {
  // Şu anki tahtada bir parçanın en iyi yeri; aynı seçimde defalarca sorulduğu için önbellekten gelir
  const firstBest = (cells) => {
    let m = base && base.get(cells);
    if (m) return m;
    let bs = -1, br = 0, bc = 0;
    for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) { const v = evalPlace(o, ic, cells, r, c); if (v > bs) { bs = v; br = r; bc = c; } }
    m = { bs, br, bc };
    if (base) base.set(cells, m);
    return m;
  };
  if (!shapes.every((sh) => firstBest(sh.cells).bs >= 0)) return -1;
  let best = -1;
  for (const perm of PERMS) {
    let O = o, I = ic, total = 0, ok = true;
    for (let j = 0; j < 3; j++) {
      const cells = shapes[perm[j]].cells;
      let bs = -1, br = 0, bc = 0;
      if (j === 0) ({ bs, br, bc } = firstBest(cells));
      else for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        const v = evalPlace(O, I, cells, r, c);
        if (v > bs) { bs = v; br = r; bc = c; }
      }
      if (bs < 0) { ok = false; break; }
      total += bs;
      [O, I] = applyPlace(O, I, cells, br, bc);
    }
    if (ok && total > best) best = total;
  }
  return best;
}

function chooseShapes() {
  const o = grid.map((row) => row.map(Boolean));
  const ic = grid.map((row) => row.map((b) => (b && b.icon) || null));
  const fill = o.flat().filter(Boolean).length / (N * N);
  const cands = [], base = new Map();
  for (let t = 0; t < 36; t++) {
    const shapes = [pickShape(fill), pickShape(fill), pickShape(fill)];
    const v = tripleValue(shapes, o, ic, base);
    if (v < 0) continue;
    cands.push({ shapes, v });
    if (mode === 'endless') break;           // sonsuz modda rastlantı korunur, yalnız sığması şart
  }
  if (cands.length) {
    cands.sort((a, b) => b.v - a.v);
    // Zor bölümlerde dağıtım daha az yardımcı: en iyi k üçlü arasından seçilir (normalde 4)
    const K = (mode === 'level' && !daily && L && L.dealK) || 4;
    return cands[Math.floor(rnd() * Math.min(K, cands.length))].shapes;
  }
  // Hiçbir üçlü sığmıyorsa küçük parçalarla dene, olmazsa en az birinin sığmasına razı ol
  const small = SHAPES.filter((sh) => sh.n <= 3);
  for (let t = 0; t < 30; t++) {
    const shapes = [0, 1, 2].map(() => small[Math.floor(rnd() * small.length)]);
    if (tripleValue(shapes, o, ic, base) >= 0) return shapes;
  }
  for (let t = 0; t < 30; t++) {
    const shapes = [randomShape(), randomShape(), randomShape()];
    if (shapes.some((sh) => fitsAnywhere(sh))) return shapes;
  }
  return [SHAPES[0], SHAPES[0], SHAPES[0]];
}

// Renkli parçalar: sonsuz modda ve özel bölümlerde
const colorful = () => mode === 'endless' || !!(L && (L.special || L.promo));
function needColors() {
  const set = new Set();
  for (const row of grid) for (const b of row) if (b && b.need) set.add(b.need);
  return [...set];
}
function deal(from = true) {
  const shapes = chooseShapes();
  const needs = mode === 'level' ? needColors() : [];
  shapes.forEach((s, i) => makeTrayPiece(i, s, needs.length ? needs[(Math.random() * needs.length) | 0] : colorful() ? 'c' + ((Math.random() * PALETTE.length) | 0) : 'block', from));
  Sound.deal();
  save();
}

// ---------- Kurallar ----------
function canPlace(shape, r0, c0) {
  for (const [x, y] of shape.cells) {
    const r = r0 + y, c = c0 + x;
    if (r < 0 || c < 0 || r >= N || c >= N || grid[r][c]) return false;
  }
  return true;
}
function fitsAnywhere(shape) {
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) if (canPlace(shape, r, c)) return true;
  return false;
}
// Bu yerleşimle tamamlanacak satır ve sütunlar
function linesAfter(shape, r0, c0) {
  const filled = (r, c) => grid[r][c] || shape.cells.some(([x, y]) => r0 + y === r && c0 + x === c);
  const rows = [], cols = [];
  for (let r = 0; r < N; r++) { let ok = true; for (let c = 0; c < N; c++) if (!filled(r, c)) { ok = false; break; } if (ok) rows.push(r); }
  for (let c = 0; c < N; c++) { let ok = true; for (let r = 0; r < N; r++) if (!filled(r, c)) { ok = false; break; } if (ok) cols.push(c); }
  return { rows, cols };
}

// ---------- Sürükleme ----------
let drag = null;
let preview = { key: '', painted: [] };

function startDrag(p, e) {
  if (busy || over || drag || targeting) return;
  drag = { p, pid: e.pointerId, x: e.global.x, y: e.global.y, vx: p.view.x, vy: p.view.y };   // tepsiden parmağa süzülür; yalnız bu parmak izlenir
  trayLayer.removeChild(p.view);
  // Yumuşak gölge: parça elde havada duruyormuş gibi
  p.shadow = pieceView(p.shape, p.color, cell);
  for (const c of p.shadow.children) c.tint = 0x000018;
  p.shadow.alpha = 0;
  dragLayer.addChild(p.shadow, p.view);
  killTweens(p.view.scale);
  tween(p.view.scale, { x: 1.04, y: 1.04 }, 0.14, Ease.outBack);
  tween(p.shadow, { alpha: 0.32 }, 0.14);
  Haptics.light();
  Haptics.selectStart();
  Sound.pickup();
  moveDrag(e.global);
}

function liftOffset(p) {
  const [, h] = size(p.shape.cells);
  return (h * cell) / 2 + cell * 1.1; // parça parmağın üstünde dursun
}

function moveDrag(g) {
  if (!drag) return;
  const p = drag.p;
  // Hedef konum parmağın üstü; görünüm her karede yumuşakça izler (updateDrag)
  drag.tx = g.x; drag.ty = g.y - liftOffset(p);
  if (drag.vx === undefined) { drag.vx = drag.tx; drag.vy = drag.ty; p.view.position.set(drag.vx, drag.vy); }
  const [w, h] = size(p.shape.cells);
  const c0 = Math.round((drag.tx - (w * cell) / 2 - BX) / cell);
  const r0 = Math.round((drag.ty - (h * cell) / 2 - BY) / cell);
  const ok = canPlace(p.shape, r0, c0);
  drag.target = ok ? [r0, c0] : null;
  showPreview(ok ? p : null, r0, c0);
}

function updateDrag(dt) {
  if (!drag || drag.vx === undefined) return;
  const p = drag.p, k = Math.min(1, dt * 38);
  const px = drag.vx;
  drag.vx += (drag.tx - drag.vx) * k;
  drag.vy += (drag.ty - drag.vy) * k;
  p.view.position.set(drag.vx, drag.vy);
  // Yana hızla çekince parça hareket yönüne hafifçe yatar, durunca toparlanır
  const vel = (drag.vx - px) / Math.max(dt, 1e-3) / cell;
  const lean = Math.max(-0.14, Math.min(0.14, vel * 0.012));
  p.view.rotation += (lean - p.view.rotation) * Math.min(1, dt * 14);
  if (p.shadow) { p.shadow.position.set(p.view.x + cell * 0.12, p.view.y + cell * 0.22); p.shadow.rotation = p.view.rotation; }
}
function clearPreview() {
  ghostLayer.removeChildren();
  for (const b of preview.painted) if (b.s && !b.s.destroyed) { b.s.texture = tex[b.color]; b.s.alpha = 1; }
  preview.painted = [];
  preview.key = '';
}

function showPreview(p, r0, c0) {
  const key = p ? `${r0},${c0}` : '';
  if (key === preview.key) return;
  if (key) Haptics.tick(); // yeni hücreye geçişte ince tık
  clearPreview();
  preview.key = key;
  if (!p) return;
  for (const [x, y] of p.shape.cells) {
    const s = blockSprite(p.color);
    s.alpha = 0.3;
    s.position.set(cx(c0 + x), cy(r0 + y));
    ghostLayer.addChild(s);
  }
  const gh = new Graphics();
  const col = colorful() || /^c\d$/.test(p.color) ? colorHex[p.color] ?? 0xffffff : 0xffffff;
  pieceOutline(gh, p.shape.cells, (x) => BX + (c0 + x) * cell, (y) => BY + (r0 + y) * cell, cell, col);
  ghostLayer.addChild(gh);
  // Patlayacak satır/sütunlardaki bloklar parçanın rengine boyanır
  const { rows, cols } = linesAfter(p.shape, r0, c0);
  const mark = (r, c) => {
    const b = grid[r][c];
    if (b && !preview.painted.includes(b)) { b.s.texture = colorful() ? tex[p.color] : tex.hi; preview.painted.push(b); }
  };
  for (const r of rows) for (let c = 0; c < N; c++) mark(r, c);
  for (const c of cols) for (let r = 0; r < N; r++) mark(r, c);
}

app.stage.eventMode = 'static';
app.stage.hitArea = new Rectangle(0, 0, 10000, 10000);
// Sürükleme yalnız parçayı tutan parmağa bağlıdır: ikinci parmak parçayı oynatamaz ve bırakamaz
const ownPtr = (e) => !drag || drag.pid === undefined || e.pointerId === drag.pid;
app.stage.on('globalpointermove', (e) => { if (ownPtr(e)) moveDrag(e.global); });
app.stage.on('pointerup', (e) => { if (ownPtr(e)) endDrag(); });
app.stage.on('pointerupoutside', (e) => { if (ownPtr(e)) endDrag(); });
// Dokunuş sistemce kesilirse (Denetim Merkezi, bildirim, arama, uygulama değiştirme) parça tepsiye döner, Blok
// Kaçışı'nda tutulan blok bırakılır; yoksa parça havada kalıyor ve sonraki dokunuşta istenmeden yerleşiyordu
function cancelDrags(e) {
  const pid = e && e.pointerId;   // görünürlük olayında pid yok: hepsi bırakılır
  if (drag && (pid === undefined || drag.pid === undefined || pid === drag.pid)) { drag.target = null; endDrag(); }
  if (esc && esc.drag && (pid === undefined || pid === esc.drag.pid)) escRelease();
}
window.addEventListener('pointercancel', cancelDrags);
document.addEventListener('visibilitychange', () => { if (document.hidden) cancelDrags(); });

async function endDrag() {
  if (!drag) return;
  const { p } = drag;
  const target = over || busy ? null : drag.target;   // süre bittiyse ya da başka bir hamle sürüyorsa parça yerleşmez
  drag = null;
  clearPreview();
  Haptics.selectEnd();
  if (p.shadow) { p.shadow.destroy({ children: true }); p.shadow = null; }
  if (!target) {
    Haptics.warning();
    Sound.back();
    dragLayer.removeChild(p.view);
    trayLayer.addChild(p.view);
    tween(p.view, { x: slotX(p.i), y: trayY, rotation: 0 }, 0.22, Ease.outCubic);
    tween(p.view.scale, { x: trayScale(), y: trayScale() }, 0.22, Ease.outCubic);
    return;
  }
  busy = true;
  tray[p.i] = null;
  // Parça hedef hücrelere süzülür, düzleşir, sonra yerine "tık" diye oturur
  const run = runId;
  const [w, h] = size(p.shape.cells);
  const sx = BX + target[1] * cell + (w * cell) / 2, sy = BY + target[0] * cell + (h * cell) / 2;
  killTweens(p.view.scale);
  await Promise.all([tween(p.view, { x: sx, y: sy, rotation: 0 }, 0.07, Ease.outQuad), tween(p.view.scale, { x: 1, y: 1 }, 0.07, Ease.outQuad)]);
  p.view.destroy({ children: true });
  if (run !== runId) return;   // bırakma süzülmesi sırasında oyundan çıkıldı / yeniden başlandı
  try { await place(p, target[0], target[1]); } finally { if (run === runId) busy = false; }   // hata olsa da giriş kilitli kalmasın
}

// ---------- Yerleştirme ve patlatma ----------
async function place(p, r0, c0) {
  const run = runId;   // patlatma sürerken oyuncu çıkar / yeniden başlarsa kalan adımlar yeni oyuna uygulanmaz
  placed++;
  if (mode === 'level' && !daily) lifeAtRisk = true;
  if (hasMoves()) { movesLeft--; updateMoves(); }
  p.shape.cells.forEach(([x, y], k) => {
    setBlock(r0 + y, c0 + x, p.color, 'slam', k * 0.012);
    // Oturan hücrelerde kısa ışık parlaması
    const f = new Sprite(tex.white);
    f.anchor.set(0.5);
    f.width = f.height = cell;
    f.position.set(cx(c0 + x), cy(r0 + y));
    f.alpha = 0;
    fx.addChild(f);
    tween(f, { alpha: 0.6 }, 0.04, Ease.linear, k * 0.012).then(() => tween(f, { alpha: 0 }, 0.26, Ease.outQuad)).then(() => f.destroy());
  });
  boardBump.v += cell * (0.9 + p.shape.n * 0.12);
  placeDust(p.shape.cells, r0, c0);
  Haptics.medium();
  Sound.place(placed);
  addScore(p.shape.n);
  mission('place');
  const { rows, cols } = linesAfter({ cells: [] }, 0, 0);
  const lines = rows.length + cols.length;
  if (lines) {
    combo++;
    sinceClear = 0;
    streak++;
    // Ateş yalnız art arda 3 hamlede satır patlatınca yanar; kombo sürdükçe yanmaya devam eder
    const wasFire = fire;
    if (!fire && streak >= 3) fire = true;
    const base = [0, 100, 300, 600, 1000, 1500, 2100][Math.min(lines, 6)];
    const pts = Math.round(base * (1 + 0.5 * (combo - 1)) * (fire ? 2 : 1));
    if (fire && !wasFire) enterFire();
    mission('lines', lines);
    if (lines >= 2) mission('multi');
    if (combo >= 2) mission('combo');
    const [w, h] = size(p.shape.cells);
    const ox = cx(c0 + (w - 1) / 2), oy = cy(r0 + (h - 1) / 2);
    Sound.clear(lines, combo);
    await clearLines(rows, cols, ox, oy, p.color);
    if (run !== runId) return;
    addScore(pts, ox, oy);
    if (L.power && lines >= 2) spawnPower(lines, rows, cols, p, r0, c0, ox, oy);
    // Tek yazı: büyük patlatmada övgü (kombo varsa altında etiket), yoksa yalnız kombo yazısı
    const comboSub = combo >= 2 && !fire ? 'KOMBO ×' + combo : null;   // ateşte kombo rozette görünür
    if (lines >= 2) { praise(L.power ? POWER_NAME[powerOf(lines)] : lines >= 4 ? 'Muhteşem!' : lines === 3 ? 'Süper!' : 'Harika!', comboSub); Sound.praise(lines >= 3); }
    else if (comboSub) comboText(combo);
    if (grid.every((row) => row.every((b) => !b))) { praise('Tertemiz!'); Sound.perfect(); addScore(500, W / 2, BY + N * cell * 0.75); confetti(60); screenFlash(0.45); boardFlash(p.color, 1.2); }
  } else {
    // Kombo yalnız art arda patlatmalarda sayılır: patlatmayan her hamle komboyu ve ateşi bitirir
    streak = 0;
    sinceClear++;
    combo = 0;
    if (fire) exitFire();
  }
  renderCombo();
  if (tut) tutAfterPlace();
  if (mode === 'level' && levelDone()) { await wait(0.5); if (run !== runId) return; return win(); }
  if (mode === 'level' && !lines && spreadMoss()) { await wait(0.35); if (run !== runId) return; }
  if (mode === 'level' && tickBombs()) { await explodeBombs(); if (run !== runId) return; return checkGameOver('bomb'); }
  if (hasMoves() && movesLeft <= 0) return checkGameOver('moves');
  if (tray.every((t) => !t)) { deal(); await wait(0.3); if (run !== runId) return; }
  save();
  checkGameOver();
}

// ---------- Oyun içi ipuçları ----------
// (Satır parıltısı kaldırıldı — kullanıcı isteği.) Hiçbir yere sığmayan tepsi parçası soluklaşır.
// 3) Tahta %70 dolunca ekran kenarları nabız gibi kızarır; %85 üstünde hafif kalp atışı.
let hintSig = '', hintTick = 0, fullBeat = 0;
const hintG = new Graphics();
hintLayer.addChild(hintG);
function updatePlayHints(dt) {
  const active = !fall && (mode === 'level' || mode === 'endless') && boardLayer.visible && !over && !$('hud').classList.contains('falling');
  const full = $('fullFx');
  if (!active) { if (hintSig) { hintG.clear(); hintSig = ''; } full.classList.remove('on'); return; }
  hintLayer.alpha = 0.78 + 0.22 * Math.sin(time * 4);
  if (++hintTick % 8) return;
  // Tahta değiştiyse yeniden hesapla
  let sig = '', filled = 0;
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) { const b = !!grid[r][c]; sig += b ? 1 : 0; if (b) filled++; }
  if (sig !== hintSig) {
    hintSig = sig;
    hintG.clear();
  }
  // Sığmayan parçalar soluk
  for (const t of tray) {
    if (!t || !t.view || t.view.destroyed || (drag && drag.p === t)) continue;
    const fits = fitsAnywhere(t.shape);
    if (fits === !t.dim) continue;
    t.dim = !fits;
    t.view.alpha = fits ? 1 : 0.4;
    for (const ch of t.view.children) ch.tint = fits ? 0xffffff : 0x8a8a9a;
  }
  // Tahta doluluk uyarısı
  const f = filled / (N * N), k = Math.max(0, Math.min(1, (f - 0.68) / 0.22));
  full.classList.toggle('on', k > 0);
  full.style.setProperty('--k', k.toFixed(2));
  if (f >= 0.85 && !busy) {
    fullBeat -= dt * 8;
    if (fullBeat <= 0) { fullBeat = 1.6; Sound.heartbeat(0.25); }
  } else fullBeat = 0;
}
// ---------- İlk bölüm öğreticisi ----------
// 1. bölümde iki elmasın sütunu dikey 4'lü parçayla tamamlanır: parmak parçayı hedefe sürükler, hedef parlar,
// altta kısa yönerge. Her doğru hamlede övgü; bölüm bitince bir daha gösterilmez.
let tut = null;
const tutPiece = () => tray.find((t) => t && t.shape.n === 4 && t.shape.cells.every(([x]) => x === 0));
function tutTip(html, kind = '') {
  const el = $('tutTip');
  el.innerHTML = html;
  el.className = 'tut-tip show ' + kind;
  el.style.top = `${BY + N * cell + Math.max(10, cell * 0.25)}px`;
}
function hideTutTip() { $('tutTip').classList.remove('show'); }
function startTutorial() {
  if (Store.get('tut_done', '') || levelN !== 0 || mode !== 'level' || daily) return;
  const I4 = SHAPES.find((sh) => sh.n === 4 && sh.cells.every(([x]) => x === 0));
  const D2 = SHAPES.find((sh) => sh.n === 2 && sh.cells.every(([, y]) => y === 0));
  for (const t of tray) if (t) t.view.destroy({ children: true });
  tray = [null, null, null];
  makeTrayPiece(0, D2, 'block', 'center');
  makeTrayPiece(1, I4, 'block', 'center');
  makeTrayPiece(2, I4, 'block', 'center');
  tut = { step: 0, targets: [[0, 1], [0, 6]], left: goals[0] ? goals[0].left : 0 };
  clearIdleHint();
  tutTip('<b>Parçayı sürükle</b>ve parlayan yere bırak', 'first');
}
// Her yerleştirmeden sonra: elmas toplandıysa sonraki adıma geç
function tutAfterPlace() {
  if (!tut) return;
  const left = goals[0] ? goals[0].left : 0;
  if (left < tut.left) {
    tut.left = left; tut.step++;
    if (tut.step >= tut.targets.length || left <= 0) { Store.set('tut_done', '1'); tutTip('<b>Harika!</b>Dolan satır ve sütunlar patlar', 'ok'); setTimeout(() => endTutorial(true), 1600); return; }
    tutTip('<b>Harika!</b>Dolan sütun patladı, elmas toplandı', 'ok');
    setTimeout(() => { if (tut) tutTip('<b>Şimdi sıra sende</b>Diğer elmasın sütununu doldur'); }, 1700);
  }
}
function endTutorial(done = false) {
  if (!tut) return;
  tut = null;
  if (done) Store.set('tut_done', '1');
  hideTutTip();
  clearIdleHint();
}
// Boşta kalan oyuncuya ipucu (eğitim tarzı): 20 sn hamle yoksa önerilen parçanın üstünde bir dokunma noktası
// belirir, parçanın yarı saydam kopyasını tahtadaki hedefe taşır; hedefin ince dış hattı bir an parlar.
// Döngü ~3,2 sn; ekrana dokununca kaybolur.
let idleT = 0, idleHint = null;
const idleFx = new Container();
const idleG = new Graphics();
idleFx.addChild(idleG);
fx.addChild(idleFx);
function clearIdleHint() {
  idleT = 0;
  if (!idleHint) return;
  idleG.clear();
  if (idleHint.ghost && !idleHint.ghost.destroyed) idleHint.ghost.destroy({ children: true });
  if (idleHint.dot && !idleHint.dot.destroyed) idleHint.dot.destroy();
  if (idleHint.dim && !idleHint.dim.destroyed) idleHint.dim.destroy();
  $('tutHand').classList.remove('on', 'down');
  const v = idleHint.p.view;
  if (v && !v.destroyed) v.scale.set(trayScale());
  idleHint = null;
}
app.stage.on('pointerdown', clearIdleHint);
function updateIdleHint(dt) {
  if (!idleFx.parent || idleFx.parent !== fx) fx.addChild(idleFx);   // efekt katmanı temizlenirse geri ekle
  if (tut) $('tutTip').classList.toggle('away', !!drag || busy);   // parça tutulunca yönerge çekilir, bırakınca döner
  const active = !fall && (mode === 'level' || mode === 'endless') && boardLayer.visible && !over && !busy && !drag && !targeting
    && !popupOpen && !$('veil').classList.contains('show');
  if (!active) { clearIdleHint(); return; }
  if (!idleHint) {
    idleT += dt;
    if (idleT < (tut ? 0.7 : 20)) return;   // oyuncu 20 sn oynamazsa (öğreticide hemen)
    // En iyi yerleşim: en çok satır/simge açan, yoksa en çok yaslanan
    const o = grid.map((row) => row.map(Boolean)), ic = grid.map((row) => row.map((b) => (b && b.icon) || null));
    let best = null;
    // Öğretici: gösterilecek parça ve hedef sabit
    if (tut) {
      if (tut.step >= tut.targets.length) return;   // son adım bitti: kutlama yazısı gösteriliyor
      const tp = tutPiece(), [tr, tc] = tut.targets[tut.step];
      if (!tp) return;                                // parça şu an elde/yerleşiyor
      if (canPlace(tp.shape, tr, tc)) best = { p: tp, r: tr, c: tc, v: 99 };
      else endTutorial();                             // hedef kapandıysa öğretici serbest oyuna bırakır
    }
    if (!best) for (const p of tray) {
      if (!p) continue;
      for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
        if (!canPlace(p.shape, r, c)) continue;
        const v = evalPlace(o, ic, p.shape.cells, r, c);
        if (!best || v > best.v) best = { p, r, c, v };
      }
    }
    if (!best) { idleT = 0; return; }
    const ghost = pieceView(best.p.shape, best.p.color, cell);
    ghost.alpha = 0;
    const dot = new Sprite(glowTex);
    dot.anchor.set(0.5); dot.tint = 0xffffff; dot.alpha = 0;
    idleFx.addChild(ghost, dot);
    const [w, h] = size(best.p.shape.cells);
    let dim = null;
    if (tut) {
      dim = new Graphics();
      dim.rect(-10, -10, W + 20, H + 20).fill({ color: 0x02040f, alpha: 0.5 });
      const pad = cell * 0.12;
      dim.roundRect(BX + best.c * cell - pad, BY + best.r * cell - pad, w * cell + pad * 2, h * cell + pad * 2, cell * 0.25).cut();
      const vb = best.p.view.getBounds();
      dim.roundRect(vb.x - cell * 0.4, vb.y - cell * 0.4, vb.width + cell * 0.8, vb.height + cell * 0.8, cell * 0.35).cut();
      dim.alpha = 0;
      idleFx.addChildAt(dim, 0);
      tween(dim, { alpha: 1 }, 0.35);
    }
    idleHint = { ...best, t: 0, ghost, dot, dim, tx: BX + (best.c + w / 2) * cell, ty: BY + (best.r + h / 2) * cell };
  }
  const h = idleHint, v = h.p.view;
  if (!v || v.destroyed) { clearIdleHint(); return; }
  h.t += dt;
  const T = h.t % 3.2;
  const sx = v.x, sy = v.y, ease = (q) => (q < 0.5 ? 2 * q * q : 1 - Math.pow(-2 * q + 2, 2) / 2);
  idleG.clear();
  // 0–0.35: parmak basar (halka), 0.35–1.25: kopya hedefe süzülür, 1.25–1.75: hedef hattı parlar, sonra söner
  let gx = sx, gy = sy, ga = 0, da = 0, ds = 0.55;
  if (T < 0.35) {
    const q = T / 0.35;
    da = q; ds = 0.75 - 0.2 * q; ga = 0.25 * q;
    idleG.circle(sx, sy, cell * (0.35 + q * 0.6)).stroke({ width: Math.max(2, cell * 0.05), color: 0xffffff, alpha: 0.6 * (1 - q) });
  } else if (T < 1.25) {
    const q = ease((T - 0.35) / 0.9);
    gx = sx + (h.tx - sx) * q; gy = sy + (h.ty - sy) * q - Math.sin(q * Math.PI) * cell * 0.8;
    da = 1; ga = 0.38;
  } else if (T < 1.75) {
    const q = (T - 1.25) / 0.5;
    gx = h.tx; gy = h.ty; da = 1 - q; ga = 0.38 * (1 - q);
    pieceOutline(idleG, h.p.shape.cells, (x) => BX + (h.c + x) * cell, (y) => BY + (h.r + y) * cell, cell, 0xffffff);
    idleG.alpha = 1 - q;
  }
  if (T >= 1.25 && T < 1.75) { /* hat görünür */ } else idleG.alpha = 1;
  h.ghost.position.set(gx, gy);
  h.ghost.scale.set(T < 0.35 ? trayScale() : T < 1.25 ? trayScale() + (1 - trayScale()) * ease((T - 0.35) / 0.9) : 1);
  h.ghost.alpha = ga;
  h.dot.position.set(gx + cell * 0.25, gy + cell * 0.35);
  h.dot.width = h.dot.height = cell * ds;
  h.dot.alpha = tut ? 0 : da * 0.85;
  if (tut) {
    const hand = $('tutHand');
    hand.classList.add('on');
    hand.classList.toggle('down', T < 1.25 && T > 0.12);
    hand.style.transform = `translate(${gx}px, ${gy}px)`;
    hand.style.opacity = Math.min(1, da * 1.2).toFixed(2);
  }
  // Önerilen tepsi parçası: hafif nabız
  const k = trayScale();
  v.scale.set(k * (1 + 0.04 * (0.5 + 0.5 * Math.sin(h.t * 5))));
}
// Tahta yayı: yerleşmede ve patlamada tahta hafifçe çöker, geri sıçrar
const boardBump = { y: 0, v: 0 };
// Parçanın alt kenarlarından iki yana savrulan yumuşak toz
function placeDust(cells, r0, c0) {
  const has = new Set(cells.map(([x, y]) => x + ',' + y));
  for (const [x, y] of cells) {
    if (has.has(x + ',' + (y + 1))) continue;
    const bx = cx(c0 + x), by = BY + (r0 + y + 1) * cell;
    for (let k = 0; k < 2; k++) {
      const d = new Sprite(glowTex);
      d.anchor.set(0.5);
      d.tint = 0xe6ecff; d.alpha = 0.3;
      d.width = d.height = cell * (0.35 + Math.random() * 0.3);
      d.position.set(bx + (Math.random() - 0.5) * cell * 0.7, by - cell * 0.05);
      fx.addChild(d);
      const dir = k ? 1 : -1;
      tween(d, { x: d.x + dir * cell * (0.4 + Math.random() * 0.5), y: by - cell * (0.15 + Math.random() * 0.3), alpha: 0, width: cell, height: cell }, 0.42 + Math.random() * 0.15, Ease.outCubic).then(() => d.destroy());
    }
  }
}
async function clearLines(rows, cols, ox, oy, color) {
  const cells = new Map();
  for (const r of rows) for (let c = 0; c < N; c++) cells.set(r * N + c, [r, c]);
  for (const c of cols) for (let r = 0; r < N; r++) cells.set(r * N + c, [r, c]);
  const lines = rows.length + cols.length;
  Haptics.success();
  if (lines >= 2) setTimeout(() => Haptics.heavy(), 120);
  // Şarj: patlayacak bloklar bir an beyaz yanar
  const charge = [];
  for (const [r, c] of cells.values()) {
    if (!grid[r][c]) continue;
    const g = new Sprite(tex.white);
    g.anchor.set(0.5); g.blendMode = 'add';
    g.width = g.height = cell * 0.96;
    g.position.set(cx(c), cy(r));
    g.alpha = 0;
    fx.addChild(g);
    charge.push(g);
  }
  await Promise.all(charge.map((g) => tween(g, { alpha: 0.65 }, 0.05)));
  for (const g of charge) tween(g, { alpha: 0 }, 0.2, Ease.outQuad).then(() => g.destroy());
  boardBump.v += cell * (2 + lines * 1.6);
  shake = Math.min(1, 0.25 + 0.15 * lines);
  for (const r of rows) beam(BX + (N * cell) / 2, cy(r), N * cell * 1.15, false, color);
  for (const c of cols) beam(cx(c), BY + (N * cell) / 2, N * cell * 1.15, true, color);
  // Bırakılan noktadan iki yana açılan ince ışık çizgisi (satır boyunca "fermuar")
  const zip = (x, y, v) => {
    const z = new Sprite(tex.white);
    z.anchor.set(0.5); z.blendMode = 'add';
    z.position.set(v ? x : ox, v ? oy : y);
    if (v) { z.width = Math.max(2, cell * 0.12); z.height = cell * 0.4; } else { z.width = cell * 0.4; z.height = Math.max(2, cell * 0.12); }
    fx.addChild(z);
    const full = N * cell;
    tween(z, v ? { height: full, y: BY + full / 2 } : { width: full, x: BX + full / 2 }, 0.16, Ease.outCubic)
      .then(() => tween(z, v ? { width: 0, alpha: 0 } : { height: 0, alpha: 0 }, 0.22, Ease.inQuad)).then(() => z.destroy());
  };
  for (const r of rows) zip(0, cy(r), false);
  for (const c of cols) zip(cx(c), 0, true);
  if (lines >= 2) shockwave(ox, oy, color, lines);
  if (lines >= 3) screenFlash(0.35);
  boardFlash(color, 0.45 + lines * 0.2);
  if (fire) {
    for (const r of rows) for (let c = 0; c < N; c++) { addFlame(cx(c), cy(r) + cell * 0.45, cell * (1.4 + Math.random() * 0.8), false, 1.6); addFlame(cx(c), cy(r) + cell * 0.45, cell * 0.8, true, 1.8); }
    for (const c of cols) for (let r = 0; r < N; r++) { addFlame(cx(c), cy(r) + cell * 0.45, cell * (1.4 + Math.random() * 0.8), false, 1.6); addFlame(cx(c), cy(r) + cell * 0.45, cell * 0.8, true, 1.8); }
  }
  const key = colorful() && tex[color] ? color : 'hi';
  // Bırakılan noktadan dışa doğru dalga; her blok kendi anında patlar
  const order = [...cells.values()].map(([r, c]) => ({ r, c, d: Math.hypot(cx(c) - ox, cy(r) - oy) / cell })).sort((a, b) => a.d - b.d);
  const jobs = [];
  let popN = 0, digMax = -1;
  for (const { r, c, d } of order) {
    if (dig && dig.n[r][c] > 0) { jobs.push(digHit(r, c, d * 0.032)); digMax = Math.max(digMax, d * 0.032); }
    const b = grid[r][c];
    if (!b) continue;
    const delay = d * 0.032;
    if (b.need && !colorMatches(b.need, color)) { jobs.push(wait(delay).then(() => needReject(b))); continue; }
    if (b.hp > 0) { jobs.push(wait(delay).then(() => hitObstacle(b))); continue; }
    if (b.power) {
      // Roket patlayan çizgiyle aynı yöndeyse boşa gitmesin: diğer yöne döner
      if (b.power === 'rocket') { const inRow = rows.includes(r), inCol = cols.includes(c); if (inRow && !inCol) b.dir = 'v'; else if (inCol && !inRow) b.dir = 'h'; }
      grid[r][c] = null; jobs.push(wait(delay + 0.05).then(() => firePower(b, r, c))); continue;
    }
    grid[r][c] = null;
    if (b.bomb !== undefined) { addScore(50); jobs.push(wait(delay).then(() => { shockwave(b.s.x, b.s.y, 'c3', 1); Sound.crack(false); })); }
    dropOverlays(b);
    const s = b.s;
    s.texture = tex[key];
    if (b.is) jobs.push(wait(delay).then(() => collectIcon(b)));
    // Ses: dalga boyunca yükselen "pop"lar (her 2 blokta bir, en fazla 8)
    if (popN % 2 === 0 && popN < 16) Sound.pop(popN / 2, delay);
    popN++;
    jobs.push(wait(delay).then(() => blastBlock(s, key, ox, oy, 0.8 + Math.min(0.6, lines * 0.15))));
  }
  if (digMax >= 0) jobs.push(wait(digMax + 0.3).then(digReveal));
  await Promise.all(jobs);
  if (dig) await digReveal();   // güçlerin kazdığı yerler
}

// Tek blok: beyaz parlar, büyür, dört parçaya bölünüp saçılır
function popBlock(s, key, cell = mainCell()) {   // cell: patlayan karenin boyu (düşen blok tahtası daha küçük)
  const flash = new Sprite(tex.white);
  flash.anchor.set(0.5);
  flash.width = flash.height = cell;
  flash.position.copyFrom(gpos(s));
  flash.alpha = 0;
  fx.addChild(flash);
  const k = s.scale.x;
  return Promise.all([
    tween(flash, { alpha: 0.85 }, 0.05).then(() => tween(flash, { alpha: 0 }, 0.18)).then(() => flash.destroy()),
    tween(s.scale, { x: k * 1.18, y: k * 1.18 }, 0.07, Ease.outQuad),
  ]).then(() => {
    const { x, y } = gpos(s);
    s.destroy();
    const hx = colorHex[key] ?? themeHex;
    shards(key).forEach((t, i) => {
      const sh = new Sprite(t);
      sh.anchor.set(0.5);
      sh.width = sh.height = cell * 0.5;
      const dx = i % 2 ? 1 : -1, dy = i < 2 ? -1 : 1;
      sh.position.set(x + dx * cell * 0.25, y + dy * cell * 0.25);
      fx.addChild(sh);
      const v = cell * (3 + Math.random() * 4);
      parts.push({ s: sh, vx: dx * v * (0.6 + Math.random() * 0.8), vy: dy * v * 0.7 - cell * 5, t: 0, life: 0.55 + Math.random() * 0.3, vr: dx * (4 + Math.random() * 8), k0: sh.scale.x });
    });
    const gl = new Sprite(glowTex);
    gl.anchor.set(0.5);
    gl.blendMode = 'add';
    gl.tint = hx;
    gl.position.set(x, y);
    gl.width = gl.height = cell * 1.3;
    gl.alpha = 0.9;
    fx.addChild(gl);
    tween(gl, { width: cell * 2.8, height: cell * 2.8, alpha: 0 }, 0.38, Ease.outCubic).then(() => gl.destroy());
    for (let i = 0; i < 3; i++) {
      const d = new Sprite(tex[key]);
      d.anchor.set(0.5);
      d.width = d.height = cell * (0.16 + Math.random() * 0.14);
      d.position.set(x + (Math.random() - 0.5) * cell * 0.6, y + (Math.random() - 0.5) * cell * 0.6);
      fx.addChild(d);
      const a = Math.random() * Math.PI * 2, v = cell * (5 + Math.random() * 6);
      parts.push({ s: d, vx: Math.cos(a) * v, vy: Math.sin(a) * v - cell * 6, t: 0, life: 0.6 + Math.random() * 0.4, vr: (Math.random() - 0.5) * 20, k0: d.scale.x });
    }
    for (let i = 0; i < 2; i++) {
      const sp = new Sprite(sparkTex);
      sp.anchor.set(0.5);
      sp.blendMode = 'add';
      sp.tint = i ? 0xffffff : hx;
      sp.width = sp.height = cell * (0.5 + Math.random() * 0.4);
      sp.position.set(x, y);
      fx.addChild(sp);
      const a = Math.random() * Math.PI * 2, v = cell * (4 + Math.random() * 4);
      parts.push({ s: sp, vx: Math.cos(a) * v, vy: Math.sin(a) * v - cell * 3, t: 0, life: 0.4 + Math.random() * 0.3, vr: 6, k0: sp.scale.x });
    }
  });
}

const mainCell = () => cell;
// Sprite'ın ekran (fx katmanı) konumu: düşen blok tahtası kayarken de efektler bloğun üstünde çıkar
const gpos = (s) => (s.parent && !s.destroyed ? s.parent.toGlobal(s.position) : { x: s.x, y: s.y });
// Çoklu patlamada genişleyen halka
function shockwave(x, y, color, lines) {
  for (let i = 0; i < 2; i++) {
    const r = new Sprite(ringTex);
    r.anchor.set(0.5);
    r.blendMode = 'add';
    r.tint = i ? 0xffffff : colorHex[color] ?? themeHex;
    r.position.set(x, y);
    r.width = r.height = cell;
    fx.addChild(r);
    const to = cell * (5 + lines * 2.5);
    tween(r, { width: to, height: to, alpha: 0 }, 0.55 + i * 0.1, Ease.outCubic, i * 0.06).then(() => r.destroy());
  }
}

let flashEl = null;
function screenFlash(a, color = '#ffffff') {
  flashEl ??= $('flash');
  flashEl.style.background = color;
  flashEl.style.transition = 'none';
  flashEl.style.opacity = a;
  void flashEl.offsetWidth;
  flashEl.style.transition = 'opacity 0.35s ease-out';
  flashEl.style.opacity = 0;
}

// Simge hedef paneline uçar; uçmuyorsa söner
function collectIcon(b) {
  const s = b.is, run = runId;   // uçuş sürerken bölüm değişirse (çıkış / yeniden başlat) eski hedef sayılmaz
  const gi = goals.findIndex((g) => g.icon === b.icon && g.left > 0);
  if (mode !== 'level' || gi < 0) {
    return tween(s, { alpha: 0 }, 0.2).then(() => s.destroy());
  }
  goals[gi].left--;
  mission('icons');
  iconLayer.removeChild(s);
  fx.addChild(s);
  const el = $('goal' + gi).querySelector('img').getBoundingClientRect();
  const tx = el.left + el.width / 2, ty = el.top + el.height / 2;
  const sx = s.x, sy = s.y;
  const mid = { x: (sx + tx) / 2 + (Math.random() - 0.5) * 120, y: Math.min(sy, ty) - 60 };
  const path = { t: 0 };
  const k = s.scale.x;
  tween(s.scale, { x: k * 1.4, y: k * 1.4 }, 0.15, Ease.outBack);
  // Kavisli uçuş
  const tick = () => {
    if (s.destroyed) return;
    const t = path.t, u = 1 - t;
    s.x = u * u * sx + 2 * u * t * mid.x + t * t * tx;
    s.y = u * u * sy + 2 * u * t * mid.y + t * t * ty;
    requestAnimationFrame(tick);
  };
  tick();
  return tween(path, { t: 1 }, 0.6, Ease.inOutCubic, 0.1).then(() => {
    s.destroy();
    if (run !== runId || !goals[gi]) return;
    goals[gi].shown--;
    renderGoals();
    const d = $('goal' + gi);
    d.classList.remove('bump');
    void d.offsetWidth;
    d.classList.add('bump');
    Haptics.light();
    Sound.gem(gemCount++);
  });
}

// ---------- Hazine kazısı ----------
// Tahtanın tabanı toprakla kaplı, altında hazineler gömülü. Patlayan satır ve sütunların altındaki toprak bir kat kazılır
// (koyu toprak iki kat). Bir hazinenin bütün kareleri açılınca hazine topraktan fırlar ve hedefe uçar.
let dig = null, forceL = null;
const dirtKey = (r, c, n) => `dirt${n}_${(r * 5 + c * 3) % 3}`;
function buildDig() {
  digLayer.removeChildren();
  dig = { n: L.dig.map((row) => [...row].map((ch) => +ch || 0)), s: Array.from({ length: N }, () => Array(N).fill(null)), items: L.treasures.map((t) => ({ ...t, done: false })), glint: 1.2 };
  // Hazine yalnız açılmış karelerden görünür (maske), toprak aralarından sızmaz
  for (const t of dig.items) {
    t.hole = new Sprite(treasureTex[t.kind + '_hole']);
    t.item = new Sprite(treasureTex[t.kind]);
    t.box = new Container();
    t.mask = new Graphics();
    for (const sp of [t.hole, t.item]) { sp.anchor.set(0.5); t.box.addChild(sp); }
    t.box.mask = t.mask;
    digLayer.addChild(t.box, t.mask);
  }
  dig.n.forEach((row, r) => row.forEach((n, c) => {
    if (!n) return;
    const s = new Sprite(tex[dirtKey(r, c, n)]);
    s.anchor.set(0.5);
    digLayer.addChild(s);
    dig.s[r][c] = s;
  }));
  digLayout();
  // Giriş: toprak kareleri köşeden dalga hâlinde serilir
  dig.s.forEach((row, r) => row.forEach((s, c) => {
    if (!s) return;
    const k = s.scale.x, d = (r + c) * 0.025;
    s.scale.set(k * 0.6); s.alpha = 0;
    tween(s, { alpha: 1 }, 0.2, Ease.outQuad, d);
    tween(s.scale, { x: k, y: k }, 0.3, Ease.outBack, d);
  }));
}
function digLayout() {
  if (!dig) return;
  for (const t of dig.items) {
    const [w, h] = TREASURE[t.kind];
    const x = BX + (t.c + w / 2) * cell, y = BY + (t.r + h / 2) * cell;
    if (!t.hole.destroyed) { t.hole.texture = treasureTex[t.kind + '_hole']; t.hole.width = w * cell; t.hole.height = h * cell; t.hole.position.set(x, y); }
    if (!t.done) { t.item.texture = treasureTex[t.kind]; t.item.width = w * cell; t.item.height = h * cell; t.item.position.set(x, y); }
    digMask(t);
  }
  dig.s.forEach((row, r) => row.forEach((s, c) => {
    if (!s) return;
    s.texture = tex[dirtKey(r, c, dig.n[r][c])];
    s.width = s.height = cell;
    s.position.set(cx(c), cy(r));
  }));
}
function digMask(t) {
  const [w, h] = TREASURE[t.kind];
  t.mask.clear();
  for (let dr = 0; dr < h; dr++) for (let dc = 0; dc < w; dc++) {
    if (dig.n[t.r + dr][t.c + dc] > 0 && dig.s[t.r + dr][t.c + dc]) continue;
    t.mask.rect(BX + (t.c + dc) * cell, BY + (t.r + dr) * cell, cell, cell);
  }
  t.mask.fill(0xffffff);
}
// Bir kat kazı: sayı hemen düşer (hedef kontrolü için), görüntü dalgayla birlikte değişir
function digHit(r, c, delay) {
  const left = --dig.n[r][c], d0 = dig;
  return wait(delay + 0.04).then(() => {
    if (dig !== d0) return;
    const s = dig.s[r][c];
    if (!s || s.destroyed) return;
    dirtBurst(s.x, s.y, left > 0);
    const k = s.scale.x;
    if (left > 0) {
      s.texture = tex[dirtKey(r, c, left)];
      s.scale.set(k * 0.82);
      return tween(s.scale, { x: k, y: k }, 0.25, Ease.outBack);
    }
    dig.s[r][c] = null;
    for (const t of dig.items) { const [w, h] = TREASURE[t.kind]; if (r >= t.r && r < t.r + h && c >= t.c && c < t.c + w) digMask(t); }
    return tween(s.scale, { x: k * 1.12, y: k * 1.12 }, 0.08, Ease.outQuad)
      .then(() => Promise.all([tween(s, { alpha: 0 }, 0.16), tween(s.scale, { x: k * 0.5, y: k * 0.5 }, 0.16, Ease.inQuad)]))
      .then(() => s.destroy());
  });
}
// Toprak saçılması: yukarı fırlayan topak parçaları ve toz bulutu
function dirtBurst(x, y, hard) {
  const cols = hard ? [0xb07a44, 0x8e5c34, 0x5f3a1f] : [0xf0c47c, 0xd59a52, 0xa8763e];
  for (let i = 0; i < 7; i++) {
    const d = new Sprite(tex.white);
    d.anchor.set(0.5);
    d.tint = cols[i % 3];
    d.width = d.height = cell * (0.1 + Math.random() * 0.13);
    d.position.set(x + (Math.random() - 0.5) * cell * 0.6, y + (Math.random() - 0.5) * cell * 0.6);
    d.rotation = Math.random() * 3;
    fx.addChild(d);
    const a = -Math.PI / 2 + (Math.random() - 0.5) * 2.4, v = cell * (3 + Math.random() * 4);
    parts.push({ s: d, vx: Math.cos(a) * v, vy: Math.sin(a) * v - cell * 2, t: 0, life: 0.5 + Math.random() * 0.3, vr: (Math.random() - 0.5) * 14, k0: d.scale.x });
  }
  const p = new Sprite(puffTex);
  p.anchor.set(0.5);
  p.tint = cols[0];
  p.alpha = 0.5;
  p.width = p.height = cell * 0.9;
  p.position.set(x, y);
  fx.addChild(p);
  tween(p, { width: cell * 1.9, height: cell * 1.9, alpha: 0, y: y - cell * 0.3 }, 0.5, Ease.outCubic).then(() => p.destroy());
}
// Bütün kareleri açılan hazineler çıkar (aynı anda birden çoksa sırayla)
function digReveal() {
  if (!dig) return Promise.resolve();
  const jobs = [];
  for (const t of dig.items) {
    if (t.done) continue;
    const [w, h] = TREASURE[t.kind];
    let open = true;
    for (let dr = 0; dr < h; dr++) for (let dc = 0; dc < w; dc++) if (dig.n[t.r + dr][t.c + dc] > 0) open = false;
    if (!open) continue;
    t.done = true;
    const gi = goals.findIndex((g) => g.icon === 't_' + t.kind && g.left > 0);
    if (gi >= 0) goals[gi].left--;
    jobs.push(collectTreasure(t, gi, jobs.length * 0.3));
  }
  return Promise.all(jobs);
}
async function collectTreasure(t, gi, delay = 0) {
  const run = runId;
  await wait(delay);
  const s = t.item;
  if (s.destroyed) return;
  const x = s.x, y = s.y, k = s.scale.x;
  Sound.chest();
  Haptics.medium();
  // Topraktan fırlar: arkasında altın parıltı, etrafa kıvılcım
  const gl = new Sprite(glowTex);
  gl.anchor.set(0.5); gl.blendMode = 'add'; gl.tint = 0xffc23a;
  gl.position.set(x, y); gl.width = gl.height = cell; gl.alpha = 0;
  fx.addChild(gl);
  fx.addChild(s);   // maskeden çıkar, tahtanın üstünde uçar
  tween(gl, { alpha: 1, width: cell * 4.2, height: cell * 4.2 }, 0.25, Ease.outCubic).then(() => tween(gl, { alpha: 0 }, 0.55)).then(() => gl.destroy());
  sparkBurst(x, y, 16, 0xffd84a, cell * 1.9);
  boardFlash('c3', 0.5);
  await Promise.all([tween(s.scale, { x: k * 1.3, y: k * 1.3 }, 0.28, Ease.outBack), tween(s, { y: y - cell * 0.35 }, 0.28, Ease.outCubic)]);
  await tween(s, { rotation: 0.12 }, 0.07);
  await tween(s, { rotation: -0.1 }, 0.1);
  await tween(s, { rotation: 0 }, 0.08);
  if (!t.hole.destroyed) tween(t.hole, { alpha: 0 }, 0.6, Ease.outQuad, 0.3).then(() => t.hole.destroy());
  if (s.destroyed) return;
  if (gi < 0 || mode !== 'level') { await tween(s, { alpha: 0 }, 0.2); s.destroy(); return; }
  // Kavisli uçuş: hedef simgesinin boyuna küçülür, arkasında kıvılcım izi bırakır
  const el = $('goal' + gi).querySelector('img').getBoundingClientRect();
  const tx = el.left + el.width / 2, ty = el.top + el.height / 2, sx = s.x, sy = s.y;
  const mid = { x: (sx + tx) / 2 + (sx < W / 2 ? -1 : 1) * 70, y: Math.min(sy, ty) - 90 };
  const k1 = s.scale.x, k2 = k1 * (el.width * 1.15) / Math.max(s.width, s.height);
  const path = { t: 0 };
  let trail = 0;
  const tick = () => {
    if (s.destroyed) return;
    const p = path.t, u = 1 - p;
    s.x = u * u * sx + 2 * u * p * mid.x + p * p * tx;
    s.y = u * u * sy + 2 * u * p * mid.y + p * p * ty;
    s.scale.set(k1 + (k2 - k1) * p);
    if (++trail % 3 === 0) {
      const sp = new Sprite(sparkTex);
      sp.anchor.set(0.5); sp.blendMode = 'add'; sp.tint = trail % 2 ? 0xffffff : 0xffd84a;
      sp.position.set(s.x, s.y); sp.width = sp.height = cell * 0.5;
      fx.addChildAt(sp, fx.getChildIndex(s));
      tween(sp, { width: 0, height: 0, alpha: 0 }, 0.4).then(() => sp.destroy());
    }
    requestAnimationFrame(tick);
  };
  tick();
  await tween(path, { t: 1 }, 0.7, Ease.inOutCubic);
  s.destroy();
  if (run !== runId || !goals[gi]) return;   // uçuş sürerken bölüm değişti
  goals[gi].shown--;
  renderGoals();
  const d = $('goal' + gi);
  d.classList.remove('bump');
  void d.offsetWidth;
  d.classList.add('bump');
  sparkBurst(tx, ty, 10, 0xffd84a, cell * 0.9);
  Haptics.light();
  Sound.gem(gemCount++);
}
// Kısmen açılmış hazinelerin görünen yerlerinde ara ara parıltı: "az kaldı!"
function digTick(dt) {
  dig.glint -= dt;
  if (dig.glint > 0) return;
  dig.glint = 1.4 + Math.random() * 1.2;
  const open = [];
  for (const t of dig.items) {
    if (t.done) continue;
    const [w, h] = TREASURE[t.kind];
    for (let dr = 0; dr < h; dr++) for (let dc = 0; dc < w; dc++) if (!dig.n[t.r + dr][t.c + dc] && !grid[t.r + dr][t.c + dc]) open.push([t.r + dr, t.c + dc]);
  }
  if (!open.length) return;
  const [r, c] = open[Math.floor(Math.random() * open.length)];
  const sp = new Sprite(sparkTex);
  sp.anchor.set(0.5); sp.blendMode = 'add'; sp.tint = 0xfff1b0;
  sp.position.set(cx(c) + (Math.random() - 0.5) * cell * 0.5, cy(r) + (Math.random() - 0.5) * cell * 0.5);
  sp.width = sp.height = 0;
  fx.addChild(sp);
  tween(sp, { width: cell * 0.8, height: cell * 0.8, rotation: 1.5 }, 0.25, Ease.outQuad)
    .then(() => tween(sp, { width: 0, height: 0, rotation: 3 }, 0.3, Ease.inQuad)).then(() => sp.destroy());
}
function digTipImage() {
  const S = 160, q = S / 2, cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  x.drawImage(renderTreasure('chest', q, 'hole'), 0, 0);
  x.drawImage(renderTreasure('chest', q, 'item'), 0, 0);
  x.drawImage(renderDirt(q, 2, 1), q, 0);
  x.drawImage(renderDirt(q, 1, 2), q, q);
  return cv.toDataURL();
}
// Deneme bölümü (tarayıcıda ?kazi): dört farklı hazine
const DIG_DEMO = () => ({
  type: 'gems', par: 16, bombTimer: 12,
  layout: ['........', 'xxxx.xxx', '........', '........', 'x...xx..', '........', 'xxx.xxxx', '........'],
  dig: ['..1111..', '.12..121', '.11..211', '.11..11.', '21......', '11......', '...1121.', '...111..'],
  treasures: [{ kind: 'chest', r: 1, c: 1 }, { kind: 'crown', r: 1, c: 5 }, { kind: 'vase', r: 4, c: 1 }, { kind: 'key', r: 6, c: 4 }],
  goals: [{ icon: 't_chest', count: 1 }, { icon: 't_crown', count: 1 }, { icon: 't_vase', count: 1 }, { icon: 't_key', count: 1 }],
});

// ---------- Güç oluşturma ----------
// Aynı anda 2 satır/sütun patlatınca Roket, 3'te Bomba, 4 ve fazlasında Yıldırım Küresi doğar.
// Güce dokununca ya da satırı patlayınca ateşlenir; patlamada başka güç varsa zincirleme ateşlenir.
// Görünüm: renkli kare (b.s) + ayrı canlanan simge (b.pi) + arkada nabız ışığı (b.glow) + fitil/elektrik ışığı (b.spark)
const POWER_NAME = { rocket: 'Roket!', bomb: 'Bomba!', bolt: 'Yıldırım!', prop: 'Pervane!' };
const powerOf = (lines) => (lines >= 4 ? 'bolt' : lines === 3 ? 'bomb' : 'rocket');
const FUSE = [0.30, -0.365];   // bomba fitilinin ucu (kare boyuna oranla, merkezden; yeni bomba çizimi)
// Güçler iki tahtada çalışır: normal 8×8 tahta ve düşen blok (tetris) tahtası. PA() o anki tahtanın ölçülerini verir.
// px/py: ekran (fx katmanı) koordinatı; lx/ly: blokların kendi katmanındaki koordinat; dy: ikisi arasındaki dikey fark.
function PA() {
  if (fall && fall.m) {
    const dy = fall.world.y + fallLayer.y;
    return { cs: fall.m.cs, rows: L.rows, cols: L.cols, dy, lx: fx0, ly: fy0, px: fx0, py: (r) => fy0(r) + dy, left: fall.m.ox, top: fall.m.oy + dy,
      at: (r, c) => (fall.grid[r] ? fall.grid[r][c] : null), put: (r, c, col) => fallSetCell(r, c, col, null, -1), kill: fallSmash,
      under: fall.blocks, over: fall.icons, bump: (v) => { const bp = fall.bump || (fall.bump = { y: 0, v: 0 }); bp.v += v; }, dig: false };
  }
  return { cs: cell, rows: N, cols: N, dy: 0, lx: cx, ly: cy, px: cx, py: cy, left: BX, top: BY,
    at: (r, c) => grid[r][c], put: (r, c, col) => { setBlock(r, c, col, false); return grid[r][c]; }, kill: smash,
    under: blockLayer, over: iconLayer, bump: (v) => { boardBump.v += v; }, dig: true };
}
function makePower(r, c, kind, dir = 'h', from = null) {
  const A = PA(), cell = A.cs;
  const b = A.put(r, c, 'pw_' + kind);
  b.power = kind;
  b.dir = dir;
  b.seed = Math.random() * 10;
  b.born = !from;
  const x = A.lx(c), y = A.ly(r);
  const g = new Sprite(glowTex);
  g.anchor.set(0.5); g.blendMode = 'add'; g.tint = colorHex['pw_' + kind];
  g.width = g.height = cell * 1.8; g.position.set(x, y); g.alpha = 0.5;
  A.under.addChildAt(g, 0);
  b.glow = g;
  b.pi = new Sprite(powerIconTex[kind]);
  b.pi.anchor.set(0.5);
  b.pi.width = b.pi.height = cell;
  b.pi.position.set(x, y);
  if (dir === 'v') b.pi.rotation = Math.PI / 2;
  A.over.addChild(b.pi);
  // Altın çerçevenin üstünden ara ara geçen çapraz parlama (kareye kırpılır)
  b.shineMask = new Graphics();
  shineMaskDraw(b, cell);
  b.shineMask.position.set(x, y);
  b.shine = new Sprite(beamTex);
  b.shine.anchor.set(0.5); b.shine.blendMode = 'add'; b.shine.rotation = -0.85;
  b.shine.width = cell * 1.9; b.shine.height = cell * 0.55; b.shine.alpha = 0;
  b.shine.mask = b.shineMask;
  A.over.addChild(b.shineMask, b.shine);
  if (kind !== 'rocket' && kind !== 'prop') {
    b.spark = new Sprite(kind === 'bomb' ? sparkTex : glowTex);
    b.spark.anchor.set(0.5); b.spark.blendMode = 'add';
    b.spark.tint = kind === 'bomb' ? 0xffe14a : 0x7ff0ff;
    A.over.addChild(b.spark);
    placeSpark(b);
  }
  if (from) powerBirth(b, x, y + A.dy, from);
  return b;
}
function placeSpark(b) {
  if (!b.spark) return;
  const cell = PA().cs;
  const x = b.s.x, y = b.s.y;
  if (b.power === 'bomb') { b.spark.position.set(x + FUSE[0] * cell, y + FUSE[1] * cell); b.spark.width = b.spark.height = cell * 0.45; }
  else { b.spark.position.set(x, y); b.spark.width = b.spark.height = cell * 1.1; }
}
// Doğuş: patlayan çizgilerden enerji akar, karede toplanır, güç parlayarak çıkar
function powerBirth(b, x, y, from) {
  const A = PA(), cell = A.cs;
  const col = colorHex['pw_' + b.power];
  const parts0 = [b.s, b.pi, b.glow, b.spark].filter(Boolean);
  for (const sp of parts0) sp.alpha = 0;
  const src = from.slice().sort(() => Math.random() - 0.5).slice(0, 14);
  src.forEach(([sx, sy], i) => {
    const p = new Sprite(glowTex);
    p.anchor.set(0.5); p.blendMode = 'add'; p.tint = i % 3 ? col : 0xffffff;
    p.position.set(sx, sy); p.width = p.height = cell * 0.9; p.alpha = 0;
    fx.addChild(p);
    const d = i * 0.012;
    tween(p, { alpha: 1 }, 0.08, Ease.outQuad, d);
    tween(p, { x, y, width: cell * 0.35, height: cell * 0.35 }, 0.34, Ease.inQuad, d).then(() => p.destroy());
  });
  // Toplanma: karede büyüyen ışık
  const core = new Sprite(glowTex);
  core.anchor.set(0.5); core.blendMode = 'add'; core.tint = col; core.position.set(x, y);
  core.width = core.height = cell * 0.3; core.alpha = 0.9;
  fx.addChild(core);
  tween(core, { width: cell * 2.2, height: cell * 2.2 }, 0.38, Ease.inQuad).then(() => tween(core, { alpha: 0, width: cell * 3.4, height: cell * 3.4 }, 0.35, Ease.outCubic)).then(() => core.destroy());
  wait(0.38).then(() => {
    if (b.s.destroyed || b.firing || !b.glow || !b.pi) return;   // doğarken ateşlendiyse animasyon atlanır
    for (const sp of parts0) sp.alpha = 1;
    b.glow.alpha = 0.5;
    // Kare esneyerek oturur, simge yukarıdan büyük gelip yerine çakılır
    const k = b.s.scale.x;
    b.s.scale.set(k * 1.45, k * 0.6);
    tween(b.s.scale, { x: k, y: k }, 0.42, Ease.outBack);
    const ki = b.pi.scale.x, r0 = b.pi.rotation;
    b.pi.scale.set(ki * 1.9); b.pi.rotation = r0 - 0.5;
    tween(b.pi.scale, { x: ki, y: ki }, 0.38, Ease.outBack, 0.04);
    tween(b.pi, { rotation: r0 }, 0.4, Ease.outBack, 0.04).then(() => { b.born = true; });
    const fl = new Sprite(tex.white);
    fl.anchor.set(0.5); fl.blendMode = 'add'; fl.width = fl.height = cell; fl.position.set(x, y);
    fx.addChild(fl);
    tween(fl, { alpha: 0 }, 0.3, Ease.outQuad).then(() => fl.destroy());
    shockwave(x, y, 'pw_' + b.power, 1);
    sparkBurst(x, y, 16, col, cell * 1.6);
    // Altın halka ve altın kıvılcımlar (çerçeveyle uyumlu)
    const gr = new Sprite(ringTex);
    gr.anchor.set(0.5); gr.blendMode = 'add'; gr.tint = 0xffd23a; gr.position.set(x, y); gr.width = gr.height = cell;
    fx.addChild(gr);
    tween(gr, { width: cell * 3.4, height: cell * 3.4, alpha: 0 }, 0.5, Ease.outCubic).then(() => gr.destroy());
    sparkBurst(x, y, 10, 0xffd23a, cell * 1.2);
    A.bump(cell * 2);
    Sound.chest();
    Haptics.medium();
  });
}
// Büyük patlatmanın ardından: gücü, yerleştirilen parçanın patlatma merkezine en yakın boş karesine koy
function spawnPower(lines, rows, cols, p, r0, c0, ox, oy) {
  const kind = powerOf(lines);
  const dir = rows.length > cols.length ? 'h' : cols.length > rows.length ? 'v' : Math.random() < 0.5 ? 'h' : 'v';
  let best = null, bd = 1e9;
  const consider = (r, c) => { if (grid[r][c]) return; const d = Math.hypot(cx(c) - ox, cy(r) - oy); if (d < bd) { bd = d; best = [r, c]; } };
  p.shape.cells.forEach(([x, y]) => consider(r0 + y, c0 + x));
  if (!best) { for (const r of rows) for (let c = 0; c < N; c++) consider(r, c); for (const c of cols) for (let r = 0; r < N; r++) consider(r, c); }
  if (!best) return;
  const from = [];
  for (const r of rows) for (let c = 0; c < N; c++) from.push([cx(c), cy(r)]);
  for (const c of cols) for (let r = 0; r < N; r++) from.push([cx(c), cy(r)]);
  makePower(best[0], best[1], kind, dir, from);
}
function shineMaskDraw(b, cell) { b.shineMask.clear().roundRect(-cell * 0.42, -cell * 0.42, cell * 0.84, cell * 0.84, cell * 0.17).fill(0xffffff); }
// Bekleyen güçler canlı durur: roket ara ara titrer ve duman üfler, bombanın fitili çıtırdar, küre elektrikle titrer
function powerTick() {
  const A = PA(), cell = A.cs;
  for (let r = 0; r < A.rows; r++) for (let c = 0; c < A.cols; c++) {
    const b = A.at(r, c);
    if (!b || !b.power || !b.pi || b.firing) continue;
    // Doğarken de simge ve ışık bloğu izler (altındaki bloklar patlayıp düşerse havada kalmasın)
    if (!b.born) { b.pi.position.set(b.s.x, b.s.y); if (b.glow) b.glow.position.set(b.s.x, b.s.y); placeSpark(b); if (b.shineMask) b.shineMask.position.set(b.s.x, b.s.y); continue; }
    const t = time + b.seed, x = b.s.x, y = b.s.y, ki = cell / b.pi.texture.width, gy = y + A.dy;
    // Parçalar bloğu izler (tetriste satırlar kayar, tahta yükselir)
    b.glow.position.set(x, y);
    if (b.power !== 'rocket') b.pi.position.set(x, y);
    placeSpark(b);
    b.glow.alpha = 0.4 + 0.25 * Math.sin(t * 4);
    // Cam parlaması: her ~3 sn'de bir kareyi çapraz geçer; köşelerde ara ara yıldızcık
    if (b.shine) {
      b.shineMask.position.set(x, y);
      const sp = (t * 0.85) % 3;
      if (sp < 0.5) { const q = sp / 0.5; b.shine.position.set(x - cell * 0.8 + q * cell * 1.6, y); b.shine.alpha = Math.sin(Math.PI * q) * 0.8; } else b.shine.alpha = 0;
    }
    if (Math.random() < 0.007) {
      const tw = new Sprite(sparkTex);
      tw.anchor.set(0.5); tw.blendMode = 'add'; tw.tint = 0xfff3b0;
      tw.position.set(x + (Math.random() < 0.5 ? -1 : 1) * cell * 0.36, y + (Math.random() < 0.5 ? -1 : 1) * cell * 0.36);
      tw.width = tw.height = 0;
      A.over.addChild(tw);
      tween(tw, { width: cell * 0.5, height: cell * 0.5, rotation: 1.2 }, 0.2, Ease.outQuad).then(() => tween(tw, { width: 0, height: 0, rotation: 2.4 }, 0.25, Ease.inQuad)).then(() => tw.destroy());
    }
    if (b.power === 'rocket') {
      const ph = t % 2.2;
      const shake = ph < 0.35 ? Math.sin(ph * 90) * cell * 0.025 * (1 - ph / 0.35) : 0;
      b.pi.position.set(x + (b.dir === 'h' ? shake : 0), y + (b.dir === 'v' ? shake : 0));
      if (ph < 0.35 && Math.random() < 0.3) {
        const sgn = Math.random() < 0.5 ? -1 : 1, p = new Sprite(puffTex);
        p.anchor.set(0.5); p.tint = 0xdfe6ff; p.alpha = 0.5;
        p.position.set(x, gy); p.width = p.height = cell * 0.2;
        fx.addChild(p);
        tween(p, { x: x + (b.dir === 'h' ? 0 : sgn * cell * 0.4), y: gy + (b.dir === 'h' ? sgn * cell * 0.4 : 0) - cell * 0.1, width: cell * 0.5, height: cell * 0.5, alpha: 0 }, 0.5, Ease.outCubic).then(() => p.destroy());
      }
    } else if (b.power === 'prop') {
      // Pervane ara ara hızlanıp bir tur döner, hafifçe süzülür
      const ph = t % 2.4, q = Math.min(1, ph / 0.8);
      b.pi.rotation = ph < 0.8 ? Math.PI * 2 * (1 - Math.pow(1 - q, 3)) : 0;
      b.pi.position.set(x, y - Math.sin(t * 3) * cell * 0.03);
    } else if (b.power === 'bomb') {
      const k = ki * (1 + 0.04 * Math.sin(t * 7));
      b.pi.scale.set(k);
      b.spark.width = b.spark.height = cell * (0.35 + Math.random() * 0.25);
      b.spark.rotation = Math.random() * 6;
      b.spark.alpha = 0.7 + Math.random() * 0.3;
      if (Math.random() < 0.12) {
        const sp = new Sprite(sparkTex);
        sp.anchor.set(0.5); sp.blendMode = 'add'; sp.tint = 0xffc23a;
        sp.position.set(b.spark.x, b.spark.y + A.dy); sp.width = sp.height = cell * 0.18;
        fx.addChild(sp);
        const a = -Math.PI / 2 + (Math.random() - 0.5) * 2;
        tween(sp, { x: sp.x + Math.cos(a) * cell * 0.4, y: sp.y + Math.sin(a) * cell * 0.4, alpha: 0 }, 0.35, Ease.outCubic).then(() => sp.destroy());
      }
    } else {
      b.pi.scale.set(ki * (1 + 0.05 * Math.sin(t * 5)));
      b.spark.alpha = 0.18 + Math.random() * 0.25;
      b.spark.width = b.spark.height = cell * (0.9 + Math.random() * 0.2);
      if (Math.random() < 0.025) {
        const a = Math.random() * Math.PI * 2;
        lightning(x + Math.cos(a) * cell * 0.25, gy + Math.sin(a) * cell * 0.25, x + Math.cos(a) * cell * 0.75, gy + Math.sin(a) * cell * 0.75, 0.45);
      }
    }
  }
}
function dropPowerParts(b) {
  for (const k of ['shine', 'shineMask']) if (b[k]) { const s = b[k]; b[k] = null; if (!s.destroyed) s.destroy(); }
  for (const k of ['pi', 'spark']) if (b[k]) { const s = b[k]; b[k] = null; if (!s.destroyed) tween(s, { alpha: 0 }, 0.12).then(() => s.destroy()); }
}
// Güç ateşlenir: grid'den çoktan çıkarılmış olmalı. Önce kısa hazırlık, sonra patlama.
async function firePower(b, r, c) {
  const A = PA(), cell = A.cs, cx = A.px, cy = A.py, BX = A.left, BY = A.top, dy = A.dy;
  const x = b.s.x, y = b.s.y + dy, kind = b.power, col = colorHex['pw_' + kind];
  b.firing = true;
  dropOverlays(b);
  const jobs = [];
  let hits = 0;
  const force = kind === 'bomb' ? 1.25 : kind === 'rocket' ? 1 : 0.8;
  const hit = (rr, cc, d) => { if (rr < 0 || rr >= A.rows || cc < 0 || cc >= A.cols) return; if (A.at(rr, cc) || (A.dig && dig && dig.n[rr][cc] > 0)) hits++; jobs.push(A.kill(rr, cc, d, [x, kind === 'bolt' ? y - cell * 0.35 : y, force])); };
  const flashTile = () => { const fl = new Sprite(tex.white); fl.anchor.set(0.5); fl.blendMode = 'add'; fl.width = fl.height = cell; fl.position.set(x, y); fx.addChild(fl); tween(fl, { alpha: 0 }, 0.25).then(() => fl.destroy()); };
  if (kind === 'prop') {
    // Pervane: çevresindeki dört kareyi kırar, dönerek havalanır ve en tehlikeli hedefe uçup çarpar
    Sound.aim();
    const k = cell / powerIconTex.prop.width;
    dropPowerParts(b);
    popBlock(b.s, 'pw_prop', cell);
    const fly = new Sprite(powerIconTex.prop);
    fly.anchor.set(0.5); fly.scale.set(k); fly.position.set(x, y);
    fx.addChild(fly);
    for (const [dr, dc] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) hit(r + dr, c + dc, 0.06);
    const tgt = b.propTarget !== undefined ? b.propTarget : propTarget(r, c);
    let spinning = true;
    const spin = () => { if (!spinning || fly.destroyed) return; fly.rotation += 0.55; requestAnimationFrame(spin); };
    spin();
    await tween(fly.scale, { x: k * 1.35, y: k * 1.35 }, 0.18, Ease.outBack);
    if (tgt) {
      const [tr, tc] = tgt, sx = x, sy = y, ex = cx(tc), ey = cy(tr), lift = cell * 1.8, t0 = performance.now(), dur = 0.5;
      await new Promise((res) => {
        const step = () => {
          if (fly.destroyed) { res(); return; }
          const q = Math.min(1, (performance.now() - t0) / 1000 / dur), e = q < 0.5 ? 2 * q * q : 1 - Math.pow(-2 * q + 2, 2) / 2;
          fly.position.set(sx + (ex - sx) * e, sy + (ey - sy) * e - Math.sin(Math.PI * q) * lift);
          if (Math.random() < 0.6) {
            const p = new Sprite(glowTex);
            p.anchor.set(0.5); p.blendMode = 'add'; p.tint = 0x6dffb0; p.position.copyFrom(fly.position); p.width = p.height = cell * 0.5; p.alpha = 0.5;
            fx.addChildAt(p, fx.getChildIndex(fly));
            tween(p, { alpha: 0, width: cell * 0.15, height: cell * 0.15 }, 0.3).then(() => p.destroy());
          }
          if (q >= 1) { res(); return; }
          requestAnimationFrame(step);
        };
        step();
      });
      hit(tr, tc, 0);
      shake = Math.max(shake, 0.4);
      Haptics.medium();
      Sound.crack(true);
      const rg = new Sprite(ringTex);
      rg.anchor.set(0.5); rg.blendMode = 'add'; rg.tint = 0x6dffb0; rg.position.set(ex, ey); rg.width = rg.height = cell;
      fx.addChild(rg);
      tween(rg, { width: cell * 3.2, height: cell * 3.2, alpha: 0 }, 0.35, Ease.outCubic).then(() => rg.destroy());
      sparkBurst(ex, ey, 10, 0x6dffb0, cell * 1.6);
    }
    spinning = false;
    jobs.push(tween(fly.scale, { x: 0, y: 0 }, 0.16, Ease.inQuad).then(() => fly.destroy()));
  } else if (kind === 'rocket') {
    // Hazırlık: kare ısınıp beyaza döner, roket uçuş eksenine dik sarsılır
    Sound.aim();
    const pi = b.pi, v = b.dir === 'v';
    const ax = v ? 0 : 1, ay = v ? 1 : 0;   // uçuş ekseni
    const px = ay, py = ax;                 // dik eksen
    const heat = new Sprite(tex.white);
    heat.anchor.set(0.5); heat.blendMode = 'add'; heat.width = heat.height = cell; heat.position.set(x, y); heat.alpha = 0;
    fx.addChild(heat);
    tween(heat, { alpha: 0.75 }, 0.13, Ease.inQuad);
    for (let i = 0; i < 6; i++) { if (pi && !pi.destroyed) pi.position.set(x + px * (i % 2 ? 1 : -1) * cell * 0.045, y - dy + py * (i % 2 ? 1 : -1) * cell * 0.045); await wait(0.022); }
    tween(heat, { alpha: 0 }, 0.2).then(() => heat.destroy());
    dropPowerParts(b);
    popBlock(b.s, 'pw_' + kind, cell);
    Sound.fire();
    Haptics.heavy();
    shake = Math.max(shake, 0.5);
    A.bump(cell * 3);
    // Ateşleme: merkezde parlama, eksen boyunca basık şok halkası, iki yana kıvılcım konisi
    const fl = new Sprite(glowTex);
    fl.anchor.set(0.5); fl.blendMode = 'add'; fl.position.set(x, y); fl.width = fl.height = cell * 1.2;
    fx.addChild(fl);
    tween(fl, { width: cell * 3.2, height: cell * 3.2, alpha: 0 }, 0.3, Ease.outCubic).then(() => fl.destroy());
    const ring = new Sprite(ringTex);
    ring.anchor.set(0.5); ring.blendMode = 'add'; ring.tint = col; ring.position.set(x, y);
    ring.width = v ? cell * 0.5 : cell; ring.height = v ? cell : cell * 0.5;
    fx.addChild(ring);
    tween(ring, v ? { width: cell * 1.4, height: cell * 4.8, alpha: 0 } : { width: cell * 4.8, height: cell * 1.4, alpha: 0 }, 0.4, Ease.outCubic).then(() => ring.destroy());
    for (let i = 0; i < 16; i++) {
      const sgn = i % 2 ? 1 : -1, sp = new Sprite(sparkTex);
      sp.anchor.set(0.5); sp.blendMode = 'add'; sp.tint = i % 3 ? 0xffd27a : 0xffffff;
      sp.position.set(x, y); sp.width = sp.height = cell * (0.25 + Math.random() * 0.25);
      fx.addChild(sp);
      const spread = (Math.random() - 0.5) * 0.9, dd = cell * (1 + Math.random() * 1.5);
      tween(sp, { x: x + (ax * sgn + px * spread) * dd, y: y + (ay * sgn + py * spread) * dd, alpha: 0 }, 0.35 + Math.random() * 0.2, Ease.outCubic).then(() => sp.destroy());
    }
    const speed = cell * 24, acc = 1.5, edge = cell * 2.4;
    const lineFx = [];
    for (const sgn of [-1, 1]) {
      const rot = v ? (sgn > 0 ? Math.PI / 2 : -Math.PI / 2) : sgn > 0 ? 0 : Math.PI;
      // İz: renkli geniş ışın + beyaz ince lazer çekirdeği
      const mk = (tint, h) => { const t = new Sprite(beamTex); t.anchor.set(0, 0.5); t.blendMode = 'add'; t.tint = tint; t.rotation = rot; t.position.set(x, y); t.width = 1; t.height = h; fx.addChild(t); return t; };
      const st = mk(col, cell * 1.15), core = mk(0xffffff, cell * 0.3);
      lineFx.push(st, core);
      const ex = new Sprite(glowTex);
      ex.anchor.set(0.5); ex.blendMode = 'add'; ex.tint = 0xffa02a;
      fx.addChild(ex);
      const rk = new Sprite(rocketTex);
      rk.anchor.set(0.3, 0.5);
      rk.width = cell * 1.7; rk.height = cell * 0.85;
      rk.position.set(x, y); rk.rotation = rot;
      fx.addChild(rk);
      const kx = rk.scale.x;
      const toEdge = v ? (sgn > 0 ? BY + A.rows * cell - y : y - BY) : sgn > 0 ? BX + A.cols * cell - x : x - BX;
      const dist = toEdge + edge;
      const t0 = performance.now();
      let n = 0, out = false;
      const fly = () => {
        if (rk.destroyed) return;
        const t = (performance.now() - t0) / 1000;
        const d = Math.min(dist, speed * t * (1 + t * acc));
        const vel = speed * (1 + 2 * t * acc);
        const rx = x + ax * sgn * d, ry = y + ay * sgn * d;
        rk.position.set(rx, ry);
        rk.scale.x = kx * (1 + Math.min(0.3, vel / (cell * 120)));   // hızlandıkça uzar
        st.width = core.width = Math.max(1, Math.min(d, toEdge + cell * 0.5));
        ex.position.set(rx - ax * sgn * cell * 0.5, ry - ay * sgn * cell * 0.5);
        ex.width = ex.height = cell * (0.75 + Math.random() * 0.45);
        // Alev ve duman izi, ara ara yana kıvılcım
        if (++n % 2 === 0) {
          const f = new Sprite(glowTex); f.anchor.set(0.5); f.blendMode = 'add'; f.tint = n % 4 ? 0xffa02a : 0xfff0a0;
          f.position.copyFrom(ex.position); f.width = f.height = cell * 0.8;
          fx.addChildAt(f, fx.getChildIndex(rk)); tween(f, { width: cell * 0.15, height: cell * 0.15, alpha: 0 }, 0.3).then(() => f.destroy());
          const sm = new Sprite(puffTex); sm.anchor.set(0.5); sm.tint = 0x9aa0b4; sm.alpha = 0.3;
          sm.position.set(ex.x + px * (Math.random() - 0.5) * cell * 0.3, ex.y + py * (Math.random() - 0.5) * cell * 0.3); sm.width = sm.height = cell * 0.4;
          fx.addChildAt(sm, 0); tween(sm, { width: cell * 1.1, height: cell * 1.1, alpha: 0, x: sm.x + px * (Math.random() - 0.5) * cell * 0.6, y: sm.y + py * (Math.random() - 0.5) * cell * 0.6 }, 0.7, Ease.outCubic).then(() => sm.destroy());
        }
        // Tahtadan çıkış: kenarda kıvılcım patlaması
        if (!out && d >= toEdge) {
          out = true;
          const ex2 = x + ax * sgn * toEdge, ey2 = y + ay * sgn * toEdge;
          sparkBurst(ex2, ey2, 10, col, cell * 1.1);
          const eg = new Sprite(glowTex); eg.anchor.set(0.5); eg.blendMode = 'add'; eg.tint = col; eg.position.set(ex2, ey2); eg.width = eg.height = cell;
          fx.addChild(eg); tween(eg, { width: cell * 2.6, height: cell * 2.6, alpha: 0 }, 0.35, Ease.outCubic).then(() => eg.destroy());
        }
        if (d >= dist) { rk.destroy(); ex.destroy(); return; }
        requestAnimationFrame(fly);
      };
      fly();
    }
    // Kareler roket geçtikçe kesilir gibi parlar ve patlar (ivmeli uçuşa göre zamanlı)
    const at = (dpx) => (-speed + Math.sqrt(speed * speed + 4 * acc * speed * dpx)) / (2 * acc * speed);
    const slash = (sx, sy) => {
      const sl = new Sprite(beamTex);
      sl.anchor.set(0.5); sl.blendMode = 'add'; sl.rotation = v ? 0 : Math.PI / 2;
      sl.position.set(sx, sy); sl.width = cell * 1.4; sl.height = cell * 0.55;
      fx.addChild(sl);
      tween(sl, { height: 0, alpha: 0 }, 0.2, Ease.outQuad).then(() => sl.destroy());
    };
    let last = 0;
    for (let i = 1; i < Math.max(A.rows, A.cols); i++) {
      const d = at(i * cell);
      for (const sg of [-1, 1]) {
        const rr = r + ay * sg * i, cc = c + ax * sg * i;
        if (rr < 0 || rr >= A.rows || cc < 0 || cc >= A.cols) continue;
        jobs.push(wait(d).then(() => slash(cx(cc), cy(rr))));
        hit(rr, cc, d);
        last = Math.max(last, d);
      }
    }
    // İz, roketler çıkınca ince çizgiye çekilip söner
    jobs.push(wait(last + 0.12).then(() => Promise.all(lineFx.map((t) => tween(t, { height: 0, alpha: 0 }, 0.28, Ease.inQuad).then(() => t.destroy())))));
  } else if (kind === 'bomb') {
    // 1) Fitil yanar: kıvılcım fitilden bombaya iner; bomba hızlanan nabızla şişip kızarır, tahta hafif kararır
    const pi = b.pi, sp = b.spark, k = pi ? pi.scale.x : 1;
    const dim = new Graphics().rect(BX - cell * 0.2, BY - cell * 0.2, A.cols * cell + cell * 0.4, A.rows * cell + cell * 0.4).fill({ color: 0x1a0602 });
    dim.alpha = 0;
    fx.addChildAt(dim, 0);
    tween(dim, { alpha: 0.32 }, 0.3, Ease.outQuad);
    const heat = new Sprite(glowTex);
    heat.anchor.set(0.5); heat.blendMode = 'add'; heat.tint = 0xff3a1a; heat.position.set(x, y); heat.width = heat.height = cell * 1.4; heat.alpha = 0;
    fx.addChild(heat);
    tween(heat, { alpha: 0.9, width: cell * 2.6, height: cell * 2.6 }, 0.42, Ease.inQuad);
    if (sp) {
      tween(sp, { x: x + cell * 0.13, y: y - dy - cell * 0.14 }, 0.42, Ease.inQuad);   // kıvılcım fitil boyunca kapağa iner
      let n = 0;
      const burn = () => {
        if (!sp || sp.destroyed || n++ > 40) return;
        sp.width = sp.height = cell * (0.4 + Math.random() * 0.35);
        const e = new Sprite(sparkTex);
        e.anchor.set(0.5); e.blendMode = 'add'; e.tint = Math.random() < 0.5 ? 0xffd23a : 0xff7a1a;
        e.position.set(sp.x, sp.y + dy); e.width = e.height = cell * 0.2;
        fx.addChild(e);
        const a = -Math.PI / 2 + (Math.random() - 0.5) * 2.6, v = cell * (2 + Math.random() * 3);
        parts.push({ s: e, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0, life: 0.35 + Math.random() * 0.2, vr: 8, k0: e.scale.x });
        requestAnimationFrame(burn);
      };
      burn();
    }
    let sc = 1;
    for (const gap of [0.12, 0.095, 0.075, 0.06, 0.05]) {
      Sound.aim();
      sc += 0.07;
      if (pi && !pi.destroyed) { pi.tint = 0xff5a4a; tween(pi.scale, { x: k * sc * 1.06, y: k * sc * 0.96 }, gap * 0.45, Ease.outQuad); }
      await wait(gap * 0.5);
      if (pi && !pi.destroyed) { pi.tint = 0xffffff; tween(pi.scale, { x: k * sc, y: k * sc }, gap * 0.45, Ease.outQuad); }
      await wait(gap * 0.5);
    }
    // 2) Patlama anı: kısa bir beyaz çekirdek (donma hissi), sonra ateş topu ve şok dalgaları
    dropPowerParts(b);
    popBlock(b.s, 'pw_' + kind, cell);
    tween(heat, { alpha: 0 }, 0.2).then(() => heat.destroy());
    const core = new Sprite(glowTex);
    core.anchor.set(0.5); core.blendMode = 'add'; core.position.set(x, y); core.width = core.height = cell * 2.8;
    fx.addChild(core);
    flashTile();
    Sound.bomb();
    Haptics.heavy();
    setTimeout(() => Haptics.heavy(), 110);
    await wait(0.05);
    tween(core, { width: cell * 5.5, height: cell * 5.5, alpha: 0 }, 0.4, Ease.outCubic).then(() => core.destroy());
    shake = Math.max(shake, 1.4);
    A.bump(cell * 7);
    screenFlash(0.25, '#fff1c4');
    boardFlash('c1', 1);
    explosionFx(x, y);
    for (const [tint, to, dur, dl] of [[0xffffff, 8.5, 0.32, 0], [0xff8a2a, 6.5, 0.6, 0.04], [0xffd23a, 4.5, 0.5, 0.08]]) {
      const rg = new Sprite(ringTex);
      rg.anchor.set(0.5); rg.blendMode = 'add'; rg.tint = tint;
      rg.position.set(x, y); rg.width = rg.height = cell;
      fx.addChild(rg);
      tween(rg, { width: cell * to, height: cell * to, alpha: 0 }, dur, Ease.outCubic, dl).then(() => rg.destroy());
    }
    // Etki alanı: 5×5 kareler merkezden dışa dalga hâlinde yanar
    for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) {
      const rr = r + dr, cc = c + dc;
      if (rr < 0 || rr >= A.rows || cc < 0 || cc >= A.cols) continue;
      const w = new Sprite(tex.white);
      w.anchor.set(0.5); w.blendMode = 'add'; w.tint = 0xffb04a;
      w.width = w.height = cell * 0.94; w.position.set(cx(cc), cy(rr)); w.alpha = 0;
      fx.addChildAt(w, 1);
      const d = Math.hypot(dr, dc) * 0.045;
      tween(w, { alpha: 0.6 }, 0.05, Ease.outQuad, d).then(() => tween(w, { alpha: 0 }, 0.35, Ease.outQuad)).then(() => w.destroy());
    }
    // Közler: her yöne fırlayan, yerçekimiyle düşen kıvılcımlar
    for (let i = 0; i < 28; i++) {
      const e = new Sprite(i % 4 ? glowTex : sparkTex);
      e.anchor.set(0.5); e.blendMode = 'add'; e.tint = [0xffd23a, 0xff8a2a, 0xff5a1a, 0xffffff][i % 4];
      e.position.set(x, y); e.width = e.height = cell * (0.18 + Math.random() * 0.22);
      fx.addChild(e);
      const a = Math.random() * Math.PI * 2, v = cell * (7 + Math.random() * 10);
      parts.push({ s: e, vx: Math.cos(a) * v, vy: Math.sin(a) * v - cell * 4, t: 0, life: 0.6 + Math.random() * 0.45, vr: 6, k0: e.scale.x });
    }
    for (let dr = -2; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) if (dr || dc) hit(r + dr, c + dc, 0.03 + Math.hypot(dr, dc) * 0.045);
    // 3) Sonrası: alanda sönen köz parıltıları ve yükselen ince duman; karanlık açılır
    jobs.push(wait(0.35).then(() => {
      for (let i = 0; i < 9; i++) {
        const rr = r + Math.round((Math.random() - 0.5) * 4), cc = c + Math.round((Math.random() - 0.5) * 4);
        if (rr < 0 || rr >= A.rows || cc < 0 || cc >= A.cols) continue;
        const ex = cx(cc) + (Math.random() - 0.5) * cell * 0.5, ey = cy(rr) + (Math.random() - 0.5) * cell * 0.5;
        const g = new Sprite(glowTex);
        g.anchor.set(0.5); g.blendMode = 'add'; g.tint = 0xff6a1a; g.position.set(ex, ey); g.width = g.height = cell * 0.7; g.alpha = 0.7;
        fx.addChildAt(g, 1);
        tween(g, { alpha: 0, width: cell * 0.3, height: cell * 0.3 }, 0.7 + Math.random() * 0.4, Ease.inQuad, i * 0.03).then(() => g.destroy());
        const sm = new Sprite(puffTex);
        sm.anchor.set(0.5); sm.tint = 0x5a5460; sm.alpha = 0;
        sm.position.set(ex, ey); sm.width = sm.height = cell * 0.5;
        fx.addChild(sm);
        tween(sm, { alpha: 0.35 }, 0.15, Ease.outQuad, i * 0.04).then(() => tween(sm, { y: ey - cell * 1.2, width: cell * 1.4, height: cell * 1.4, alpha: 0 }, 0.9, Ease.outCubic)).then(() => sm.destroy());
      }
      return tween(dim, { alpha: 0 }, 0.45, Ease.outQuad).then(() => dim.destroy());
    }));
  } else {
    // 1) Şarj: tahta kararır, küre yükselir, çevreden enerji emer, etrafında dönen elektrik halkası
    const pi = b.pi, sp = b.spark, k = pi ? pi.scale.x : 1;
    const ox = x, oy = y - cell * 0.35;
    Sound.chest();
    Haptics.medium();
    const dim = new Graphics().rect(BX - cell * 0.2, BY - cell * 0.2, A.cols * cell + cell * 0.4, A.rows * cell + cell * 0.4).fill({ color: 0x02031a });
    dim.alpha = 0;
    fx.addChildAt(dim, 0);
    tween(dim, { alpha: 0.42 }, 0.25, Ease.outQuad);
    popBlock(b.s, 'pw_' + kind, cell);
    if (pi) { fx.addChild(pi); pi.position.set(x, y); tween(pi, { y: oy }, 0.4, Ease.outCubic); tween(pi.scale, { x: k * 1.55, y: k * 1.55 }, 0.4, Ease.outBack); }
    if (sp) { fx.addChildAt(sp, fx.getChildIndex(pi)); sp.position.set(x, y); sp.alpha = 1; tween(sp, { y: oy, width: cell * 2.6, height: cell * 2.6 }, 0.4, Ease.outCubic); }
    const rings = [0, 1].map((i) => {
      const rg = new Sprite(ringTex);
      rg.anchor.set(0.5); rg.blendMode = 'add'; rg.tint = i ? 0xffffff : 0x7ff0ff;
      rg.position.set(ox, oy); rg.width = rg.height = cell * 3; rg.alpha = 0;
      fx.addChild(rg);
      tween(rg, { alpha: 0.8, width: cell * (1.5 - i * 0.3), height: cell * (1.5 - i * 0.3) }, 0.4, Ease.outCubic);
      return rg;
    });
    for (let i = 0; i < 18; i++) {
      const a = Math.random() * Math.PI * 2, d = cell * (1.6 + Math.random() * 1.4);
      const e = new Sprite(sparkTex);
      e.anchor.set(0.5); e.blendMode = 'add'; e.tint = i % 3 ? 0x9fe8ff : 0xffffff;
      e.position.set(ox + Math.cos(a) * d, oy + Math.sin(a) * d); e.width = e.height = cell * 0.35; e.alpha = 0;
      fx.addChild(e);
      tween(e, { alpha: 1 }, 0.06, Ease.outQuad, i * 0.015);
      tween(e, { x: ox, y: oy, width: cell * 0.1, height: cell * 0.1 }, 0.3, Ease.inQuad, i * 0.015).then(() => e.destroy());
    }
    for (let i = 0; i < 7; i++) {
      wait(i * 0.055).then(() => {
        const a = Math.random() * Math.PI * 2;
        lightning(ox + Math.cos(a) * cell * 0.35, oy + Math.sin(a) * cell * 0.35, ox + Math.cos(a) * cell * (0.9 + i * 0.08), oy + Math.sin(a) * cell * (0.9 + i * 0.08), 0.5);
      });
    }
    let alive = true;
    const spinLoop = () => { if (!alive) return; rings.forEach((rg, i) => { if (!rg.destroyed) { rg.rotation += i ? -0.12 : 0.09; rg.scale.y = rg.scale.x * (0.92 + Math.random() * 0.12); } }); if (pi && !pi.destroyed) pi.rotation = (Math.random() - 0.5) * 0.12; requestAnimationFrame(spinLoop); };
    spinLoop();
    // 2) Hedefler: vurulacak kareler önce kısa bir an işaretlenir
    const targets = [];
    // Renk seçilmişse (kaydırma bölümü) o rengin bütün blokları, değilse rastgele 10 blok
    const want = b.boltColor;
    for (let rr = 0; rr < A.rows; rr++) for (let cc = 0; cc < A.cols; cc++) { const t = A.at(rr, cc); if (t && (!want || t.color === want)) targets.push([rr, cc]); }
    targets.sort(() => Math.random() - 0.5);
    const tg = want ? targets : targets.slice(0, 10);
    await wait(0.22);
    const marks = tg.map(([rr, cc], i) => {
      const m = new Sprite(tex.white);
      m.anchor.set(0.5); m.blendMode = 'add'; m.tint = 0x7ff0ff;
      m.position.set(cx(cc), cy(rr)); m.width = m.height = cell * 0.94; m.alpha = 0;
      fx.addChild(m);
      tween(m, { alpha: 0.4 }, 0.08, Ease.outQuad, i * 0.012);
      return m;
    });
    await wait(0.2);
    Haptics.heavy();
    screenFlash(0.18, '#cfe8ff');
    // 3) Vuruşlar: hızlanan ritimle şimşek; blok elektrikle titreyip parçalanır
    let tsum = 0;
    tg.forEach(([rr, cc], i) => {
      const d = tsum;
      tsum += Math.max(0.045, 0.1 - i * 0.008);
      const bb = A.at(rr, cc);
      jobs.push(wait(d).then(() => {
        lightning(ox, oy, cx(cc), cy(rr), 1.15, true);
        Sound.crack(true);
        if (i % 2 === 0) Haptics.light();
        boardFlash('pw_bolt', 0.25);
        if (pi && !pi.destroyed) { pi.scale.set(k * 1.75); tween(pi.scale, { x: k * 1.55, y: k * 1.55 }, 0.07); }
        const m = marks[i];
        if (m && !m.destroyed) { m.alpha = 0.9; tween(m, { alpha: 0 }, 0.18).then(() => m.destroy()); }
        const hg = new Sprite(glowTex);
        hg.anchor.set(0.5); hg.blendMode = 'add'; hg.tint = 0x9fe8ff;
        hg.position.set(cx(cc), cy(rr)); hg.width = hg.height = cell * 1.2;
        fx.addChild(hg);
        tween(hg, { width: cell * 2.4, height: cell * 2.4, alpha: 0 }, 0.3, Ease.outCubic).then(() => hg.destroy());
        // Elektriklenme: blok mavi yanar ve titrer
        if (bb && bb.s && !bb.s.destroyed) {
          const s0 = bb.s, x0 = s0.x, y0 = s0.y;
          s0.tint = 0xbff6ff;
          let j = 0;
          const jit = () => { if (s0.destroyed || j++ > 5) return; s0.position.set(x0 + (Math.random() - 0.5) * cell * 0.08, y0 + (Math.random() - 0.5) * cell * 0.08); requestAnimationFrame(jit); };
          jit();
        }
      }));
      hit(rr, cc, d + 0.09);
    });
    // 4) Final: küre aşırı yüklenir, şok dalgasıyla patlayıp söner
    jobs.push(wait(tsum + 0.1).then(async () => {
      alive = false;
      if (pi && !pi.destroyed) { pi.tint = 0xffffff; await tween(pi.scale, { x: k * 2.1, y: k * 2.1 }, 0.1, Ease.outQuad); }
      screenFlash(0.22, '#e6f6ff');
      shake = Math.max(shake, 0.6);
      for (let i = 0; i < 2; i++) {
        const rg = new Sprite(ringTex);
        rg.anchor.set(0.5); rg.blendMode = 'add'; rg.tint = i ? 0xffffff : 0x7ff0ff;
        rg.position.set(ox, oy); rg.width = rg.height = cell;
        fx.addChild(rg);
        tween(rg, { width: cell * 6, height: cell * 6, alpha: 0 }, 0.5 + i * 0.1, Ease.outCubic, i * 0.05).then(() => rg.destroy());
      }
      sparkBurst(ox, oy, 18, 0x9fe8ff, cell * 2);
      for (const rg of rings) if (!rg.destroyed) tween(rg, { width: cell * 3, height: cell * 3, alpha: 0 }, 0.25).then(() => rg.destroy());
      if (pi && !pi.destroyed) tween(pi.scale, { x: 0, y: 0 }, 0.14, Ease.inQuad);
      if (sp && !sp.destroyed) tween(sp, { width: cell * 4, height: cell * 4, alpha: 0 }, 0.3);
      tween(dim, { alpha: 0 }, 0.35, Ease.outQuad).then(() => dim.destroy());
      await wait(0.2);
      dropPowerParts(b);
    }));
  }
  await Promise.all(jobs);
  if (hits) addScore(hits * 20, x, y);
}
// Şimşek: kırık çizgi + çatallar; iki kez titreyip söner
function lightning(x0, y0, x1, y1, power = 1, fork = false) {
  const g = new Graphics();
  g.blendMode = 'add';
  fx.addChild(g);
  const path = () => {
    const len = Math.hypot(x1 - x0, y1 - y0), n = Math.max(5, Math.round(len / cell * 2.2)), pts = [[x0, y0]];
    const nx = -(y1 - y0) / (len || 1), ny = (x1 - x0) / (len || 1);
    for (let i = 1; i < n; i++) { const t = i / n, o = (Math.random() - 0.5) * Math.min(cell * 0.8, len * 0.25); pts.push([x0 + (x1 - x0) * t + nx * o, y0 + (y1 - y0) * t + ny * o]); }
    pts.push([x1, y1]);
    return pts;
  };
  const stroke = (pts, w) => {
    for (const [ww, col, a] of [[w * 3, 0x5a8cff, 0.35], [w * 1.2, 0xbff6ff, 1], [w * 0.5, 0xffffff, 1]]) {
      g.moveTo(pts[0][0], pts[0][1]);
      for (const [px, py] of pts.slice(1)) g.lineTo(px, py);
      g.stroke({ color: col, width: ww, alpha: a, cap: 'round', join: 'round' });
    }
  };
  const draw = () => {
    g.clear();
    const pts = path();
    stroke(pts, cell * 0.1 * power);
    if (fork) for (let i = 0; i < 2; i++) {
      const [fx0, fy0] = pts[2 + i * 2], a = Math.atan2(y1 - y0, x1 - x0) + (i ? 0.7 : -0.7), l = cell * (0.6 + Math.random() * 0.5);
      const fp = [[fx0, fy0], [fx0 + Math.cos(a) * l * 0.5 + (Math.random() - 0.5) * cell * 0.2, fy0 + Math.sin(a) * l * 0.5], [fx0 + Math.cos(a) * l, fy0 + Math.sin(a) * l]];
      stroke(fp, cell * 0.06 * power);
    }
  };
  draw();
  if (power >= 1) sparkBurst(x1, y1, 6, 0x9fe8ff, cell * 0.8);
  // Titreme: şekil iki kez yeniden çakar, sonra söner; uçta kısa ışık
  wait(0.04).then(() => { if (!g.destroyed) draw(); });
  wait(0.085).then(() => { if (!g.destroyed) draw(); });
  if (power >= 1) {
    const e = new Sprite(glowTex);
    e.anchor.set(0.5); e.blendMode = 'add'; e.tint = 0xbff6ff; e.position.set(x1, y1); e.width = e.height = cell * 1.4;
    fx.addChild(e);
    tween(e, { alpha: 0, width: cell * 0.4, height: cell * 0.4 }, 0.25, Ease.inQuad).then(() => e.destroy());
  }
  tween(g, { alpha: 0 }, 0.2, Ease.inQuad, 0.12).then(() => g.destroy());
}
// Güce dokununca ateşlenir
async function tapPower(r, c) {
  const b = grid[r][c], run = runId;
  busy = true;
  clearIdleHint();
  grid[r][c] = null;
  await firePower(b, r, c);
  if (run !== runId) return;   // güç zinciri sürerken oyundan çıkıldı / yeniden başlandı
  if (dig) await digReveal();
  if (run !== runId) return;
  busy = false;
  afterBoost();
}
function powerTipImage() {
  const S = 160, cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  x.drawImage(renderPower('bolt', S * 0.52), S * 0.24, 0);
  x.drawImage(renderPower('rocket', S * 0.52), 0, S * 0.46);
  x.drawImage(renderPower('bomb', S * 0.52), S * 0.48, S * 0.46);
  return cv.toDataURL();
}
// Deneme bölümü (tarayıcıda ?guc): hazır bir roket, bomba ve yıldırım; 2 satır birden patlatmaya hazır yerler
const POWER_DEMO = () => ({
  type: 'score', target: 4000, par: 20, bombTimer: 12, power: true,
  layout: ['........', '..Y.....', '........', 'xxxxxx..', 'xxxxBx..', '........', 'xxx.xxRx', 'xxx.xxxx'],
  goals: [],
});

function beam(x, y, len, vertical, color) {
  const b = new Sprite(beamTex);
  b.anchor.set(0.5);
  b.blendMode = 'add';
  b.position.set(x, y);
  if (vertical) b.rotation = Math.PI / 2;
  b.width = len;
  b.height = cell * 1.6;
  fx.addChild(b);
  const g = new Sprite(beamTex);
  g.anchor.set(0.5);
  g.blendMode = 'add';
  g.tint = colorHex[color] ?? themeHex;
  g.position.set(x, y);
  g.rotation = b.rotation;
  g.width = len;
  g.height = cell * 3;
  fx.addChild(g);
  b.width = g.width = cell;
  tween(b, { width: len }, 0.14, Ease.outCubic).then(() => tween(b, { alpha: 0, height: cell * 0.2 }, 0.32, Ease.inQuad)).then(() => b.destroy());
  tween(g, { width: len }, 0.16, Ease.outCubic).then(() => tween(g, { alpha: 0 }, 0.42, Ease.inQuad)).then(() => g.destroy());
}

const parts = [];
// ---------- Puan ve yazılar ----------
const FONT = 'ui-rounded, "SF Pro Rounded", "Arial Rounded MT Bold", system-ui';
const grad = (top, bottom) => new FillGradient({ type: 'linear', start: { x: 0, y: 0 }, end: { x: 0, y: 1 }, colorStops: [{ offset: 0, color: top }, { offset: 1, color: bottom }], textureSpace: 'local' });

// Renk grubu bölümünün ★★ puan ve ★★★ zincir bölmeleri
function updateSpecialChips() {
  if (!L || !L.bridge || !$('scTxt')) return;
  $('scTxt').textContent = score.toLocaleString('tr-TR');
  const f = Math.min(1, score / L.star2);
  $('scFill').style.width = `${f * 100}%`;
  const ch = Math.min(3, (fall && fall.maxChain) || 0);
  $('chTxt').textContent = `${ch}/3`;
  for (const [id, ok] of [['scChip', f >= 1], ['chChip', ch >= 3]]) {
    const el = $(id);
    if (ok && !el.classList.contains('done')) { el.classList.add('done', 'hit'); setTimeout(() => el.classList.remove('hit'), 650); Sound.star(2); Haptics.success(); }
  }
}
function addScore(n, x, y) {
  score += n;
  if (L && L.bridge) updateSpecialChips();
  if (x !== undefined) scorePop(n, x, y);
  if (mode === 'endless' && score >= 500) mission('endless', score);
  if (mode === 'endless' && score > best) { best = score; Store.set('best', best); $('best').textContent = best.toLocaleString('tr-TR'); }
}

// Kıvılcım patlaması: merkezden dışa saçılıp sönen ışık noktaları
function sparkBurst(x, y, n, tint, spread) {
  for (let i = 0; i < n; i++) {
    const sp = new Sprite(sparkTex);
    sp.anchor.set(0.5); sp.blendMode = 'add';
    sp.tint = i % 3 === 0 ? 0xffffff : tint;
    sp.width = sp.height = cell * (0.25 + Math.random() * 0.3);
    sp.position.set(x, y);
    fx.addChild(sp);
    const a = (i / n) * Math.PI * 2 + Math.random() * 0.5, d = spread * (0.6 + Math.random() * 0.6);
    tween(sp, { x: x + Math.cos(a) * d, y: y + Math.sin(a) * d * 0.7, alpha: 0, rotation: 3 }, 0.55 + Math.random() * 0.25, Ease.outCubic).then(() => sp.destroy());
  }
}

// Puan yazısı: sayarak yükselir, esneyerek belirir, süzülüp söner. Büyük puan altın/ateş renginde, ışıklı.
const SCORE_TIER = [
  { min: 0, size: 32, colors: ['#ffffff', '#bfe0ff'], glow: 0 },
  { min: 300, size: 42, colors: ['#fffbe0', '#ffc928'], glow: 0xffc23a },
  { min: 1000, size: 50, colors: ['#fff3c0', '#ff6a1a'], glow: 0xff7a2a },
];
// Puan yazısı: zincirleme patlamalarda üst üste yeni sayı çıkmaz; tek sayaç büyüyerek sayar, kademesi yükseldikçe
// rengi ve boyu değişir (beyaz → altın → ateş). Son eklemeden ~0,8 sn sonra süzülüp söner.
let curPop = null;
const popTier = (v) => (v >= 1000 ? 2 : v >= 300 ? 1 : 0);
// Hazır harf görüntüleri: büyük yazıların ve puan sayacının harfleri bir kez çizilip saklanır.
// (Her seferinde Pixi Text ile bulanık gölgeli, 3x çözünürlükte yeniden çizmek iPhone'da patlama anlarında takılma yapıyordu.)
const glyphCache = new Map();
const measureG = document.createElement('canvas').getContext('2d');
function glyph(ch, size, c0, c1, strokeW, shadow, fillOnly = false) {
  const key = ch + '|' + size + '|' + c0 + '|' + c1 + '|' + strokeW + '|' + (shadow ? shadow.blur + ',' + shadow.dist + ',' + shadow.alpha : '') + '|' + (fillOnly ? 1 : 0);
  let g = glyphCache.get(key);
  if (g) return g;
  const R = DPR, font = `900 ${size}px ${FONT}`;
  measureG.font = font;
  const adv = measureG.measureText(ch).width;
  const pad = Math.ceil(strokeW / 2 + (shadow ? shadow.blur * 1.5 : 0) + 2);
  const sd = shadow ? shadow.dist : 0;
  const lw = Math.ceil(adv + pad * 2), lh = Math.ceil(size * 1.2 + pad * 2 + sd);
  const cv = document.createElement('canvas');
  cv.width = Math.ceil(lw * R); cv.height = Math.ceil(lh * R);
  const x = cv.getContext('2d');
  x.scale(R, R);
  x.font = font; x.textAlign = 'center'; x.textBaseline = 'middle'; x.lineJoin = 'round'; x.miterLimit = 2;
  const cx = lw / 2, cy = pad + size * 0.6;
  if (!fillOnly) {
    if (shadow) {
      x.save();
      x.shadowColor = `rgba(0,0,24,${shadow.alpha})`; x.shadowBlur = shadow.blur * R; x.shadowOffsetY = sd * R;
      x.lineWidth = strokeW; x.strokeStyle = '#000018'; x.strokeText(ch, cx, cy); x.fillStyle = '#000018'; x.fillText(ch, cx, cy);
      x.restore();
    }
    if (strokeW) { x.lineWidth = strokeW; x.strokeStyle = shadow && shadow.stroke || '#10164a'; x.strokeText(ch, cx, cy); }
  }
  const gr = x.createLinearGradient(0, cy - size * 0.55, 0, cy + size * 0.55);
  gr.addColorStop(0, c0); gr.addColorStop(1, c1);
  x.fillStyle = gr;
  x.fillText(ch, cx, cy);
  g = { tex: Texture.from(cv), adv, w: lw, h: lh, ax: 0.5, ay: cy / lh, R };
  glyphCache.set(key, g);
  return g;
}
const glyphSprite = (g) => { const s = new Sprite(g.tex); s.anchor.set(g.ax, g.ay); s.scale.set(1 / g.R); return s; };
// Puan sayacının harfleri (kademe stiliyle)
const popGlyph = (ch, tier) => { const T = SCORE_TIER[tier]; return glyph(ch, T.size, T.colors[0], T.colors[1], tier ? 8 : 7, { blur: 4, dist: 4, alpha: 0.5, stroke: '#141a4a' }); };
function scorePop(n, x, y) {
  const now = performance.now();
  if (curPop && !curPop.box.destroyed && now - curPop.last < 850) { curPop.add(n); return; }
  curPop = makePop(n, x, y);
}
function makePop(n, x, y) {
  let total = n, tier = popTier(n), shown = -1;
  const box = new Container(), c = { v: n >= 50 ? Math.round(n * 0.25) : n };   // sayaç sıfırdan değil, çeyrekten başlar ("+0" görünmez)
  const gl = new Sprite(glowTex);
  gl.anchor.set(0.5); gl.blendMode = 'add'; gl.alpha = 0;
  // Sayı: hazır harf görüntülerinden dizilir (t.width / t.height sayının ölçüleri)
  const t = new Container();
  t.width0 = 0; t.h0 = SCORE_TIER[tier].size * 1.2;
  const setNum = (str) => {
    const kids = t.children;
    let w = 0;
    const gs = [...str].map((ch) => popGlyph(ch, tier));
    for (const g of gs) w += g.adv;
    let px = -w / 2;
    gs.forEach((g, i) => {
      let sp = kids[i];
      if (!sp) { sp = glyphSprite(g); t.addChild(sp); } else { sp.texture = g.tex; sp.anchor.set(g.ax, g.ay); sp.visible = true; }
      sp.x = px + g.adv / 2; px += g.adv;
    });
    for (let i = gs.length; i < kids.length; i++) kids[i].visible = false;
    t.width0 = w; t.h0 = SCORE_TIER[tier].size * 1.2;
  };
  box.addChild(gl, t);
  let badge = null;
  if (fire) {
    badge = new Text({ text: '×2', style: { fontFamily: FONT, fontWeight: '900', fontSize: 18, fill: grad('#fff6c8', '#ff7a1a'), stroke: { color: '#5a1400', width: 5, join: 'round' } } });
    badge.anchor.set(0.5); badge.rotation = 0.25; badge.scale.set(0);
    box.addChild(badge);
    tween(badge.scale, { x: 1, y: 1 }, 0.3, Ease.outBack, 0.12);
  }
  const clampX = (v) => { const hw = t.width0 / 2 + (badge ? 30 : 0); return Math.max(hw + 10, Math.min(W - hw - 10, v)); };
  box.position.set(clampX(x), y);
  fx.addChild(box);
  const glowUp = () => {
    const T = SCORE_TIER[tier];
    if (!T.glow) return;
    gl.tint = T.glow;
    gl.width = Math.max(80, t.width0 * 1.7); gl.height = t.h0 * 2.3;
    killTweens(gl);
    gl.alpha = 0.7;
    tween(gl, { alpha: 0 }, 0.7, Ease.inQuad, 0.15);
    sparkBurst(box.x, box.y, 6 + tier * 4, T.glow, cell * (1.4 + tier * 0.5));
  };
  // Belirme: esneyerek
  box.scale.set(0.2);
  tween(box.scale, { x: 1.25, y: 0.82 }, 0.1, Ease.outQuad).then(() => tween(box.scale, { x: 0.92, y: 1.12 }, 0.08, Ease.outQuad)).then(() => tween(box.scale, { x: 1, y: 1 }, 0.22, Ease.outBack));
  if (n >= 50) tween(c, { v: n }, 0.32 + tier * 0.08, Ease.outCubic);
  const P = {
    box, last: performance.now(), drawn: 0,
    add(m) {
      total += m;
      P.last = performance.now();
      killTweens(c);
      tween(c, { v: total }, 0.35, Ease.outCubic);
      const nt = popTier(total);
      if (nt > tier) { tier = nt; if (shown >= 0) setNum('+' + shown.toLocaleString('tr-TR')); glowUp(); }
      // Her eklemede tok bir "vuruş": büyüyüp yerine oturur
      killTweens(box.scale);
      box.scale.set(1.28);
      tween(box.scale, { x: 1, y: 1 }, 0.26, Ease.outBack);
      box.alpha = 1;
    },
  };
  glowUp();
  let prev = performance.now(), vy = -cell * 0.9;
  const loop = () => {
    if (box.destroyed) return;
    const now = performance.now(), dt = Math.min(0.05, (now - prev) / 1000);
    prev = now;
    const v = Math.round(c.v);
    if (v !== shown && (now - P.drawn > 30 || v === total)) { shown = v; P.drawn = now; setNum('+' + v.toLocaleString('tr-TR')); if (badge) badge.position.set(t.width0 / 2 + 12, -t.h0 * 0.32); box.x = clampX(box.x); }
    const idle = (now - P.last) / 1000;
    // Yavaşça yukarı süzülür; eklenince hızı tazelenir
    vy += (idle < 0.1 ? -cell * 0.9 - vy : -vy * 0.9) * Math.min(1, dt * 6);
    box.y += vy * dt;
    if (idle > 0.8) box.alpha -= dt * 3.2;
    if (box.alpha <= 0) { box.destroy({ children: true }); if (curPop === P) curPop = null; return; }
    requestAnimationFrame(loop);
  };
  loop();
  return P;
}

// Büyük yazı: harfler tek tek dönerek düşer, dalga gibi salınır, üstünden ışık geçer, sonra sırayla uçar.
// tier 3: kıvılcım patlaması
const measureCtx = document.createElement('canvas').getContext('2d');
// Ekranda aynı anda tek büyük yazı olur: yenisi gelince eskisi hızla yukarı uçup çekilir
let curBig = null;
function bigText(str, colors, glowHex, y, tier = 1, sub = null) {
  if (curBig) curBig();
  const size = 56, ls = 1;
  measureCtx.font = `900 ${size}px ${FONT}`;
  const chars = [...str];
  const adv = chars.map((ch) => measureCtx.measureText(ch).width + ls);
  const total = adv.reduce((a, b) => a + b, 0);
  const box = new Container();
  box.position.set(W / 2, y);
  // Ekrana sığsın: büyüme payı dahil iki yanda 20 px
  const fit = Math.min(1, (W - 40) / ((total + 24) * 1.12));
  // Arka plan: renkli ışık
  const gl = new Sprite(glowTex);
  gl.anchor.set(0.5); gl.blendMode = 'add'; gl.tint = glowHex;
  gl.width = Math.min(W, total * fit * 1.4); gl.height = size * fit * 2.6;
  gl.alpha = 0;
  fx.addChild(gl);
  gl.position.copyFrom(box.position);
  tween(gl, { alpha: 0.55 }, 0.15).then(() => tween(gl, { alpha: 0 }, 0.6, Ease.inQuad, 0.45)).then(() => { if (!gl.destroyed) gl.destroy(); });
  if (tier >= 3) sparkBurst(W / 2, y, 16, glowHex, cell * 3);
  fx.addChild(box);
  box.scale.set(fit);
  const letters = [];
  let px = -total / 2;
  chars.forEach((ch, i) => {
    const cx2 = px + adv[i] / 2;
    px += adv[i];
    if (ch === ' ') return;
    const t = glyphSprite(glyph(ch, size, colors[0], colors[1], 11, { blur: 6, dist: 6, alpha: 0.6, stroke: '#10164a' }));
    const sh = glyphSprite(glyph(ch, size, '#ffffff', '#ffffff', 11, { blur: 6, dist: 6, alpha: 0.6 }, true));
    sh.blendMode = 'add'; sh.alpha = 0;
    const L2 = new Container();
    L2.addChild(t, sh);
    L2.position.set(cx2, -size * 0.7);
    L2.alpha = 0;
    L2.scale.set(0.2);
    L2.rotation = (Math.random() - 0.5) * 0.8;
    box.addChild(L2);
    letters.push({ L2, sh, x: cx2, i });
    const d = i * 0.035;
    tween(L2, { alpha: 1 }, 0.08, Ease.linear, d);
    tween(L2, { y: 0, rotation: 0 }, 0.36, Ease.outBack, d);
    tween(L2.scale, { x: 1, y: 1 }, 0.36, Ease.outBack, d);
  });
  // Alt etiket (ör. KOMBO ×3): harfler oturunca altında küçük bir hap olarak belirir
  const introT = 0.36 + chars.length * 0.035;
  if (sub) {
    const sg = glyph(sub, 22, '#ffffff', '#ffffff', 0, null);
    const st = glyphSprite(sg);
    const pw = sg.adv + 34, ph = 36;
    const pill = new Container();
    const bg = new Graphics().roundRect(-pw / 2, -ph / 2, pw, ph, ph / 2).fill({ color: 0x1a2a8a }).stroke({ color: COMBO_HEX[Math.min(+sub.replace(/\D/g, '') || 2, 6)] ?? 0x4fd2ff, width: 3 });
    pill.addChild(bg, st);
    pill.position.set(0, size * 0.78);
    pill.scale.set(0);
    box.addChild(pill);
    tween(pill.scale, { x: 1, y: 1 }, 0.32, Ease.outBack, introT * 0.7);
  }
  // Bekleme: dalga salınımı + soldan sağa ışık süpürmesi + hüzme dönüşü
  const t0 = performance.now(), intro = introT;
  const live = () => {
    if (box.destroyed) return;
    const e = (performance.now() - t0) / 1000;
    if (e > intro) for (const l of letters) l.L2.y = Math.sin(e * 7 - l.i * 0.55) * 3;
    const sw = -total / 2 - 60 + ((e - intro + 0.05) / 0.45) * (total + 120);
    for (const l of letters) l.sh.alpha = e > intro - 0.05 ? Math.max(0, 1 - Math.abs(sw - l.x) / 38) * 0.75 : 0;
    requestAnimationFrame(live);
  };
  live();
  // Çıkış: normalde sırayla yukarı uçar; yeni yazı gelirse (hızlı) hepsi birden çekilir
  let gone = false;
  const exit = (fast) => {
    if (gone) return Promise.resolve();
    gone = true;
    if (curBig === kill) curBig = null;
    if (fast && !gl.destroyed) { killTweens(gl); tween(gl, { alpha: 0 }, 0.12).then(() => { if (!gl.destroyed) gl.destroy(); }); }
    for (const l of letters) { killTweens(l.L2); killTweens(l.L2.scale); }
    const d = fast ? 0.14 : 0.28, st = fast ? 0.006 : 0.02;
    tween(box, { y: box.y - (fast ? size * 0.5 : 0) }, d, Ease.inQuad);
    return Promise.all(letters.map((l) => Promise.all([
      tween(l.L2, { y: -size * 0.9, alpha: 0, rotation: (Math.random() - 0.5) * 0.5 }, d, Ease.inQuad, l.i * st),
      tween(l.L2.scale, { x: 1.2, y: 1.2 }, d, Ease.outQuad, l.i * st),
    ]))).then(() => { if (!box.destroyed) box.destroy({ children: true }); });
  };
  const kill = () => exit(true);
  curBig = kill;
  return wait(Math.max(0.85, intro + 0.45)).then(() => exit(false));
}
const praise = (s, sub = null) => bigText(s, ['#fff7c2', '#ffb31f'], 0xffc23a, BY + N * cell * 0.42, /Muhteşem|Tertemiz/.test(s) ? 3 : /Süper/.test(s) ? 2 : 1, sub);
const comboText = (n) => bigText('Kombo ×' + n, ['#e6fdff', '#4fd2ff'], COMBO_HEX[Math.min(n, 6)], BY + N * cell * 0.42, n >= 4 ? 2 : 1);

function renderProgress() {
  if (mode !== 'level' || !L || L.type !== 'score') return;
  const f = Math.min(1, shownScore / L.target);
  $('pfill').style.width = `${Math.max(f > 0 ? 8 : 0, f * 100)}%`;
  $('pcur').textContent = shownScore.toLocaleString('tr-TR');
  if ($('ptTxt')) {
    $('ptTxt').textContent = shownScore.toLocaleString('tr-TR');
    $('ptFill').style.width = `${f * 100}%`;
    const pc = $('ptChip');
    if (f >= 1 && !pc.classList.contains('done')) { pc.classList.add('done', 'hit'); setTimeout(() => pc.classList.remove('hit'), 650); }
    else if (f < 1) pc.classList.remove('done');
  }
  const box = $('progress');
  if (f >= 1 && !box.classList.contains('done')) {
    box.classList.add('done');
    box.querySelector('.pmedal').animate([{ transform: 'scale(1)' }, { transform: 'scale(1.3)' }, { transform: 'scale(1)' }], { duration: 500, easing: 'cubic-bezier(0.3, 1.6, 0.5, 1)' });
  } else if (f < 1) box.classList.remove('done');
}

function renderCombo() {
  const el = $('combo');
  el.innerHTML = combo < 2 ? '' : fire
    ? `<svg class="cb-flame"><use href="#c-flame"/></svg><span>KOMBO ×${combo}</span><b class="cb-mult">PUAN ×2</b>`
    : `KOMBO ×${combo}`;
  el.classList.toggle('show', combo >= 2);
  el.classList.toggle('fire', fire);
  el.classList.toggle('hot', fire && combo >= 6);    // yüksek komboda ateş beyaz-mavi kızışır
  if (fire && combo !== renderCombo.last) el.animate([{ transform: 'translateX(-50%) scale(1.25)' }, { transform: 'translateX(-50%) scale(1)' }], { duration: 380, easing: 'cubic-bezier(0.2, 1.6, 0.4, 1)' });
  renderCombo.last = fire ? combo : 0;

}

// ---------- Kombo ateş modu ----------
let fire = false, flameAcc = 0;
const flames = [];
function enterFire() {
  mission('fire');
  fireIgnite = 0; fireCombo = combo; fireHeat = 0;
  bigText('ATEŞ!', ['#fff6c8', '#ff6a14'], 0xff5a1f, BY + N * cell * 0.32, 3);
  Sound.fire();
  Haptics.heavy();
  setTimeout(() => Haptics.medium(), 120);
  $('fireGlow').classList.add('on');
  screenFlash(0.45, '#ff8a2a');
  shake = Math.max(shake, 0.6);
  // Tahtanın ortasından dışarı alev halkası
  const ox = BX + (N * cell) / 2, oy = BY + (N * cell) / 2;
  for (let i = 0; i < 26; i++) {
    const a = (i / 26) * Math.PI * 2;
    const f = new Sprite(flameTex);
    f.anchor.set(0.5, 0.8);
    f.blendMode = 'add';
    f.rotation = a + Math.PI / 2;
    f.position.set(ox, oy);
    f.height = cell * 1.6; f.width = cell * 1.05;
    fireLayer.addChild(f);
    const v = cell * (7 + Math.random() * 3);
    flames.push({ s: f, t: 0, life: 0.55, vx: Math.cos(a) * v, vy: Math.sin(a) * v, sway: 0, k0x: f.scale.x, k0y: f.scale.y, burst: true });
  }
  shockwave(ox, oy, 'c1', 4);
  const ty = BY + N * cell * 0.32 + cell * 0.7;
  for (let i = 0; i < 16; i++) addFlame(W / 2 + (i / 15 - 0.5) * Math.min(W * 0.7, cell * 6), ty, cell * (1.3 + Math.random() * 0.9), i % 2 === 1, 1.3);
}
function exitFire() {
  const was = fire;
  fire = false;
  $('fireGlow').classList.remove('on');
  if (!was || !boardLayer.visible) return;
  // Sönme: çerçeve boyunca yükselip dağılan duman bulutları
  for (let i = 0; i < 18; i++) {
    const [px, py] = spawnAt();
    const d = new Sprite(glowTex);
    d.anchor.set(0.5); d.tint = 0x6a6470; d.alpha = 0;
    d.position.set(px, py); d.width = d.height = cell * (0.8 + Math.random() * 0.7);
    fx.addChild(d);
    const k = d.scale.x;
    tween(d, { alpha: 0.38 }, 0.15, Ease.outCubic, Math.random() * 0.15)
      .then(() => tween(d, { y: py - cell * (1.2 + Math.random() * 1.2), x: px + (Math.random() - 0.5) * cell, alpha: 0 }, 0.9 + Math.random() * 0.4, Ease.outCubic))
      .then(() => d.destroy());
    tween(d.scale, { x: k * 2.2, y: k * 2.2 }, 1.2, Ease.outCubic);
  }
}
// Özel bölüm: çerçeve çevresinde süzülen altın parıltılar
let goldAcc = 0;
const golds = [];
function updateGold(dt) {
  if (theme.special && boardLayer.visible && !over) {
    goldAcc += dt * 7;
    while (goldAcc >= 1) {
      goldAcc--;
      const g = new Sprite(sparkTex);
      g.anchor.set(0.5);
      g.blendMode = 'add';
      g.tint = Math.random() < 0.7 ? 0xffd23a : 0xffffff;
      const bw = N * cell, t = Math.random() * 4;
      const e = Math.floor(t), u = (t % 1) * bw, o = cell * 0.2;
      g.position.set(e === 0 ? BX + u : e === 1 ? BX + bw + o : e === 2 ? BX + u : BX - o, e === 0 ? BY - o : e === 1 ? BY + u : e === 2 ? BY + bw + o : BY + u);
      g.width = g.height = cell * (0.22 + Math.random() * 0.22);
      g.alpha = 0;
      fx.addChild(g);
      golds.push({ s: g, t: 0, life: 1 + Math.random() * 0.8, k0: g.scale.x, vy: -cell * 0.4 });
    }
  }
  for (let i = golds.length - 1; i >= 0; i--) {
    const p = golds[i];
    p.t += dt;
    if (p.t > p.life || p.s.destroyed) { if (!p.s.destroyed) p.s.destroy(); golds.splice(i, 1); continue; }
    const k = p.t / p.life;
    p.s.alpha = Math.sin(k * Math.PI);
    p.s.y += p.vy * dt;
    p.s.rotation += dt * 2;
    p.s.scale.set(p.k0 * (0.6 + 0.6 * Math.sin(k * Math.PI)));
  }
}

// Ateş modunda tahtanın çevresinde titreyerek yükselen alevler ve kıvılcımlar
let emberAcc = 0;
let emitters = [];
function buildEmitters() {
  emitters = [];
  emitters.cell = cell;
  const bw = N * cell, step = cell * 0.9, o = cell * 0.06;
  for (let d = step / 2; d < bw; d += step) {
    emitters.push({ x: BX + d, y: BY + bw + o, h: 1.35, t: Math.random() * 0.3 });        // alt kenar: en yüksek alevler
    emitters.push({ x: BX + d, y: BY + o, h: 0.75, t: Math.random() * 0.3 });             // üst kenar: kısa alevler
    emitters.push({ x: BX - o, y: BY + d + step * 0.4, h: 1.0, t: Math.random() * 0.3 });  // sol kenar
    emitters.push({ x: BX + bw + o, y: BY + d + step * 0.4, h: 1.0, t: Math.random() * 0.3 }); // sağ kenar
  }
}
function spawnAt() {
  const bw = N * cell, side = Math.random();
  if (side < 0.36) return [BX + Math.random() * bw, BY + bw + cell * 0.12];
  if (side < 0.6) return [BX - cell * 0.08, BY + Math.random() * bw];
  if (side < 0.84) return [BX + bw + cell * 0.08, BY + Math.random() * bw];
  return [BX + Math.random() * bw, BY + cell * 0.05];
}
// Tek alev dili: dış (turuncu-kırmızı) ya da iç (sarı-beyaz çekirdek)
function addFlame(px, py, h, inner = false, vyMul = 1) {
  const f = new Sprite(flameTex);
  f.anchor.set(0.5, 0.9);
  f.blendMode = 'add';
  f.position.set(px, py);
  f.height = h; f.width = h * (inner ? 0.5 : 0.66);
  f.rotation = (Math.random() - 0.5) * 0.3;
  f.alpha = 0;
  f.tint = inner ? 0xfff2c0 : Math.random() < 0.5 ? 0xff8a3a : 0xffffff;
  fireLayer.addChild(f);
  flames.push({ s: f, t: 0, life: (inner ? 0.35 : 0.5) + Math.random() * 0.3, vx: 0, vy: -cell * (inner ? 1.4 : 1.1) * vyMul * (0.8 + Math.random() * 0.5), sway: Math.random() * 6, k0x: f.scale.x, k0y: f.scale.y, peak: inner ? 0.9 : 1 });
}
function updateFlames(dt) {
  if (fire && boardLayer.visible && !over) {
    // Çerçeve boyunca eşit aralıklı alev kaynakları: her biri kendi ritminde yanar (düzenli ateş çemberi)
    if (!fireFx && (!emitters.length || emitters.cell !== cell)) buildEmitters();
    for (const e of fireFx ? [] : emitters) {
      e.t -= dt;
      if (e.t > 0) continue;
      e.t = 0.2 + Math.random() * 0.12;
      addFlame(e.x + (Math.random() - 0.5) * cell * 0.15, e.y, cell * e.h * (0.85 + Math.random() * 0.3));
      if (Math.random() < 0.6) addFlame(e.x, e.y, cell * e.h * 0.55, true);
    }
    emberAcc += dt * 16;
    while (emberAcc >= 1) {
      emberAcc--;
      const e = new Sprite(sparkTex);
      e.anchor.set(0.5);
      e.blendMode = 'add';
      e.tint = Math.random() < 0.5 ? 0xffb030 : 0xff6a20;
      const [px, py] = spawnAt();
      e.position.set(px, py);
      e.width = e.height = cell * (0.12 + Math.random() * 0.12);
      fireLayer.addChild(e);
      flames.push({ s: e, t: 0, life: 0.7 + Math.random() * 0.5, vx: (Math.random() - 0.5) * cell, vy: -cell * (3 + Math.random() * 2.5), sway: Math.random() * 6, k0x: e.scale.x, k0y: e.scale.y, ember: true });
    }
  }
  for (let i = flames.length - 1; i >= 0; i--) {
    const p = flames[i];
    p.t += dt;
    if (p.t > p.life || p.s.destroyed) { if (!p.s.destroyed) p.s.destroy(); flames.splice(i, 1); continue; }
    const k = p.t / p.life;
    p.s.x += (p.vx + Math.sin(time * 9 + p.sway) * cell * (p.burst ? 0 : 0.5)) * dt;
    p.s.y += p.vy * dt;
    if (p.burst) {
      p.s.alpha = 1 - k;
      p.s.scale.set(p.k0x * (1 + k * 0.6), p.k0y * (1 - k * 0.5));
    } else if (p.ember) {
      p.s.alpha = (1 - k) * (0.6 + 0.4 * Math.sin(time * 30 + p.sway));
    } else {
      // Alev: hızla belirir, titrer, incelip söner
      const grow = Math.min(1, k * 4);
      p.s.alpha = (p.peak || 0.95) * grow * (1 - k * k);
      const flick = 1 + Math.sin(time * 26 + p.sway) * 0.08;
      p.s.scale.set(p.k0x * (1 - k * 0.45) * flick, p.k0y * (0.6 + grow * 0.5) * (1 - k * 0.3));
    }
  }
}

// Sade, düz simgeler: hamle = blok parçası, puan = kupa
const MV_ICO = '<svg viewBox="0 0 24 24" fill="currentColor"><rect x="6" y="2.5" width="5.6" height="5.6" rx="1.4"/><rect x="6" y="9" width="5.6" height="5.6" rx="1.4"/><rect x="6" y="15.5" width="5.6" height="5.6" rx="1.4"/><rect x="12.5" y="15.5" width="5.6" height="5.6" rx="1.4"/></svg>';
const PT_ICO = '<svg viewBox="0 0 24 24"><path d="M7 3.5h10v4.8a5 5 0 0 1-10 0z" fill="currentColor"/><path d="M7 5.6H4.6a2.6 2.6 0 0 0 2.8 3.6M17 5.6h2.4a2.6 2.6 0 0 1-2.8 3.6" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/><path d="M12 13.4v3.2M8.6 20.5h6.8M10 20.5l.5-3.9h3l.5 3.9" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
function renderGoals() {
  const box = $('goalBar');
  const scoreLvl = L.type === 'score' && !daily;
  const want = goals.length + (scoreLvl ? 1 : 0) + (L.escape ? 1 : 0) + (hasMoves() ? 1 : 0) + (timed() ? 1 : 0) + (timed() && L.bridge ? 2 : 0);
  if (box.childElementCount !== want) {
    box.replaceChildren(...goals.map((g, i) => {
      const d = document.createElement('div');
      d.className = 'goal goal-top';
      d.id = 'goal' + i;
      const img = document.createElement('img');
      img.src = iconURL[g.icon];
      const span = document.createElement('span');
      d.append(img, span);
      return d;
    }));
    if (scoreLvl) {
      // Puan bölümü: sade kupa simgesi, etiket, sayı ve dolan çizgi
      const pt = document.createElement('div');
      pt.className = 'goal-seg goal-pt'; pt.id = 'ptChip';
      pt.innerHTML = `<span class="sg-ico">${PT_ICO}</span><span class="sg-col"><small>PUAN</small><b><span id="ptTxt">0</span><small> / ${L.target.toLocaleString('tr-TR')}</small></b></span><i class="gt-bar"><i id="ptFill"></i></i>`;
      box.append(pt);
    }
    if (L.escape) {
      // Blok Kaçışı: kalan blok sayısı ve çıkan bloklarla dolan çizgi
      const e = document.createElement('div');
      e.className = 'goal-seg goal-pt goal-esc';
      e.innerHTML = `<span class="sg-ico">${ESC_ICO}</span><span class="sg-col"><small>BLOK</small><b id="escTxt">${L.esc.blocks.length}</b></span><i class="gt-bar"><i id="escFill"></i></i>`;
      box.append(e);
    }
    if (hasMoves()) {
      // Kalan hamle: sade blok simgesi, etiket, sayı ve azalan çizgi
      const m = document.createElement('div');
      m.className = 'goal-seg goal-mv';
      m.innerHTML = `<span class="sg-ico">${MV_ICO}</span><span class="sg-col"><small>HAMLE</small><b id="movesNum">${movesLeft}</b></span><i class="gt-bar"><i id="movesFill"></i></i>`;
      box.append(m);
    }
    if (timed() && L.bridge) {
      // Renk grubu bölümü: solda ★★ puan hedefi, sağda ★★★ zincir hedefi
      const sc = document.createElement('div');
      sc.className = 'goal-sc'; sc.id = 'scChip';
      sc.innerHTML = `<small>PUAN<em>★★</em></small><b><span id="scTxt">0</span><small> / ${L.star2.toLocaleString('tr-TR')}</small></b><i class="gt-bar"><i id="scFill"></i></i>`;
      box.append(sc);
    }
    if (timed()) {
      // Süreli özel bölüm: hedeflerin yanında kum saati, kalan süre ve incelen süre çizgisi
      const t = document.createElement('div');
      t.className = 'goal-time';
      t.id = 'timeChip';
      t.innerHTML = '<span class="gt-ico"><svg viewBox="0 0 24 24"><circle cx="12" cy="13.5" r="8" fill="none" stroke="currentColor" stroke-width="2.6"/><path d="M12 9.5v4.5l2.8 1.8M9.5 2.5h5M12 2.5v3" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/></svg></span><b id="timeTxt">0:00</b><i class="gt-bar"><i id="timeFill"></i></i>';
      box.append(t);
    }
    if (timed() && L.bridge) {
      const ch = document.createElement('div');
      ch.className = 'goal-ch'; ch.id = 'chChip';
      ch.innerHTML = '<small>ZİNCİR<em>★★★</em></small><b id="chTxt">0/3</b>';
      box.append(ch);
    }
    box.classList.toggle('has-bar', !!box.querySelector('.gt-bar'));
    if (hasMoves()) updateMoves(true);
    if (scoreLvl) renderProgress();
  }
  goals.forEach((g, i) => {
    const d = $('goal' + i);
    d.classList.toggle('done', g.shown <= 0);
    d.querySelector('span').textContent = g.shown <= 0 ? '' : g.shown;
  });
}

// ---------- Güçlendiriciler ----------
let targeting = null;            // 'hammer' | 'bomb' | null: tahtada hedef seçiliyor
let stuck = false, gaveUp = false; // bölüm modunda hamle kalmadı; oyuncu pes etti mi

function renderBoosters() {
  for (const el of document.querySelectorAll('.boost[data-k]')) {
    const k = el.dataset.k, n = boostCount(k);
    const c = el.querySelector('.bo-count');
    c.textContent = n > 0 ? n : '+';
    c.classList.toggle('buy', n <= 0);
    el.classList.toggle('active', targeting === k);
    el.classList.toggle('glow', stuck && !targeting);
    el.classList.toggle('free', freeB[k] > 0);
  }
}
function showHint(id, on) {
  const el = $(id);
  el.style.top = `${trayY}px`;
  el.classList.toggle('show', on);
}
function setTargeting(k) {
  targeting = k;
  if (aim) { aim.g.destroy({ children: true }); aim = null; }
  if (k) {
    $('boostHintText').textContent = BOOSTERS[k].hint;
    $('boostHintIco').className = 'bh-ico bo-ico ' + k;
    $('boostHintUse').setAttribute('href', '#i-' + k);
    if (!esc) {
      aim = makeAim(k);
      const [r, c] = bestAimCell(k);
      aimAt(r, c);
    }
  }
  showHint('boostHint', !!k);
  showHint('stuckBar', stuck && !k);
  if (esc) $('boostHint').style.top = `${H - safeB - BAR_H - 56}px`;
  trayLayer.alpha = k || stuck ? 0.3 : 1;
  renderBoosters();
}
function setStuck(on) {
  stuck = on;
  showHint('stuckBar', on && !targeting);
  trayLayer.alpha = targeting || on ? 0.3 : 1;   // sığmayan parçalar soluklaşır
  renderBoosters();
}

function onBoost(k) {
  if (busy || over || drag) return;
  if (boostCount(k) <= 0) return openShop(k);
  if (k === 'shuffle') { setTargeting(null); return esc ? escShuffle() : useShuffle(); }
  setTargeting(targeting === k ? null : k);
  Haptics.light();
}

// Tek bloğu efektle kaldırır (hedef simgesi varsa toplanır)
function smash(r, c, delay, from = null) {   // from: [x, y, güç] verilirse blok patlama merkezinden savrulur
  const b = grid[r][c];
  const dj = dig && dig.n[r][c] > 0 ? digHit(r, c, delay) : null;
  if (!b) return dj || Promise.resolve();
  if (b.power) { grid[r][c] = null; return Promise.all([dj, wait(delay).then(() => firePower(b, r, c))]); }   // zincirleme
  grid[r][c] = null;
  dropOverlays(b);
  const jobs = [wait(delay).then(() => (from ? blastBlock(b.s, b.color, from[0], from[1], from[2]) : popBlock(b.s, b.color)))];
  if (dj) jobs.push(dj);
  if (b.is) jobs.push(wait(delay).then(() => collectIcon(b)));
  return Promise.all(jobs);
}

// Güç patlamasıyla kırılan blok: bir an beyaz yanıp merkezden itilir, sonra parçaları dışa doğru savrulur
function blastBlock(s, key, ox, oy, force = 1, cell = mainCell()) {
  const { x: x0, y: y0 } = gpos(s), lx = s.x, ly = s.y;
  let dx = x0 - ox, dy = y0 - oy;
  const dl = Math.hypot(dx, dy) || 1;
  dx /= dl; dy /= dl;
  const fl = new Sprite(tex.white);
  fl.anchor.set(0.5); fl.blendMode = 'add'; fl.width = fl.height = cell; fl.position.set(x0, y0); fl.alpha = 0.9;
  fx.addChild(fl);
  const k = s.scale.x;
  return Promise.all([
    tween(fl, { alpha: 0 }, 0.16).then(() => fl.destroy()),
    tween(s, { x: lx + dx * cell * 0.16, y: ly + dy * cell * 0.16 }, 0.06, Ease.outQuad),
    tween(s.scale, { x: k * 1.12, y: k * 1.12 }, 0.06, Ease.outQuad),
  ]).then(() => {
    if (s.destroyed) return;
    const { x, y } = gpos(s);
    s.destroy();
    const hx = colorHex[key] ?? themeHex;
    shards(key).forEach((t, i) => {
      const sh = new Sprite(t);
      sh.anchor.set(0.5);
      sh.width = sh.height = cell * 0.5;
      const qx = i % 2 ? 1 : -1, qy = i < 2 ? -1 : 1;
      sh.position.set(x + qx * cell * 0.25, y + qy * cell * 0.25);
      fx.addChild(sh);
      const v = cell * (6 + Math.random() * 5) * force;
      parts.push({ s: sh, vx: (dx * 0.75 + qx * 0.35 + (Math.random() - 0.5) * 0.3) * v, vy: (dy * 0.75 + qy * 0.35 + (Math.random() - 0.5) * 0.3) * v - cell * 3, t: 0, life: 0.45 + Math.random() * 0.25, vr: qx * (6 + Math.random() * 10), k0: sh.scale.x });
    });
    const gl = new Sprite(glowTex);
    gl.anchor.set(0.5); gl.blendMode = 'add'; gl.tint = hx; gl.position.set(x, y);
    gl.width = gl.height = cell * 1.2; gl.alpha = 0.8;
    fx.addChild(gl);
    tween(gl, { width: cell * 2.2, height: cell * 2.2, alpha: 0 }, 0.3, Ease.outCubic).then(() => gl.destroy());
    const sp = new Sprite(sparkTex);
    sp.anchor.set(0.5); sp.blendMode = 'add'; sp.position.set(x, y); sp.width = sp.height = cell * 0.9; sp.rotation = Math.random() * 3;
    fx.addChild(sp);
    tween(sp, { width: 0, height: 0, rotation: sp.rotation + 2 }, 0.25, Ease.inQuad).then(() => sp.destroy());
  });
}

async function useHammer(r, c) {
  const b = grid[r][c];
  if (!b) { aimBad(); return; }
  useBoost('hammer');
  mission('booster');
  busy = true;
  setTargeting(null);
  bumpCount('hammer');
  const x = cx(c), y = cy(r);
  await hammerSwing(x, y, c >= N / 2 ? -1 : 1);
  Haptics.heavy();
  Sound.hammer();
  shake = 0.75;
  boardFlash(b.color, 0.6);
  impactFx(x, y, colorHex[b.color] ?? themeHex);
  crackFx(x, y);
  await wait(0.06);
  await smash(r, c, 0);
  if (dig) await digReveal();
  busy = false;
  afterBoost();
}

async function useBomb(r, c) {
  const cells = [];
  for (let y = r - 1; y <= r + 1; y++) for (let x = c - 1; x <= c + 1; x++) if (y >= 0 && y < N && x >= 0 && x < N && (grid[y][x] || (dig && dig.n[y][x] > 0))) cells.push([y, x]);
  if (!cells.length) { aimBad(); return; }
  useBoost('bomb');
  mission('booster');
  busy = true;
  setTargeting(null);
  bumpCount('bomb');
  const x = cx(c), y = cy(r);
  await bombDrop(x, y, r, c);
  Haptics.heavy();
  setTimeout(() => Haptics.heavy(), 110);
  Sound.bomb();
  shake = 1.3;
  screenFlash(0.35, '#fff1c4');
  explosionFx(x, y);
  boardFlash('c1', 1);
  await Promise.all(cells.map(([yy, xx]) => smash(yy, xx, 0.03 + Math.hypot(yy - r, xx - c) * 0.05)));
  if (dig) await digReveal();
  busy = false;
  afterBoost();
}

async function useShuffle() {
  if (!useBoost('shuffle')) return;
  mission('booster');
  busy = true;
  renderBoosters();
  bumpCount('shuffle');
  const ico = document.querySelector('.booster-bar .bo-ico.shuffle');
  if (ico) { ico.classList.remove('spin'); void ico.offsetWidth; ico.classList.add('spin'); }
  Haptics.medium();
  Sound.shuffle();
  const X = W / 2, Y = trayY;
  const vortex = vortexFx(X, Y);
  const old = tray.filter(Boolean);
  tray = [null, null, null];
  await Promise.all(old.map((t, i) => {
    const v = t.view, k = v.scale.x;
    killTweens(v); killTweens(v.scale);
    return tween(v, { x: X, y: Y, rotation: Math.PI * (1.2 + i * 0.3), alpha: 0.15, 'scale.x': k * 0.12, 'scale.y': k * 0.12 }, 0.4, Ease.inQuad, i * 0.05)
      .then(() => v.destroy({ children: true }));
  }));
  vortex.burst();
  Haptics.light();
  deal('center');
  await wait(0.5);
  vortex.stop();
  busy = false;
  afterBoost();
}

function afterBoost() {
  renderBoosters();
  if (mode === 'endless' && !daily) save();   // çekiç/bomba sonrası tahta kaydedilsin (DEVAM'da kırılan bloklar geri gelmesin)
  if (mode === 'level' && levelDone()) { setStuck(false); win(); return; }
  checkGameOver();
}

function bumpCount(k) {
  const el = document.querySelector(`.boost[data-k="${k}"] .bo-count`);
  if (!el) return;
  el.classList.remove('bump');
  void el.offsetWidth;
  el.classList.add('bump');
}

// ---------- Güçlendirici efektleri ----------
// Çekiç ve bomba çizimleri HTML'deki SVG simgelerinden dokuya çevrilir (düğmelerle aynı görünüm)
const boostTex = {};
function symbolTexture(id, px) {
  const sym = document.getElementById(id);
  if (!sym) return Promise.resolve(null);
  const refs = new Set([...sym.innerHTML.matchAll(/url\(#([\w-]+)\)/g)].map((m) => m[1]));
  const defs = [...refs].map((r) => document.getElementById(r)?.outerHTML || '').join('');
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${px}" height="${px}" viewBox="${sym.getAttribute('viewBox')}"><defs>${defs}</defs>${sym.innerHTML}</svg>`;
  const img = new Image();
  img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  return img.decode().then(() => {
    const c = document.createElement('canvas');
    c.width = c.height = px;
    c.getContext('2d').drawImage(img, 0, 0, px, px);
    return Texture.from(c);
  }).catch(() => null);
}
// Bomba simgesi her yerde tek tasarım: güç bombasının çizimi (güçlendirici çubuğu, mağaza, özel bölüm kutusu, düşen bomba)
{
  const sym = document.getElementById('i-bomb');
  if (sym) sym.innerHTML = `<image href="${renderPower('bomb', 192, 'icon').toDataURL()}" x="0" y="0" width="64" height="64"/>`;
}
for (const k of ['hammer', 'bomb']) symbolTexture('i-' + k, 192).then((t) => { boostTex[k] = t; });

// Hedefleme nişangâhı: parmağı izler, parmak kalkınca güçlendirici uygulanır
let aim = null;
function aimArea(k, r, c) {
  const R = k === 'bomb' ? 1 : 0;
  return { r0: Math.max(0, r - R), r1: Math.min(N - 1, r + R), c0: Math.max(0, c - R), c1: Math.min(N - 1, c + R) };
}
function makeAim(k) {
  const g = new Container();
  const frame = new Graphics();
  g.addChild(frame);
  let icon = null;
  if (boostTex[k]) {
    icon = new Sprite(boostTex[k]);
    icon.anchor.set(0.5);
    icon.width = icon.height = cell * 1.3;
    g.addChild(icon);
  }
  g.alpha = 0;
  fx.addChild(g);
  return { k, g, frame, icon, r: -1, c: -1, x: 0, y: 0, tx: 0, ty: 0, held: false, shown: 0, bad: 0 };
}
function drawAim(a) {
  const { r0, r1, c0, c1 } = aimArea(a.k, a.r, a.c);
  const w = (c1 - c0 + 1) * cell, h = (r1 - r0 + 1) * cell;
  const col = a.bad > 0 ? 0xff4a4a : a.k === 'bomb' ? 0xff7a2a : 0xffd84a;
  const f = a.frame;
  f.clear();
  f.roundRect(-w / 2, -h / 2, w, h, cell * 0.16).fill({ color: col, alpha: a.k === 'bomb' ? 0.22 : 0.16 });
  f.roundRect(-w / 2, -h / 2, w, h, cell * 0.16).stroke({ color: col, width: 3, alpha: 0.95 });
  const L = cell * 0.3, o = cell * 0.09;
  for (const [sx, sy] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
    const x = sx * (w / 2 + o), y = sy * (h / 2 + o);
    f.moveTo(x, y - sy * L).lineTo(x, y).lineTo(x - sx * L, y);
  }
  f.stroke({ color: 0xffffff, width: 3.5, cap: 'round', join: 'round' });
  a.w = w; a.h = h;
  a.tx = BX + ((c0 + c1 + 1) / 2) * cell;
  a.ty = BY + ((r0 + r1 + 1) / 2) * cell;
}
function aimAt(r, c) {
  if (!aim || (aim.r === r && aim.c === c)) return;
  const first = aim.r < 0;
  aim.r = r; aim.c = c;
  drawAim(aim);
  if (first) { aim.x = aim.tx; aim.y = aim.ty; return; }
  Haptics.tick();
  Sound.aim();
}
function aimBad() {
  Haptics.warning();
  Sound.back();
  if (aim) { aim.bad = 0.35; drawAim(aim); }
}
// İlk nişan: bombada en çok bloğu kapsayan, çekiçte merkeze en yakın dolu hücre
function bestAimCell(k) {
  let best = [Math.floor(N / 2), Math.floor(N / 2)], bestScore = -Infinity;
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    const { r0, r1, c0, c1 } = aimArea(k, r, c);
    let n = 0;
    for (let y = r0; y <= r1; y++) for (let x = c0; x <= c1; x++) if (grid[y][x]) n++;
    const score = n * 10 - Math.hypot(r - (N - 1) / 2, c - (N - 1) / 2);
    if (score > bestScore) { bestScore = score; best = [r, c]; }
  }
  return best;
}
function updateAim(dt) {
  if (!aim) return;
  const k = Math.min(1, dt * 22);
  aim.x += (aim.tx - aim.x) * k;
  aim.y += (aim.ty - aim.y) * k;
  aim.shown = Math.min(1, aim.shown + dt * 6);
  if (aim.bad > 0) { aim.bad -= dt; if (aim.bad <= 0) drawAim(aim); }
  const jolt = aim.bad > 0 ? Math.sin(time * 70) * cell * 0.08 : 0;
  aim.g.position.set(aim.x + jolt, aim.y);
  aim.g.alpha = aim.shown;
  aim.frame.scale.set((1 + Math.sin(time * 7) * 0.025) * (0.8 + 0.2 * aim.shown));
  if (aim.icon) {
    aim.icon.position.set(aim.w / 2 - cell * 0.1, -aim.h / 2 - cell * 0.45 + Math.sin(time * 5) * cell * 0.07);
    aim.icon.rotation = aim.k === 'hammer' ? -0.2 + Math.sin(time * 5) * 0.14 : Math.sin(time * 4) * 0.08;
  }
}

// Çekiç: havaya kalkar, geriye gerilir, hızla iner; vurduğu anda döner
const rotV = (p, a) => ({ x: p.x * Math.cos(a) - p.y * Math.sin(a), y: p.x * Math.sin(a) + p.y * Math.cos(a) });
function hammerSwing(tx, ty, m) {
  const t = boostTex.hammer;
  if (!t) return Promise.resolve();
  const S = cell * 2.3;
  const s = new Sprite(t);
  s.anchor.set(0.7, 0.8);                                  // sapın tutulduğu yer
  s.width = s.height = S;
  const k = s.scale.x;
  s.scale.x = k * m;                                       // sağ kenarda aynalanır
  const face = { x: m * (-34.5 / 64) * S, y: (-20.3 / 64) * S }; // vuran yüzün sapa göre yeri
  const hit = -0.12 * m;
  const f = rotV(face, hit);
  s.position.set(tx - f.x, ty - f.y);
  s.rotation = hit + 1.5 * m;
  s.alpha = 0;
  fx.addChild(s);
  return tween(s, { alpha: 1, rotation: hit + 1.0 * m }, 0.2, Ease.outBack)
    .then(() => tween(s, { rotation: hit + 1.3 * m }, 0.13, Ease.outQuad))
    .then(() => tween(s, { rotation: hit }, 0.085, Ease.inQuad))
    .then(() => {
      tween(s, { rotation: hit + 0.45 * m }, 0.14, Ease.outQuad)
        .then(() => tween(s, { alpha: 0, y: s.y - cell * 0.6, rotation: hit + 0.75 * m }, 0.22, Ease.inQuad))
        .then(() => s.destroy());
    });
}
// Darbe: beyaz parlama, halka, yıldız gibi saçılan kıvılcımlar, toz
function impactFx(x, y, hex) {
  const fl = new Sprite(glowTex);
  fl.anchor.set(0.5); fl.blendMode = 'add'; fl.position.set(x, y);
  fl.width = fl.height = cell * 1.2;
  fx.addChild(fl);
  tween(fl, { width: cell * 3.4, height: cell * 3.4, alpha: 0 }, 0.3, Ease.outCubic).then(() => fl.destroy());
  const ring = new Sprite(ringTex);
  ring.anchor.set(0.5); ring.blendMode = 'add'; ring.position.set(x, y);
  ring.width = ring.height = cell * 0.7;
  fx.addChild(ring);
  tween(ring, { width: cell * 3.6, height: cell * 3.6, alpha: 0 }, 0.36, Ease.outCubic).then(() => ring.destroy());
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2 + Math.random() * 0.4, v = cell * (7 + Math.random() * 5);
    const sp = new Sprite(sparkTex);
    sp.anchor.set(0.5); sp.blendMode = 'add'; sp.tint = i % 2 ? 0xffffff : hex;
    sp.width = sp.height = cell * (0.35 + Math.random() * 0.3);
    sp.position.set(x, y);
    fx.addChild(sp);
    parts.push({ s: sp, vx: Math.cos(a) * v, vy: Math.sin(a) * v - cell * 2, t: 0, life: 0.3 + Math.random() * 0.2, vr: 8, k0: sp.scale.x });
  }
  for (let i = 0; i < 5; i++) {
    const d = new Sprite(glowTex);
    d.anchor.set(0.5); d.tint = 0xe6d6b8; d.alpha = 0.4;
    const a = Math.PI * (0.1 + 0.8 * Math.random()) + (Math.random() < 0.5 ? 0 : Math.PI);
    d.position.set(x, y + cell * 0.3);
    d.width = d.height = cell * 0.6;
    fx.addChild(d);
    tween(d, { x: x + Math.cos(a) * cell * 1.1, y: y + cell * 0.2 - Math.abs(Math.sin(a)) * cell * 0.5, width: cell * 1.5, height: cell * 1.5, alpha: 0 }, 0.5 + Math.random() * 0.2, Ease.outCubic)
      .then(() => d.destroy());
  }
}
// Bloğun üzerinde bir anlık çatlaklar
function crackFx(x, y) {
  const g = new Graphics();
  const h = cell * 0.46;
  for (let i = 0; i < 5; i++) {
    let a = (i / 5) * Math.PI * 2 + Math.random() * 0.6, px = 0, py = 0;
    g.moveTo(0, 0);
    for (let j = 0; j < 3; j++) {
      const l = h * (0.3 + Math.random() * 0.25);
      a += (Math.random() - 0.5) * 0.9;
      px = Math.max(-h, Math.min(h, px + Math.cos(a) * l));
      py = Math.max(-h, Math.min(h, py + Math.sin(a) * l));
      g.lineTo(px, py);
    }
  }
  g.stroke({ color: 0x1a0f20, width: 2.4, alpha: 0.8, cap: 'round', join: 'round' });
  g.position.set(x, y);
  fx.addChild(g);
  tween(g, { alpha: 0 }, 0.14, Ease.linear, 0.06).then(() => g.destroy());
}

// Bomba: yukarıdan düşer, ezilip oturur, fitili kıvılcım saçarak yanar, kırmızı parlar
async function bombDrop(tx, ty, r, c, rect = null) {   // rect: [x, y, w, h] verilirse alan oradan çizilir (Blok Kaçışı)
  const zone = new Graphics();
  const { r0, r1, c0, c1 } = aimArea('bomb', r, c);
  const [zx, zy, zw, zh] = rect || [BX + c0 * cell, BY + r0 * cell, (c1 - c0 + 1) * cell, (r1 - r0 + 1) * cell];
  zone.roundRect(zx, zy, zw, zh, cell * 0.16)
    .fill({ color: 0xff3a2a, alpha: 0.25 })
    .stroke({ color: 0xff8a3a, width: 3 });
  fx.addChild(zone);
  const t = boostTex.bomb;
  if (!t) { await wait(0.3); zone.destroy(); return; }
  const S = cell * 1.6;
  const shadow = new Sprite(glowTex);
  shadow.anchor.set(0.5); shadow.tint = 0x000000; shadow.alpha = 0;
  shadow.position.set(tx, ty + cell * 0.42);
  shadow.width = cell * 0.5; shadow.height = cell * 0.18;
  fx.addChild(shadow);
  const heat = new Sprite(glowTex);
  heat.anchor.set(0.5); heat.blendMode = 'add'; heat.tint = 0xff3a1a; heat.alpha = 0;
  heat.position.set(tx, ty);
  heat.width = heat.height = cell * 2.2;
  fx.addChild(heat);
  const s = new Sprite(t);
  s.anchor.set(29 / 64, 37 / 64);                         // gövdenin merkezi
  s.width = s.height = S;
  const k = s.scale.x;
  s.position.set(tx, ty - cell * 4.5);
  s.rotation = -0.6; s.alpha = 0;
  fx.addChild(s);
  tween(shadow, { alpha: 0.6, width: cell * 1.5, height: cell * 0.45 }, 0.32, Ease.inQuad);
  await tween(s, { y: ty, rotation: 0.1, alpha: 1 }, 0.32, Ease.inQuad);
  Haptics.medium();
  Sound.land();
  for (const side of [-1, 1]) {
    const d = new Sprite(glowTex);
    d.anchor.set(0.5); d.tint = 0xe6d6b8; d.alpha = 0.45;
    d.position.set(tx + side * cell * 0.3, ty + cell * 0.45);
    d.width = d.height = cell * 0.6;
    fx.addChild(d);
    tween(d, { x: tx + side * cell * 1.2, width: cell * 1.4, height: cell * 1.1, alpha: 0 }, 0.45, Ease.outCubic).then(() => d.destroy());
  }
  await tween(s.scale, { x: k * 1.2, y: k * 0.78 }, 0.07, Ease.outQuad);
  await tween(s.scale, { x: k, y: k }, 0.18, Ease.outBack);
  // Fitil yanar: kıvılcımlar saçılır, bomba kızarıp şişer
  const tipX = (56.5 - 29) / 64 * S, tipY = (9 - 37) / 64 * S;
  for (let tt = 0; tt < 0.55; tt += 0.035) {
    const tip = rotV({ x: tipX * (s.scale.x / k), y: tipY * (s.scale.y / k) }, s.rotation);
    for (let i = 0; i < 2; i++) {
      const sp = new Sprite(sparkTex);
      sp.anchor.set(0.5); sp.blendMode = 'add';
      sp.tint = [0xffe066, 0xff9a2a, 0xffffff][(Math.random() * 3) | 0];
      sp.width = sp.height = cell * (0.22 + Math.random() * 0.25);
      sp.position.set(s.x + tip.x, s.y + tip.y);
      fx.addChild(sp);
      const a = -Math.PI / 2 + (Math.random() - 0.5) * 2.4, v = cell * (2 + Math.random() * 3);
      parts.push({ s: sp, vx: Math.cos(a) * v, vy: Math.sin(a) * v, t: 0, life: 0.25 + Math.random() * 0.15, vr: 6, k0: sp.scale.x });
    }
    const p = tt / 0.55;
    heat.alpha = (0.25 + 0.55 * p) * (0.6 + 0.4 * Math.sin(tt * 38));
    zone.alpha = 0.6 + 0.4 * Math.sin(tt * 30);
    s.scale.set(k * (1 + p * 0.22 + Math.sin(tt * 45) * 0.02));
    await wait(0.035);
  }
  s.destroy(); shadow.destroy(); heat.destroy(); zone.destroy();
}
// Patlama: beyaz çekirdek, alev topu, şok halkaları, duman, kor parçaları ve tahtada is izi
function explosionFx(x, y) {
  const scorch = new Sprite(glowTex);
  scorch.anchor.set(0.5); scorch.tint = 0x000000; scorch.alpha = 0.6;
  scorch.position.set(x, y);
  scorch.width = scorch.height = cell * 3.4;
  boardLayer.addChild(scorch);
  tween(scorch, { alpha: 0 }, 1.5, Ease.inQuad, 0.7).then(() => scorch.destroy());
  for (let i = 0; i < 9; i++) {
    const p = new Sprite(puffTex);
    p.anchor.set(0.5); p.tint = [0x5a5460, 0x6e6874, 0x7c7682][i % 3]; p.alpha = 0;
    const a = Math.random() * Math.PI * 2, d = cell * (0.4 + Math.random() * 0.8);
    p.position.set(x + Math.cos(a) * d * 0.4, y + Math.sin(a) * d * 0.4);
    p.width = p.height = cell * 1.3;
    fx.addChild(p);
    const sz = cell * (2.6 + Math.random() * 1.2);
    tween(p, { alpha: 0.4 }, 0.12, Ease.outQuad, 0.18)
      .then(() => tween(p, { x: x + Math.cos(a) * d * 2, y: y + Math.sin(a) * d * 1.5 - cell * 1.3, width: sz, height: sz, alpha: 0 }, 1 + Math.random() * 0.4, Ease.outCubic))
      .then(() => p.destroy());
  }
  // Alev topu: önce doygun turuncu-kırmızı bulutlar (normal karışım), üstünde sarı-beyaz sıcak çekirdek (ışık)
  const puffs = [
    [0xff4a14, 0], [0xff6a1a, 0], [0xff3a10, 0], [0xff8a24, 0], [0xff5a18, 0], [0xff7a1a, 0], [0xe8320e, 0],
    [0xffb02a, 1], [0xffd23a, 1], [0xffc030, 1], [0xfff0a0, 1], [0xffffff, 1],
  ];
  puffs.forEach(([tint, add], i) => {
    const p = new Sprite(add ? glowTex : puffTex);
    p.anchor.set(0.5); p.tint = tint;
    if (add) p.blendMode = 'add';
    const a = Math.random() * Math.PI * 2, d = add ? cell * 0.25 * Math.random() : cell * (0.5 + Math.random() * 0.9);
    p.position.set(x, y);
    p.width = p.height = cell * (add ? 0.9 : 1.1);
    p.alpha = add ? 1 : 0.95;
    fx.addChild(p);
    const to = add ? cell * (tint === 0xffffff ? 2.6 : 3.2 + Math.random()) : cell * (1.9 + Math.random() * 1.1);
    const dur = add ? 0.32 + Math.random() * 0.12 : 0.5 + Math.random() * 0.25;
    tween(p, { x: x + Math.cos(a) * d, y: y + Math.sin(a) * d - cell * 0.25, width: to, height: to }, dur, Ease.outCubic, i * 0.01);
    tween(p, { alpha: 0 }, dur, Ease.inQuad, i * 0.01).then(() => p.destroy());
  });
  [0xffb347, 0xffffff].forEach((tint, i) => {
    const ring = new Sprite(ringTex);
    ring.anchor.set(0.5); ring.blendMode = 'add'; ring.tint = tint;
    ring.position.set(x, y);
    ring.width = ring.height = cell;
    fx.addChild(ring);
    tween(ring, { width: cell * 8.5, height: cell * 8.5, alpha: 0 }, 0.6 + i * 0.1, Ease.outCubic, i * 0.05).then(() => ring.destroy());
  });
  for (let i = 0; i < 24; i++) {
    const sp = new Sprite(sparkTex);
    sp.anchor.set(0.5); sp.blendMode = 'add';
    sp.tint = [0xffe066, 0xffa53a, 0xff6a2a, 0xffffff][i % 4];
    sp.width = sp.height = cell * (0.25 + Math.random() * 0.4);
    sp.position.set(x, y);
    fx.addChild(sp);
    const a = Math.random() * Math.PI * 2, v = cell * (8 + Math.random() * 9);
    parts.push({ s: sp, vx: Math.cos(a) * v, vy: Math.sin(a) * v - cell * 6, t: 0, life: 0.5 + Math.random() * 0.45, vr: 10, k0: sp.scale.x });
  }
}

// Yenile: parçalar mavi bir girdaba çekilir, ortadan parıltıyla yenileri doğar
function vortexFx(X, Y) {
  const g = new Container();
  g.position.set(X, Y);
  fx.addChild(g);
  const core = new Sprite(glowTex);
  core.anchor.set(0.5); core.blendMode = 'add'; core.tint = 0x5ac8ff; core.alpha = 0;
  core.width = core.height = cell * 2;
  g.addChild(core);
  const R = cell * 2.4;
  const orbs = [];
  for (let i = 0; i < 18; i++) {
    const sp = new Sprite(sparkTex);
    sp.anchor.set(0.5); sp.blendMode = 'add';
    sp.tint = i % 3 ? 0x7fdcff : 0xffffff;
    sp.width = sp.height = cell * (0.25 + Math.random() * 0.25);
    g.addChild(sp);
    orbs.push({ sp, a: (i / 18) * Math.PI * 2, r: R * (0.35 + Math.random() * 0.65) });
  }
  let life = 0, ending = false;
  const tick = () => {
    const dt = Math.min(0.05, app.ticker.deltaMS / 1000);
    life += dt;
    core.alpha = Math.min(0.85, life * 4) * (ending ? 0 : 1) + (ending ? core.alpha * 0.9 : 0);
    core.rotation += dt * 3;
    for (const o of orbs) {
      o.a += dt * (5 + (R / Math.max(o.r, cell * 0.2)) * 1.6);
      o.r -= dt * cell * 2.6;
      if (o.r < cell * 0.15) o.r = R * (0.75 + Math.random() * 0.25);
      o.sp.position.set(Math.cos(o.a) * o.r, Math.sin(o.a) * o.r * 0.55);
      o.sp.alpha = Math.min(1, o.r / (cell * 0.6)) * Math.min(1, life * 5);
    }
  };
  app.ticker.add(tick);
  return {
    burst() {
      const fl = new Sprite(glowTex);
      fl.anchor.set(0.5); fl.blendMode = 'add'; fl.tint = 0xbfeaff;
      fl.position.set(X, Y);
      fl.width = fl.height = cell * 1.2;
      fx.addChild(fl);
      tween(fl, { width: cell * 5, height: cell * 5, alpha: 0 }, 0.45, Ease.outCubic).then(() => fl.destroy());
      const ring = new Sprite(ringTex);
      ring.anchor.set(0.5); ring.blendMode = 'add'; ring.tint = 0x7fdcff;
      ring.position.set(X, Y);
      ring.width = ring.height = cell;
      fx.addChild(ring);
      tween(ring, { width: W * 0.95, height: cell * 3.2, alpha: 0 }, 0.5, Ease.outCubic).then(() => ring.destroy());
      for (let i = 0; i < 16; i++) {
        const sp = new Sprite(sparkTex);
        sp.anchor.set(0.5); sp.blendMode = 'add'; sp.tint = i % 2 ? 0xffffff : 0x7fdcff;
        sp.width = sp.height = cell * (0.3 + Math.random() * 0.3);
        sp.position.set(X, Y);
        fx.addChild(sp);
        const a = Math.random() * Math.PI * 2, v = cell * (5 + Math.random() * 6);
        parts.push({ s: sp, vx: Math.cos(a) * v * 1.6, vy: Math.sin(a) * v * 0.7 - cell * 3, t: 0, life: 0.45 + Math.random() * 0.3, vr: 8, k0: sp.scale.x });
      }
    },
    stop() {
      ending = true;
      tween(g, { alpha: 0 }, 0.25).then(() => { app.ticker.remove(tick); g.destroy({ children: true }); });
    },
  };
}

// Hedef seçiliyken: tahtaya dokun ya da parmağını gezdir, bırakınca uygulanır; tahta dışı seçimi iptal eder
const boardCell = (p) => [Math.floor((p.y - BY) / cell), Math.floor((p.x - BX) / cell)];
app.stage.on('pointerdown', (e) => {
  if (!targeting && !busy && !over && !drag && !fall && mode === 'level' && L.power) {
    const [r, c] = boardCell(e.global);
    if (r >= 0 && r < N && c >= 0 && c < N && grid[r][c] && grid[r][c].power) return tapPower(r, c);
  }
  if (!targeting || busy || over || !aim) return;
  const [r, c] = boardCell(e.global);
  if (r < 0 || r >= N || c < 0 || c >= N) return setTargeting(null);
  aim.held = true;
  aimAt(r, c);
});
app.stage.on('globalpointermove', (e) => {
  if (!aim || !aim.held) return;
  const [r, c] = boardCell(e.global);
  aimAt(Math.max(0, Math.min(N - 1, r)), Math.max(0, Math.min(N - 1, c)));
});
function releaseAim(e) {
  if (!aim || !aim.held || busy || over) return;
  aim.held = false;
  // Parmak tahtadan çok uzakta kalktıysa uygulama, nişan yerinde beklesin
  const [r, c] = boardCell(e.global);
  if (r < -1 || r > N || c < -1 || c > N) return;
  if (targeting === 'hammer') useHammer(aim.r, aim.c);
  else if (targeting === 'bomb') useBomb(aim.r, aim.c);
}
app.stage.on('pointerup', releaseAim);
app.stage.on('pointerupoutside', releaseAim);

// Mağaza: altınla al ya da reklam izleyerek ücretsiz kazan
let shopKey = 'hammer';
function openShop(k) {
  shopKey = k;
  const B = BOOSTERS[k];
  $('shopIco').className = 'bo-ico big ' + k;
  $('shopUse').setAttribute('href', '#i-' + k);
  $('shopTitle').textContent = B.name;
  // Kum/özel bölümde bomba farklı çalışır: düşen parçayı bombaya çevirir, geniş alan patlar
  const sandBomb = k === 'bomb' && mode === 'level' && L && L.sand && fall;
  $('shopDesc').textContent = sandBomb ? `Düşen parçayı bombaya çevirir. Değdiği yerde ${bombRadius() * 2} kare genişliğinde bir alanı patlatır.` : B.desc;
  $('shopCoins').textContent = Wallet.coins.toLocaleString('tr-TR');
  $('shopPrice').textContent = B.price;
  $('shopPrice3').textContent = bundlePrice(k);
  $('shopOwn').textContent = Wallet.count(k);
  $('shopBuy').classList.toggle('poor', Wallet.coins < B.price);
  $('shopBuy3').classList.toggle('poor', Wallet.coins < bundlePrice(k));
  openPopup('shop');
}
const bundlePrice = (k) => Math.round((BOOSTERS[k].price * 3 * 0.8) / 2) * 2;   // 3'lü paket %20 indirimli
function grantBooster(k, n = 1, close = true) {   // close=false: reklam beklenirken mağaza kapatıldıysa başka pencereye dokunma
  Wallet.addBooster(k, n);
  if (close) closePopups();
  renderBoosters();
  updateCoins();
  Sound.coin();
  Haptics.success();
}

// ---------- Oyun sonu ----------
async function checkGameOver(reason = null) {
  if (tut && over) endTutorial();
  if (over) return;
  if (!reason) {
    const left = tray.filter(Boolean);
    if (!left.length || left.some((p) => fitsAnywhere(p.shape))) { if (stuck) setStuck(false); return; }
    if (mode === 'level' && !gaveUp) {
      if (!stuck) { setStuck(true); Haptics.warning(); Sound.back(); }
      return;
    }
  }
  const boom = reason === 'bomb';
  setStuck(false);
  exitFire();
  over = true;
  // Sonsuz oyunun canı başlarken harcandı; bitince kayıt silinir
  if (mode === 'endless') Store.set('save', '');
  Sound.lose();
  Haptics.error();
  const outOfMoves = reason === 'moves';
  overReason = reason;
  const stack = reason === 'stack';
  const timeUp = reason === 'time';
  const run = runId;
  await wait(0.5);   // bitiş yazısı yok: sonuç penceresi zaten nedeni yazar
  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) if (grid[r][c]) { grid[r][c].s.texture = tex.grey; if (grid[r][c].pi) grid[r][c].pi.tint = 0x8a8a8a; }
    await wait(0.05);
  }
  await wait(0.3);
  if (run !== runId) return;   // bu arada oyundan çıkıldıysa pencere açılmaz
  gamesPlayed++;
  const lvl = mode === 'level';
  $('overTitle').textContent = timeUp ? 'SÜRE BİTTİ!' : boom ? 'BOMBA PATLADI!' : outOfMoves ? 'HAMLE BİTTİ!' : stack ? 'TAHTA DOLDU!' : 'YER KALMADI!';
  $('overIcoUse').setAttribute('href', boom ? '#c-bombbig' : outOfMoves || timeUp ? '#c-hourglass' : '#c-boardfull');
  $('onIcoUse').setAttribute('href', boom ? '#c-bombbig' : outOfMoves || timeUp ? '#c-hourglass' : '#c-boardfull');
  $('reviveSub').textContent = timeUp ? 'Reklam izle · +30 saniye' : outOfMoves ? 'Reklam izle · +5 hamle' : boom ? 'Reklam izle · +6 hamle' : stack ? 'Reklam izle · tahta açılır' : 'Reklam izle';
  $('overLevel').textContent = lvl ? (daily ? 'Günlük Bulmaca' : `Bölüm ${levelN + 1}`) : '';
  $('overLevel').classList.toggle('hidden', !lvl);
  $('overLabel').textContent = lvl ? 'KALAN HEDEF' : 'SKOR';
  $('overScore').classList.toggle('hidden', lvl);
  $('overGoals').classList.toggle('hidden', !lvl);
  document.querySelector('#over .over-box').style.display = lvl && !goals.length ? 'none' : '';   // kum bölümünde hedef yok, yalnız süre
  $('overBestRow').classList.toggle('hidden', lvl);
  if (lvl) {
    // Hedef başına toplanan / toplam ve ilerleme çubuğu (çubuk açılışta dolarak gelir)
    $('overGoals').replaceChildren(...goals.map((g, i) => {
      const total = (L.goals && L.goals[i] && L.goals[i].count) || Math.max(1, g.left);
      const got = Math.max(0, total - Math.max(0, g.left));
      const d = document.createElement('div');
      d.className = 'og-chip' + (g.left <= 0 ? ' done' : '');
      d.style.animationDelay = `${0.45 + i * 0.1}s`;
      d.innerHTML = `<img src="${iconURL[g.icon]}" alt=""><span class="og-txt"><b>${got}<small> / ${total}</small></b><i class="og-bar"><i style="--f:${Math.round((got / total) * 100)}%"></i></i></span>`;
      return d;
    }));
  } else {
    $('overBest').textContent = best.toLocaleString('tr-TR');
    countUp($('overScore'), score);
  }
  const earned = lvl ? 0 : Math.max(0, Math.min(20, Math.floor(score / 400)) - coinsPaid);
  coinsPaid += earned;
  if (earned) Wallet.addCoins(earned);
  $('overCoins').textContent = earned;
  $('overCoinsRow').classList.toggle('hidden', !earned);
  const record = !lvl && score >= best && score > 0;
  $('newBest').classList.toggle('show', record);
  $('againLabel').textContent = lvl ? 'TEKRAR DENE' : 'TEKRAR OYNA';
  $('reviveBtn').classList.toggle('hidden', revived);
  // "Neredeyse!" — hedefe ne kadar kaldığını göster, altınla devam etmeyi teklif et
  $('over').classList.toggle('lvl', lvl);
  $('overNear').classList.toggle('hidden', !lvl);
  $('coinRevive').classList.toggle('hidden', !lvl);
  $('overStreak').classList.toggle('hidden', !(lvl && !daily));
  if (lvl) {
    $('overNearS').textContent = nearText();
    document.querySelector('#coinRevive .cr-text small').textContent = timeUp ? '+30 saniye' : outOfMoves ? '+5 hamle' : 'Tahta açılır';
    const price = contPrice();
    $('coinRevPrice').textContent = price.toLocaleString('tr-TR');
    $('coinRevive').classList.toggle('poor', Wallet.coins < price);
    $('overStreakT').innerHTML = (daily ? '' : 'Vazgeçersen <span class="ow-life">−1<svg><use href="#c-heart"/></svg></span>')
      + (!daily && streakN > 0 ? `<span class="ow-sep">·</span><span class="ow-streak"><svg><use href="#c-flame"/></svg>${streakN}</span> seri bozulur` : '');
  }
  openPopup('over');
  if (record) { confetti(70); Sound.praise(true); }
  if (!revived) startReviveTimer();
}

// Reklamla devam teklifi 6 saniye sürer; halka boşalınca teklif kaybolur
let reviveTimer = null;
function startReviveTimer() {
  const ring = $('reviveRing');
  ring.style.transition = 'none';
  ring.style.strokeDashoffset = '0';
  void ring.getBoundingClientRect();
  ring.style.transition = 'stroke-dashoffset 6s linear';
  ring.style.strokeDashoffset = '119.4';
  clearTimeout(reviveTimer);
  reviveTimer = setTimeout(() => $('reviveBtn').classList.add('hidden'), 6000);
}

// Sayı sıfırdan hedefe sayarak yükselir
function countUp(el, target) {
  const t0 = performance.now(), dur = Math.min(1200, 400 + target * 0.6);
  const step = (now) => {
    const f = Math.min(1, (now - t0) / dur);
    el.textContent = Math.round(target * (1 - (1 - f) ** 3)).toLocaleString('tr-TR');
    if (f < 1) requestAnimationFrame(step);
  };
  requestAnimationFrame(step);
}

// Konfeti: yukarıdan renkli küçük bloklar yağar
// Bölüm tamam ekranının zemininde konfeti (CSS; tahta tuvali bu sırada örtünün altında)
function cssConfetti(n) {
  const box = $('pbConfetti');
  box.replaceChildren();
  const cols = ['#ff4757', '#ff8c1a', '#ffcf1a', '#2ed573', '#1e90ff', '#a55eea', '#17d1e6', '#ffffff'];
  for (let i = 0; i < n; i++) {
    const e = document.createElement('i');
    const w = 7 + Math.random() * 7;
    e.style.cssText = `left:${Math.random() * 100}%;width:${w}px;height:${w * (0.45 + Math.random() * 0.4)}px;background:${cols[i % cols.length]};`
      + `--dx:${(Math.random() - 0.5) * 120}px;--r:${(Math.random() < 0.5 ? -1 : 1) * (360 + Math.random() * 540)}deg;animation-duration:${2.2 + Math.random() * 1.6}s;animation-delay:${Math.random() * 0.6}s`;
    box.appendChild(e);
  }
  setTimeout(() => box.replaceChildren(), 4600);
}
function confetti(n) {
  for (let i = 0; i < n; i++) {
    const s = new Sprite(tex['c' + (i % PALETTE.length)]);
    s.anchor.set(0.5);
    s.width = cell * (0.22 + Math.random() * 0.18);
    s.height = s.width * (0.5 + Math.random() * 0.5);
    s.position.set(Math.random() * W, -20 - Math.random() * H * 0.4);
    fx.addChild(s);
    parts.push({ s, vx: (Math.random() - 0.5) * cell * 3, vy: cell * (2 + Math.random() * 4), t: 0, life: 3 + Math.random() * 1.5, vr: (Math.random() - 0.5) * 12, k0: 0, conf: true });
  }
}

// Kalan hedefi tek cümleyle söyler: "Sadece 2 elmas kaldı!"
const GOAL_NAME = { gem: 'elmas', star: 'yıldız', heart: 'kalp', crown: 'taç', line: 'satır', t_chest: 'sandık', t_crown: 'taç', t_vase: 'vazo', t_key: 'anahtar' };
function nearText() {
  if (L.sand) return `Bitişe sadece ${clockText(timeLeft)} kaldı!`;
  if (esc) return `Sadece ${esc.st.blocks.length} blok kaldı!`;   // Blok Kaçışı: hedef sayacı yok, kalan blok sayılır
  if (L.type === 'score') return `Sadece ${Math.max(1, L.target - score).toLocaleString('tr-TR')} puan kaldı!`;
  const left = goals.filter((g) => g.left > 0);
  if (left.length === 1) return `Sadece ${left[0].left} ${GOAL_NAME[left[0].icon] || 'hedef'} kaldı!`;
  return `Sadece ${left.reduce((a, g) => a + g.left, 0)} hedef kaldı!`;
}
const contPrice = () => 400 * (paidRevives + 1);
$('coinRevive').addEventListener('click', () => {
  if (!$('over').classList.contains('show')) return;
  if (reviving) return;
  const price = contPrice();
  if (!Wallet.spend(price)) { toast('Yeterli altının yok'); Haptics.warning(); return; }
  paidRevives++;
  updateCoins();
  Sound.coin();
  revive(true);
});
let reviving = false;   // reklamlı devam yükleniyor/oynuyor: ikinci bir devam isteği yok sayılır
async function revive(paid = false) {
  if (reviving) return;
  clearTimeout(reviveTimer);
  if (!paid) {
    // Reklam yüklenirken (birkaç sn) oyuncu ana sayfaya ya da yeni bölüme geçmiş olabilir: o zaman devam uygulanmaz
    const run = runId;
    reviving = true;
    let ok = false;
    try { ok = await Ads.rewarded(); } finally { reviving = false; }
    if (!ok || run !== runId || !$('over').classList.contains('show')) return;
  }
  closePopups();
  if (!paid) revived = true;
  over = false;
  gaveUp = false;
  if (timed() && !L.sand) { timeLeft = Math.max(0, timeLeft) + 30; renderClock(); }   // dayanma bölümünde süre eklenmez (süre bitince kazanılır)
  if (L.escape) return;   // Blok Kaçışı: yalnız süre eklenir (tahta temizleme / parça dağıtma bu modda yok)
  if (fall) { await fallRevive(); return; }
  // Hamle bitti: tahta olduğu gibi kalır, yalnız +5 hamle
  if (hasMoves() && overReason === 'moves') { movesLeft += 5; updateMoves(); if (L.escape) return; if (tray.every((t) => !t)) deal(); checkGameOver(); return; }
  if (hasMoves()) { movesLeft += 5; updateMoves(); }
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    const b = grid[r][c];
    if (!b) continue;
    b.s.texture = tex[b.color];
    if (b.bomb !== undefined) { b.bomb += 6; b.tx.text = String(b.bomb); b.tx.style.fill = '#ffffff'; }
  }
  await clearLines([2, 3, 4, 5], [], W / 2, BY + N * cell / 2, 4);
  for (const t of tray) if (t) t.view.destroy({ children: true });
  tray = [null, null, null];
  deal();
  if (mode === 'level' && levelDone()) win();
}

function levelDone() {
  if (L.sand) return false;   // kum bölümü yalnız süre dolunca biter
  if (L.escape) return !!esc && !esc.st.blocks.length;
  return L.type === 'score' ? score >= L.target : goals.every((g) => g.left <= 0);
}

// Bölüm hamleler bitmeden geçilince: kalan her hamle sayaçtan tahtaya uçan altın yıldız olur, patlar, +100 puan
// Kalan hamle finali: her kalan hamle tahtaya uçan bir yıldız olur, indiği karede güce (roket / bomba) dönüşür
// ve puan verir; hepsi inince "PATLAT!" ile güçler sırayla ateşlenir, zincirleme tahtayı temizler.
async function movesFinale() {
  const chip = $('movesNum') && $('movesNum').closest('.goal-mv');
  const rc = chip ? chip.getBoundingClientRect() : null;
  const sx = rc ? rc.left + rc.width / 2 : W / 2, sy = rc ? rc.top + rc.height / 2 : BY - 60;
  const total = movesLeft, shown = Math.min(total, 12), PER = 250, run = runId;
  // Ekrana dokununca final hızlanır: yeni yıldız atılmaz, kalan hamleler toplu puana döner, güçler aynı anda patlar
  let skip = false, onSkip;
  const skipP = new Promise((r) => (onSkip = r));
  const hint = document.createElement('div');
  hint.className = 'skip-hint';
  hint.textContent = 'Geçmek için dokun';
  document.body.appendChild(hint);
  const tap = () => { if (skip) return; skip = true; onSkip(); hint.classList.add('gone'); Haptics.light(); };
  addEventListener('pointerdown', tap, true);
  const sw = (t) => (skip ? Promise.resolve() : Promise.race([wait(t), skipP]));
  try {
  bigText('Kalan Hamle!', ['#fff7c2', '#ffb31f'], 0xffc23a, BY + N * cell * 0.42, 2, `${total} HAMLE · GÜCE DÖNÜŞÜYOR`);
  if (chip) chip.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.2)' }, { transform: 'scale(1)' }], { duration: 420, easing: 'cubic-bezier(0.3, 1.6, 0.5, 1)' });
  await sw(0.7);
  // Hedef kareler: önce boş kareler, sonra düz bloklar; tahtaya dağılsın diye karışık
  const empty = [], plain = [];
  for (let r = 0; r < N; r++) for (let c = 0; c < N; c++) {
    const b = grid[r][c];
    if (!b) empty.push([r, c]);
    else if (!b.power && !b.is && !b.kind && !b.need && !b.moss) plain.push([r, c]);
  }
  const mix = (a) => { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
  const targets = [...mix(empty), ...mix(plain)];
  const gap = Math.max(0.11, Math.min(0.2, 1.8 / shown));
  const made = [];
  const lands = [];
  for (let i = 0; i < shown && i < targets.length; i++) {
    if (skip) break;
    movesLeft--;
    updateMoves();
    const [tr, tc] = targets[i];
    const tx = cx(tc), ty = cy(tr);
    // Kuyruklu altın yıldız: sayaçtan kavis çizerek kareye uçar
    const st = new Sprite(sparkTex);
    st.anchor.set(0.5); st.blendMode = 'add'; st.tint = 0xffd23a;
    st.width = st.height = cell * 1.1; st.position.set(sx, sy);
    fx.addChild(st);
    const core = new Sprite(glowTex);
    core.anchor.set(0.5); core.blendMode = 'add'; core.tint = 0xfff3b0; core.width = core.height = cell * 0.9;
    fx.addChild(core);
    const mid = { x: (sx + tx) / 2 + (Math.random() - 0.5) * cell * 3, y: Math.min(sy, ty) - cell * 1.6 };
    const path = { t: 0 };
    let tick = 0;
    const fly = () => {
      if (st.destroyed) return;
      const t = path.t, u = 1 - t;
      st.x = u * u * sx + 2 * u * t * mid.x + t * t * tx;
      st.y = u * u * sy + 2 * u * t * mid.y + t * t * ty;
      core.position.copyFrom(st.position);
      st.rotation += 0.35;
      if (++tick % 2 === 0) {
        const tr2 = new Sprite(glowTex);
        tr2.anchor.set(0.5); tr2.blendMode = 'add'; tr2.tint = 0xffc23a; tr2.position.copyFrom(st.position); tr2.width = tr2.height = cell * 0.6;
        fx.addChildAt(tr2, 0);
        tween(tr2, { alpha: 0, width: cell * 0.1, height: cell * 0.1 }, 0.32).then(() => tr2.destroy());
      }
      requestAnimationFrame(fly);
    };
    fly();
    const kind = i % 4 === 3 ? 'bomb' : 'rocket', dir = i % 2 ? 'v' : 'h';
    lands.push(tween(path, { t: 1 }, 0.38, Ease.inQuad).then(() => {
      st.destroy(); core.destroy();
      if (runId !== run) return;
      const old = grid[tr][tc];
      if (old) { grid[tr][tc] = null; dropOverlays(old); popBlock(old.s, old.color); }
      const b = makePower(tr, tc, kind, dir);
      // Güç kareye çakılır: beyaz parlama, altın halka, kıvılcımlar
      const k = b.s.scale.x;
      b.s.scale.set(k * 1.6);
      tween(b.s.scale, { x: k, y: k }, 0.3, Ease.outBack);
      if (b.pi) { const kp = b.pi.scale.x; b.pi.scale.set(kp * 1.6); tween(b.pi.scale, { x: kp, y: kp }, 0.3, Ease.outBack); }
      const fl = new Sprite(tex.white);
      fl.anchor.set(0.5); fl.blendMode = 'add'; fl.width = fl.height = cell; fl.position.set(tx, ty);
      fx.addChild(fl);
      tween(fl, { alpha: 0 }, 0.25).then(() => fl.destroy());
      const ring = new Sprite(ringTex);
      ring.anchor.set(0.5); ring.blendMode = 'add'; ring.tint = 0xffd23a; ring.position.set(tx, ty); ring.width = ring.height = cell * 0.6;
      fx.addChild(ring);
      tween(ring, { width: cell * 2.4, height: cell * 2.4, alpha: 0 }, 0.4, Ease.outCubic).then(() => ring.destroy());
      sparkBurst(tx, ty, 12, 0xffd23a, cell * 1.4);
      boardBump.v += cell * 1.5;
      addScore(PER, tx, ty);
      made.push([tr, tc]);
      Sound.gem(i);
      Haptics.light();
    }));
    await sw(gap);
  }
  await Promise.all(lands);
  if (runId !== run) return;
  if (movesLeft > 0) { const rest = movesLeft; movesLeft = 0; updateMoves(); addScore(rest * PER, W / 2, BY + N * cell / 2); }
  await sw(0.45);
  if (!made.length) return;
  // PATLAT: güçler sırayla ateşlenir, birbirini zincirleme tetikler
  bigText('PATLAT!', ['#fff1e8', '#ff6a3c'], 0xff5a2a, BY + N * cell * 0.42, 3);
  Haptics.heavy();
  await sw(0.4);
  const jobs = [];
  for (const [r, c] of made) {
    const b = grid[r][c];
    if (!b || !b.power) continue;
    grid[r][c] = null;
    jobs.push(firePower(b, r, c));
    await (skip ? wait(0.03) : sw(0.14));
  }
  await Promise.all(jobs);
  await sw(0.25);
  if (grid.every((row) => row.every((b) => !b))) { praise('Tertemiz!'); Sound.perfect(); }
  boardFlash('c2', 0.7);
  await sw(0.9);
  } finally {
    removeEventListener('pointerdown', tap, true);
    hint.classList.add('gone');
    setTimeout(() => hint.remove(), 400);
  }
}
async function win() {
  lifeAtRisk = false;
  if (tut) endTutorial(true);   // öğretici bölümü geçildi: balon ve gösterim kapanır
  if (escTut) escTutEnd(true);
  if (daily) return winDaily();
  over = true;
  setWinMode(false);
  if (L.special) { $('winRibbon').textContent = 'ÖZEL BÖLÜM TAMAM!'; $('winRibbon').style.fontSize = '0.8em'; }
  else if (L.superHard) { $('winRibbon').textContent = 'SÜPER ZOR GEÇİLDİ!'; $('winRibbon').style.fontSize = '0.8em'; }
  if (levelN >= TOTAL_LEVELS - 1) {
    document.querySelector('#winNext .lbl-long').textContent = 'BÜYÜK FİNAL';
    document.querySelector('#winNext .lbl-short').textContent = 'FİNAL';
  }
  Sound.win();
  const run = runId;
  // Kısa kutlama: tahta parlar, sonra pencere açılır
  Haptics.success();
  boardFlash('c3', 0.9);
  await wait(0.45);
  // Kalan hamle finali: her kalan hamle tahtaya uçan bir yıldıza dönüşür, patlar, puan verir
  if (hasMoves() && movesLeft > 0 && !L.escape) { await movesFinale(); if (runId !== run) return; }
  // Yıldız: hedefe ne kadar az parçayla ulaşıldı
  const par = L.par;
  const sandGoal = L.sand ? Math.max(2, Math.round(L.timeLimit / 12)) : 0;   // 3 yıldız için patlatılacak satır
  const stars = L.bridge
    ? 1 + (score >= L.star2 ? 1 : 0) + ((fall.maxChain || 0) >= 3 ? 1 : 0)   // ★ dayan, ★★ puan, ★★★ 3'lü zincir
    : L.escape
    ? (timeLeft >= L.star3 ? 3 : timeLeft >= L.star2 ? 2 : 1)   // ne kadar süre artırıldı
    : L.sand
    ? (fall.lines >= sandGoal ? 3 : fall.lines >= sandGoal / 2 ? 2 : 1)
    : placed <= par ? 3 : placed <= par * 1.5 ? 2 : 1;
  setStreak(streakN + 1);
  const prev = starsOf(levelN), first = levelN >= unlocked;
  if (stars > prev) Store.set('stars_' + levelN, stars);
  if (first) { unlocked = levelN + 1; Store.set('level', unlocked); }
  // Bildirim izni: oyuncu oyunu biraz tanıdıktan sonra (2. bölüm geçilince) bir kez sorulur
  if (unlocked >= 2) setTimeout(() => Notify.ask(), 2500);
  syncScores();
  mission('levels');
  const coins = levelCoins(stars, prev, first) * (L.special || L.superHard ? 2 : 1);   // özel ve süper zor: 2× altın
  Wallet.addCoins(coins);
  const bricks = Build.forLevel(stars, prev, first, !!L.special);
  if (bricks) Build.addBricks(bricks);
  $('winBricks').textContent = '0';
  $('winBrickCard').classList.toggle('hidden', !bricks);
  $('winCoins').textContent = '0';
  const prog = unlocked % CHEST_EVERY, chestReady = first && (prog === 0 || L.special);
  const shown = chestReady ? CHEST_EVERY : prog;
  $('winChestFill').style.width = `${((first ? shown - 1 : shown) / CHEST_EVERY) * 100}%`;
  $('winChestLabel').textContent = `${shown}/${CHEST_EVERY}`;
  $('winTitle').textContent = `Bölüm ${levelN + 1}`;
  $('winScore').textContent = '0';
  const scoreLvl = L.type === 'score';
  // Renk grubu özel bölümü: skor gösterilir (eski kum modunun "patlatılan satır" yazısı değil)
  $('winLabel').textContent = scoreLvl || L.bridge || L.escape ? 'SKOR' : L.sand ? 'PATLATILAN SATIR' : 'HAMLE';
  $('winSub').textContent = scoreLvl ? `Hedef ${L.target.toLocaleString('tr-TR')}` : stars === 3 ? 'En iyi sonuç!'
    : L.bridge ? `★★ ${L.star2.toLocaleString('tr-TR')} puan · ★★★ 3'lü zincir`
    : L.escape ? `3 yıldız için en az ${clockText(L.star3)} kala bitir`
    : L.sand ? `3 yıldız için en az ${sandGoal} satır` : `3 yıldız için en fazla ${L.par} hamle`;
  $('winSub').classList.toggle('best', !scoreLvl && stars === 3);
  for (let i = 0; i < 3; i++) { $('ws' + i).classList.remove('on'); $('ws' + i).parentElement.classList.remove('lit'); }
  $('winPraise').textContent = stars === 3 ? 'Mükemmel!' : stars === 2 ? 'Harika!' : 'Tamamlandı!';
  $('winPraise').classList.remove('show');
  $('winStreakN').textContent = streakN;
  const nt = nextTier(streakN);
  $('winStreakNext').textContent = levelN + 1 >= TOTAL_LEVELS ? 'Harika bir seri!'
    : streakBonus(streakN).length ? `Sonraki bölüm: ${bonusText(streakN)}`
      : `${nt[0]} seride bedava ${BOOSTERS[nt[1][nt[1].length - 1]].name}! (${nt[0] - streakN} kaldı)`;
  $('winStreak').classList.remove('hidden', 'pop');
  const fillStreak = renderStreakTrack(streakN);
  if (run !== runId) { if (chestReady) { openChest(); toast('Sandık ödülün eklendi!'); } return; }
  openPopup('win');
  cssConfetti(L.special ? 46 : 32);
  setTimeout(() => countUp($('winScore'), scoreLvl || L.bridge || L.escape ? score : L.sand ? fall.lines : placed), 350);
  Haptics.medium();
  for (let i = 0; i < stars; i++) {
    await wait(0.35);
    landStar(i);
  }
  $('winPraise').classList.add('show');
  $('winStreak').classList.add('pop');
  setTimeout(fillStreak, 250);
  await wait(0.3);
  await wait(0.5);
  countUp($('winCoins'), coins);
  if (bricks) countUp($('winBricks'), bricks);
  Sound.coin();
  setTimeout(() => { bumpCard($('winCoins')); if (bricks) setTimeout(() => bumpCard($('winBricks')), 120); }, 450);
  if (first) $('winChestFill').style.width = `${(shown / CHEST_EVERY) * 100}%`;
  if (chestReady) {
    await wait(0.9);
    if (run !== runId) { openChest(); toast('Sandık ödülün eklendi!'); return; }
    showChest();
  }
}

// Yıldız oturur: halka, dışa saçılan kıvılcımlar, kart hafifçe sarsılır
function landStar(i) {
  const st = $('ws' + i), slot = st.parentElement;
  st.classList.add('on');
  slot.classList.add('lit');
  Sound.star(i);
  Haptics.light();
  setTimeout(() => {
    for (let k = 0; k < 10; k++) {
      const sp = document.createElement('i');
      sp.className = 'wsp';
      const a = (k / 10) * Math.PI * 2 + Math.random() * 0.4, d = 44 + Math.random() * 30 + (i === 1 ? 14 : 0);
      sp.style.setProperty('--x', `${Math.cos(a) * d}px`);
      sp.style.setProperty('--y', `${Math.sin(a) * d}px`);
      slot.appendChild(sp);
      setTimeout(() => sp.remove(), 700);
    }
    const card = document.querySelector('#win .pop-card');
    card.classList.remove('thud'); void card.offsetWidth; card.classList.add('thud');
  }, 160);
}
// Ödül kartının simgesi sayaç bitince zıplar
function bumpCard(el) { const c = el.closest('.wr-card'); if (!c) return; c.classList.remove('bump'); void c.offsetWidth; c.classList.add('bump'); }
// Bölüm tamam penceresinin bulmaca / normal bölüm hâli
function setWinMode(isDaily) {
  $('winRibbon').textContent = isDaily ? 'BULMACA ÇÖZÜLDÜ!' : 'BÖLÜM TAMAM!';
  $('winRibbon').style.fontSize = isDaily ? '0.84em' : '';
  $('winLabel').textContent = isDaily ? 'SERİ' : 'SKOR';
  document.querySelector('#win .chest-mini').classList.toggle('hidden', isDaily);
  document.querySelector('#win .win-rewards').classList.toggle('no-chest', isDaily);
  document.querySelector('#winNext .lbl-long').textContent = isDaily ? 'ANA SAYFA' : 'SONRAKİ BÖLÜM';
  document.querySelector('#winNext .lbl-short').textContent = isDaily ? 'ANA SAYFA' : 'SONRAKİ';
}
async function winDaily() {
  over = true;
  setWinMode(true);
  Sound.win();
  // Kısa kutlama: tahta parlar, sonra pencere açılır
  Haptics.success();
  boardFlash('c3', 0.9);
  await wait(0.45);
  const used = L.moves - movesLeft;
  const stars = used <= L.par ? 3 : used <= L.par * 1.3 ? 2 : 1;
  const res = DailyPuzzle.complete();      // bugün zaten çözüldüyse ödül yok
  mission('levels');
  const st = DailyPuzzle.state();
  $('winTitle').textContent = `Günlük Bulmaca · ${todayLabel()}`;
  $('winScore').textContent = `${st.streak} gün`;
  $('winSub').textContent = '';
  $('winCoins').textContent = '0';
  for (let i = 0; i < 3; i++) { $('ws' + i).classList.remove('on'); $('ws' + i).parentElement.classList.remove('lit'); }
  $('winPraise').textContent = stars === 3 ? 'Mükemmel!' : stars === 2 ? 'Harika!' : 'Tamamlandı!';
  $('winPraise').classList.remove('show');
  $('winStreak').classList.add('hidden');
  openPopup('win');
  confetti(90);
  Haptics.medium();
  for (let i = 0; i < stars; i++) {
    await wait(0.35);
    landStar(i);
  }
  $('winPraise').classList.add('show');
  await wait(0.3);
  if (res) { countUp($('winCoins'), res.coins); Sound.coin(); updateCoins(); }
  if (res && res.chest) { await wait(0.9); showChestReward(openChest(), true); }
}

// Ödül sandığı: sallanır, açılır, altın ve bir güçlendirici verir
async function showChest() { return showChestReward(openChest(), true); }
async function showChestReward(res, fromWin = false) {
  chestFromWin = fromWin;
  const ico = $('chestIco');
  $('chestRewards').replaceChildren();
  $('chestTake').style.visibility = 'hidden';
  ico.classList.remove('open');
  ico.classList.add('shake');
  if (fromWin) $('win').classList.remove('show');   // sandık açılırken bölüm penceresi geri çekilir
  openPopup('chest');
  Haptics.light();
  await wait(0.75);
  ico.classList.remove('shake');
  ico.classList.add('open');
  Sound.chest();
  Haptics.success();
  confetti(50);
  $('chestRewards').innerHTML = `<div class="cr-item"><svg class="coin"><use href="#i-coin"/></svg><b>+${res.coins}</b></div>`
    + `<div class="cr-item" style="animation-delay:.12s"><span class="bo-ico ${res.booster}"><svg><use href="#i-${res.booster}"/></svg></span><b>${BOOSTERS[res.booster].name} ×1</b></div>`;
  $('chestTake').style.visibility = '';
}

// ---------- Kaydetme / başlatma ----------
function save() {
  if (over || mode !== 'endless') return;
  Store.set('save', JSON.stringify({
    grid: grid.map((row) => row.map((b) => (b ? b.color : -1))),
    tray: tray.map((t) => (t ? { s: SHAPES.indexOf(t.shape), c: t.color } : null)),
    score, combo, sinceClear, revived, coinsPaid,
  }));
}

function reset() {
  runId++;
  closePopups();
  if (tut) { tut = null; hideTutTip(); }
  if (escTut) escTutEnd();
  blockLayer.removeChildren();
  ovLayer.removeChildren();
  iconLayer.removeChildren();
  digLayer.removeChildren();
  dig = null;
  $('feverFx').classList.remove('on');
  $('finalCount').classList.remove('tick');
  fireLayer.removeChildren();
  trayLayer.removeChildren();
  fx.removeChildren();
  grid = Array.from({ length: N }, () => Array(N).fill(null));
  tray = [null, null, null];
  over = false;
  busy = false;
  score = 0; shownScore = 0; combo = 0; sinceClear = 0; streak = 0; revived = false; placed = 0; coinsPaid = 0;
  $('score').textContent = '0';
  gaveUp = false;
  setTargeting(null);
  setStuck(false);
  exitFire();
  flames.length = 0;
  golds.length = 0;
  fall = null;
  fallTouch = null;
  swapTouch = null;
  fallLayer.removeChildren();
  $('fallBomb').classList.remove('show', 'armed');
  if (esc && esc.v3) esc.v3.dispose();
  esc = null;
  escLayer.removeChildren();
  boardLayer.visible = true;
  $('hud').classList.remove('falling', 'escape');
}

function newGame(saved = null) {
  spendLifeIfRisk();
  $('hud').classList.remove('timed');
  freeB = { hammer: 0, bomb: 0, shuffle: 0 };
  // Sonsuz mod da can ister: her giriş 1 can harcar (yeni oyun da, kayıtlı oyuna devam da)
  if (Lives.count <= 0) { goHome(); openLives(); return; }
  Lives.lose(); renderLives();
  $('hud').classList.remove('special');
  daily = false;
  rnd = Math.random;
  mode = 'endless';
  $('hud').classList.remove('superhard');   // süper zor bölümün kırmızı hedef çubuğu sonsuz oyunda kalmasın
  L = {};   // sonsuz modun bölüm kuralı yok: L boş kalınca satır patlatmada çöküyordu, önceki bölümün kuralları da sızmasın
  placeTray();
  if (theme !== BASE) applyTheme(BASE);
  reset();
  if (saved) {
    // Kayıtta renk 'c3' gibi metin, boş hücre -1 (eskiden col >= 0 kontrolü metinleri eliyor, tahta boş geliyordu)
    saved.grid.forEach((row, r) => row.forEach((col, c) => { if (typeof col === 'string' && tex[col]) setBlock(r, c, col, false); }));
    saved.tray.forEach((t, i) => { if (t) makeTrayPiece(i, SHAPES[t.s], t.c, true); });
    score = shownScore = saved.score;
    $('score').textContent = score.toLocaleString('tr-TR');   // sayaç yalnız değişince yazar: kayıttan dönen puan hemen görünsün
    combo = saved.combo; sinceClear = saved.sinceClear; revived = saved.revived; coinsPaid = saved.coinsPaid || 0;
    if (tray.every((t) => !t)) deal();
  } else {
    deal();
  }
  renderCombo();
  showScreen('game');
}

function startLevel(n) {
  spendLifeIfRisk();
  if (n >= TOTAL_LEVELS) { openMap(); return; }
  if (Lives.count <= 0) { if ($('hud').classList.contains('show')) goHome(); openLives(n); return; }   // oyun ekranındaysa arkada ölü tahta kalmasın
  daily = false;
  rnd = Math.random;
  mode = 'level';
  placeTray();
  levelN = n;
  L = (forceL && forceL(n)) || (isEscape(n) ? getEscape(n) : isFalling(n) ? getFalling(n) : getLevel(n));   // her 6. bölüm Blok Kaçışı
  applyTheme(L.special ? { ...worldOf(n), frame: '#e8b13a', special: true } : worldOf(n));
  reset();
  goals = L.type === 'score' ? [] : L.goals.map((g) => ({ icon: g.icon, left: g.count, shown: g.count }));
  movesLeft = L.moves || 0;
  $('goalBar').replaceChildren();
  renderGoals();
  $('levelLabel').innerHTML = L.special
    ? `<span class="lv-row"><img class="lv-crown" src="${iconURL.crown}" alt="">Bölüm ${n + 1}</span><small class="special">${L.sand ? 'ÖZEL · SÜRE BİTENE KADAR DAYAN' : 'SÜRELİ ÖZEL BÖLÜM'}</small>`
    : L.escape ? `Bölüm ${n + 1}<small class="escape">BLOK KAÇIŞI</small>`
    : L.falling ? `Bölüm ${n + 1}<small class="falling">${L.sand ? 'SÜRE BİTENE KADAR DAYAN' : 'DÜŞEN BLOKLAR'}</small>`
      : L.superHard ? `Bölüm ${n + 1}<small class="superhard">SÜPER ZOR</small>` : `Bölüm ${n + 1}<small>${worldOf(n).name.toLocaleUpperCase('tr-TR')}</small>`;
  $('hud').classList.toggle('special', !!L.special);
  $('hud').classList.toggle('superhard', !!L.superHard);
  $('ptarget').textContent = L.target ? L.target.toLocaleString('tr-TR') : '';
  $('progress').classList.remove('done');
  if (L.falling) startFalling(); else if (L.escape) startEscape(); else buildLayout();
  // Süreli özel bölüm: sayaç giriş kartı kapanınca işlemeye başlar
  $('hud').classList.toggle('timed', timed());
  if (timed()) { timeLeft = L.timeLimit; renderClock(); }
  lifeAtRisk = true;                                    // bölüme girildiği anda çıkış bir cana mal olur
  paidRevives = 0;
  freeB = { hammer: 0, bomb: 0, shuffle: 0 };
  if (streakBonus(streakN).length && !L.falling) {
    for (const k of streakBonus(streakN)) freeB[k] = 1;
    renderBoosters();
    const tryBanner = () => { if (levelN !== n || over) return; if ($('specialIntro').classList.contains('show') || $('levelIntro').classList.contains('show')) setTimeout(tryBanner, 400); else showStreakBanner(); };
    setTimeout(tryBanner, 650);
  }
  showTips(n);
}

// ---------- Blok Kaçışı ----------
// Duvarlı kabın içindeki renkli blokları parmakla bir yöne kaydır: blok duvara ya da başka bloğa çarpana kadar gider.
// Kendi rengindeki açık kapıya ulaşan blok dışarı çıkar. Kilitli kapının sayacı her çıkışta 1 azalır, 0 olunca açılır.
// Süre bitmeden bütün bloklar çıkınca bölüm biter; Çekiç/Bomba blok kırar (çıkmış sayılır), Yenile renkleri karıştırır. Kurallar escape.js'te (bölüm üreticisi de aynısını kullanır).
const escLayer = new Container();
app.stage.addChildAt(escLayer, app.stage.getChildIndex(fx));
let esc = null;
const ESC_ICO = '<svg viewBox="0 0 24 24"><rect x="2.5" y="6.5" width="11" height="11" rx="2.4" fill="currentColor"/><path d="M16 12h5.5M18.6 8.8l3.1 3.2-3.1 3.2" fill="none" stroke="currentColor" stroke-width="2.3" stroke-linecap="round" stroke-linejoin="round"/></svg>';
// Kabın sığacağı ekran alanı: üst bilgi ile güçlendirici çubuğu arası
const escRect = () => { const top = BY - 8, bottom = H - safeB - BAR_H - 2; return { x: 8, y: top, w: W - 16, h: bottom - top }; };
// Blok renkleri: oyunun normal paleti (diğer bölümlerdeki bloklarla aynı tonlar)
const ESC_PAL = { c: PALETTE };
const escHex = (col) => colorHex[col];
// Blok Kaçışı görünümü: normal bölümlerle aynı çizim — tahta (zemin, ızgara, ince çerçeve, gölge) aynı fonksiyonlarla,
// bloklar oyunun blok dokularıyla, çıkış patlaması normal patlamanın aynısı. Kap şekilli olabilir (T, L, H…).
// Kapılar çerçevenin üstünde renkli çubuk (dışa bakan oklar); kilitliyken buz kaplı ve dışında koyu cam sayaç.
// Arayüz (pick, floorAt, toScreen, hold, drop, exit, …) main.js'teki akışın kullandığıyla aynı; birim = hücre.
function escOutline(lv) {
  // Kabın sınırları: her döngü saat yönünde köşe noktaları (hücre biriminde); içte duvar/sütun varsa onların da döngüsü olur
  const inM = (r, c) => r >= 0 && c >= 0 && r < lv.h && c < lv.w && (lv.mask[r][c] === '#' || lv.mask[r][c] === 'S');   // taş da zemin üstünde
  const next = new Map();
  for (let r = 0; r < lv.h; r++) for (let c = 0; c < lv.w; c++) {
    if (!inM(r, c)) continue;
    if (!inM(r - 1, c)) next.set(`${c},${r}|t`, [c + 1, r]);
    if (!inM(r, c + 1)) next.set(`${c + 1},${r}|r`, [c + 1, r + 1]);
    if (!inM(r + 1, c)) next.set(`${c + 1},${r + 1}|b`, [c, r + 1]);
    if (!inM(r, c - 1)) next.set(`${c},${r + 1}|l`, [c, r]);
  }
  // Aynı noktadan çıkan kenar: saat yönünde dönüşü tercih et (köşede birleşen iki döngü ayrı kalsın)
  const from = (p, prevDir) => {
    const k = p.join(',');
    const order = { t: ['r', 't', 'l', 'b'], r: ['b', 'r', 't', 'l'], b: ['l', 'b', 'r', 't'], l: ['t', 'l', 'b', 'r'] }[prevDir] || ['t', 'r', 'b', 'l'];
    for (const d of order) if (next.has(k + '|' + d)) return d;
    return null;
  };
  const loops = [];
  while (next.size) {
    const k0 = next.keys().next().value, [p0s, d0] = k0.split('|');
    const start = p0s.split(',').map(Number), pts = [start];
    let d = d0, p = next.get(k0);
    next.delete(k0);
    for (let guard = 0; guard < 600; guard++) {
      if (p[0] === start[0] && p[1] === start[1]) break;
      pts.push(p);
      const nd = from(p, d);
      if (!nd) break;
      const key = p.join(',') + '|' + nd;
      const q = next.get(key);
      next.delete(key);
      d = nd; p = q;
    }
    loops.push(pts.filter((q, i) => {
      const a = pts[(i - 1 + pts.length) % pts.length], b = pts[(i + 1) % pts.length];
      return (q[0] - a[0]) * (b[1] - q[1]) - (q[1] - a[1]) * (b[0] - q[0]) !== 0;
    }));
  }
  return loops;
}
// Koyu cam hap sayaç (Blok Kaçışı kilitleri): lacivert, buz mavisi kenar, kar tanesi, beyaz rakam; dikey=yan kapılar için
function escPillCanvas(n, vert) {
  const txt = String(n), k = 2, u = 22;
  const w = vert ? u * 1.5 : u * (txt.length > 1 ? 2.75 : 2.35), h = vert ? u * (txt.length > 1 ? 2.45 : 2.2) : u * 1.15;
  const cv = document.createElement('canvas');
  cv.width = Math.ceil((w + 6) * k); cv.height = Math.ceil((h + 8) * k);
  const x = cv.getContext('2d');
  x.scale(k, k); x.translate(3, 2);
  const r = Math.min(w, h) / 2;
  x.fillStyle = 'rgba(0,0,0,0.35)'; x.beginPath(); x.roundRect(1, 3.5, w - 2, h, r); x.fill();
  const g = x.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, '#1d4274'); g.addColorStop(1, '#0a1d3b');
  x.fillStyle = g; x.beginPath(); x.roundRect(0, 0, w, h, r); x.fill();
  x.strokeStyle = '#9fe3ff'; x.lineWidth = 1.6; x.beginPath(); x.roundRect(0.8, 0.8, w - 1.6, h - 1.6, r - 0.8); x.stroke();
  x.fillStyle = 'rgba(255,255,255,0.14)'; x.beginPath(); x.roundRect(3, 2.5, w - 6, Math.min(h, w) * 0.32, 3); x.fill();
  // Kar tanesi
  const fx0 = vert ? w / 2 : r * 1.02, fy0 = vert ? r * 0.98 : h / 2, fr = u * 0.27;
  x.strokeStyle = '#c4f0ff'; x.lineWidth = 1.5; x.lineCap = 'round';
  for (let i = 0; i < 3; i++) { const a = i * Math.PI / 3; x.beginPath(); x.moveTo(fx0 - Math.cos(a) * fr, fy0 - Math.sin(a) * fr); x.lineTo(fx0 + Math.cos(a) * fr, fy0 + Math.sin(a) * fr); x.stroke(); }
  x.font = `900 ${Math.round(u * (vert && txt.length > 1 ? 0.62 : 0.78))}px ${FONT}`; x.textAlign = 'center'; x.textBaseline = 'middle';
  const tx = vert ? w / 2 : r * 1.9 + (w - r * 1.9) / 2 - 1, ty = vert ? h - r * 0.98 + 1 : h / 2 + 1;
  x.fillStyle = 'rgba(0,0,0,0.25)'; x.fillText(txt, tx + 0.5, ty + 1.2);
  x.fillStyle = '#ffffff'; x.fillText(txt, tx, ty);
  return cv;
}
// Kapı oku: beyaz, hafif gölgeli ok (çubuğun kalınlığına göre)
const chevCache = new Map();
function chevTex(th) {
  if (chevCache.has(th)) return chevCache.get(th);
  const a = th * 0.36, cv = document.createElement('canvas'), k = DPR, S = Math.ceil(th * 1.4);
  cv.width = cv.height = Math.ceil(S * k);
  const x = cv.getContext('2d');
  x.scale(k, k);
  x.strokeStyle = '#ffffff'; x.lineWidth = Math.max(3.5, th * 0.3); x.lineCap = x.lineJoin = 'round';   // kalın (bold) ok
  x.shadowColor = 'rgba(0,0,0,0.35)'; x.shadowBlur = 2; x.shadowOffsetY = 1.2;
  x.beginPath(); x.moveTo(S / 2 - a, S / 2 + a * 0.5); x.lineTo(S / 2, S / 2 - a * 0.5); x.lineTo(S / 2 + a, S / 2 + a * 0.5); x.stroke();
  const t = Texture.from(cv);
  chevCache.set(th, t);
  return t;
}
// Kilitli kapının buzu: köşeli buz kalıbı — buz mavisi geçiş, çapraz ışık yüzeyleri, beyaz donmuş kenar,
// çatlaklar ve kırağı noktaları; altta koyu buz kalınlığı. Hafif saydam (altındaki kapının rengi sezilir).
function escIceCanvas(w, h, seed = 1) {
  const k = DPR, cv = document.createElement('canvas');
  cv.width = Math.ceil((w + 4) * k); cv.height = Math.ceil((h + 6) * k);
  const x = cv.getContext('2d');
  x.scale(k, k); x.translate(2, 1);
  let sd = seed * 9301 + 49297;
  const rnd = () => ((sd = (sd * 9301 + 49297) % 233280) / 233280);
  const r = Math.min(6, h * 0.3);
  x.fillStyle = 'rgba(0,0,0,0.3)'; x.beginPath(); x.roundRect(0.5, 3, w - 1, h, r); x.fill();
  // Kalınlık (alt kenar) ve gövde
  x.fillStyle = 'rgba(58,150,205,0.95)'; x.beginPath(); x.roundRect(0, 1.5, w, h, r); x.fill();
  const g = x.createLinearGradient(0, 0, 0, h);
  g.addColorStop(0, 'rgba(240,252,255,0.97)'); g.addColorStop(0.45, 'rgba(176,229,250,0.9)'); g.addColorStop(1, 'rgba(112,196,238,0.92)');
  x.fillStyle = g; x.beginPath(); x.roundRect(0, 0, w, h - 1.5, r); x.fill();
  x.save(); x.beginPath(); x.roundRect(0, 0, w, h - 1.5, r); x.clip();
  // Çapraz ışık yüzeyleri
  for (let i = 0; i < 3; i++) {
    const cx = w * (0.15 + i * 0.33 + rnd() * 0.1), bw = w * (0.08 + rnd() * 0.06);
    x.fillStyle = `rgba(255,255,255,${0.28 + rnd() * 0.2})`;
    x.beginPath(); x.moveTo(cx, -2); x.lineTo(cx + bw, -2); x.lineTo(cx + bw - h * 0.8, h + 2); x.lineTo(cx - h * 0.8, h + 2); x.closePath(); x.fill();
  }
  x.fillStyle = 'rgba(40,120,180,0.12)';
  x.beginPath(); x.moveTo(w * 0.62, -2); x.lineTo(w * 0.72, -2); x.lineTo(w * 0.72 - h * 0.8, h + 2); x.lineTo(w * 0.62 - h * 0.8, h + 2); x.closePath(); x.fill();
  // Çatlaklar
  x.strokeStyle = 'rgba(255,255,255,0.9)'; x.lineWidth = 1; x.lineJoin = 'round';
  for (let i = 0; i < 2; i++) {
    let px = w * (0.25 + i * 0.45 + rnd() * 0.1), py = h * (0.2 + rnd() * 0.2);
    x.beginPath(); x.moveTo(px, py);
    for (let k2 = 0; k2 < 3; k2++) { px += (rnd() - 0.3) * h * 0.6; py += h * (0.18 + rnd() * 0.15); x.lineTo(px, py); }
    x.stroke();
  }
  // Kırağı noktaları
  for (let i = 0; i < Math.round(w / 6); i++) { x.fillStyle = `rgba(255,255,255,${0.5 + rnd() * 0.5})`; x.beginPath(); x.arc(rnd() * w, rnd() * h, 0.6 + rnd() * 0.9, 0, Math.PI * 2); x.fill(); }
  // Üst parlama çizgisi
  x.fillStyle = 'rgba(255,255,255,0.75)'; x.fillRect(r * 0.6, 1.2, w - r * 1.2, 1.4);
  x.restore();
  // Donmuş kenar
  x.strokeStyle = 'rgba(255,255,255,0.95)'; x.lineWidth = 1.5; x.beginPath(); x.roundRect(0.75, 0.75, w - 1.5, h - 3, r - 0.5); x.stroke();
  x.strokeStyle = 'rgba(70,160,215,0.55)'; x.lineWidth = 1; x.beginPath(); x.roundRect(2.2, 2.2, w - 4.4, h - 6, r - 1.5); x.stroke();
  return cv;
}
// Taş engel: düzensiz kenarlı gri kaya — gölge, köşegen ışık geçişi, açık/koyu yüzeyler, çatlak ve benekler
const stoneCache = new Map();
// Kaya renkleri: [açık, orta, koyu, kenar]; süs: yosun / deniz kabuğu / kum katmanı
const ROCK = { tas: ['#b3b7c1', '#7f838e', '#565a65', 'rgba(30,32,40,0.6)'], yosun: ['#aab0a6', '#787f75', '#4f564d', 'rgba(28,34,26,0.6)'],
  deniz: ['#a9c3d6', '#6f8ea6', '#465f75', 'rgba(22,36,50,0.65)'], kum: ['#f0d29c', '#cfa266', '#9a7040', 'rgba(70,45,20,0.6)'] };
function stoneCanvas(S, kind = 'tas') {
  const key = kind + S;
  if (stoneCache.has(key)) return stoneCache.get(key);
  const [c0, c1, c2, edge] = ROCK[kind] || ROCK.tas;
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  const P = [[0.12, 0.07], [0.6, 0.03], [0.95, 0.2], [0.97, 0.7], [0.76, 0.95], [0.24, 0.96], [0.03, 0.74], [0.04, 0.3]].map(([a, b]) => [a * S, b * S]);
  const path = (dy = 0) => {
    x.beginPath();
    const n = P.length, mid = (i) => [(P[i][0] + P[(i + 1) % n][0]) / 2, (P[i][1] + P[(i + 1) % n][1]) / 2 + dy];
    const m0 = mid(n - 1); x.moveTo(m0[0], m0[1]);
    for (let i = 0; i < n; i++) { const m = mid(i); x.quadraticCurveTo(P[i][0], P[i][1] + dy, m[0], m[1]); }
    x.closePath();
  };
  path(S * 0.05); x.fillStyle = 'rgba(0,0,0,0.35)'; x.fill();
  const g = x.createLinearGradient(S * 0.15, S * 0.1, S * 0.85, S * 0.95);
  g.addColorStop(0, c0); g.addColorStop(0.55, c1); g.addColorStop(1, c2);
  path(); x.fillStyle = g; x.fill();
  x.save(); path(); x.clip();
  if (kind === 'kum') {
    // Kum taşı: yatay dalgalı katmanlar
    for (let i = 0; i < 6; i++) { const y = S * (0.2 + i * 0.13); x.strokeStyle = i % 2 ? 'rgba(255,240,205,0.35)' : 'rgba(120,80,40,0.3)'; x.lineWidth = S * 0.04; x.beginPath(); x.moveTo(0, y); x.bezierCurveTo(S * 0.3, y - S * 0.04, S * 0.65, y + S * 0.04, S, y - S * 0.01); x.stroke(); }
  }
  x.fillStyle = 'rgba(255,255,255,0.16)'; x.beginPath(); x.moveTo(S * 0.1, S * 0.3); x.lineTo(S * 0.6, S * 0.08); x.lineTo(S * 0.52, S * 0.42); x.lineTo(S * 0.14, S * 0.56); x.closePath(); x.fill();
  x.fillStyle = 'rgba(0,0,0,0.16)'; x.beginPath(); x.moveTo(S * 0.92, S * 0.6); x.lineTo(S * 0.56, S * 0.52); x.lineTo(S * 0.4, S * 0.95); x.lineTo(S * 0.75, S * 0.95); x.closePath(); x.fill();
  x.strokeStyle = 'rgba(35,37,46,0.55)'; x.lineWidth = S * 0.028; x.lineCap = x.lineJoin = 'round';
  if (kind !== 'kum') { x.beginPath(); x.moveTo(S * 0.46, S * 0.14); x.lineTo(S * 0.52, S * 0.4); x.lineTo(S * 0.42, S * 0.58); x.moveTo(S * 0.52, S * 0.4); x.lineTo(S * 0.7, S * 0.5); x.stroke(); }
  for (let i = 0; i < 9; i++) { x.fillStyle = i % 2 ? 'rgba(255,255,255,0.18)' : 'rgba(30,30,40,0.22)'; x.beginPath(); x.arc(S * (0.22 + ((i * 37) % 60) / 100), S * (0.25 + ((i * 53) % 55) / 100), S * 0.018, 0, Math.PI * 2); x.fill(); }
  if (kind === 'yosun') {
    // Yosun: üst kenarda yeşil öbekler, aşağı sarkan birkaç damla
    for (const [cx, cy, r, col] of [[0.3, 0.12, 0.17, '#3f8a3a'], [0.55, 0.08, 0.15, '#4fa046'], [0.78, 0.16, 0.13, '#3f8a3a'], [0.2, 0.3, 0.1, '#4fa046'], [0.42, 0.18, 0.1, '#6cbf55'], [0.68, 0.14, 0.08, '#6cbf55']]) {
      x.fillStyle = col; x.beginPath(); x.ellipse(cx * S, cy * S, r * S, r * 0.7 * S, 0, 0, Math.PI * 2); x.fill();
    }
    for (const [cx, cy] of [[0.36, 0.32], [0.62, 0.27], [0.83, 0.3]]) { x.fillStyle = '#3f8a3a'; x.beginPath(); x.ellipse(cx * S, cy * S, S * 0.03, S * 0.06, 0, 0, Math.PI * 2); x.fill(); }
  }
  if (kind === 'deniz') {
    // Islak parlaklık ve küçük deniz kabukları / midye
    x.fillStyle = 'rgba(255,255,255,0.22)'; x.beginPath(); x.ellipse(S * 0.62, S * 0.3, S * 0.16, S * 0.05, -0.3, 0, Math.PI * 2); x.fill();
    for (const [cx, cy, r] of [[0.3, 0.68, 0.07], [0.42, 0.78, 0.05], [0.72, 0.72, 0.06]]) {
      x.fillStyle = '#f4ede0'; x.beginPath(); x.arc(cx * S, cy * S, r * S, Math.PI, 0); x.closePath(); x.fill();
      x.strokeStyle = 'rgba(150,120,90,0.7)'; x.lineWidth = S * 0.012; x.stroke();
      for (let k = -1; k <= 1; k++) { x.beginPath(); x.moveTo(cx * S, cy * S); x.lineTo((cx + k * r * 0.6) * S, (cy - r * 0.85) * S); x.stroke(); }
    }
  }
  x.restore();
  path(); x.strokeStyle = edge; x.lineWidth = S * 0.03; x.stroke();
  x.fillStyle = 'rgba(255,255,255,0.45)'; x.beginPath(); x.ellipse(S * 0.3, S * 0.22, S * 0.08, S * 0.035, -0.45, 0, Math.PI * 2); x.fill();
  stoneCache.set(key, cv);
  return cv;
}
// Dünyaya göre sabit engeller (hepsi taşla aynı kural: yerinden oynamaz, çekiç/bomba kırar). Hücre başına tür
// dünyanın listesinden sırayla seçilir; bir bölümde 1–2 farklı görünüm olur.
const OBST_NAME = { tas: 'Taş', yosun: 'Yosunlu taş', deniz: 'Deniz taşı', kum: 'Kum taşı', meteor: 'Göktaşı', buz: 'Buz kütlesi', lav: 'Lav taşı' };
const OBST_WORLD = [['tas', 'yosun'], ['deniz', 'tas'], ['kum', 'tas'], ['meteor'], ['buz'], ['lav', 'tas']];
const escObstKind = (n, r, c) => { const L0 = OBST_WORLD[worldIndex(n)] || OBST_WORLD[0]; return L0[(r * 3 + c * 5) % L0.length]; };
const escObstKinds = (lv, n) => { const set = []; for (let r = 0; r < lv.h; r++) for (let c = 0; c < lv.w; c++) if (lv.mask[r][c] === 'S') { const k = escObstKind(n, r, c); if (!set.includes(k)) set.push(k); } return set; };
const obstCache = new Map();
function obstacleCanvas(kind, S) {
  if (ROCK[kind]) return stoneCanvas(S, kind);
  const key = kind + S;
  if (obstCache.has(key)) return obstCache.get(key);
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  const e = (cx, cy, rx, ry, fill) => { x.fillStyle = fill; x.beginPath(); x.ellipse(cx * S, cy * S, rx * S, ry * S, 0, 0, Math.PI * 2); x.fill(); };
  const lg = (x0, y0, x1, y1, stops) => { const g = x.createLinearGradient(x0 * S, y0 * S, x1 * S, y1 * S); stops.forEach(([o, c]) => g.addColorStop(o, c)); return g; };
  x.lineCap = x.lineJoin = 'round';
  if (kind === 'meteor') {
    e(0.5, 0.9, 0.38, 0.07, 'rgba(0,0,0,0.35)');
    const P = [[0.16, 0.14], [0.64, 0.06], [0.94, 0.3], [0.9, 0.74], [0.62, 0.95], [0.2, 0.9], [0.05, 0.6], [0.06, 0.3]];
    x.beginPath(); P.forEach(([a, b], i) => (i ? x.lineTo(a * S, b * S) : x.moveTo(a * S, b * S))); x.closePath();
    x.fillStyle = lg(0.1, 0.1, 0.9, 0.95, [[0, '#8c84a6'], [0.55, '#5a5470'], [1, '#2f2a40']]); x.fill();
    x.strokeStyle = '#211d2e'; x.lineWidth = S * 0.03; x.stroke();
    for (const [cx, cy, r] of [[0.36, 0.34, 0.12], [0.66, 0.58, 0.14], [0.3, 0.7, 0.07], [0.68, 0.24, 0.06]]) {
      e(cx, cy, r, r * 0.85, 'rgba(25,20,40,0.55)'); e(cx - r * 0.15, cy - r * 0.15, r * 0.7, r * 0.6, 'rgba(60,52,82,0.9)');
      x.strokeStyle = 'rgba(200,190,230,0.45)'; x.lineWidth = S * 0.015; x.beginPath(); x.ellipse((cx + r * 0.05) * S, (cy + r * 0.08) * S, r * S, r * 0.85 * S, 0, 0.2, 1.9); x.stroke();
    }
    e(0.24, 0.2, 0.06, 0.025, 'rgba(255,255,255,0.35)');
  } else if (kind === 'buz') {
    e(0.5, 0.92, 0.38, 0.06, 'rgba(0,0,0,0.3)');
    x.fillStyle = lg(0, 0.06, 0, 0.94, [[0, '#e6fbff'], [0.5, '#8fdcf7'], [1, '#4aa5d6']]);
    x.beginPath(); x.roundRect(0.08 * S, 0.08 * S, 0.84 * S, 0.84 * S, 0.12 * S); x.fill();
    x.fillStyle = 'rgba(255,255,255,0.45)'; x.beginPath(); x.moveTo(0.12 * S, 0.14 * S); x.lineTo(0.52 * S, 0.12 * S); x.lineTo(0.22 * S, 0.46 * S); x.closePath(); x.fill();
    x.fillStyle = 'rgba(30,110,170,0.22)'; x.beginPath(); x.moveTo(0.9 * S, 0.5 * S); x.lineTo(0.88 * S, 0.88 * S); x.lineTo(0.5 * S, 0.88 * S); x.closePath(); x.fill();
    x.strokeStyle = 'rgba(255,255,255,0.85)'; x.lineWidth = S * 0.02;
    x.beginPath(); x.moveTo(0.58 * S, 0.24 * S); x.lineTo(0.5 * S, 0.46 * S); x.lineTo(0.64 * S, 0.6 * S); x.moveTo(0.5 * S, 0.46 * S); x.lineTo(0.34 * S, 0.58 * S); x.stroke();
    x.strokeStyle = '#2f7fae'; x.lineWidth = S * 0.03; x.beginPath(); x.roundRect(0.08 * S, 0.08 * S, 0.84 * S, 0.84 * S, 0.12 * S); x.stroke();
    e(0.76, 0.2, 0.035, 0.035, 'rgba(255,255,255,0.9)');
  } else if (kind === 'lav') {
    e(0.5, 0.9, 0.38, 0.07, 'rgba(0,0,0,0.35)');
    const P = [[0.14, 0.12], [0.6, 0.05], [0.94, 0.24], [0.95, 0.7], [0.72, 0.95], [0.24, 0.94], [0.04, 0.7], [0.05, 0.3]];
    x.beginPath(); P.forEach(([a, b], i) => (i ? x.lineTo(a * S, b * S) : x.moveTo(a * S, b * S))); x.closePath();
    x.fillStyle = lg(0.1, 0.05, 0.9, 0.95, [[0, '#5e4e4c'], [0.5, '#3a2e2d'], [1, '#1e1616']]); x.fill();
    x.strokeStyle = '#120c0c'; x.lineWidth = S * 0.03; x.stroke();
    const crack = (pts) => { for (const [col, w] of [['#c2410c', 0.06], ['#ff8a2a', 0.035], ['#ffd36a', 0.012]]) { x.strokeStyle = col; x.lineWidth = w * S; x.beginPath(); pts.forEach(([a, b], i) => (i ? x.lineTo(a * S, b * S) : x.moveTo(a * S, b * S))); x.stroke(); } };
    crack([[0.3, 0.14], [0.42, 0.38], [0.34, 0.6], [0.46, 0.86]]); crack([[0.42, 0.38], [0.66, 0.46], [0.84, 0.36]]); crack([[0.66, 0.46], [0.7, 0.72]]);
    e(0.24, 0.2, 0.06, 0.025, 'rgba(255,255,255,0.18)');
  }
  obstCache.set(key, cv);
  return cv;
}
function createEscape2D(lv, st, rect, still = false) {   // still: giriş animasyonu yok (önizleme resmi için)
  // Bu tahtaya özel tuval dokuları: kapanışta yok edilir (yoksa her bölüm başlangıcında ~15 MB birikiyordu)
  const owned = [], own = (t) => (owned.push(t), t);
  const root = new Container();
  escLayer.addChild(root);
  const lockSide = (sd) => lv.gates.some((g) => g.side === sd && g.lock);
  // Hücre boyu: normal tahtadaki kadar büyük olabilir; kilitli kapı olan kenarda sayaç için pay bırakılır
  // Kapı oku çubuğun dışında durduğu için kapılı kenarda da pay bırakılır
  const gateSide = (sd) => lv.gates.some((g) => g.side === sd);
  const extra = (sd) => (lockSide(sd) ? (sd === 'left' || sd === 'right' ? 1.15 : 0.95) : gateSide(sd) ? 0.8 : 0.32);
  const cs = Math.floor(Math.min(rect.w / (lv.w + extra('left') + extra('right')), rect.h / (lv.h + extra('top') + extra('bottom')), cell * 1.15));
  const bw = cs * lv.w, bh = cs * lv.h;
  const ox = Math.round(rect.x + (rect.w - bw - (extra('left') + extra('right')) * cs) / 2 + extra('left') * cs);
  const oy = Math.round(rect.y + (rect.h - bh - (extra('top') + extra('bottom')) * cs) / 2 + extra('top') * cs);
  const pad = Math.max(11, Math.round(cs * 0.28));   // çerçeve dış kenarı (hücre kenarından)
  const inPad = Math.max(2, Math.round(pad * 0.3)), ring = pad - inPad;   // zemin hücreden inPad taşar; çerçeve halkası ring kalınlığında
  const segRect = (g) => { const n = g.len * cs; return g.side === 'top' ? [g.at * cs, -pad - 4, n, pad + 4] : g.side === 'bottom' ? [g.at * cs, bh, n, pad + 4] : g.side === 'left' ? [-pad - 4, g.at * cs, pad + 4, n] : [bw, g.at * cs, pad + 4, n]; };
  const segMasks = [];
  // Tahta: kabartmalı çerçeve (üst ışık, alt gölge, içe düşen gölge), hafif açık zemin; ızgara çizgisi yerine köşe noktaları
  {
    const M = 26, cv = document.createElement('canvas');
    cv.width = Math.ceil((bw + M * 2) * DPR); cv.height = Math.ceil((bh + M * 2) * DPR);
    const x = cv.getContext('2d');
    x.scale(DPR, DPR); x.translate(M, M);
    // Her döngü dışa doğru pad kadar genişler (dik köşeli çokgen: köşe = iki kenarın dış normallerinin toplamı);
    // içteki duvar/sütun döngüleri de aynı kuralla küçülür. Hepsi tek yolda, çift-tek dolgu kuralıyla çizilir.
    const outline = escOutline(lv);
    const loopsAt = (pd) => outline.map((L0) => {
      const P = L0.map(([c, r]) => [c * cs, r * cs]), n = P.length;
      return P.map((p, i) => {
        const a = P[(i - 1 + n) % n], b = P[(i + 1) % n];
        const d1 = [Math.sign(p[0] - a[0]), Math.sign(p[1] - a[1])], d2 = [Math.sign(b[0] - p[0]), Math.sign(b[1] - p[1])];
        return [p[0] + pd * (d1[1] + d2[1]), p[1] + pd * (-d1[0] - d2[0])];
      });
    });
    let loops = loopsAt(pad);
    const pathOn = (x, Ls, rad) => {
      x.beginPath();
      for (const Q of Ls) {
        const n = Q.length;
        const mid = (i) => { const a = Q[i], b = Q[(i + 1) % n]; return [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2]; };
        const m0 = mid(n - 1); x.moveTo(m0[0], m0[1]);
        for (let i = 0; i < n; i++) {
          const a = Q[(i - 1 + n) % n], p = Q[i], b = Q[(i + 1) % n];
          const convex = (p[0] - a[0]) * (b[1] - p[1]) - (p[1] - a[1]) * (b[0] - p[0]) > 0;
          x.arcTo(p[0], p[1], mid(i)[0], mid(i)[1], convex ? rad : 3);
        }
        x.closePath();
      }
    };
    const shape = (rad = 10) => pathOn(x, loops, rad);
    x.save(); x.filter = 'blur(12px)'; x.fillStyle = 'rgba(0,0,0,0.4)'; x.translate(0, 6); shape(16); x.fill('evenodd'); x.restore();
    // Kabartmalı kenar: dış yol çerçeve renginde dikey geçişle dolar, iç yol zeminle; aradaki halka çerçeve olur
    const outerL = loops, inner = loopsAt(inPad);
    const topY = -pad, botY = bh + pad;
    const FV = window.__escFrame || 'kabartma';   // GEÇİCİ: çerçeve tasarım denemesi
    const FC = { kabartma: [mixHex(theme.frame, '#ffffff', 0.32), theme.frame, mixHex(theme.frame, '#000000', 0.4)], ahsap: ['#c98a4b', '#9a6230', '#6b3f1c'],
      altin: ['#fff1b8', '#e8b13a', '#9c6a14'], koyu: [mixHex(theme.board, '#000000', 0.1), mixHex(theme.board, '#000000', 0.35), mixHex(theme.board, '#000000', 0.55)],
      cam: ['rgba(255,255,255,0.22)', 'rgba(255,255,255,0.10)', 'rgba(255,255,255,0.05)'] }[FV];
    const rg = x.createLinearGradient(0, topY, 0, botY);
    rg.addColorStop(0, FC[0]); rg.addColorStop(0.5, FC[1]); rg.addColorStop(1, FC[2]);
    shape(16); x.fillStyle = rg; x.fill('evenodd');
    if (FV === 'ahsap') {
      // Ahşap damarları: halkanın içinde ince, dalgalı açık/koyu çizgiler
      x.save(); shape(16); x.clip('evenodd');
      const E = pad + 6, grain = (horiz) => { for (let i = 0; i < 14; i++) {
        const t = -pad + (i + 0.5) / 14 * pad;   // halka kalınlığı boyunca
        x.strokeStyle = i % 2 ? 'rgba(255,220,170,0.18)' : 'rgba(60,30,10,0.25)'; x.lineWidth = 0.8 + (i % 3) * 0.4;
        for (const base of horiz ? [t, bh - t] : [t, bw - t]) {
          x.beginPath();
          if (horiz) { x.moveTo(-E, base); x.bezierCurveTo(bw * 0.3, base + 1.5, bw * 0.6, base - 1.5, bw + E, base + 0.5); }
          else { x.moveTo(base, -E); x.bezierCurveTo(base + 1.5, bh * 0.3, base - 1.5, bh * 0.6, base + 0.5, bh + E); }
          x.stroke();
        } } };
      x.save(); x.beginPath(); x.rect(-E, -E, bw + E * 2, E); x.rect(-E, bh, bw + E * 2, E); x.clip(); grain(true); x.restore();
      x.save(); x.beginPath(); x.rect(-E, 0, E, bh); x.rect(bw, 0, E, bh); x.clip(); grain(false); x.restore();
      x.restore();
    }
    if (FV === 'koyu') { shape(16); x.lineWidth = 2; x.strokeStyle = theme.frame; x.stroke(); }
    // Kapılar çerçevenin kendisi: kapının olduğu çerçeve parçası kapı renginde, çerçeveyle aynı ışık/gölge geçişiyle
    // boyanır (dış şekille kırpılır; iç kısmı birazdan zemin örter). Uçlarda ince koyu ek yeri.
    x.save(); shape(16); x.clip('evenodd');
    for (const g of lv.gates) {
      const hex = PALETTE[+g.col.slice(1)], r = segRect(g);
      // Kalınlık boyunca kabartma: dış kenar açık, iç kenar koyu (kapı nerede olursa olsun aynı canlılıkta)
      const gg = g.side === 'top' ? x.createLinearGradient(0, -pad, 0, -inPad) : g.side === 'bottom' ? x.createLinearGradient(0, bh + pad, 0, bh + inPad)
        : g.side === 'left' ? x.createLinearGradient(-pad, 0, -inPad, 0) : x.createLinearGradient(bw + pad, 0, bw + inPad, 0);
      gg.addColorStop(0, mixHex(hex, '#ffffff', 0.18)); gg.addColorStop(0.4, hex); gg.addColorStop(1, mixHex(hex, '#000000', 0.32));
      x.fillStyle = gg; x.fillRect(...r);
      x.strokeStyle = 'rgba(0,0,0,0.35)'; x.lineWidth = 1.2; x.beginPath();
      if (g.side === 'top' || g.side === 'bottom') { x.moveTo(r[0], r[1]); x.lineTo(r[0], r[1] + r[3]); x.moveTo(r[0] + r[2], r[1]); x.lineTo(r[0] + r[2], r[1] + r[3]); }
      else { x.moveTo(r[0], r[1]); x.lineTo(r[0] + r[2], r[1]); x.moveTo(r[0], r[1] + r[3]); x.lineTo(r[0] + r[2], r[1] + r[3]); }
      x.stroke();
    }
    x.restore();
    // Dış kenarda ince ışık (üst) / gölge (alt)
    const eg = x.createLinearGradient(0, topY, 0, botY);
    eg.addColorStop(0, 'rgba(255,255,255,0.45)'); eg.addColorStop(0.5, 'rgba(255,255,255,0.08)'); eg.addColorStop(1, 'rgba(0,0,0,0.35)');
    x.lineWidth = 1.5; x.strokeStyle = eg; x.stroke();
    loops = inner;
    shape(5); x.fillStyle = mixHex(theme.board, theme.line, 0.3); x.fill('evenodd');
    // İç kenar: koyu çizgi + zeminin üstüne düşen yumuşak gölge
    x.lineWidth = 1.5; x.strokeStyle = 'rgba(0,0,0,0.5)'; x.stroke();
    x.save(); shape(5); x.clip('evenodd');
    const ig = x.createLinearGradient(0, -pad, 0, Math.min(bh, cs * 0.6));
    ig.addColorStop(0, 'rgba(0,0,0,0.38)'); ig.addColorStop(1, 'rgba(0,0,0,0)');
    x.fillStyle = ig; x.fillRect(-pad * 2, -pad * 2, bw + pad * 4, Math.min(bh, cs * 0.6) + pad * 2);
    x.restore();
    // Kapı parçası maskeleri (şeritler için): çerçeve halkası ∩ kapı dikdörtgeni
    for (const g of lv.gates) {
      const r = segRect(g), mc = document.createElement('canvas');
      mc.width = Math.ceil(r[2] * DPR); mc.height = Math.ceil(r[3] * DPR);
      const m = mc.getContext('2d');
      m.scale(DPR, DPR); m.translate(-r[0], -r[1]);
      pathOn(m, outerL, 16); m.clip('evenodd');
      m.fillStyle = '#fff'; m.fillRect(...r);
      m.globalCompositeOperation = 'destination-out'; pathOn(m, inner, 5); m.fill('evenodd');
      segMasks.push(mc);
    }
    // Köşe noktaları: yalnız dört yanı da kab hücresi olan iç köşelerde
    const inM = (r, c) => r >= 0 && c >= 0 && r < lv.h && c < lv.w && (lv.mask[r][c] === '#' || lv.mask[r][c] === 'S');
    x.fillStyle = mixHex(theme.line, '#ffffff', 0.15);
    const dr = Math.max(1.8, cs * 0.045);
    for (let r = 1; r < lv.h; r++) for (let c = 1; c < lv.w; c++) {
      if (!(inM(r - 1, c - 1) && inM(r - 1, c) && inM(r, c - 1) && inM(r, c))) continue;
      x.beginPath(); x.arc(c * cs, r * cs, dr, 0, Math.PI * 2); x.fill();
    }
    const s = new Sprite(own(Texture.from(cv)));
    s.scale.set(1 / DPR); s.position.set(ox - M, oy - M);
    root.addChild(s);
  }
  const laneLayer = new Container(), stoneL = new Container(), blockL = new Container(), gateL = new Container();
  root.addChild(laneLayer, stoneL, blockL, gateL);
  // Taşlar (maskede 'S'): zeminin üstünde, blokların altında
  const stones = new Map(), oTex = {};
  for (let r = 0; r < lv.h; r++) for (let c = 0; c < lv.w; c++) if (lv.mask[r][c] === 'S') {
    const kind = escObstKind(levelN, r, c);
    // Taş tuvali önbellekten paylaşılır (önizleme ile oyun aynı dokuyu kullanır): bu yüzden kapanışta silinmez
    const sp = new Sprite(oTex[kind] ||= Texture.from(obstacleCanvas(kind, Math.round(cs * DPR))));
    sp.anchor.set(0.5); sp.width = sp.height = cs - 2;
    sp.position.set(ox + (c + 0.5) * cs, oy + (r + 0.5) * cs);
    if (!still) { const k = sp.scale.x; sp.scale.set(0); tween(sp.scale, { x: k, y: k }, 0.3, Ease.outBack, 0.05); }
    stoneL.addChild(sp);
    stones.set(r * lv.w + c, sp);
  }
  const blocks = new Map();
  const place = (o) => { o.v.position.set(ox + (o.x + o.s / 2) * cs, oy + (o.z + o.s / 2) * cs - (o.lf || 0) * cs * 0.07); };   // tutulan blok hafifçe yükselir
  for (const b of st.blocks) {
    const v = new Container();
    // Tutulunca beliren yumuşak gölge (üç katman, kenarı yumuşak)
    const sh = new Graphics(), sz = cs * b.s;
    for (const [g, a] of [[cs * 0.1, 0.1], [cs * 0.05, 0.12], [0, 0.16]]) sh.roundRect(-sz / 2 + 2 - g / 2, -sz / 2 + 2 - g / 2, sz - 4 + g, sz - 4 + g, cs * 0.14 + g / 2).fill({ color: 0x000000, alpha: a });
    sh.alpha = 0;
    const sp = new Sprite(tex[b.col]);
    sp.anchor.set(0.5); sp.width = sp.height = cs * b.s;
    v.addChild(sh, sp);
    blockL.addChild(v);
    const o = { id: b.id, s: b.s, col: b.col, v, sp, sh, x: b.c, z: b.r, tx: b.c, tz: b.r, vx: 0, vz: 0, k: 1, tk: 1, lf: 0, held: false, speed: 20 };
    place(o);
    if (!still) { v.scale.set(0); tween(v.scale, { x: 1, y: 1 }, 0.3, Ease.outBack, 0.1 + b.id * 0.015); }
    blocks.set(b.id, o);
  }
  // Kapılar
  const gateMid = (g) => {
    const horiz = g.side === 'top' || g.side === 'bottom';
    const edge = inPad + ring / 2;   // çerçeve halkasının ortası
    return horiz ? [ox + (g.at + g.len / 2) * cs, g.side === 'top' ? oy - edge : oy + bh + edge] : [g.side === 'left' ? ox - edge : ox + bw + edge, oy + (g.at + g.len / 2) * cs];
  };
  let animT = 0;
  const gates = lv.gates.map((g, gi) => {
    const v = new Container();
    const [mx, my] = gateMid(g);
    v.position.set(mx, my);
    v.rotation = { top: 0, right: Math.PI / 2, bottom: Math.PI, left: -Math.PI / 2 }[g.side];
    gateL.addChild(v);
    const o = { g, gi, v, lock: -1, pill: null };
    // Şeritler: kapı parçasının üstünde, onun şekliyle maskeli; kapı boyunca sakin akar (render)
    const r = segRect(g), horiz = g.side === 'top' || g.side === 'bottom', step = Math.round(pad * 0.9);
    const W2 = r[2] + (horiz ? step * 2 : 0), H2 = r[3] + (horiz ? 0 : step * 2);
    const sc = document.createElement('canvas');
    sc.width = Math.ceil(W2 * DPR); sc.height = Math.ceil(H2 * DPR);
    const y = sc.getContext('2d');
    y.scale(DPR, DPR); y.strokeStyle = 'rgba(255,255,255,0.16)'; y.lineWidth = step * 0.3;
    for (let t = -H2 - step; t < W2 + step; t += step) { y.beginPath(); y.moveTo(t, H2 + 2); y.lineTo(t + H2 + 4, -2); y.stroke(); }
    const sp = new Sprite(own(Texture.from(sc)));
    sp.scale.set(1 / DPR); sp.position.set(ox + r[0] - (horiz ? step : 0), oy + r[1] - (horiz ? 0 : step));
    const mk = new Sprite(own(Texture.from(segMasks[gi])));
    mk.scale.set(1 / DPR); mk.position.set(ox + r[0], oy + r[1]);
    sp.mask = mk;
    laneLayer.addChild(sp, mk);
    Object.assign(o, { stripe: sp, sx0: sp.x, sy0: sp.y, horiz, step });
    draw(o, st.locks[gi]);
    return o;
  });
  // Kapının çerçeve parçası tahta çiziminde boyanır, şeritleri ayrı katmanda akar. Burada: dışarıda kapı renginde ok;
  // kilitliyken parçanın üstünde buz ve sayaç (ok yok)
  function draw(o, n) {
    o.v.removeChildren();
    const g = o.g, hex = PALETTE[+g.col.slice(1)];
    // Açık kapı: eşiğin dışında kapı renginde ok (yerinde durur, ara ara hafifçe belirginleşir)
    o.arrows = [];
    if (!n) for (let i = 0; i < g.len; i++) {
      const a = new Sprite(chevTex(pad));
      a.anchor.set(0.5); a.scale.set(1 / DPR);
      a.tint = mixHex(hex, '#ffffff', 0.35);
      a.position.set((i + 0.5 - g.len / 2) * cs, -(ring / 2 + pad * 0.85));
      o.v.addChild(a);
      o.arrows.push(a);
    }
    if (n) {
      // Buz: oyunun buz engel dokusu çubuğun üstüne
      const ice = new Sprite(own(Texture.from(escIceCanvas(g.len * cs, ring + 6, o.gi))));
      ice.anchor.set(0.5); ice.scale.set(1 / DPR);
      o.v.addChild(ice);
      o.ice = ice;
      const vert = g.side === 'left' || g.side === 'right';
      const pill = new Sprite(own(Texture.from(escPillCanvas(n, vert))));
      pill.anchor.set(0.5); pill.scale.set(0.5);
      pill.rotation = -o.v.rotation;
      pill.position.set(0, -(ring / 2 + (vert ? 0.4 : 0.34) * cs));
      o.v.addChild(pill);
      o.pill = pill;
    } else { o.ice = null; o.pill = null; }
    o.lock = n;
  }
  // Çıkışta ufalanma (parçacık sistemi): blok 4×4 parçaya (2×2 blokta 8×8) ve ince kırıntılara bölünür. Parçalar kapı
  // yönünde bir koni içinde fırlar; yerçekimi ve hava direnciyle yay çizer, döner, küçülerek söner. Kapıya yakın parçalar
  // önce kopar. Işık / parlama yok. Güncelleme render() içinde (dt ile).
  const parts = [];
  const SHADE = [0xffffff, 0xffffff, 0xe6e6e6, 0xcfcfcf];
  function spawn(tex0, x, y, w, ang, spd, life, delay, spin) {
    const sp = new Sprite(tex0);
    sp.anchor.set(0.5); sp.width = sp.height = w; sp.tint = SHADE[(Math.random() * SHADE.length) | 0];
    sp.position.set(x, y); sp.rotation = Math.random() * 6.28; sp.visible = delay <= 0;
    fx.addChild(sp);
    parts.push({ sp, vx: Math.cos(ang) * spd, vy: Math.sin(ang) * spd, vr: spin, t: 0, life, delay, k: sp.scale.x });
  }
  function shatterOut(o, dr, dc) {
    const cx0 = ox + (o.x + o.s / 2) * cs, cy0 = oy + (o.z + o.s / 2) * cs, size = cs * o.s;
    const q = shards(o.col), n = 4 * o.s, ps = size / n, dir = Math.atan2(dr, dc);
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) {
      const px = cx0 + (j + 0.5 - n / 2) * ps, py = cy0 + (i + 0.5 - n / 2) * ps;
      // Çıkış kenarına yakınlık: 0 (en yakın) … 1 (en uzak)
      const lead = dc > 0 ? (n - 1 - j) / (n - 1) : dc < 0 ? j / (n - 1) : dr > 0 ? (n - 1 - i) / (n - 1) : i / (n - 1);
      spawn(q[(Math.random() * 4) | 0], px, py, ps * (0.75 + Math.random() * 0.55), dir + (Math.random() - 0.5) * 1.15,
        cs * (3.2 + Math.random() * 3.4) * (1 - lead * 0.35), 0.55 + Math.random() * 0.35, lead * 0.07, (Math.random() - 0.5) * 14);
    }
    for (let k = 0; k < 12 * o.s; k++) {
      spawn(q[(Math.random() * 4) | 0], cx0 + (Math.random() - 0.5) * size * 0.8, cy0 + (Math.random() - 0.5) * size * 0.8, ps * (0.3 + Math.random() * 0.25),
        dir + (Math.random() - 0.5) * 1.9, cs * (4.5 + Math.random() * 4.5), 0.4 + Math.random() * 0.35, Math.random() * 0.06, (Math.random() - 0.5) * 20);
    }
  }
  function stepParts(dt) {
    const G = cs * 15, drag = Math.max(0, 1 - 1.6 * dt);
    for (let i = parts.length - 1; i >= 0; i--) {
      const p = parts[i];
      if (p.delay > 0) { p.delay -= dt; if (p.delay <= 0) p.sp.visible = true; continue; }
      p.t += dt;
      p.vy += G * dt; p.vx *= drag; p.vy *= drag;
      p.sp.x += p.vx * dt; p.sp.y += p.vy * dt; p.sp.rotation += p.vr * dt;
      const f = p.t / p.life;
      p.sp.scale.set(p.k * (1 - 0.45 * f));
      p.sp.alpha = f < 0.55 ? 1 : Math.max(0, 1 - (f - 0.55) / 0.45);
      if (f >= 1) { p.sp.destroy(); parts.splice(i, 1); }
    }
  }
  const api = {
    cs, root,
    pick(px, py) { const r = Math.floor((py - oy) / cs), c = Math.floor((px - ox) / cs); const b = esc.st.blocks.find((q) => r >= q.r && r < q.r + q.s && c >= q.c && c < q.c + q.s); return b ? b.id : null; },
    floorAt(px, py) { return { x: (px - ox) / cs, z: (py - oy) / cs }; },
    toScreen(x, z) { return [ox + x * cs, oy + z * cs]; },
    moveTo(id, r, c) { const o = blocks.get(id); if (o) { o.tx = c; o.tz = r; } },
    hold(id, x, z) { const o = blocks.get(id); if (o) { o.tx = x; o.tz = z; o.held = true; } },
    drop(id, r, c) {
      const o = blocks.get(id); if (!o) return;
      o.tx = c; o.tz = r; o.speed = 22; o.tk = 1; o.held = false; o.vx = o.vz = 0;
      tween(o.v.scale, { x: 1.08, y: 0.92 }, 0.06, Ease.outCubic).then(() => tween(o.v.scale, { x: 1, y: 1 }, 0.2, Ease.outBack));
    },
    lift(id, on) { const o = blocks.get(id); if (!o) return; o.tk = on ? 1.06 : 1; o.held = on; if (on) blockL.addChild(o.v); },
    // Kapıdan çıkış: blok kapının içinden tamamen kayarak geçer; çerçevenin iç kenarında kırpılır (tünele girer gibi
    // kaybolur), sonra kapının dışında ufalanır
    exit(id, dr, dc) {
      const o = blocks.get(id);
      if (!o) return Promise.resolve();
      o.exit = true; o.tk = 1; o.speed = 10; o.held = false;
      const m = new Graphics().rect(ox - inPad, oy - inPad, bw + inPad * 2, bh + inPad * 2).fill(0xffffff);
      root.addChild(m); o.v.mask = m;
      o.tx = (dc ? (dc > 0 ? lv.w + 0.15 : -o.s - 0.15) : o.x); o.tz = (dr ? (dr > 0 ? lv.h + 0.15 : -o.s - 0.15) : o.z);
      return new Promise((res) => { o.onDone = () => { blocks.delete(id); shatterOut(o, dr, dc); o.v.mask = null; m.destroy(); o.v.destroy({ children: true }); res(); }; });
    },
    // Taş kırılır: dört parçaya bölünüp saçılır, söner
    breakStone(r, c) {
      const sp = stones.get(r * lv.w + c);
      if (!sp) return Promise.resolve();
      stones.delete(r * lv.w + c);
      const src = sp.texture.source, fw = src.width / 2, fh = src.height / 2, k = sp.scale.x;
      const ps = [];
      for (let i = 0; i < 2; i++) for (let j = 0; j < 2; j++) {
        const pc = new Sprite(new Texture({ source: src, frame: new Rectangle(i * fw, j * fh, fw, fh) }));
        pc.anchor.set(0.5); pc.scale.set(k);
        pc.position.set(sp.x + (i - 0.5) * cs * 0.5, sp.y + (j - 0.5) * cs * 0.5);
        fx.addChild(pc);
        const dx = (i - 0.5) * 2, dy = (j - 0.5) * 2;
        tween(pc, { x: pc.x + dx * cs * (0.5 + Math.random() * 0.4), y: pc.y + dy * cs * 0.5 + cs * 0.6, rotation: (Math.random() - 0.5) * 3 }, 0.5, Ease.outCubic);
        ps.push(tween(pc, { alpha: 0 }, 0.3, Ease.inQuad, 0.22).then(() => pc.destroy()));
      }
      sp.destroy();
      return Promise.all(ps);
    },
    breakBlock(id) { const o = blocks.get(id); if (!o) return Promise.resolve(); blocks.delete(id); return popBlock(o.sp, o.col, cs * o.s); },
    recolor(id, col) { const o = blocks.get(id); if (o) { o.col = col; o.sp.texture = tex[col]; } },
    spin(id, delay) { const o = blocks.get(id); if (o) tween(o.v.scale, { x: 0 }, 0.12, Ease.inQuad, delay).then(() => tween(o.v.scale, { x: 1 }, 0.18, Ease.outBack)); },
    setLock(gi, n) {
      const o = gates[gi];
      if (n === o.lock) return;
      if (n && o.pill) {
        o.pill.texture = own(Texture.from(escPillCanvas(n, o.g.side === 'left' || o.g.side === 'right')));
        o.pill.scale.set(0.66); tween(o.pill.scale, { x: 0.5, y: 0.5 }, 0.25, Ease.outBack);
        o.lock = n;
        return;
      }
      if (!n && o.ice) {
        // Buz kırılır: buz ve sayaç dağılır, çubuk oklarıyla açılır
        const ice = o.ice, pill = o.pill, gp = o.v.toGlobal({ x: 0, y: 0 });
        const pillPos = o.v.toGlobal(pill.position);
        ice.parent.removeChild(ice); pill.parent.removeChild(pill);
        fx.addChild(pill);
        pill.position.copyFrom(pillPos);
        ice.rotation = o.v.rotation; pill.rotation = 0;
        // Buz kalıbı parçalara bölünüp dışarı saçılır (ışıksız)
        const src = ice.texture.source, fw = src.width / 4, fh = src.height / 2;
        const out = { top: [0, -1], bottom: [0, 1], left: [-1, 0], right: [1, 0] }[o.g.side];
        for (let i = 0; i < 4; i++) for (let j = 0; j < 2; j++) {
          const pc = new Sprite(new Texture({ source: src, frame: new Rectangle(i * fw, j * fh, fw, fh) }));
          pc.anchor.set(0.5); pc.scale.set(1 / DPR); pc.rotation = ice.rotation;
          const lx = (i + 0.5 - 2) * fw / DPR, ly = (j + 0.5 - 1) * fh / DPR, c = Math.cos(ice.rotation), sn = Math.sin(ice.rotation);
          pc.position.set(gp.x + lx * c - ly * sn, gp.y + lx * sn + ly * c);
          fx.addChild(pc);
          const sp = cs * (0.8 + Math.random() * 0.9), side = (Math.random() - 0.5) * cs * 1.2;
          tween(pc, { x: pc.x + out[0] * sp + (out[1] ? side : 0), y: pc.y + out[1] * sp + (out[0] ? side : 0), rotation: pc.rotation + (Math.random() - 0.5) * 4 }, 0.5, Ease.outCubic);
          tween(pc.scale, { x: pc.scale.x * 0.4, y: pc.scale.y * 0.4 }, 0.5, Ease.inQuad);
          tween(pc, { alpha: 0 }, 0.25, Ease.inQuad, 0.28).then(() => pc.destroy());
        }
        ice.destroy();
        tween(pill, { y: pill.y - cs, alpha: 0 }, 0.45, Ease.outCubic).then(() => pill.destroy());
        draw(o, 0);
        o.v.scale.set(0.7); tween(o.v.scale, { x: 1, y: 1 }, 0.4, Ease.outBack);
      }
    },
    gateScreen(gi) { return gateMid(lv.gates[gi]); },
    render(dt) {
      stepParts(dt);
      // Kapı okları: yerinde durur; her ~2,6 sn'de bir iki kez ışıkla parlar (kapılar sırayla, aynı anda değil)
      animT += dt;
      for (const o of gates) {
        if (!o.arrows || !o.arrows.length) continue;
        const ph = (animT + o.gi * 0.45) % 2.6;
        const k = ph < 0.9 ? Math.max(0, Math.sin((ph / 0.9) * Math.PI * 2)) : 0;
        for (const a of o.arrows) a.alpha = 0.7 + k * 0.3;
      }
      // Şeritler kapı boyunca sakin akar (~1,4 sn'de bir şerit); kilitli kapıda buzun altında durur
      for (const o of gates) if (o.stripe && !o.lock) { const ph = ((animT / 1.4 + o.gi * 0.17) % 1) * o.step; if (o.horiz) o.stripe.x = o.sx0 + ph; else o.stripe.y = o.sy0 + ph; }
      for (const o of blocks.values()) {
        if (o.held) {
          // Tutulan blok parmağı kritik sönümlü yayla izler: hızlı, yumuşak, titremesiz, geride kalmadan.
          // Yayın kesin çözümü kullanılır: kare süresi ne olursa olsun kararlı (adım adım hesap, telefon bir an
          // takılıp kare uzayınca salınımı büyütüp bloğu fırlatıyordu)
          const w = 34, e = Math.exp(-w * dt);
          const ex = o.x - o.tx, cx = o.vx + w * ex, ez = o.z - o.tz, cz = o.vz + w * ez;
          o.x = o.tx + (ex + cx * dt) * e; o.vx = (o.vx - w * cx * dt) * e;
          o.z = o.tz + (ez + cz * dt) * e; o.vz = (o.vz - w * cz * dt) * e;
        } else {
          const k = Math.min(1, dt * o.speed);
          o.x += (o.tx - o.x) * k; o.z += (o.tz - o.z) * k;
        }
        o.lf += ((o.held ? 1 : 0) - o.lf) * Math.min(1, dt * 14);
        o.sh.alpha = o.lf; o.sh.y = cs * (0.06 + 0.06 * o.lf);
        o.k += (o.tk - o.k) * Math.min(1, dt * 16);
        o.sp.scale.set((cs * o.s / o.sp.texture.width) * o.k);
        place(o);
        if (o.exit && o.onDone && Math.abs(o.tx - o.x) + Math.abs(o.tz - o.z) < 0.06) { const f = o.onDone; o.onDone = null; f(); }
      }
    },
    dispose() { for (const p of parts) p.sp.destroy(); parts.length = 0; root.destroy({ children: true }); for (const t of owned) if (!t.destroyed) t.destroy(true); owned.length = 0; },
  };
  return api;
}
function startEscape() {
  boardLayer.visible = false;
  $('hud').classList.add('escape');
  const lv = { ...L.esc, mask: L.esc.mask.slice() }, st = escInit(lv);   // maske kopyalanır: kırılan taş bölüm verisini değiştirmesin
  escLayer.removeChildren();
  // Arka plan biraz karartılır (tahta öne çıksın)
  const dim = new Graphics();
  dim.rect(0, 0, W, H).fill({ color: 0x000000, alpha: 0.28 });
  escLayer.addChild(dim);
  esc = { lv, st, v3: null, drag: null };
  esc.v3 = createEscape2D(lv, st, escRect());
  escRenderGoal();
  showScreen('game');
  renderBoosters();
  Sound.start();
  // İlk Blok Kaçışı bölümünde öğretici: tanıtım kartı kapanınca başlar
  const run = runId;
  const tryTut = () => { if (run !== runId || !esc) return; if (screenBlocked()) { setTimeout(tryTut, 300); return; } setTimeout(() => run === runId && escTutStart(), 400); };
  if (levelN === 5 && !Store.get('esc_tut_done', '')) setTimeout(tryTut, 700);
}
// Blok Kaçışı görünümü her karede güncellenir (blokların kayması)
app.ticker.add((tk) => { if (esc && esc.v3 && !covered) esc.v3.render(Math.min(0.05, tk.deltaMS / 1000)); });
function escRenderGoal() {
  const el = $('escTxt');
  if (!el) return;
  el.textContent = esc ? esc.st.blocks.length : 0;
  const fill = $('escFill');
  if (fill && esc) fill.style.width = `${(1 - esc.st.blocks.length / esc.lv.blocks.length) * 100}%`;
}
const escBlock = (id) => esc.st.blocks.find((q) => q.id === id);
// Sürükleme: tuğla parmağı kesintisiz izler ama yalnız boş hücrelerde ilerler (duvara / bloğa değince durur).
// Köşe dönerken öbür eksende en yakın uygun hücreye kendiliğinden hizalanır. Kural durumu (esc.st) her zaman
// tuğlanın en yakın hücresidir; bırakınca tuğla o hücreye yumuşakça oturur. Kendi rengindeki açık kapıya
// yarım hücreden fazla itilen tuğla parçalanarak çıkar.
const escFree = (r, c, id) => r >= 0 && c >= 0 && r < esc.lv.h && c < esc.lv.w && esc.lv.mask[r][c] === '#'
  && !esc.st.blocks.some((q) => q.id !== id && r >= q.r && r < q.r + q.s && c >= q.c && c < q.c + q.s);
// Dokunulan tuğla: önce zemindeki hücre, sonra 3D isabet, en son yakındaki tuğla (affedici dokunuş)
function escPickAt(x, y) {
  const f = esc.v3.floorAt(x, y);
  if (f) {
    const r = Math.floor(f.z), c = Math.floor(f.x);
    const b = esc.st.blocks.find((q) => r >= q.r && r < q.r + q.s && c >= q.c && c < q.c + q.s);
    if (b) return { b, f };
  }
  const id = esc.v3.pick(x, y);
  if (id !== null && id !== undefined && f) return { b: escBlock(id), f };
  if (!f) return null;
  let best = null, bd = 0.8;
  for (const q of esc.st.blocks) { const d = Math.hypot(f.x - (q.c + q.s / 2), f.z - (q.r + q.s / 2)) - (q.s - 1) * 0.5; if (d < bd) { bd = d; best = q; } }
  return best ? { b: best, f } : null;
}
app.stage.on('pointerdown', (e) => {
  if (!esc || !esc.v3 || over || busy || screenBlocked() || esc.drag) return;
  const { x, y } = e.global;
  if (targeting) { escUseBoost(targeting, x, y); return; }
  const hit = escPickAt(x, y);
  if (!hit || !hit.b) return;
  const b = hit.b;
  esc.drag = { id: b.id, pid: e.pointerId, offX: hit.f.x - b.c, offZ: hit.f.z - b.r, px: b.c, pz: b.r, bumped: false };
  esc.v3.lift(b.id, true);
  Sound.pickup(); Haptics.light();
});
app.stage.on('globalpointermove', (e) => {
  const d = esc && esc.drag;
  if (!d || over || e.pointerId !== d.pid) return;
  const f = esc.v3.floorAt(e.global.x, e.global.y);
  if (f) escDragTo(f.x - d.offX, f.z - d.offZ);
});
const escRelease = (e) => {
  const d = esc && esc.drag;
  if (!d || (e && e.pointerId !== undefined && e.pointerId !== d.pid)) return;
  esc.drag = null;
  const b = escBlock(d.id);
  if (b) { esc.v3.drop(d.id, b.r, b.c); Sound.place(); Haptics.light(); }
};
app.stage.on('pointerup', escRelease);
app.stage.on('pointerupoutside', escRelease);
// Bir eksende serbest aralık: tuğla (öbür eksende hizalı, satır/sütun başı `o`) bu eksende nereye kadar gidebilir.
// Döner { lo, hi, exitLo, exitHi }: exit* = o uçta kendi rengindeki açık kapı varsa kapının sırası
function escSpan(b, axis, pos, o) {
  const s = b.s, lv = esc.lv;
  const lineFree = (k) => { for (let i = 0; i < s; i++) if (!(axis === 'x' ? escFree(o + i, k, b.id) : escFree(k, o + i, b.id))) return false; return true; };
  let hi = Math.floor(pos + 1e-6); while (lineFree(hi + s)) hi++;
  let lo = Math.ceil(pos - 1e-6); while (lineFree(lo - 1)) lo--;
  const gateAt = (side) => lv.gates.findIndex((g, k) => g.side === side && esc.st.locks[k] === 0 && g.col === b.col && g.at <= o && o + s - 1 <= g.at + g.len - 1);
  const max = axis === 'x' ? lv.w : lv.h;
  return { lo, hi, exitLo: lo === 0 ? gateAt(axis === 'x' ? 'left' : 'top') : -1, exitHi: hi + s === max ? gateAt(axis === 'x' ? 'right' : 'bottom') : -1 };
}
function escDragTo(tx, tz) {
  const d = esc.drag, b = escBlock(d.id);
  if (!b) return;
  const dx = tx - d.px, dz = tz - d.pz;
  const first = Math.abs(dx) >= Math.abs(dz) ? 'x' : 'z';
  let blocked = false;
  for (const axis of [first, first === 'x' ? 'z' : 'x']) {
    const want = axis === 'x' ? tx : tz;
    let pos = axis === 'x' ? d.px : d.pz, other = axis === 'x' ? d.pz : d.px;
    if (Math.abs(want - pos) < 0.02) continue;
    // Öbür eksende hizalı değilse: gidilmek istenen yönde yolu açık olan en yakın hizaya otur
    if (Math.abs(other - Math.round(other)) > 0.02) {
      const cands = [Math.round(other), Math.round(other) === Math.floor(other) ? Math.ceil(other) : Math.floor(other)];
      // Kapıdan çıkış için hizaya çekme yalnız blok kapıyla neredeyse tam hizalıyken (ucu değince çıkmasın)
      const ok = cands.find((o) => {
        const sp = escSpan(b, axis, pos, o);
        if (want > pos ? sp.hi > pos + 0.02 : sp.lo < pos - 0.02) return true;
        return (want > pos ? sp.exitHi >= 0 : sp.exitLo >= 0) && Math.abs(o - other) <= 0.15;
      });
      if (ok === undefined || Math.abs(ok - other) > 0.6) { if (axis === first) blocked = true; continue; }
      other = ok;
      if (axis === 'x') d.pz = ok; else d.px = ok;
      escSync(d, b);
      if (!escBlock(d.id)) return;
    }
    const sp = escSpan(escBlock(d.id), axis, pos, other);
    // Kapıdan çıkış: tam hizalı blok açık kapısına doğru itilince önce kapının ağzına girer (en çok 0,35 hücre;
    // geçeceği hissedilir), 0,35'i aşınca kapıdan geçer. Ağızdayken bırakılırsa yerine geri oturur.
    const MOUTH = 0.35;
    if (sp.exitHi >= 0 && want > sp.hi + MOUTH) { escPushOut(d, axis === 'x' ? 'right' : 'down', axis, sp.hi); return; }
    if (sp.exitLo >= 0 && want < sp.lo - MOUTH) { escPushOut(d, axis === 'x' ? 'left' : 'up', axis, sp.lo); return; }
    const np = Math.max(sp.exitLo >= 0 ? sp.lo - MOUTH * 0.85 : sp.lo, Math.min(sp.exitHi >= 0 ? sp.hi + MOUTH * 0.85 : sp.hi, want));
    if (Math.abs(np - want) > 0.3 && axis === first) blocked = true;
    if (axis === 'x') d.px = np; else d.pz = np;
    escSync(d, escBlock(d.id));
    if (!escBlock(d.id)) return;
    // Birincil eksende tam hizaya gelmediyse ikinci eksene geçme (çapraz kaymasın)
    if (Math.abs(np - Math.round(np)) > 0.15) break;
  }
  // Duvara / bloğa dayandı: bir kez hafif titreşim
  if (blocked && !d.bumped) { d.bumped = true; Haptics.light(); } else if (!blocked) d.bumped = false;
  esc.v3.hold(d.id, d.px, d.pz);
}
// Kural durumunu tuğlanın en yakın hücresine getir (adım adım; her yeni hücrede tık sesi)
function escSync(d, b) {
  const rc = Math.round(d.px), rr = Math.round(d.pz);
  let guard = 12;
  while (guard-- > 0) {
    const cur = escBlock(d.id);
    if (!cur || (cur.c === rc && cur.r === rr)) return;
    const dir = cur.c < rc ? 'right' : cur.c > rc ? 'left' : cur.r < rr ? 'down' : 'up';
    const res = escApplyStep(esc.lv, esc.st, d.id, dir);
    if (!res || res.info.gate !== undefined) return;
    esc.st = res.st;
    Sound.aim(); Haptics.tick();
  }
}
// Kapıya itilen tuğla: kural durumunda çıkış adımı, ardından parçalanma
function escPushOut(d, dir, axis, edge) {
  if (axis === 'x') d.px = edge; else d.pz = edge;
  escSync(d, escBlock(d.id));
  const b = escBlock(d.id);
  const prevLocks = esc.st.locks;
  const res = escApplyStep(esc.lv, esc.st, d.id, dir);
  if (!res || res.info.gate === undefined) return;
  esc.st = res.st;
  esc.drag = null;
  placed++;
  escExit(b, dir, res.info.gate, prevLocks);
}
async function escExit(b, dir, gi, prevLocks) {
  const [dr, dc] = DIRS[dir], run = runId;
  await esc.v3.exit(b.id, dr, dc);
  if (run !== runId || !esc) return;
  const [gx, gy] = esc.v3.gateScreen(gi);
  Sound.crumble();
  Haptics.medium();
  // Seri: art arda hızlı çıkışlar puanı katlar (2,5 sn içinde)
  const now = performance.now();
  esc.chain = now - (esc.lastOut || 0) < 2500 ? (esc.chain || 1) + 1 : 1;
  esc.lastOut = now;
  const mult = Math.min(5, esc.chain), pts = (b.s > 1 ? 200 : 50) * mult;
  addScore(pts);
  const g = esc.lv.gates[gi], outX = g.side === 'left' ? -1 : g.side === 'right' ? 1 : 0, outY = g.side === 'top' ? -1 : g.side === 'bottom' ? 1 : 0;
  escScorePop(pts, gx + outX * cell * 0.2, gy + (outY ? outY * cell * 0.55 : -cell * 0.9), colorHex[b.col], mult);
  escAfterOut(prevLocks, run);
}
// "AÇILDI" etiketi: açılan kapının hemen dışında (sayacın durduğu yerde), kapının renginde hap; açık kilit simgesi
// ve beyaz yazı. Esneyerek belirir, kısa durur, kapıdan dışa doğru süzülüp söner. Işık / parlama yok.
function escGateLabel(gi) {
  const g = esc.lv.gates[gi], hex = PALETTE[+g.col.slice(1)];
  const k = 2, h = 26, font = `900 14px ${FONT}`, txt = 'AÇILDI!';
  measureG.font = font;
  const tw = measureG.measureText(txt).width, w = Math.ceil(tw + 46);
  const cv = document.createElement('canvas');
  cv.width = (w + 6) * k; cv.height = (h + 8) * k;
  const x = cv.getContext('2d');
  x.scale(k, k); x.translate(3, 2);
  x.fillStyle = 'rgba(0,0,0,0.35)'; x.beginPath(); x.roundRect(1, 3.5, w - 2, h, h / 2); x.fill();
  x.fillStyle = mixHex(hex, '#000000', 0.3); x.beginPath(); x.roundRect(0, 2, w, h, h / 2); x.fill();
  const gr = x.createLinearGradient(0, 0, 0, h);
  gr.addColorStop(0, mixHex(hex, '#ffffff', 0.25)); gr.addColorStop(1, hex);
  x.fillStyle = gr; x.beginPath(); x.roundRect(0, 0, w, h, h / 2); x.fill();
  x.strokeStyle = 'rgba(255,255,255,0.85)'; x.lineWidth = 1.5; x.beginPath(); x.roundRect(0.75, 0.75, w - 1.5, h - 1.5, h / 2 - 0.75); x.stroke();
  // Açık kilit
  x.fillStyle = '#ffffff'; x.strokeStyle = '#ffffff'; x.lineWidth = 2;
  x.beginPath(); x.roundRect(12, 11.5, 10, 8, 2); x.fill();
  x.beginPath(); x.arc(17, 11.5, 3.2, Math.PI, Math.PI * 1.9); x.stroke();
  x.font = font; x.textBaseline = 'middle'; x.lineJoin = 'round';
  x.strokeStyle = mixHex(hex, '#000000', 0.45); x.lineWidth = 3; x.strokeText(txt, 30, h / 2 + 1);
  x.fillStyle = '#ffffff'; x.fillText(txt, 30, h / 2 + 1);
  const sp = new Sprite(Texture.from(cv));
  sp.anchor.set(0.5); sp.scale.set(1 / k);
  // Yer: kapının dışında; yan kapılarda kapının üstünde (ekrana sığacak biçimde)
  const [gx, gy] = esc.v3.gateScreen(gi), cs = esc.v3.cs;
  const out = { top: [0, -1], bottom: [0, 1], left: [-1, 0], right: [1, 0] }[g.side];
  let lx = gx + out[0] * cs * 0.55, ly = out[0] ? gy - (g.len / 2) * cs - cs * 0.42 : gy + out[1] * cs * 0.55;   // yan kapıda kapının üst ucunun üstünde
  lx = Math.max(w / 2 + 8, Math.min(W - w / 2 - 8, lx));
  sp.position.set(lx, ly);
  fx.addChild(sp);
  sp.scale.set(0);
  tween(sp.scale, { x: 0.6, y: 0.6 }, 0.16, Ease.outQuad).then(() => tween(sp.scale, { x: 0.5, y: 0.5 }, 0.22, Ease.outBack));
  tween(sp, { x: lx + out[0] * cs * 0.3, y: ly + (out[1] || -1) * cs * 0.3, alpha: 0 }, 0.4, Ease.inQuad, 1.1).then(() => sp.destroy({ texture: true, textureSource: true }));   // etiket dokusu her kapıda yeni: silinir
}
// Çıkış puanı: net "+50" (beyazdan altına), ışımasız; seride yanında "×2" rozeti.
// Esneyerek belirir, hafifçe yukarı süzülür ve söner. Ekran dışına taşmaz.
function escScorePop(n, x, y, hex, mult) {
  const box = new Container();
  const gs = [...('+' + n)].map((ch) => glyph(ch, 30, '#ffffff', '#ffd75a', 7, { blur: 4, dist: 3, alpha: 0.5, stroke: '#141a4a' }));
  let w = 0;
  for (const g of gs) w += g.adv;
  let px = -w / 2;
  for (const g of gs) { const sp = glyphSprite(g); sp.x = px + g.adv / 2; px += g.adv; box.addChild(sp); }
  let bw = 0;
  if (mult > 1) {
    const bg2 = [...('×' + mult)].map((ch) => glyph(ch, 19, '#ffffff', '#bfe9ff', 5, { blur: 2, dist: 2, alpha: 0.45, stroke: '#0d2a55' }));
    const badge = new Container();
    let bx = 0;
    for (const g of bg2) { const sp = glyphSprite(g); sp.x = bx + g.adv / 2; bx += g.adv; badge.addChild(sp); }
    bw = bx;
    badge.position.set(w / 2 + 4, -12); badge.rotation = 0.18;
    badge.scale.set(0); tween(badge.scale, { x: 1, y: 1 }, 0.3, Ease.outBack, 0.1);
    box.addChild(badge);
  }
  const hw = (w + bw) / 2 + 12;
  box.position.set(Math.max(hw, Math.min(W - hw, x)), Math.max(BY - 20, Math.min(H - safeB - BAR_H - 10, y)));
  fx.addChild(box);
  box.scale.set(0.3);
  tween(box.scale, { x: 1.18, y: 1.18 }, 0.14, Ease.outQuad).then(() => tween(box.scale, { x: 1, y: 1 }, 0.22, Ease.outBack));
  tween(box, { y: box.y - cell * 0.8 }, 1.0, Ease.outCubic);
  tween(box, { alpha: 0 }, 0.3, Ease.inQuad, 0.75).then(() => box.destroy({ children: true }));
}
// Blok(lar) çıktıktan / kırıldıktan sonra: sayaç, buzlu kapılar, bitiş
// ---------- Blok Kaçışı öğreticisi (ilk Blok Kaçışı bölümü, 6. bölüm) ----------
// Parmak, kapısına yolu açık bir bloğu tutup yol boyunca kendi rengindeki kapıya sürükler; yol noktalarla gösterilir.
// 1) "Bloğu sürükle" → ilk çıkış → 2) "Önü açık olanla başla" (ikinci blok gösterilir) → ikinci çıkış →
// 3) "Süre bitmeden hepsini çıkar!" ve süre başlar. Öğretici sürerken süre işlemez. Bir kez gösterilir.
let escTut = null;
const escTutG = new Graphics();
// Bloğun kapısına giden en kısa yol (hücre konumları) ve çıkış yönü; yol yoksa null
function escTutRoute(b) {
  const lv = esc.lv, key = (r, c) => r * lv.w + c;
  const fits = (r, c) => { for (let i = 0; i < b.s; i++) for (let j = 0; j < b.s; j++) if (!escFree(r + i, c + j, b.id)) return false; return true; };
  const exitDir = (r, c) => {
    for (const [side, dir] of [['top', 'up'], ['bottom', 'down'], ['left', 'left'], ['right', 'right']]) {
      const at = side === 'top' ? r === 0 : side === 'bottom' ? r + b.s === lv.h : side === 'left' ? c === 0 : c + b.s === lv.w;
      if (!at) continue;
      const ok = lv.gates.some((g, k) => g.side === side && esc.st.locks[k] === 0 && g.col === b.col
        && (side === 'top' || side === 'bottom' ? g.at <= c && c + b.s - 1 <= g.at + g.len - 1 : g.at <= r && r + b.s - 1 <= g.at + g.len - 1));
      if (ok) return dir;
    }
    return null;
  };
  const prev = new Map([[key(b.r, b.c), null]]), q = [[b.r, b.c]];
  while (q.length) {
    const [r, c] = q.shift();
    const d = exitDir(r, c);
    if (d) {
      const path = [];
      for (let p = [r, c]; p; p = prev.get(key(p[0], p[1]))) path.unshift(p);
      return { path, dir: d };
    }
    for (const [dr, dc] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
      const nr = r + dr, nc = c + dc;
      if (prev.has(key(nr, nc)) || !fits(nr, nc)) continue;
      prev.set(key(nr, nc), [r, c]);
      q.push([nr, nc]);
    }
  }
  return null;
}
// Gösterilecek blok: kapısına en kısa yolu olan küçük blok
function escTutPick() {
  let best = null;
  for (const b of esc.st.blocks) {
    if (b.s > 1) continue;
    const rt = escTutRoute(b);
    if (rt && (!best || rt.path.length < best.rt.path.length)) best = { b, rt };
  }
  return best;
}
function escTutTip(html, kind = '') {
  const el = $('tutTip');
  el.innerHTML = html;
  el.className = 'tut-tip show ' + kind;
  el.style.top = `${H - safeB - BAR_H - 70}px`;
}
function escTutShow() {
  const p = escTutPick();
  if (!p) { escTutEnd(true); return; }
  const pts = p.rt.path.map(([r, c]) => esc.v3.toScreen(c + p.b.s / 2, r + p.b.s / 2));
  const [dr, dc] = DIRS[p.rt.dir], last = pts[pts.length - 1], cs = esc.v3.cs;
  pts.push([last[0] + dc * cs * 0.9, last[1] + dr * cs * 0.9]);
  escTut.id = p.b.id; escTut.pts = pts; escTut.t = 0;
  // Yol: kapıya kadar beyaz noktalar
  escTutG.clear();
  for (let i = 0; i < pts.length - 1; i++) {
    const [x0, y0] = pts[i], [x1, y1] = pts[i + 1], n = Math.max(2, Math.round(Math.hypot(x1 - x0, y1 - y0) / (cs * 0.34)));
    for (let k = i ? 0 : 1; k <= n; k++) escTutG.circle(x0 + (x1 - x0) * k / n, y0 + (y1 - y0) * k / n, Math.max(2.5, cs * 0.06));
  }
  escTutG.fill({ color: 0xffffff, alpha: 0.55 });
  fx.addChild(escTutG);
}
function escTutStart() {
  if (!esc || Store.get('esc_tut_done', '') || levelN !== 5) return;
  escTut = { step: 0, id: -1, pts: null, t: 0, out: 0 };
  escTutTip('<b>Bloğu sürükle</b>kendi rengindeki kapıdan çıkar', 'first');
  escTutShow();
}
// Her çıkıştan sonra çağrılır
function escTutAfterOut() {
  if (!escTut) return;
  escTut.out++;
  escTut.pts = null; escTutG.clear(); $('tutHand').classList.remove('on', 'down');
  if (escTut.out === 1) {
    escTutTip('<b>Harika!</b>Bloklar yalnız kendi rengindeki kapıdan çıkar', 'ok');
    setTimeout(() => { if (!escTut || escTut.out !== 1) return; escTutTip('<b>Önü açık olanla başla</b>Yolu tıkayan blokları kenara çekebilirsin'); escTutShow(); }, 1900);
  } else {
    escTutTip('<b>Süper!</b>Süre bitmeden bütün blokları çıkar', 'ok');
    Store.set('esc_tut_done', '1');
    setTimeout(() => escTutEnd(true), 2000);
  }
}
function escTutEnd(done = false) {
  if (!escTut) return;
  escTut = null;
  if (done) Store.set('esc_tut_done', '1');
  escTutG.clear();
  if (escTutG.parent) escTutG.parent.removeChild(escTutG);
  hideTutTip();
  $('tutHand').classList.remove('on', 'down');
}
// El: bloğun üstünde basar, yol boyunca kapıya kadar sürükler, bırakır; döngü
function escTutTick(dt) {
  if (!escTut || !escTut.pts || !esc) return;
  const hand = $('tutHand');
  if (esc.drag || screenBlocked() || over) { hand.classList.remove('on'); $('tutTip').classList.toggle('away', !!esc.drag); return; }
  $('tutTip').classList.remove('away');
  const pts = escTut.pts, seg = 0.32, travel = (pts.length - 1) * seg, cyc = travel + 1.3;
  escTut.t = (escTut.t + dt) % cyc;
  const T = escTut.t;
  let x, y;
  if (T < 0.45) [x, y] = pts[0];
  else if (T < 0.45 + travel) {
    const u = (T - 0.45) / seg, i = Math.min(pts.length - 2, Math.floor(u)), f = u - i;
    x = pts[i][0] + (pts[i + 1][0] - pts[i][0]) * f; y = pts[i][1] + (pts[i + 1][1] - pts[i][1]) * f;
  } else [x, y] = pts[pts.length - 1];
  hand.classList.add('on');
  hand.classList.toggle('down', T > 0.25 && T < 0.45 + travel);
  hand.style.transform = `translate(${x}px, ${y}px)`;
  hand.style.opacity = T > cyc - 0.35 ? ((cyc - T) / 0.35).toFixed(2) : '1';
}
app.ticker.add((tk) => escTutTick(Math.min(0.05, tk.deltaMS / 1000)));
async function escAfterOut(prevLocks, run) {
  escRenderGoal();
  escTutAfterOut();
  esc.st.locks.forEach((n, k) => {
    if (prevLocks[k] === n) return;
    esc.v3.setLock(k, n);
    if (n === 0) {
      // Buz kırıldı, kapı açıldı
      Sound.crack(true); Sound.chest(); Haptics.heavy();
      escGateLabel(k);
    }
  });
  if (!esc.st.blocks.length) { await wait(0.35); if (run === runId && !over) win(); }
}
function escTargetGlow() {}
async function escUseBoost(k, px, py) {
  const f = esc.v3.floorAt(px, py);
  const r = f ? Math.floor(f.z) : -9, c = f ? Math.floor(f.x) : -9;
  // Kabın dışına dokunmak seçimi iptal eder
  if (!f || r < -1 || c < -1 || r > esc.lv.h || c > esc.lv.w) { setTargeting(null); return; }
  const run = runId, prevLocks = esc.st.locks;
  const center = (b) => esc.v3.toScreen(b.c + b.s / 2, b.r + b.s / 2);
  const breakFx = (b, delay = 0) => wait(delay).then(() => {
    const [x, y] = center(b);
    sparkBurst(x, y, b.s > 1 ? 22 : 12, escHex(b.col), cell * (b.s > 1 ? 1.6 : 1));
    impactFx(x, y, escHex(b.col));
    addScore(b.s > 1 ? 200 : 50, x, y - cell * 0.5);
    return esc.v3.breakBlock(b.id);
  });
  if (k === 'hammer') {
    const id = esc.v3.pick(px, py), b = id === null ? null : escBlock(id);
    if (!b && esc.lv.mask[r] && esc.lv.mask[r][c] === 'S') {
      // Taş kırılır: hücre boşalır
      useBoost('hammer'); mission('booster'); bumpCount('hammer');
      busy = true;
      setTargeting(null);
      const [x, y] = esc.v3.toScreen(c + 0.5, r + 0.5, 0);
      await hammerSwing(x, y, x > W / 2 ? -1 : 1);
      Haptics.heavy(); Sound.hammer(); Sound.crumble();
      shake = 0.6;
      crackFx(x, y);
      esc.lv.mask[r] = esc.lv.mask[r].slice(0, c) + '#' + esc.lv.mask[r].slice(c + 1);
      sparkBurst(x, y, 10, 0x9a9ea8, cell);
      await esc.v3.breakStone(r, c);
      busy = false;
      renderBoosters();
      return;
    }
    if (!b) { Haptics.warning(); Sound.back(); return; }
    useBoost('hammer'); mission('booster'); bumpCount('hammer');
    busy = true;
    setTargeting(null);
    const [x, y] = center(b);
    await hammerSwing(x, y, x > W / 2 ? -1 : 1);
    Haptics.heavy(); Sound.hammer();
    shake = 0.75;
    crackFx(x, y);
    esc.st = escRemoveBlocks(esc.st, [b.id]);
    await breakFx(b);
  } else if (k === 'bomb') {
    const hit = esc.st.blocks.filter((b) => b.r <= r + 1 && b.r + b.s - 1 >= r - 1 && b.c <= c + 1 && b.c + b.s - 1 >= c - 1);
    const rocks = [];
    for (let i = r - 1; i <= r + 1; i++) for (let j = c - 1; j <= c + 1; j++) if (esc.lv.mask[i] && esc.lv.mask[i][j] === 'S') rocks.push([i, j]);
    if (!hit.length && !rocks.length) { Haptics.warning(); Sound.back(); return; }
    useBoost('bomb'); mission('booster'); bumpCount('bomb');
    busy = true;
    setTargeting(null);
    const [x, y] = esc.v3.toScreen(c + 0.5, r + 0.5, 0);
    const pts = [[c - 1, r - 1], [c + 2, r - 1], [c - 1, r + 2], [c + 2, r + 2]].map(([q, p]) => esc.v3.toScreen(q, p, 0));
    const zx = Math.min(...pts.map((p) => p[0])), zy = Math.min(...pts.map((p) => p[1]));
    await bombDrop(x, y, r, c, [zx, zy, Math.max(...pts.map((p) => p[0])) - zx, Math.max(...pts.map((p) => p[1])) - zy]);
    Haptics.heavy(); setTimeout(() => Haptics.heavy(), 110);
    Sound.bomb();
    shake = 1.3;
    screenFlash(0.35, '#fff1c4');
    explosionFx(x, y);
    esc.st = escRemoveBlocks(esc.st, hit.map((b) => b.id));
    for (const [i, j] of rocks) esc.lv.mask[i] = esc.lv.mask[i].slice(0, j) + '#' + esc.lv.mask[i].slice(j + 1);
    if (rocks.length) Sound.crumble();
    await Promise.all([...hit.map((b) => breakFx(b, 0.03 + Math.hypot(b.c + b.s / 2 - c - 0.5, b.r + b.s / 2 - r - 0.5) * 0.05)), ...rocks.map(([i, j]) => esc.v3.breakStone(i, j))]);
  }
  busy = false;
  renderBoosters();
  if (run === runId && esc) escAfterOut(prevLocks, run);
}
// Yenile: küçük tuğlaların renkleri karışır (çözülebilir bir dağılım seçilir); tuğlalar dönerek yeni rengini alır
async function escShuffle() {
  if (busy) return;
  const next = escShuffleColors(esc.lv, esc.st);
  // Çözülebilir yeni bir dizilim yoksa güçlendirici harcanmaz
  if (next === esc.st) { toast('Şu an karıştırılacak uygun dizilim yok'); Haptics.warning(); return; }
  if (!useBoost('shuffle')) return;
  mission('booster'); bumpCount('shuffle');
  busy = true;
  renderBoosters();
  const ico = document.querySelector('.booster-bar .bo-ico.shuffle');
  if (ico) { ico.classList.remove('spin'); void ico.offsetWidth; ico.classList.add('spin'); }
  Haptics.medium(); Sound.shuffle();
  const before = new Map(esc.st.blocks.map((b) => [b.id, b.col]));
  esc.st = next;
  esc.st.blocks.forEach((b, i) => {
    if (before.get(b.id) === b.col) return;
    esc.v3.spin(b.id, i * 0.015);
    setTimeout(() => esc && esc.v3.recolor(b.id, b.col), (i * 0.015 + 0.17) * 1000);
  });
  await wait(0.6);
  busy = false;
}
// Tanıtım kartı görseli: bölümün küçük çizimi
function escTipImage(lv) {
  const u = 26, pad = 12, cv = document.createElement('canvas');
  cv.width = lv.w * u + pad * 2; cv.height = lv.h * u + pad * 2;
  const x = cv.getContext('2d');
  const fl = (r, c) => lv.mask[r][c] === '#' || lv.mask[r][c] === 'S';
  for (let r = 0; r < lv.h; r++) for (let c = 0; c < lv.w; c++) if (fl(r, c)) { x.fillStyle = theme.frame; x.beginPath(); x.roundRect(pad + c * u - 6, pad + r * u - 6, u + 12, u + 12, 6); x.fill(); }
  for (let r = 0; r < lv.h; r++) for (let c = 0; c < lv.w; c++) if (fl(r, c)) { x.fillStyle = theme.board; x.fillRect(pad + c * u, pad + r * u, u, u); }
  for (let r = 0; r < lv.h; r++) for (let c = 0; c < lv.w; c++) if (lv.mask[r][c] === 'S') x.drawImage(obstacleCanvas(escObstKind(levelN, r, c), u * 2), pad + c * u + 1, pad + r * u + 1, u - 2, u - 2);
  for (const gt of lv.gates) {
    x.fillStyle = PALETTE[+gt.col.slice(1)];
    const L0 = gt.len * u - 4;
    if (gt.side === 'top') x.fillRect(pad + gt.at * u + 2, pad - 7, L0, 6);
    if (gt.side === 'bottom') x.fillRect(pad + gt.at * u + 2, pad + lv.h * u + 1, L0, 6);
    if (gt.side === 'left') x.fillRect(pad - 7, pad + gt.at * u + 2, 6, L0);
    if (gt.side === 'right') x.fillRect(pad + lv.w * u + 1, pad + gt.at * u + 2, 6, L0);
  }
  for (const b of lv.blocks) x.drawImage(renderTile(PALETTE[+b.col.slice(1)], u * 2 * b.s), pad + b.c * u + 1, pad + b.r * u + 1, b.s * u - 2, b.s * u - 2);
  return cv.toDataURL();
}

// ---------- Düşen blok bölümleri ----------
// Yukarıdan dörtlü şekiller düşer: sürükle = kaydır, dokun = döndür, aşağı kaydır = hızlı indir.
// Satır tamamlanınca patlar; dipteki çöp satırlardaki simgeler o satır temizlenince toplanır.
const TETRO = {
  I: { size: 4, cells: [[0, 1], [1, 1], [2, 1], [3, 1]], color: 'c6' },
  O: { size: 2, cells: [[0, 0], [1, 0], [0, 1], [1, 1]], color: 'c2' },
  T: { size: 3, cells: [[1, 0], [0, 1], [1, 1], [2, 1]], color: 'c5' },
  S: { size: 3, cells: [[1, 0], [2, 0], [0, 1], [1, 1]], color: 'c3' },
  Z: { size: 3, cells: [[0, 0], [1, 0], [1, 1], [2, 1]], color: 'c0' },
  J: { size: 3, cells: [[0, 0], [0, 1], [1, 1], [2, 1]], color: 'c4' },
  L: { size: 3, cells: [[2, 0], [0, 1], [1, 1], [2, 1]], color: 'c1' },
};
const fallLayer = new Container();
app.stage.addChildAt(fallLayer, app.stage.getChildIndex(fx));
let fall = null;

function fallMetrics() {
  const queueH = L.swap ? 44 : 112;                     // altta sıradaki parçalar + ipucu (kaydırma bölümünde yalnız ipucu)
  const top = BY - 4, bottom = H - safeB - queueH;
  const cs = Math.floor(Math.min((W - (L.bridge ? 16 : 24)) / L.cols, (bottom - top) / L.rows));
  const bw = cs * L.cols, bh = cs * L.rows;
  const ox = Math.round((W - bw) / 2);
  const oy = Math.round(top + Math.max(0, (bottom - top - bh) / 2));
  return { cs, ox, oy, bw, bh, qy: oy + bh + 14 };
}
const fx0 = (c) => fall.m.ox + c * fall.m.cs + fall.m.cs / 2;
const fy0 = (r) => fall.m.oy + r * fall.m.cs + fall.m.cs / 2;
const rotCells = (cells, size) => cells.map(([x, y]) => [size - 1 - y, x]);

// Renk köprüsü bölümünün renkleri (kırmızı, sarı, yeşil, mavi, mor)
const BRIDGE_COL = ['c0', 'c2', 'c3', 'c4', 'c5'];
const bridgeColor = () => BRIDGE_COL[Math.floor(Math.random() * (L.ncol || 4))];
function startFalling() {
  boardLayer.visible = false;
  if (L.bridge) {
    // Tahta ekran genişliğini doldurur; satır sayısı ekranın boyuna göre
    const top = BY - 4, bottom = H - safeB - (L.swap ? 44 : 112), cs = Math.floor((W - 16) / L.cols);
    L.rows = Math.max(L.swap ? 10 : 16, Math.floor((bottom - top) / cs));
  }
  $('hud').classList.add('falling');
  fall = { grid: Array.from({ length: L.rows }, () => Array(L.cols).fill(null)), bag: [], piece: null, queue: [],
    t: 0, lockT: 0, speed: L.fallMs, active: false, soft: false, combo: 0, lines: 0 };
  fallBuild();
  // Dipteki çöp satırlar
  const base = L.rows - L.garbage.length;
  const iconOf = { g: 'gem', s: 'star', h: 'heart' };
  L.garbage.forEach((row, i) => [...row].forEach((ch, c) => {
    if (ch === '.') return;
    const icon = L.sand ? null : iconOf[ch] || null;
    fallSetCell(base + i, c, icon ? 'wood' : L.bridge ? BRIDGE_COL[+ch] : L.sand ? TETRO['IOTSZJL'[(i * 3 + c) % 7]].color : 'block', icon, 0.05 * i + c * 0.02);
  }));
  fall.queue = L.swap ? [] : [fallDraw(), fallDraw(), fallDraw()];
  fallDrawNext();
  showScreen('game');
  renderGoals();
  Sound.fallStart();
  // İlk parça: özel bölüm giriş ekranı ve tanıtım kartları kapanınca gelir (arkada oyun başlamaz)
  const run0 = runId;
  const go = () => { if (!fall || over || runId !== run0 || fall.active) return; if (screenBlocked()) { setTimeout(go, 150); return; } if (!L.swap) fallSpawn(); fall.active = true; };
  setTimeout(go, 700);
}
// Tahta, kenar paneli ve "sıradaki" kutusu
function fallBuild() {
  fallLayer.removeChildren();
  fall.m = fallMetrics();
  const { cs, ox, oy, bw, bh, qy } = fall.m;
  const g = new Graphics();
  // Kaydırma bölümünde tahta zemini açık ve saydam: arka plan hafifçe görünür
  g.roundRect(ox - 5, oy - 5, bw + 10, bh + 10, 12).fill(L.swap ? { color: 0xc9d1e8, alpha: 0.26 } : { color: parseInt(theme.board.slice(1), 16) }).stroke({ color: parseInt(theme.frame.slice(1), 16), width: 3 });
  for (let c = 1; c < L.cols; c++) g.moveTo(ox + c * cs, oy).lineTo(ox + c * cs, oy + bh);
  for (let r = 1; r < L.rows; r++) g.moveTo(ox, oy + r * cs).lineTo(ox + bw, oy + r * cs);
  g.stroke(L.swap ? { color: 0xffffff, width: 1.5, alpha: 0.18 } : { color: parseInt(theme.line.slice(1), 16), width: 1.5 });
  // Tehlike çizgisi: üstteki iki satır
  g.rect(ox, oy, bw, cs * 2).fill({ color: 0xff3a4a, alpha: 0.06 });
  g.moveTo(ox, oy + cs * 2).lineTo(ox + bw, oy + cs * 2).stroke({ color: 0xff5a6a, width: 1.5, alpha: 0.35 });
  // Sıradaki parçalar paneli: üç bölme, ilki (sıradaki) altın çerçeveli
  const qh = L.swap ? 0 : 66, gap = 8, sw = (bw + 10 - gap * 2) / 3;
  fall.slots = (L.swap ? [] : [0, 1, 2]).map((i) => ({ x: ox - 5 + i * (sw + gap) + sw / 2, y: qy + 8 + qh / 2, w: sw }));
  fall.slots.forEach((sl, i) => {
    if (L.sand && i === 2) return;   // kum bölümünde üçüncü kutu bomba düğmesi
    g.roundRect(sl.x - sw / 2, qy + 8, sw, qh, 14).fill({ color: i === 0 ? 0x2a2200 : 0x000014, alpha: i === 0 ? 0.45 : 0.32 })
      .stroke({ color: i === 0 ? 0xffd84a : 0xffffff, width: i === 0 ? 2.5 : 1.5, alpha: i === 0 ? 0.85 : 0.12 });
  });
  fallLayer.addChild(g);
  const lbl = new Text({ text: 'SIRADAKİ', style: { fontFamily: FONT, fontWeight: '900', fontSize: 10, letterSpacing: 1.4, fill: '#ffe27a' } });
  lbl.anchor.set(0.5);
  if (!L.swap) {
  lbl.position.set(fall.slots[0].x, qy + 8);
  const lp = new Graphics().roundRect(-34, -8, 68, 16, 8).fill({ color: 0x3a2a00 }).stroke({ color: 0xffd84a, width: 1.5, alpha: 0.85 });
  lp.position.copyFrom(lbl.position);
  fallLayer.addChild(lp, lbl);
  }
  if (L.bridge && !L.swap) {
    // HIRS barı: tahtanın hemen üstünde; dolunca ÇILGINLIK (kaydırma bölümünde yok)
    const bw2 = Math.round(bw * 0.72), bh2 = 10, bx2 = ox + (bw - bw2) / 2, by2 = oy - 21;
    const bg = new Graphics().roundRect(bx2 - 2, by2 - 2, bw2 + 4, bh2 + 4, 7).fill({ color: 0x0a0624, alpha: 0.85 }).stroke({ color: 0xffd23a, width: 1.5, alpha: 0.55 });
    const fill = new Graphics();
    const lbl = new Text({ text: 'HIRS', style: { fontFamily: FONT, fontWeight: '900', fontSize: 9, letterSpacing: 2, fill: '#ffffff', stroke: { color: '#1a0a40', width: 3, join: 'round' } } });
    lbl.anchor.set(0.5); lbl.position.set(bx2 + bw2 / 2, by2 + bh2 / 2);
    fallLayer.addChild(bg, fill, lbl);
    fall.fev = { fill, lbl, x: bx2, y: by2, w: bw2, h: bh2 };
  }
  const hint = new Text({ text: L.swap ? 'Bloğu sağa-sola ya da yukarı-aşağı çek  ·  Aynı renkten 3 tane diz' : L.bridge ? 'Aynı renkten 8 blok birleştir  ·  Dokun: döndür' : 'Sürükle: kaydır  ·  Dokun: döndür  ·  Aşağı kaydır: indir', style: { fontFamily: FONT, fontWeight: '800', fontSize: Math.min(11.5, W / 33), fill: 'rgba(200,212,255,0.6)' } });
  hint.anchor.set(0.5, 0);
  hint.position.set(W / 2, L.swap ? qy + 2 : qy + 8 + qh + 8);
  fallLayer.addChild(hint);
  fall.blocks = new Container();
  fall.icons = new Container();
  if (L.sand) {
    // Alttan yükselen sıra tahtanın altından yavaşça görünür: bloklar tahta alanıyla kırpılır
    // Kaydırma bölümünde tahtanın üst kenarından dışarı hiçbir şey taşmaz
    const mt = L.swap ? oy : oy - cs * 3;
    fall.boardMask = new Graphics().rect(ox - 4, mt, bw + 8, oy + bh - mt).fill(0xffffff);
    fall.blocks.mask = fall.boardMask;
    fallLayer.addChild(fall.boardMask);
  }
  fall.guide = new Sprite(beamTexture());
  fall.guide.blendMode = 'add';
  fall.guide.visible = false;
  fall.ghost = new Graphics();
  fall.streaks = new Container();
  for (let i = 0; i < 4; i++) { const st = new Sprite(streakTexture()); st.anchor.set(0.5); st.blendMode = 'add'; st.visible = false; st.t = i / 4; fall.streaks.addChild(st); }
  fall.cur = new Container();
  // Parça tahtanın üstünden kayarak girer: tahta dışında kalan kısmı kırpılır
  fall.curMask = new Graphics().rect(ox - 4, oy, bw + 8, bh + cs).fill(0xffffff);
  fall.cur.mask = fall.curMask;
  fall.nextView = new Container();
  fall.fxl = new Container();
  // Oyun dünyası tek kapta: kum bölümünde tahta sürekli yükselirken hepsi birlikte kayar
  setTimeout(placeFallBomb, 0);
  fall.world = new Container();
  fall.world.addChild(fall.guide, fall.streaks, fall.ghost, fall.blocks, fall.icons, fall.cur, fall.fxl);
  fallLayer.addChild(fall.world, fall.curMask, fall.nextView);
}
// Huzmede aşağı akan ince ışık çizgisi dokusu
let fallStreakTex = null;
function streakTexture() {
  if (fallStreakTex) return fallStreakTex;
  const w = 8, h = 64, cv = document.createElement('canvas');
  cv.width = w; cv.height = h;
  const x = cv.getContext('2d'), img = x.createImageData(w, h);
  for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
    const a = Math.pow(Math.sin(Math.PI * (j + 0.5) / h), 1.6) * Math.pow(Math.sin(Math.PI * (i + 0.5) / w), 2);
    const k = (j * w + i) * 4;
    img.data[k] = img.data[k + 1] = img.data[k + 2] = 255; img.data[k + 3] = Math.round(a * 255);
  }
  x.putImageData(img, 0, 0);
  fallStreakTex = Texture.from(cv);
  return fallStreakTex;
}
// Akan çizgiler huzme boyunca aşağı süzülür; hayalet parça hafifçe nefes alır
function fallFx(dt) {
  if (!fall || !fall.streaks) return;
  const gd = fall.guide, on = gd.visible && !!fall.piece && !over;
  fall.ghost.alpha = 0.82 + Math.sin(time * 4) * 0.18;
  for (const st of fall.streaks.children) {
    if (!on) { st.visible = false; continue; }
    st.t += dt * 1.1;
    if (st.t >= 1 || st.lane === undefined) { st.t %= 1; st.lane = Math.random(); }
    const h = gd.height, cs = fall.m.cs;
    st.visible = h > cs * 0.8;
    st.tint = gd.tint;
    st.width = Math.max(2, cs * 0.12);
    st.height = Math.min(h * 0.45, cs * 1.6);
    st.x = gd.x + cs * 0.25 + st.lane * Math.max(0, gd.width - cs * 0.5);
    st.y = gd.y + st.t * h;
    st.alpha = 0.55 * Math.sin(Math.PI * st.t);
  }
}
// Düşüş ışığı dokusu: yukarıda tamamen saydam, aşağıya doğru parlayan, yumuşak kenarlı huzme
let fallBeamTex = null;
function beamTexture() {
  if (fallBeamTex) return fallBeamTex;
  const w = 64, h = 256, cv = document.createElement('canvas');
  cv.width = w; cv.height = h;
  const x = cv.getContext('2d'), img = x.createImageData(w, h);
  for (let j = 0; j < h; j++) {
    const ay = Math.pow(j / (h - 1), 1.7);
    for (let i = 0; i < w; i++) {
      const u = (i + 0.5) / w;
      const body = Math.pow(Math.sin(Math.PI * u), 0.8) * 0.55;
      const edge = Math.exp(-Math.pow((Math.min(u, 1 - u) - 0.06) / 0.025, 2)) * 0.7;
      const core = Math.exp(-Math.pow((u - 0.5) / 0.12, 2)) * 0.25;
      const a = Math.min(1, (body + edge + core) * ay);
      const k = (j * w + i) * 4;
      img.data[k] = img.data[k + 1] = img.data[k + 2] = 255;
      img.data[k + 3] = Math.round(a * 255);
    }
  }
  x.putImageData(img, 0, 0);
  fallBeamTex = Texture.from(cv);
  return fallBeamTex;
}
// Özel (kaydırma) bölümde renkli bloklar simgeli jöle blok; diğer modlarda normal blok
const symTex = {};
function ftex(color) {
  if (!L || !L.swap || !fall || !(color === 'grey' || /^c\d$/.test(color))) return tex[color];
  const S = Math.max(64, Math.round(fall.m.cs * DPR)), k = color + '_' + S;
  return symTex[k] || (symTex[k] = Texture.from(renderSymbolTile(color === 'grey' ? '#6b6f80' : PALETTE[+color.slice(1)], S)));
}
function fallSetCell(r, c, color, icon = null, delay = 0) {
  const { cs } = fall.m;
  const s = new Sprite(ftex(color));
  s.anchor.set(0.5);
  s.width = s.height = cs;
  s.position.set(fx0(c), fy0(r));
  fall.blocks.addChild(s);
  const b = { s, color, icon, is: null };
  if (icon) {
    const is = new Sprite(iconTex[icon]);
    is.anchor.set(0.5);
    is.width = is.height = cs;
    is.position.copyFrom(s.position);
    fall.icons.addChild(is);
    b.is = is;
  }
  if (delay >= 0) {
    const k = s.scale.x;
    s.scale.set(0);
    tween(s.scale, { x: k, y: k }, 0.3, Ease.outBack, delay);
  }
  fall.grid[r][c] = b;
  return b;
}
// 7'li torba: her şekil sırayla bir kez gelir, uzun süre aynı şekil beklenmez
function fallDraw() {
  if (!fall.bag.length) {
    fall.bag = Object.keys(TETRO);
    for (let i = fall.bag.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [fall.bag[i], fall.bag[j]] = [fall.bag[j], fall.bag[i]]; }
  }
  const kind = fall.bag.pop();
  return L.bridge ? kind + ':' + bridgeColor() : kind;   // köprü bölümünde her parçanın rengi rastgele
}
const qKind = (q) => q.split(':')[0];
const qColor = (q) => q.split(':')[1] || TETRO[qKind(q)].color;
function fallFits(cells, x, y) {
  for (const [cx2, cy2] of cells) {
    const c = x + cx2, r = y + cy2;
    if (c < 0 || c >= L.cols || r >= L.rows) return false;
    if (r >= 0 && fall.grid[r][c]) return false;
  }
  return true;
}
function fallSpawn() {
  const q = fall.queue.shift();
  fall.queue.push(fallDraw());
  const kind = qKind(q), t = TETRO[kind];
  const p = { kind, cells: t.cells.map((c) => [...c]), size: t.size, color: fall.feverT > 0 ? 'joker' : qColor(q), x: Math.floor((L.cols - t.size) / 2), y: kind === 'I' ? -1 : 0 };
  fall.piece = p;
  fall.t = 0; fall.lockT = 0; fall.soft = false;
  fallDrawNext(true);
  if (!fallFits(p.cells, p.x, p.y)) { fallLose(); return; }
  fall.ghost.clear();
  if (fall.guide) fall.guide.visible = false;
  fallMakeCur(p);
  // Tahtanın üstünden süzülerek girer
  fall.vis = { x: p.x, y: p.y - 1.6 };
  fall.cur.alpha = 0;
  tween(fall.cur, { alpha: 1 }, 0.16);
  fallRender();
}
// Düşen parçanın görünümü: 4 blok + kilitlenmeden önce yanan beyaz parıltı katmanı.
// Kap, parçanın dönme merkezinde durur (size/2): dönüş ve yalpalama bu noktanın çevresinde olur.
function fallMakeCur(p) {
  const cur = fall.cur;
  for (const ch of cur.removeChildren()) ch.destroy();
  fall.curB = []; fall.curG = [];
  const cs = fall.m.cs, bomb = p.kind === 'BOMB';
  for (let i = 0; i < (bomb ? 1 : p.cells.length); i++) {
    const s = new Sprite(bomb ? bombBallTex() : tex[p.color]);
    s.anchor.set(0.5);
    s.width = s.height = cs * (bomb ? 2.4 : 1);
    const g = new Sprite(bomb ? glowTex : tex.white);
    g.anchor.set(0.5);
    g.width = g.height = cs * (bomb ? 3.6 : 0.96);
    g.blendMode = 'add';
    if (bomb) g.tint = 0xff4a2a;
    g.alpha = 0;
    cur.addChild(s);
    fall.curB.push(s); fall.curG.push(g);
  }
  for (const g of fall.curG) bomb ? cur.addChildAt(g, 0) : cur.addChild(g);
  fall.spin = 0; fall.lean = 0; fall.squash = 0; fall.wasGrounded = false;
  fallPlaceCur(p);
}
function fallPlaceCur(p) {
  const cs = fall.m.cs, h = p.size / 2;
  if (p.kind === 'BOMB') { fall.curB[0].position.set(0, 0); fall.curG[0].position.set(0, 0); return; }   // 2×2 bomba bloğu tek görüntü
  p.cells.forEach(([x, y], i) => {
    const px = (x + 0.5 - h) * cs, py = (y + 0.5 - h) * cs;
    fall.curB[i].position.set(px, py);
    fall.curG[i].position.set(px, py);
  });
}
// Her kare: parça mantıksal konumunu yumuşakça izler (yerçekimi satır arasında kesintisiz akar),
// yana kayarken yalpalar, döndükten sonra yerine oturur, yere değince ezilip toparlanır.
function fallAnim(dt) {
  if (!fall || !fall.m) return;
  // Tahta yayı (sert inişte aşağı çöker, geri sıçrar)
  const bp = fall.bump || (fall.bump = { y: 0, v: 0 });
  bp.v += (-bp.y * 320 - bp.v * 17) * dt; bp.y += bp.v * dt;
  fallLayer.y = bp.y;
  const p = fall.piece;
  if (!p || !fall.vis) return;
  const cs = fall.m.cs, v = fall.vis;
  const grounded = !fallFits(p.cells, p.x, p.y + 1);
  let ty = p.y;
  if (fall.dropping) {
    v.y = Math.min(p.y, v.y + dt * 70);               // hızlı indirme: saniyede 70 satır
    v.x += (p.x - v.x) * Math.min(1, dt * 40);
    if (v.y >= p.y - 0.001) { v.y = p.y; fall.dropping = false; fallLock(true); return; }
  } else {
    const interval = fall.soft ? 45 : fall.speed;
    if (!grounded && fall.active && !busy) ty = p.y + Math.min(0.92, fall.t / interval);   // satırlar arasında akış
    const k = Math.min(1, dt * 26);
    v.x += (p.x - v.x) * k;
    v.y += (ty - v.y) * Math.min(1, dt * (ty > v.y ? 30 : 40));
  }
  // Yere ilk değiş: ezilme + toz + hafif yay
  if (grounded && !fall.wasGrounded && !fall.dropping && Math.abs(v.y - p.y) < 0.35) {
    fall.squash = 0.6;
    bp.v += cs * 1.2;
    fallDust(p, 0.6);
  }
  fall.wasGrounded = grounded;
  fall.lean += (Math.max(-0.12, Math.min(0.12, (p.x - v.x) * 0.22)) - fall.lean) * Math.min(1, dt * 18);
  fall.spin *= Math.pow(0.0005, dt);                  // dönüş animasyonu ~0.12 sn'de oturur
  if (Math.abs(fall.spin) < 0.002) fall.spin = 0;
  fall.squash = Math.max(0, fall.squash - dt * 4);
  const sq = Math.sin(fall.squash / 0.6 * Math.PI) * fall.squash;
  const h = p.size / 2;
  fall.cur.position.set(fall.m.ox + (v.x + h) * cs, fall.m.oy + (v.y + h) * cs + sq * cs * 0.12);
  fall.cur.rotation = fall.spin + fall.lean;
  fall.cur.scale.set(1 + sq * 0.07, 1 - sq * 0.1);
  // Bomba: kırmızı ışıkla nabız atar, hafifçe sallanır, fitilinden kıvılcım saçar
  if (p.kind === 'BOMB') {
    const k = 0.5 + 0.5 * Math.sin(time * 9);
    for (const g of fall.curG) g.alpha = 0.3 + 0.3 * k;
    const tick = Math.pow(Math.max(0, Math.sin(time * Math.PI * 2.2)), 12);   // saat gibi kısa tik
    for (const b of fall.curB) {
      b.rotation = Math.sin(time * 5) * 0.04;
      const base = (cs * 2.4) / b.texture.width;
      b.scale.set(base * (1 + 0.07 * tick), base * (1 + 0.05 * tick));
    }
    const b0 = fall.curB[0];
    if (b0) {
      // Fitil ateşi: uçta titreyen sıcak ışık
      if (!fall.fuseGlow || fall.fuseGlow.destroyed) {
        fall.fuseGlow = new Sprite(glowTex);
        fall.fuseGlow.anchor.set(0.5); fall.fuseGlow.blendMode = 'add'; fall.fuseGlow.tint = 0xffc23a;
        fall.cur.addChild(fall.fuseGlow);
      }
      const fg = fall.fuseGlow;
      fg.position.set(b0.x + BOMB_TIP.x * b0.width, b0.y + BOMB_TIP.y * b0.height);
      fg.width = fg.height = cs * (0.7 + Math.random() * 0.35);
      fg.alpha = 0.75 + Math.random() * 0.25;
    }
    fall.fuseT = (fall.fuseT || 0) + dt;
    if (fall.fuseT > 0.045 && b0) {
      fall.fuseT = 0;
      const b = b0, q = b.toGlobal({ x: BOMB_TIP.x * b.texture.width, y: BOMB_TIP.y * b.texture.height });
      const sp = new Sprite(sparkTex);
      sp.anchor.set(0.5); sp.blendMode = 'add'; sp.tint = Math.random() < 0.5 ? 0xffd25a : 0xffffff;
      sp.width = sp.height = cs * (0.25 + Math.random() * 0.25);
      sp.position.set(q.x, q.y);
      fx.addChild(sp);
      tween(sp, { x: q.x + (Math.random() - 0.5) * cs * 1.2, y: q.y - cs * (0.3 + Math.random() * 0.7), alpha: 0 }, 0.35, Ease.outCubic).then(() => sp.destroy());
    }
    return;
  }
  // Kilitlenmeye yaklaşırken parça beyaz nabızla parlar
  const lk = grounded && !fall.dropping ? Math.min(1, fall.lockT / 0.45) : 0;
  const ga = lk * (0.18 + 0.22 * (0.5 + 0.5 * Math.sin(time * (14 + lk * 18))));
  for (const g of fall.curG) g.alpha = ga;
}
// Parçanın alt kenarından iki yana savrulan toz ve ışık kırıntıları
function fallDust(p, power = 1, px = null, py = null) {
  const cs = fall.m.cs;
  const has = new Set(p.cells.map(([x, y]) => x + ',' + y));
  const bottoms = p.cells.filter(([x, y]) => !has.has(x + ',' + (y + 1)));
  for (const [x, y] of bottoms) {
    const bx = fall.m.ox + ((px ?? p.x) + x + 0.5) * cs, by = fall.m.oy + ((py ?? p.y) + y + 1) * cs;
    for (let k = 0; k < Math.round(2 + power * 3); k++) {
      const d = new Sprite(glowTex);
      d.anchor.set(0.5);
      d.tint = 0xdfe6ff; d.alpha = 0.35 * power;
      d.width = d.height = cs * (0.35 + Math.random() * 0.35);
      d.position.set(bx + (Math.random() - 0.5) * cs * 0.8, by - cs * 0.05);
      fall.fxl.addChild(d);
      const dir = Math.random() < 0.5 ? -1 : 1;
      tween(d, { x: d.x + dir * cs * (0.4 + Math.random() * 0.8) * (0.6 + power * 0.6), y: by - cs * (0.15 + Math.random() * 0.4), alpha: 0, width: cs * 1.1, height: cs * 1.1 }, 0.45 + Math.random() * 0.2, Ease.outCubic).then(() => d.destroy());
    }
  }
}
function fallDrawNext(shift = false) {
  const v = fall.nextView;
  v.removeChildren();
  if (L.swap) return;
  fall.queue.forEach((q, i) => {
    if (L.sand && i >= 2) return;
    const t = { ...TETRO[qKind(q)], color: fall.feverT > 0 ? 'joker' : qColor(q) }, sl = fall.slots[i];
    const u = Math.floor(Math.min(i === 0 ? 17 : 13, (sl.w - 16) / 4));
    const xs = t.cells.map(([x]) => x), ys = t.cells.map(([, y]) => y);
    const mx = Math.min(...xs), my = Math.min(...ys);
    const w = (Math.max(...xs) - mx + 1) * u, h = (Math.max(...ys) - my + 1) * u;
    const box = new Container();
    box.position.set(sl.x, sl.y + (i === 0 ? 3 : 0));
    for (const [x, y] of t.cells) {
      const s2 = new Sprite(tex[t.color]);
      s2.anchor.set(0.5);
      s2.width = s2.height = u;
      s2.position.set(-w / 2 + (x - mx) * u + u / 2, -h / 2 + (y - my) * u + u / 2);
      box.addChild(s2);
    }
    box.alpha = i === 0 ? 1 : 0.55;
    v.addChild(box);
    if (shift) {
      // Sıra sola kayar, en sondaki yeni parça belirir
      const from = i < 2 ? fall.slots[i + 1].x : sl.x + sl.w * 0.6;
      const a = box.alpha;
      box.x = from;
      if (i === 2) box.alpha = 0;
      tween(box, { x: sl.x, alpha: a }, 0.28, Ease.outCubic);
      if (i === 0) { const k = box.scale.x; box.scale.set(k * 0.8); tween(box.scale, { x: k, y: k }, 0.3, Ease.outBack); }
    }
  });
}
function fallGhostY() {
  const p = fall.piece;
  let y = p.y;
  while (fallFits(p.cells, p.x, y + 1)) y++;
  return y;
}
function fallRender(pop = false) {
  const p = fall.piece;
  if (!p) return;
  const gy = fallGhostY();
  if (fall.curB) fallPlaceCur(p);
  // Hayalet parça: tüm parçayı saran tek dış çizgi + yumuşak ışıma + çok hafif dolgu
  const gh = fall.ghost;
  gh.clear();
  if (p.kind === 'BOMB') {
    // Patlama alanı: kırmızı daire + yok olacak bloklar işaretli
    const cs = fall.m.cs, R = bombRadius(), ky = gy + 1, kx = p.x + 1;
    for (let r = Math.floor(ky) - R - 1; r <= ky + R; r++) for (let c = Math.floor(kx) - R - 1; c <= kx + R; c++) {
      if (r < 0 || c < 0 || r >= L.rows || c >= L.cols || Math.hypot(r + 0.5 - ky, c + 0.5 - kx) > R + 0.3) continue;
      gh.rect(fall.m.ox + c * cs + 1, fall.m.oy + r * cs + 1, cs - 2, cs - 2).fill({ color: 0xff3a3a, alpha: fall.grid[r][c] ? 0.32 : 0.08 });
    }
    const cx3 = fall.m.ox + kx * cs, cy3 = fall.m.oy + ky * cs;
    gh.circle(cx3, cy3, (R + 0.3) * cs).stroke({ width: Math.max(2, cs * 0.1), color: 0xff4a3a, alpha: 0.9 });
    gh.circle(cx3, cy3, (R + 0.3) * cs + cs * 0.18).stroke({ width: Math.max(1, cs * 0.05), color: 0xffffff, alpha: 0.35 });
  } else if (gy !== p.y) {
    const cs = fall.m.cs, col = colorHex[p.color] ?? themeHex;
    const X = (x) => fall.m.ox + (p.x + x) * cs, Y = (y) => fall.m.oy + (gy + y) * cs;
    for (const [x, y] of p.cells) if (gy + y >= 0) gh.rect(X(x), Y(y), cs, cs).fill({ color: col, alpha: 0.1 });
    pieceOutline(gh, p.cells, X, Y, cs, col);
  }
  // Parçanın genişliğinde tek ışık huzmesi: parçanın altından ineceği yerin üstüne kadar
  const gd = fall.guide;
  const xs = p.cells.map(([x]) => x), ys = p.cells.map(([, y]) => y);
  const minX = Math.min(...xs), maxX = Math.max(...xs);
  const top = Math.max(0, p.y + Math.max(...ys) + 1), bot = gy + Math.min(...ys);
  if (bot > top) {
    const cs = fall.m.cs;
    gd.position.set(fall.m.ox + (p.x + minX) * cs + cs * 0.06, fall.m.oy + top * cs);
    gd.width = (maxX - minX + 1) * cs - cs * 0.12;
    gd.height = (bot - top) * cs;
    gd.tint = colorHex[p.color] ?? themeHex;
    gd.alpha = 0.42;
    gd.visible = true;
  } else gd.visible = false;
}
// Parçanın dış sınırını tek, kapalı ve içe kaydırılmış parlak bir çizgi olarak çizer (hayalet parça).
// cells: parça hücreleri [x, y]; X/Y: kafes köşe koordinatını ekrana çevirir; cs: hücre boyu
function pieceOutline(gh, cells, X, Y, cs, col) {
  const has = new Set(cells.map(([x, y]) => x + ',' + y));
  const d = Math.max(1.5, cs * 0.06), lw = Math.max(1.6, cs * 0.06);
  const next = new Map();
  for (const [x, y] of cells) {
    if (!has.has(x + ',' + (y - 1))) next.set(`${x},${y}`, [x + 1, y]);
    if (!has.has((x + 1) + ',' + y)) next.set(`${x + 1},${y}`, [x + 1, y + 1]);
    if (!has.has(x + ',' + (y + 1))) next.set(`${x + 1},${y + 1}`, [x, y + 1]);
    if (!has.has((x - 1) + ',' + y)) next.set(`${x},${y + 1}`, [x, y]);
  }
  const loops = [];
  while (next.size) {
    const [k0] = next.keys();
    let cur = k0.split(',').map(Number);
    const pts = [];
    for (let g = 0; g < 64; g++) {
      const key = cur.join(',');
      const nx = next.get(key);
      if (!nx) break;
      next.delete(key);
      pts.push(cur);
      cur = nx;
      if (cur.join(',') === k0) break;
    }
    // Düz devam eden noktaları at, köşeleri içe kaydır
    const corners = pts.filter((q, i) => {
      const a2 = pts[(i - 1 + pts.length) % pts.length], c2 = pts[(i + 1) % pts.length];
      return (q[0] - a2[0]) * (c2[1] - q[1]) - (q[1] - a2[1]) * (c2[0] - q[0]) !== 0;
    });
    loops.push(corners.map((q, i) => {
      const a2 = corners[(i - 1 + corners.length) % corners.length], c2 = corners[(i + 1) % corners.length];
      const d1 = [Math.sign(q[0] - a2[0]), Math.sign(q[1] - a2[1])], d2 = [Math.sign(c2[0] - q[0]), Math.sign(c2[1] - q[1])];
      return [X(q[0]) + (-d1[1] - d2[1]) * d, Y(q[1]) + (d1[0] + d2[0]) * d];
    }));
  }
  const line = (width, color, alpha) => {
    for (const L2 of loops) { gh.moveTo(L2[0][0], L2[0][1]); for (let i = 1; i < L2.length; i++) gh.lineTo(L2[i][0], L2[i][1]); gh.closePath(); }
    gh.stroke({ width, color, alpha, join: 'round' });
  };
  line(lw * 4, col, 0.14);
  line(lw * 2.2, col, 0.22);
  line(lw, col, 0.95);
  line(Math.max(1, lw * 0.4), 0xffffff, 0.35);
}
function fallMove(dx, dy) {
  const p = fall && fall.piece;
  if (!p || !fall.active || fall.dropping) return false;
  if (!fallFits(p.cells, p.x + dx, p.y + dy)) return false;
  p.x += dx; p.y += dy;
  if (dx) { fall.lockT = 0; Sound.aim(); }
  fallRender();
  return true;
}
function fallRotate() {
  const p = fall && fall.piece;
  if (!p || !fall.active || fall.dropping) return;
  if (p.kind === 'O') { fall.spin -= Math.PI / 2; Sound.click(); Haptics.light(); return; }   // kare şekil değiştirmez ama dokununca yine 90° döner (geri bildirim)
  const cells = rotCells(p.cells, p.size);
  for (const k of [0, -1, 1, -2, 2]) {
    for (const ky of [0, -1]) {
      if (fallFits(cells, p.x + k, p.y + ky)) {
        p.cells = cells; p.x += k; p.y += ky;
        fall.lockT = 0;
        Sound.click();
        Haptics.light();
        fallRender();
        fall.spin -= Math.PI / 2;           // yeni dizilim 90° geriden başlayıp yerine döner
        return;
      }
    }
  }
  Haptics.warning();
}
function fallHardDrop() {
  const p = fall && fall.piece;
  if (!p || !fall.active || fall.dropping) return;
  const y0 = p.y;
  p.y = fallGhostY();
  if (p.y === y0) { fallLock(true); return; }
  // Düşüş izi: her sütunda parçanın renginde, yukarıda sönen ışık şeritleri
  const cs = fall.m.cs, col = colorHex[p.color] ?? 0xffffff;
  const tops = new Map();
  for (const [x, y] of p.cells) tops.set(x, Math.min(tops.get(x) ?? 99, y));
  for (const [x, y] of tops) {
    const tr = new Sprite(beamTexture());
    tr.anchor.set(0.5, 1);
    tr.blendMode = 'add';
    tr.tint = col;
    tr.width = cs * 0.86;
    tr.height = (p.y - y0) * cs + cs * 0.5;
    tr.position.set(fx0(p.x + x), fall.m.oy + (p.y + y) * cs + cs * 0.2);
    tr.alpha = 0.75;
    fall.fxl.addChild(tr);
    tween(tr, { alpha: 0, width: cs * 0.3 }, 0.32, Ease.outQuad).then(() => tr.destroy());
  }
  fall.dropping = true;
  fall.ghost.clear();
  if (fall.guide) fall.guide.visible = false;
  Sound.aim();
}
async function fallLock(hard = false) {
  const p = fall.piece;
  if (!p) return;
  fall.piece = null;
  fall.ghost.clear();
  if (fall.guide) fall.guide.visible = false;
  for (const ch of fall.cur.removeChildren()) ch.destroy();
  fall.curB = null; fall.curG = null; fall.vis = null;
  fall.cur.rotation = 0; fall.cur.scale.set(1);
  const cs = fall.m.cs;
  const fresh = new Set();
  if (p.kind === 'BOMB') await fallBomb(p, fresh);
  else {
    for (const [x, y] of p.cells) {
      const r = p.y + y, c = p.x + x;
      if (r < 0) continue;
      const b = fallSetCell(r, c, p.color, null, -1);
      fresh.add(b);
      const k = b.s.scale.x;
      b.s.scale.set(k * (hard ? 1.16 : 1.1), k * (hard ? 0.8 : 0.88));
      tween(b.s.scale, { x: k, y: k }, hard ? 0.26 : 0.2, Ease.outBack);
      // Yerleşme parlaması
      const fl = new Sprite(tex.white);
      fl.anchor.set(0.5); fl.blendMode = 'add';
      fl.width = fl.height = cs * 0.96;
      fl.position.copyFrom(b.s.position);
      fl.alpha = hard ? 0.75 : 0.45;
      fall.fxl.addChild(fl);
      tween(fl, { alpha: 0 }, 0.28, Ease.outQuad).then(() => fl.destroy());
    }
    if (hard) {
      // Çarpma: tahta çöker ve yaylanır, alt kenardan yatay ışık dalgası ve kıvılcımlar
      const bp = fall.bump || (fall.bump = { y: 0, v: 0 });
      bp.v += cs * 7;
      fallDust(p, 1.2);
      const has = new Set(p.cells.map(([x, y]) => x + ',' + y));
      const bottoms = p.cells.filter(([x, y]) => !has.has(x + ',' + (y + 1)));
      const col = colorHex[p.color] ?? 0xffffff;
      for (const [x, y] of bottoms) {
        const bx = fx0(p.x + x), by = fall.m.oy + (p.y + y + 1) * cs;
        const w = new Sprite(glowTex);
        w.anchor.set(0.5); w.blendMode = 'add'; w.tint = col;
        w.width = cs * 1.2; w.height = cs * 0.35; w.alpha = 0.9;
        w.position.set(bx, by);
        fall.fxl.addChild(w);
        tween(w, { width: cs * 3.2, height: cs * 0.2, alpha: 0 }, 0.35, Ease.outCubic).then(() => w.destroy());
        for (let k = 0; k < 3; k++) {
          const sp = new Sprite(sparkTex);
          sp.anchor.set(0.5); sp.blendMode = 'add';
          sp.tint = Math.random() < 0.5 ? 0xffffff : col;
          sp.width = sp.height = cs * (0.18 + Math.random() * 0.14);
          sp.position.set(bx + (Math.random() - 0.5) * cs * 0.8, by);
          fall.fxl.addChild(sp);
          const dir = Math.random() < 0.5 ? -1 : 1;
          tween(sp, { x: sp.x + dir * cs * (0.6 + Math.random() * 1.2), y: by - cs * (0.4 + Math.random() * 0.9), alpha: 0 }, 0.4 + Math.random() * 0.2, Ease.outCubic).then(() => sp.destroy());
        }
      }
      shake = Math.max(shake, 0.25);
      Haptics.medium();
    }
  }
  placed++;
  lifeAtRisk = true;
  mission('place');
  Sound.place();
  Haptics.light();
  // Tepeye taştıysa kaybedilir
  if (p.kind !== 'BOMB' && p.cells.some(([, y]) => p.y + y < 0)) { fallLose(); return; }
  if (L.sand) {
    // Kum kuralı: bloklar akıp oturur; dolan satırlar patlar, sonra kalanlar yine akar (zincirleme)
    busy = true;
    fall.lastCol = p.x + Math.round(p.cells.reduce((a, [x]) => a + x, 0) / p.cells.length);
    const chain = await fallResolve(fresh);
    if (chain < 0) { busy = false; return; }
    if (!chain) fall.combo = 0;
    if (fall && !over) await tickTimeBombs();
    // Patlayan sayaçlı bombanın boşluğu: üstündeki bloklar (güçler dahil) aşağı düşer, oluşan grup patlar
    if (L.bridge && fall && !over) await fallResolve(null);
    busy = false;
  } else {
    const full = [];
    for (let r = 0; r < L.rows; r++) if (fall.grid[r].every(Boolean)) full.push(r);
    if (full.length) await fallClear(full);
    else fall.combo = 0;
  }
  if (!fall || over) return;
  if (levelDone()) { fall.active = false; win(); return; }
  fallSpawn();
}
// ---------- Kum bölümü engelleri ----------
// Buzlu sıra (Okyanus+), sayaçlı bomba (Çöl+), taş blok (Uzay+), deprem (Buzul+).
// Buz ve taş: bulunduğu satır ilk dolunca çatlar/kırılır ve satırdaki diğer bloklar patlar; satır yeniden doldurulmalı.
function hazardTex(q) {
  const S = Math.max(64, Math.round(fall.m.cs * DPR)), key = q.kind === 'ice' ? (L.swap ? 'swice_' : 'ice_') + q.color : q.kind === 'stone' ? (q.hp > 0 ? 'stone' : 'stone2') : q.kind === 'tbomb' ? 'tbomb' + q.timer : q.color;
  if (tex[key] && tex[key].source.width === S) return tex[key];
  if (!q.kind) return ftex(q.color);
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  if (q.kind === 'ice') {
    x.drawImage((L.swap && q.color !== 'block' ? renderSymbolTile : renderTile)(q.color === 'block' ? theme.block : PALETTE[+q.color.slice(1)], S), 0, 0, S, S);
    // Kaydırma bölümünde buz kaplaması bloğun yuvarlak köşeli şekline kırpılır
    if (L.swap) { const m = S * 0.04, w = S - 2 * m; x.save(); x.beginPath(); x.roundRect(m, m, w, w, w * 0.16); x.clip(); x.drawImage(renderIce(S), m, m, w, w); x.restore(); }
    else x.drawImage(renderIce(S), 0, 0, S, S);
  } else if (q.kind === 'stone') {
    x.drawImage(renderTile('#8d93a6', S), 0, 0, S, S);
    x.strokeStyle = 'rgba(30,32,48,0.75)'; x.lineWidth = S * 0.05; x.lineCap = 'round'; x.lineJoin = 'round';
    const cracks = q.hp > 0 ? [[[0.3, 0.22], [0.42, 0.42], [0.36, 0.6]]] : [[[0.3, 0.22], [0.42, 0.42], [0.36, 0.6], [0.5, 0.78]], [[0.42, 0.42], [0.66, 0.38], [0.78, 0.56]], [[0.66, 0.38], [0.62, 0.2]]];
    for (const c of cracks) { x.beginPath(); x.moveTo(S * c[0][0], S * c[0][1]); for (const [a, b] of c.slice(1)) x.lineTo(S * a, S * b); x.stroke(); }
    x.fillStyle = 'rgba(255,255,255,0.18)';
    for (const [a, b, r] of [[0.66, 0.7, 0.04], [0.24, 0.7, 0.03], [0.72, 0.26, 0.03]]) { x.beginPath(); x.arc(S * a, S * b, S * r, 0, 7); x.fill(); }
  } else if (q.kind === 'tbomb') {
    x.drawImage(renderTimerBomb(S, q.timer, q.timer <= 2, FONT), 0, 0, S, S);
  }
  tex[key] = Texture.from(cv);
  return tex[key];
}
// Dolu satır, içinde buz/taş varsa: zırh çatlar, satırdaki diğer bloklar patlar, üstlerindeki bloklar iner
async function crackRow(r, fresh) {
  const row = fall.grid[r], cs = fall.m.cs, jobs = [], cols = [];
  Sound.crack(false);
  Haptics.medium();
  row.forEach((b, c) => {
    if (b.hp > 0) {
      b.hp--;
      if (b.kind === 'ice') { b.kind = null; }
      b.s.texture = hazardTex(b.kind ? b : { color: b.color });
      const k = b.s.scale.x;
      b.s.scale.set(k * 1.15); tween(b.s.scale, { x: k, y: k }, 0.25, Ease.outBack);
      const fl = new Sprite(tex.white);
      fl.anchor.set(0.5); fl.blendMode = 'add'; fl.width = fl.height = cs * 0.96; fl.position.copyFrom(b.s.position); fl.alpha = 0.6;
      fall.fxl.addChild(fl);
      tween(fl, { alpha: 0 }, 0.3, Ease.outQuad).then(() => fl.destroy());
      return;
    }
    if (b.kind === 'tbomb') defuseBonus(b);
    row[c] = null;
    cols.push(c);
    jobs.push(wait(Math.abs(c - (L.cols - 1) / 2) * 0.02).then(() => popBlock(b.s, b.color, cs)));
  });
  await Promise.all(jobs);
  addScore(cols.length * 10, fall.m.ox + fall.m.bw / 2, fy0(r));
  for (const c of cols) for (let y = 0; y < r; y++) { const b = fall.grid[y][c]; if (b) fresh.add(b); }
}
// Sayaçlı bomba satırıyla birlikte patladı: etkisiz hâle getirildi, ödül
function defuseBonus(b) {
  addScore(300, b.s.x, b.s.y);
  const ring = new Sprite(ringTex);
  ring.anchor.set(0.5); ring.blendMode = 'add'; ring.tint = 0x7aff9a;
  ring.position.copyFrom(b.s.position); ring.width = ring.height = fall.m.cs;
  fall.fxl.addChild(ring);
  tween(ring, { width: fall.m.cs * 3, height: fall.m.cs * 3, alpha: 0 }, 0.45, Ease.outCubic).then(() => ring.destroy());
}
// Her parça yerleşince sayaçlar azalır; sıfırlanan bomba patlar ve alttan sıralar fırlatır
async function tickTimeBombs() {
  const boom = [];
  fall.grid.forEach((row, r) => row.forEach((b, c) => {
    if (!b || b.kind !== 'tbomb') return;
    b.timer--;
    if (b.timer <= 0) { boom.push([r, c, b]); return; }
    b.s.texture = hazardTex(b);
    if (b.timer <= 2) { const k = b.s.scale.x; b.s.scale.set(k * 1.25); tween(b.s.scale, { x: k, y: k }, 0.3, Ease.outBack); }
  }));
  if (!boom.length) return;
  const cs = fall.m.cs;
  for (const [r, c, b] of boom) {
    fall.grid[r][c] = null;
    const x = b.s.x, y = b.s.y;
    popBlock(b.s, 'bomb', cs);
    const gl = new Sprite(glowTex);
    gl.anchor.set(0.5); gl.blendMode = 'add'; gl.tint = 0xff6a2a; gl.position.set(x, y); gl.width = gl.height = cs * 2;
    fall.fxl.addChild(gl);
    tween(gl, { width: cs * 6, height: cs * 6, alpha: 0 }, 0.45, Ease.outCubic).then(() => gl.destroy());
  }
  if (L.swap) fallGravity();   // patlayan bombanın üstündeki bloklar düşer (havada kalmaz)
  Sound.bomb(); Haptics.heavy();
  shake = Math.max(shake, 0.9);
  bigText(`+${boom.length * 2} SIRA!`, ['#ffe3e8', '#ff6b86'], 0xff4d6d, fall.m.oy + fall.m.bh * 0.45);
  await wait(0.25);
  for (let i = 0; i < boom.length * 2 && fall && !over; i++) { riseCommit(); await wait(0.12); }
}
// Deprem: uyarı (sarsıntı + yazı) ardından tahta birden birkaç sıra yükselir
async function quakeHit() {
  const n = (L.hz && L.hz.quakeRows) || 2;
  busy = true;
  Sound.bomb(); Haptics.heavy();
  shake = Math.max(shake, 1.2);
  for (let i = 0; i < n && fall && !over; i++) { riseCommit(); const bp = fall.bump || (fall.bump = { y: 0, v: 0 }); bp.v -= fall.m.cs * 4; await wait(0.14); }
  busy = false;
}
// ---------- Bomba (kum ve özel bölüm) ----------
// Düşen parça bombaya dönüşür; değdiği yerde yuvarlak bir krater açar, üstündeki bloklar aşağı akar.
function fallArmBomb() {
  const p = fall && fall.piece;
  if (!p || !fall.active || fall.dropping || busy || over || p.kind === 'BOMB') return;
  if (boostCount('bomb') <= 0) { openShop('bomb'); return; }
  useBoost('bomb');
  renderBoosters(); renderFallBomb();
  const cx2 = p.x + Math.floor(p.size / 2) - 1, cy2 = p.y + Math.floor(p.size / 2) - 1;
  Object.assign(p, { kind: 'BOMB', cells: [[0, 0], [1, 0], [0, 1], [1, 1]], size: 2, color: 'bomb', x: Math.min(L.cols - 2, Math.max(0, cx2)), y: Math.max(-2, cy2) });
  while (!fallFits(p.cells, p.x, p.y) && p.y > -3) p.y--;
  fall.vis = { x: p.x, y: p.y };
  fallMakeCur(p);
  fallRender();
  Sound.click(); Haptics.medium();
  $('fallBomb').classList.add('armed');
  const k = fall.cur.scale.x;
  fall.cur.scale.set(k * 1.6);
  tween(fall.cur.scale, { x: k, y: k }, 0.3, Ease.outBack);
}
// Patlama yarıçapı (hücre, 2×2 bomba bloğunun merkezinden): düşen blok bölümünde 5, büyük özel bölüm tahtasında 6
const bombRadius = () => (L.special ? 6 : 5);
// Düşen bomba görüntüsü: dinamit demeti (kullanıcı seçimi)
// BOMB_TIP: fitil ucu (doku merkezine göre, doku boyuna oranla); kıvılcım ve fitil ateşi buradan çıkar
let bombBall = null, bombCv = null;
const BOMB_TIP = { x: 0.33, y: -0.42 };
// Normal bölümlerdeki bombanın aynısı (güçlendirici simgesi): fitil ucu simgede (56.5, 9)/64
function bombBallTex() {
  if (boostTex.bomb) { BOMB_TIP.x = 0.30; BOMB_TIP.y = -0.365; return boostTex.bomb; }   // yeni bomba çiziminde fitilin ucu
  if (!bombBall) bombBall = Texture.from(bombCanvas());
  return bombBall;
}
function bombCanvas() {
  if (bombCv) return bombCv;
  // Dinamit demeti (2×2 alan): üç kırmızı çubuk, metal bant, örgülü fitil; oyunun lacivert dış çizgili parlak tarzı
  const S = 256, cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d'), ol = '#10164a';
  x.fillStyle = 'rgba(0,0,20,0.3)'; x.beginPath(); x.ellipse(S * 0.5, S * 0.88, S * 0.34, S * 0.05, 0, 0, 7); x.fill();
  const top = S * 0.26, h = S * 0.6, w = S * 0.18;
  [0.22, 0.41, 0.6].forEach((fx, i) => {
    const sx = S * fx, dy = i === 1 ? -S * 0.03 : 0;
    const g = x.createLinearGradient(sx, 0, sx + w, 0);
    g.addColorStop(0, '#ff8a94'); g.addColorStop(0.25, '#ff4757'); g.addColorStop(0.7, '#d81e34'); g.addColorStop(1, '#8a0a1c');
    x.fillStyle = g; x.beginPath(); x.roundRect(sx, top + dy, w, h, S * 0.045); x.fill();
    x.lineWidth = S * 0.018; x.strokeStyle = ol; x.stroke();
    // Parlama şeridi
    x.fillStyle = 'rgba(255,255,255,0.5)'; x.beginPath(); x.roundRect(sx + w * 0.18, top + dy + S * 0.05, w * 0.16, h - S * 0.12, w * 0.08); x.fill();
    // Kâğıt kapak
    x.fillStyle = '#f2e6c8'; x.beginPath(); x.ellipse(sx + w / 2, top + dy + S * 0.012, w / 2 - S * 0.012, S * 0.03, 0, 0, 7); x.fill();
    x.lineWidth = S * 0.012; x.stroke();
    x.fillStyle = '#c8b48a'; x.beginPath(); x.arc(sx + w / 2, top + dy + S * 0.012, S * 0.012, 0, 7); x.fill();
  });
  // Metal bant
  const bg = x.createLinearGradient(0, S * 0.55, 0, S * 0.65);
  bg.addColorStop(0, '#9aa2b8'); bg.addColorStop(0.45, '#eef1f8'); bg.addColorStop(1, '#5c6482');
  x.fillStyle = bg; x.beginPath(); x.roundRect(S * 0.18, S * 0.55, S * 0.64, S * 0.1, S * 0.025); x.fill();
  x.lineWidth = S * 0.016; x.strokeStyle = ol; x.stroke();
  // Örgülü fitil: ortadaki çubuktan
  const f0 = [S * 0.5, S * 0.23], f1 = [S * 0.56, S * 0.08], f2 = [S * 0.74, S * 0.1];
  const fuse = () => { x.beginPath(); x.moveTo(...f0); x.quadraticCurveTo(...f1, ...f2); };
  x.lineCap = 'round';
  fuse(); x.strokeStyle = ol; x.lineWidth = S * 0.05; x.stroke();
  fuse(); x.strokeStyle = '#a8763a'; x.lineWidth = S * 0.03; x.stroke();
  x.setLineDash([S * 0.015, S * 0.018]); fuse(); x.strokeStyle = '#f0c27a'; x.lineWidth = S * 0.014; x.stroke(); x.setLineDash([]);
  BOMB_TIP.x = f2[0] / S - 0.5; BOMB_TIP.y = f2[1] / S - 0.5;
  bombCv = cv;
  return cv;
}
async function fallBomb(p, fresh) {
  $('fallBomb').classList.remove('armed');
  busy = true;   // hazırlık sırasında tahta yükselmesin
  const R = bombRadius(), cs = fall.m.cs;
  const ky = p.y + 1, kx = p.x + 1;   // 2×2 bloğun merkezi (hücre köşesi koordinatı)
  const cr = Math.max(0, Math.round(ky - 0.5)), cc = Math.round(kx - 0.5);
  // Hazırlık: bomba yerinde şişer, beyaz yanar (an kısa durur, sonra patlar)
  {
    const bx = new Sprite(bombBallTex());
    bx.anchor.set(0.5); bx.position.set(fall.m.ox + kx * cs, fall.m.oy + ky * cs); bx.width = bx.height = cs * 2.4;
    const wh = new Sprite(glowTex);
    wh.anchor.set(0.5); wh.blendMode = 'add'; wh.tint = 0xffffff; wh.alpha = 0;
    wh.position.copyFrom(bx.position); wh.width = wh.height = cs * 2.4;
    fall.fxl.addChild(bx, wh);
    const k = bx.scale.x;
    Sound.click();
    await Promise.all([tween(bx.scale, { x: k * 1.45, y: k * 1.3 }, 0.15, Ease.inQuad), tween(wh, { alpha: 1, width: cs * 3.4, height: cs * 3.4 }, 0.15, Ease.inQuad)]);
    bx.destroy(); tween(wh, { alpha: 0 }, 0.2).then(() => wh.destroy());
  }
  const jobs = [], cols = new Set();
  let topHit = L.rows;
  for (let r = cr - R - 1; r <= cr + R + 1; r++) for (let c = cc - R - 1; c <= cc + R + 1; c++) {
    if (r < 0 || c < 0 || r >= L.rows || c >= L.cols) continue;
    const d = Math.hypot(r + 0.5 - ky, c + 0.5 - kx);
    if (d > R + 0.3) continue;
    cols.add(c);
    topHit = Math.min(topHit, r);
    const b = fall.grid[r][c];
    if (!b) continue;
    fall.grid[r][c] = null;
    jobs.push(wait(d * 0.035).then(() => popBlock(b.s, b.color, cs)));
  }
  // Patlama koreografisi: ekran parlaması → ateş topu → iki şok dalgası → kıvılcım yağmuru → duman → yanık izi
  const x = fall.m.ox + kx * cs, y = fall.m.oy + ky * cs, span = cs * (R * 2 + 1);
  screenFlash(0.55, '#ffd27a');
  const core = new Sprite(glowTex);
  core.anchor.set(0.5); core.blendMode = 'add'; core.tint = 0xffffff;
  core.position.set(x, y); core.width = core.height = cs * 1.5;
  fall.fxl.addChild(core);
  tween(core, { width: span * 0.9, height: span * 0.9, alpha: 0 }, 0.3, Ease.outCubic).then(() => core.destroy());
  // Ateş topu: iç içe kabaran bulutlar (sarı çekirdek → turuncu → kızıl dış)
  const FIRE = [[0xffe27a, 0.55, 0], [0xffa030, 0.8, 0.03], [0xff6a1a, 1.05, 0.06], [0xff3a1a, 1.25, 0.09], [0xffb84a, 0.7, 0.05], [0xd8301a, 1.4, 0.12]];
  FIRE.forEach(([tint, sc, dl], i) => {
    const f = new Sprite(glowTex);
    f.anchor.set(0.5); f.blendMode = 'add'; f.tint = tint; f.alpha = 0;
    const a = (i / FIRE.length) * Math.PI * 2, off = i > 0 ? cs * R * 0.22 : 0;
    f.position.set(x + Math.cos(a) * off, y + Math.sin(a) * off);
    f.width = f.height = cs * 1.5;
    fall.fxl.addChild(f);
    tween(f, { alpha: 0.95 }, 0.06, Ease.linear, dl);
    tween(f, { width: span * sc, height: span * sc, x: x + Math.cos(a) * off * 1.8, y: y + Math.sin(a) * off * 1.8 - cs * 0.6 }, 0.5, Ease.outCubic, dl);
    tween(f, { alpha: 0 }, 0.55, Ease.inQuad, dl + 0.18).then(() => f.destroy());
  });
  // Tahta bir an turuncuya aydınlanır
  const lit = new Sprite(tex.white);
  lit.blendMode = 'add'; lit.tint = 0xff8a3a; lit.alpha = 0.35;
  lit.position.set(fall.m.ox, fall.m.oy); lit.width = fall.m.bw; lit.height = fall.m.bh;
  fall.fxl.addChildAt(lit, 0);
  tween(lit, { alpha: 0 }, 0.5, Ease.outQuad).then(() => lit.destroy());
  // Yerde yatay toz dalgası
  const dust = new Sprite(glowTex);
  dust.anchor.set(0.5); dust.tint = 0xc8b8a8; dust.alpha = 0.5;
  dust.position.set(x, y + cs * 0.4); dust.width = cs * 2; dust.height = cs * 0.8;
  fall.fxl.addChild(dust);
  tween(dust, { width: span * 1.8, height: cs * 1.4, alpha: 0 }, 0.7, Ease.outCubic).then(() => dust.destroy());
  for (let k = 0; k < 2; k++) {
    const ring = new Sprite(ringTex);
    ring.anchor.set(0.5); ring.blendMode = 'add'; ring.tint = k ? 0xffffff : 0xffb03a;
    ring.position.set(x, y); ring.width = ring.height = cs;
    fall.fxl.addChild(ring);
    tween(ring, { width: span * (1.3 + k * 0.4), height: span * (1.3 + k * 0.4), alpha: 0 }, 0.5 + k * 0.15, Ease.outCubic, k * 0.07).then(() => ring.destroy());
  }
  // Yanık izi: krater merkezinde yavaşça sönen koyu leke
  const scorch = new Graphics().circle(0, 0, cs * (R + 0.3)).fill({ color: 0x1a0a04, alpha: 0.45 });
  scorch.position.set(x, y);
  fall.fxl.addChildAt(scorch, 0);
  tween(scorch, { alpha: 0 }, 1.6, Ease.inQuad, 0.5).then(() => scorch.destroy());
  // Kıvılcım yağmuru: yaylar çizerek savrulur
  for (let i = 0; i < 26; i++) {
    const sp = new Sprite(sparkTex);
    sp.anchor.set(0.5); sp.blendMode = 'add'; sp.tint = i % 3 ? 0xffc04a : 0xffffff;
    sp.width = sp.height = cs * (0.35 + Math.random() * 0.45);
    sp.position.set(x, y);
    fall.fxl.addChild(sp);
    const a = Math.random() * Math.PI * 2, dd = cs * (R + 1.5) * (0.5 + Math.random() * 0.8);
    const tx = x + Math.cos(a) * dd, ty = y + Math.sin(a) * dd * 0.8;
    tween(sp, { x: tx }, 0.7, Ease.outCubic);
    tween(sp, { y: ty - cs * 1.5 }, 0.3, Ease.outCubic).then(() => tween(sp, { y: ty + cs * 1.2, alpha: 0 }, 0.45, Ease.inQuad)).then(() => sp.destroy());
  }
  // Duman: yükselip büyüyerek dağılır
  for (let i = 0; i < 10; i++) {
    const sm = new Sprite(glowTex);
    sm.anchor.set(0.5); sm.tint = 0x3a3440; sm.alpha = 0;
    const a = Math.random() * Math.PI * 2, d0 = cs * R * Math.random() * 0.6;
    sm.position.set(x + Math.cos(a) * d0, y + Math.sin(a) * d0);
    sm.width = sm.height = cs * (1.6 + Math.random());
    fall.fxl.addChild(sm);
    tween(sm, { alpha: 0.45 }, 0.25, Ease.outQuad, 0.15)
      .then(() => tween(sm, { y: sm.y - cs * (2 + Math.random() * 2), alpha: 0, width: cs * 4, height: cs * 4 }, 1.1 + Math.random() * 0.4, Ease.outCubic))
      .then(() => sm.destroy());
  }
  Sound.bomb();
  Haptics.heavy();
  setTimeout(() => Haptics.heavy(), 140);
  shake = Math.max(shake, 1.3);
  const bp = fall.bump || (fall.bump = { y: 0, v: 0 });
  bp.v += cs * 9;
  await Promise.all(jobs);
  // Kraterin üstündeki bloklar aşağı akar
  for (const c of cols) for (let r = 0; r < topHit + R * 2 + 1 && r < L.rows; r++) { const b = fall.grid[r][c]; if (b) fresh.add(b); }
}
// Bomba düğmesi: sıradaki panelin üçüncü kutusunda (sayı = elindeki bomba)
function placeFallBomb() {
  const el = $('fallBomb');
  if (!fall || !L.sand || !fall.slots || !fall.slots[2]) { el.classList.remove('show'); return; }
  const sl = fall.slots[2];
  el.style.left = `${sl.x}px`;
  el.style.top = `${sl.y}px`;
  el.style.width = `${sl.w}px`;
  el.style.height = `66px`;
  el.classList.toggle('compact', sl.w < 118);   // dar ekranda simge üstte, yazı altta
  // Kutudaki simge: normal bölümlerdeki bomba simgesinin aynısı (kıvılcım simgenin içinde)
  el.classList.add('show');
  renderFallBomb();
}
function renderFallBomb() {
  const n = boostCount('bomb'), c = $('fallBombN');
  c.textContent = n > 0 ? n : '+';
  c.classList.toggle('buy', n <= 0);
}
$('fallBomb').addEventListener('click', (e) => { e.stopPropagation(); fallArmBomb(); });
$('fallBomb').addEventListener('pointerdown', (e) => e.stopPropagation());
// Kum akışı (yalnız yeni yerleşen parçanın blokları): altı boş blok düşer; yanda en az iki kat boşluk varsa oraya
// devrilir. Tahtadaki eski bloklar ve alttan yükselen sıralar yerinde kalır (boşluklar kendiliğinden dolmaz).
// ---------- Renk grubu ----------
// Aynı renkten L.group (8) ya da daha fazla blok birbirine değince grup, merkezinden dışa dalga hâlinde patlar.
// Taş, sayaçlı bomba ve güçler gruba katılmaz; yanlarında grup patlayınca etkilenirler. Sonra bloklar düşer,
// yeni grup oluşursa zincirleme devam eder (kombo).
const bridgeCol = (b) => (b && !b.power && b.kind !== 'stone' && b.kind !== 'tbomb' ? b.color : null);
function findBridges() {
  // Joker (çılgınlık parçası) her renge uyar: her grupta ayrı sayılır, kendisi grup başlatmaz
  const R = L.rows, C = L.cols, g = fall.grid, seen = new Set(), out = [], min = L.group || 8;
  for (let r = 0; r < R; r++) for (let c0 = 0; c0 < C; c0++) {
    const col = bridgeCol(g[r][c0]);
    if (!col || col === 'joker' || seen.has(r * C + c0)) continue;
    const cells = [], q = [[r, c0]], local = new Set([r * C + c0]);
    seen.add(r * C + c0);
    while (q.length) {
      const [y, x] = q.pop();
      cells.push([y, x]);
      for (const [dy, dx] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const ny = y + dy, nx = x + dx, k = ny * C + nx;
        if (ny < 0 || ny >= R || nx < 0 || nx >= C || local.has(k)) continue;
        const nc = bridgeCol(g[ny][nx]);
        if (nc !== col && nc !== 'joker') continue;
        local.add(k);
        if (nc !== 'joker') seen.add(k);
        q.push([ny, nx]);
      }
    }
    if (cells.length >= min) out.push({ color: col, cells });
  }
  return out;
}
// Akış: yerçekimi tahtayı anında günceller, düşüş animasyonu arkada oynar. Patlayacak grup yoksa beklemeden
// sıradaki parça gelir (donma hissi olmaz); grup varsa bloklar oturduktan sonra patlar (zincir sırası görünsün).
async function bridgeResolve() {
  let chain = 0;
  let g = fallGravity();
  for (;;) {
    if (!fall || over) return -1;
    const comps = L.swap ? findLines() : findBridges();
    if (!comps.length) break;
    // Güç, oyuncunun kaydırdığı bloğun yerinde doğar (zincirdeki patlamalarda grubun ortasında)
    if (L.swap && fall.swapBlocks) for (const k of comps) k.swapAt = k.cells.find(([r, c]) => fall.swapBlocks.includes(fall.grid[r][c]));
    await g;
    if (!fall || over) return -1;
    chain++;
    const pw = await bridgeClear(comps);
    if (!fall || over) return -1;
    if (L.swap) {
      // Güç patlayan sıranın en alttaki boş hücresinde doğar, sonra üstündekiler düşer
      for (const k of comps) {
        if (!k.pk) continue;
        const free = k.cells.filter(([r, c]) => !fall.grid[r][c]);
        const at = free.find(([r, c]) => k.swapAt && k.swapAt[0] === r && k.swapAt[1] === c) || free[Math.floor(free.length / 2)];
        if (at) makePower(at[0], at[1], k.pk, k.dir, k.cells.map(([r2, c2]) => [fx0(c2), fy0(r2) + fall.world.y + fallLayer.y]));
      }
      fall.swapBlocks = null;
      g = fallGravity();
      continue;
    }
    g = fallGravity();
    if (pw >= 2 && fall) fallSpawnPower(pw, comps.flatMap((k) => k.cells.filter((_, i) => i % 3 === 0).map(([r, c]) => [fx0(c), fy0(r) + fall.world.y + fallLayer.y])));
  }
  return chain;
}
// Grubun dış hattı: her hücrenin grupta komşusu olmayan kenarı çizilir (her şekilde güvenli: boşluklu, dallı gruplar)
function groupOutline(g, cells, cs, col) {
  const has = new Set(cells.map(([r, c]) => r * 1000 + c));
  const ox = fall.m.ox, oy = fall.m.oy;
  const seg = [];
  for (const [r, c] of cells) {
    const x0 = ox + c * cs, y0 = oy + r * cs, x1 = x0 + cs, y1 = y0 + cs;
    if (!has.has((r - 1) * 1000 + c)) seg.push([x0, y0, x1, y0]);
    if (!has.has((r + 1) * 1000 + c)) seg.push([x0, y1, x1, y1]);
    if (!has.has(r * 1000 + c - 1)) seg.push([x0, y0, x0, y1]);
    if (!has.has(r * 1000 + c + 1)) seg.push([x1, y0, x1, y1]);
  }
  for (const [w, color, a] of [[Math.max(4, cs * 0.28), col, 0.45], [Math.max(2, cs * 0.1), 0xffffff, 1]]) {
    for (const [ax, ay, bx, by] of seg) g.moveTo(ax, ay).lineTo(bx, by);
    g.stroke({ color, width: w, alpha: a, cap: 'round' });
  }
}
// Kaydırma bölümü patlaması: kısa ve net. Bloklar beyaz yanıp hafif büyür, renkli halka ve kıvılcım, parçalar dağılır.
// Uçuşan parçaları beklemez: tahta hemen akmaya devam eder.
async function swapPop(parts, hx, gx, gy, gdy, cs, first, total) {
  for (const p of parts) {
    tween(p.ov, { alpha: 0.8 }, 0.05);
    tween(p.b.s.scale, { x: p.k * 1.13, y: p.k * 1.13 }, 0.08, Ease.outQuad);
  }
  await wait(0.1);
  if (first) {
    Sound.clear(Math.min(4, 1 + Math.floor(total / 4)), fall ? fall.combo : 1);
    total >= 5 || (fall && fall.combo >= 2) ? Haptics.heavy() : Haptics.medium();
    if (total >= 5 || (fall && fall.combo >= 3)) shake = Math.max(shake, 0.3);
  }
  const rg = new Sprite(ringTex);
  rg.anchor.set(0.5); rg.blendMode = 'add'; rg.tint = hx; rg.position.set(gx, gy); rg.width = rg.height = cs * 0.8;
  fall.fxl.addChild(rg);
  tween(rg, { width: cs * 3.4, height: cs * 3.4, alpha: 0 }, 0.32, Ease.outCubic).then(() => rg.destroy());
  sparkBurst(gx, gy + gdy, 5 + parts.length * 2, hx, cs * 1.7);
  parts.forEach((p, i) => { p.ov.destroy(); wait(i * 0.015).then(() => blastBlock(p.b.s, p.b.color, gx, gy + gdy, 0.75, cs)); });
  await wait(0.06);
}
async function bridgeClear(comps) {
  busy = true;
  const cs = fall.m.cs, C = L.cols, jobs = [], gone = new Set();
  fall.combo++;
  combo = fall.combo;
  let n = 0, sx = 0, sy = 0;
  const total = comps.reduce((a, k) => a + k.cells.length, 0);
  const gdy = fall.world.y + fallLayer.y;   // yerel → ekran farkı (efektler ekran katmanında)
  let firstBurst = true;
  for (const comp of comps) {
    const hx = colorHex[comp.color] ?? 0xffffff;
    const ry = comp.cells.reduce((a, [r]) => a + r, 0) / comp.cells.length, rx = comp.cells.reduce((a, [, c]) => a + c, 0) / comp.cells.length;
    const gx = fall.m.ox + (rx + 0.5) * cs, gy = fall.m.oy + (ry + 0.5) * cs;
    const big = Math.min(1, comp.cells.length / 24);
    // 1) Seçim: grubun dış hattı kendi renginde parlar (kaydırma bölümünde yok: patlama kısa ve net)
    if (!L.swap) {
      const out = new Graphics();
      groupOutline(out, comp.cells, cs, hx);
      out.blendMode = 'add'; out.alpha = 0;
      fall.fxl.addChild(out);
      tween(out, { alpha: 1 }, 0.06).then(() => wait(0.2)).then(() => tween(out, { alpha: 0 }, 0.16)).then(() => out.destroy());
    }
    const parts0 = [];
    for (const [r, c] of comp.cells) {
      const b = fall.grid[r][c];
      if (!b) continue;
      const ov = new Sprite(tex.white);
      ov.anchor.set(0.5); ov.blendMode = 'add'; ov.tint = hx; ov.width = ov.height = cs * 0.96; ov.position.copyFrom(b.s.position); ov.alpha = 0;
      fall.fxl.addChild(ov);
      if (b.hp > 0) {
        // Buzlu blok: buzu kırılır, blok kalır
        b.hp--;
        if (b.kind === 'ice') b.kind = null;
        tween(ov, { alpha: 0.7 }, 0.08).then(() => tween(ov, { alpha: 0 }, 0.25)).then(() => ov.destroy());
        jobs.push(wait(0.2).then(() => { b.s.texture = hazardTex(b.kind ? b : { color: b.color }); Sound.crack(true); }));
        continue;
      }
      fall.grid[r][c] = null;
      gone.add(r * C + c);
      n++; sx += c; sy += r;
      parts0.push({ b, ov, k: b.s.scale.x });
    }
    if (L.swap) {
      const first = firstBurst;
      firstBurst = false;
      jobs.push(swapPop(parts0, hx, gx, gy, gdy, cs, first, total));
      continue;
    }
    jobs.push((async () => {
      // 2) Nabız: bloklar birlikte büyüyüp renkle yanar
      for (const p of parts0) {
        tween(p.ov, { alpha: 0.5 }, 0.08);
        tween(p.b.s.scale, { x: p.k * 1.14, y: p.k * 1.14 }, 0.09, Ease.outQuad).then(() => tween(p.b.s.scale, { x: p.k * 1.03, y: p.k * 1.03 }, 0.08));
      }
      await wait(0.1);
      // 3) Çekilme: merkeze doğru toplanıp küçülür (enerji birikir)
      const charge = new Sprite(glowTex);
      charge.anchor.set(0.5); charge.blendMode = 'add'; charge.tint = hx; charge.position.set(gx, gy); charge.width = charge.height = cs * 4; charge.alpha = 0;
      fall.fxl.addChild(charge);
      tween(charge, { alpha: 0.9, width: cs * 1.4, height: cs * 1.4 }, 0.08, Ease.inQuad);
      for (const p of parts0) {
        const tx = p.b.s.x + (gx - p.b.s.x) * 0.3, ty = p.b.s.y + (gy - p.b.s.y) * 0.3;
        tween(p.b.s, { x: tx, y: ty }, 0.08, Ease.inQuad);
        tween(p.b.s.scale, { x: p.k * 0.8, y: p.k * 0.8 }, 0.08, Ease.inQuad);
        tween(p.ov, { x: tx, y: ty, alpha: 0.95, width: cs * 0.75, height: cs * 0.75 }, 0.08, Ease.inQuad);
      }
      await wait(0.08);
      // 4) Patlama: beyaz çekirdek, renkli şok dalgaları, kıvılcımlar; parçalar merkezden dışa savrulur
      if (firstBurst) {
        firstBurst = false;
        Sound.clear(Math.min(4, 1 + Math.floor(total / 10)), fall.combo);
        Haptics.heavy();
        if (total >= 16) setTimeout(() => Haptics.heavy(), 90);
      }
      shake = Math.max(shake, 0.35 + big * 0.7);
      const bp = fall.bump || (fall.bump = { y: 0, v: 0 });
      bp.v += cs * (3 + big * 7);
      charge.destroy();
      const core = new Sprite(glowTex);
      core.anchor.set(0.5); core.blendMode = 'add'; core.position.set(gx, gy); core.width = core.height = cs * 2.4;
      fall.fxl.addChild(core);
      tween(core, { width: cs * (5 + big * 6), height: cs * (5 + big * 6), alpha: 0 }, 0.34, Ease.outCubic).then(() => core.destroy());
      const halo = new Sprite(glowTex);
      halo.anchor.set(0.5); halo.blendMode = 'add'; halo.tint = hx; halo.position.set(gx, gy); halo.width = halo.height = cs * 3; halo.alpha = 0.95;
      fall.fxl.addChild(halo);
      tween(halo, { width: cs * (8 + big * 10), height: cs * (8 + big * 10), alpha: 0 }, 0.55, Ease.outCubic).then(() => halo.destroy());
      for (const [tint, to, dur, dl] of [[0xffffff, 6 + big * 6, 0.32, 0], [hx, 9 + big * 8, 0.55, 0.04]]) {
        const rg = new Sprite(ringTex);
        rg.anchor.set(0.5); rg.blendMode = 'add'; rg.tint = tint; rg.position.set(gx, gy); rg.width = rg.height = cs;
        fall.fxl.addChild(rg);
        tween(rg, { width: cs * to, height: cs * to, alpha: 0 }, dur, Ease.outCubic, dl).then(() => rg.destroy());
      }
      // Tahta grubun rengiyle bir an aydınlanır
      const lit = new Sprite(tex.white);
      lit.blendMode = 'add'; lit.tint = hx; lit.alpha = 0.12 + big * 0.18;
      lit.position.set(fall.m.ox, fall.m.oy); lit.width = fall.m.bw; lit.height = fall.m.bh;
      fall.fxl.addChildAt(lit, 0);
      tween(lit, { alpha: 0 }, 0.4, Ease.outQuad).then(() => lit.destroy());
      sparkBurst(gx, gy + gdy, Math.round(10 + big * 14), hx, cs * (3 + big * 4));
      await Promise.all(parts0.map((p, i) => {
        p.ov.destroy();
        return wait(Math.min(0.08, i * 0.004)).then(() => blastBlock(p.b.s, p.b.color, gx, gy + gdy, 1.1 + big * 0.7, cs));
      }));
    })());
  }
  if (fall.combo >= 2) Sound.gem(fall.combo + 3);
  // Komşular: sayaçlı bomba söner (+300), taş çatlar/kırılır, güç ateşlenir
  const touched = new Set();
  for (const k of gone) {
    const r = Math.floor(k / C), c = k % C;
    for (const [dy, dx] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
      const ny = r + dy, nx = c + dx, nk = ny * C + nx;
      if (ny < 0 || ny >= L.rows || nx < 0 || nx >= C || touched.has(nk)) continue;
      const nb = fall.grid[ny][nx];
      if (!nb) continue;
      if (nb.kind === 'tbomb') { touched.add(nk); fall.grid[ny][nx] = null; defuseBonus(nb); jobs.push(wait(0.22).then(() => popBlock(nb.s, 'bomb', cs))); }
      else if (nb.kind === 'stone') {
        touched.add(nk);
        if (nb.hp > 0) { nb.hp--; jobs.push(wait(0.22).then(() => { nb.s.texture = hazardTex(nb); Sound.crack(false); })); }
        else { fall.grid[ny][nx] = null; jobs.push(wait(0.22).then(() => popBlock(nb.s, 'stone', cs))); }
      } else if (nb.power) { touched.add(nk); fall.grid[ny][nx] = null; jobs.push(wait(0.24).then(() => firePower(nb, ny, nx))); }
    }
  }
  // Puan, övgü, güç
  const mult = (fall.feverT > 0 ? 2 : 1) * (timed() && timeLeft <= 10 ? 2 : 1);   // çılgınlık ve son 10 saniye ×2
  const pts = Math.round(n * 12 * (1 + 0.5 * (fall.combo - 1)) * mult);
  fall.maxChain = Math.max(fall.maxChain || 0, fall.combo);
  feverGain(n);
  const px = n ? fx0(sx / n) : fall.m.ox + fall.m.bw / 2, py = n ? fy0(sy / n) : fall.m.oy + fall.m.bh / 2;
  addScore(pts, px, py);
  fall.lastCol = n ? Math.round(sx / n) : fall.lastCol;
  mission('lines', comps.length);
  fall.lines += comps.length;
  fall.speed = Math.max(L.fallMs * 0.75, fall.speed * 0.98);
  // Güç: büyük grup (14+ roket, 18+ bomba, 24+ yıldırım) ya da art arda patlatma
  const tier = L.swap ? (n >= 6 ? 4 : n >= 5 ? 3 : n >= 4 ? 2 : 1) : n >= 24 ? 4 : n >= 18 ? 3 : n >= 14 ? 2 : 1;
  const pw = L.swap ? 0 : L.power ? Math.max(tier, fall.combo) : 0;
  const sub = fall.combo >= 2 ? 'ZİNCİR ×' + fall.combo : null;
  const spk = L.swap && (comps.find((k) => k.pk === 'bolt') || comps.find((k) => k.pk === 'bomb') || comps.find((k) => k.pk === 'rocket') || comps.find((k) => k.pk === 'prop'));
  if (spk) praise(POWER_NAME[spk.pk], sub);
  else if (pw >= 2) praise(POWER_NAME[powerOf(pw)], sub);
  else if (n >= (L.swap ? 99 : 12)) praise(n >= 16 ? 'Süper!' : 'Harika!', sub);
  else if (sub) bigText('Zincir ×' + fall.combo, ['#e6fdff', '#4fd2ff'], COMBO_HEX[Math.min(fall.combo, 6)], L.swap ? Math.max(BY + cs, py + gdy - cs * 1.4) : BY + N * cell * 0.42, fall.combo >= 4 ? 2 : 1);
  updateSpecialChips();
  await Promise.all(jobs);
  return pw;
}
// Yerçekimi: boşluğun üstündeki her blok dümdüz aşağı düşer. Tahta hemen güncellenir; dönen söz animasyonun bitişi.
function fallGravity() {
  const R = L.rows, C = L.cols, g = fall.grid, moves = [];
  for (let c = 0; c < C; c++) {
    let w = R - 1;
    for (let r = R - 1; r >= 0; r--) {
      const b = g[r][c];
      if (!b) continue;
      if (r !== w) { g[w][c] = b; g[r][c] = null; moves.push([b, w, r]); }
      w--;
    }
  }
  if (!moves.length) return Promise.resolve();
  let landed = false;
  return Promise.all(moves.map(([b, w, r]) => {
    const dur = 0.06 + Math.sqrt(w - r) * 0.05, d = Math.max(0, (R - w) * 0.002);
    killTweenProp(b.s, 'y');
    return tween(b.s, { y: fy0(w) }, dur, Ease.inQuad, d).then(() => {
      landed = true;
      const k = b.s.scale.x;
      b.s.scale.set(k * 1.1, k * 0.88);
      return tween(b.s.scale, { x: k, y: k }, 0.14, Ease.outBack);
    });
  })).then(() => { if (landed && fall) { const bp = fall.bump || (fall.bump = { y: 0, v: 0 }); bp.v += fall.m.cs * (L.swap ? 0.5 : 1.6); Sound.land?.(); } });
}
function bridgeTipImage() {
  const S = 160, u = 18, cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  const rows = ['20330033', '22013300', '01113312', '30111102', '31002222'];
  const col = ['#ff4757', '#ffcf1a', '#2ed573', '#1e90ff'];
  const ox = (S - 8 * u) / 2, oy = 30;
  rows.forEach((row, r) => [...row].forEach((ch, c) => {
    const k = +ch;
    const onPath = k === 1 && c >= 1 && c <= 5;
    x.drawImage(renderTile(col[k], u * 2), ox + c * u, oy + r * u, u - 1, u - 1);
    if (onPath) { x.fillStyle = 'rgba(255,255,255,0.35)'; x.fillRect(ox + c * u, oy + r * u, u - 1, u - 1); }
  }));
  return cv.toDataURL();
}

// Akma + dolan satırları patlatma döngüsü (zincirleme). Dönen değer: patlatma sayısı (-1: bölüm bitti)
async function fallResolve(fresh) {
  // Bir animasyon hatası oyunu asla dondurmasın: hata kaydedilir, oyun devam eder
  if (L.bridge) { try { return await bridgeResolve(); } catch (e) { console.error('Çözüm hatası', e); busy = false; return 0; } }
  await fallSettle(fresh);
  let chain = 0;
  const cracked = new Set();   // bu hamlede çatlatılan satırlar (aynı hamlede ikinci kez işlenmez)
  for (;;) {
    if (!fall || over) return -1;
    const full = [], armored = [];
    for (let r = 0; r < L.rows; r++) {
      const row = fall.grid[r];
      if (!row.every(Boolean) || cracked.has(row)) continue;
      (row.some((b) => b.hp > 0) ? armored : full).push(r);
    }
    if (!full.length && !armored.length) break;
    for (const r of armored) { cracked.add(fall.grid[r]); await crackRow(r, fresh); }
    if (full.length) {
      chain++;
      for (const r of full) for (const b of fall.grid[r]) if (b.kind === 'tbomb') defuseBonus(b);
      await fallClear(full);
      busy = true;
    }
    if (!fall || over) return -1;
    fallHitFresh(fresh);
    await fallSettle(fresh);
  }
  return chain;
}
// Güçlerin açtığı boşlukların üstündeki bloklar akacak bloklara eklenir
function fallHitFresh(fresh) {
  if (!fall || !fall.hitCols) return;
  for (const [c, rmax] of fall.hitCols) for (let r = 0; r <= rmax && r < L.rows; r++) { const b = fall.grid[r][c]; if (b) fresh.add(b); }
  fall.hitCols = null;
}
// Güç patlamasıyla düşen tahtadan blok kırılır (güçse zincirleme ateşlenir)
function fallSmash(r, c, delay, from = null) {
  const b = fall && fall.grid[r] && fall.grid[r][c];
  if (!b) return Promise.resolve();
  fall.grid[r][c] = null;
  (fall.hitCols || (fall.hitCols = new Map())).set(c, Math.max(fall.hitCols.get(c) ?? -1, r));
  if (b.power) return wait(delay).then(() => firePower(b, r, c));
  const cs = fall.m.cs;
  return wait(delay).then(() => (from ? blastBlock(b.s, b.color, from[0], from[1], from[2], cs) : popBlock(b.s, b.color, cs)));
}
// Tetriste 2+ satır birden patlayınca güç, son parçanın düştüğü sütunda yığının üstüne oturur
function fallSpawnPower(n, from) {
  const kind = powerOf(n), c0 = Math.max(0, Math.min(L.cols - 1, fall.lastCol ?? Math.floor(L.cols / 2)));
  for (const dc of [0, 1, -1, 2, -2, 3, -3]) {
    const c = c0 + dc;
    if (c < 0 || c >= L.cols) continue;
    let r = 0;
    while (r < L.rows && !fall.grid[r][c]) r++;
    r--;
    if (r < 3) continue;   // tepeye çok yakınsa başka sütun
    makePower(r, c, kind, 'v', from);
    return;
  }
}
async function fallSettle(only = null) {   // only: yalnız bu bloklar akar (yeni yerleşen parça)
  let any = false;
  for (let it = 0; it < 60 && fall; it++) {
    const g = fall.grid, moves = [];
    const dir = it % 2 ? 1 : -1;
    for (let r = L.rows - 2; r >= 0; r--) {
      for (let i = 0; i < L.cols; i++) {
        const c = dir > 0 ? i : L.cols - 1 - i;
        const b = g[r][c];
        if (!b || b.moved === it || (only && !only.has(b))) continue;
        if (!g[r + 1][c]) { g[r + 1][c] = b; g[r][c] = null; b.moved = it; moves.push([b, r + 1, c]); continue; }
        const d = Math.random() < 0.5 ? -1 : 1;
        for (const dx of [d, -d]) {
          const nc = c + dx;
          // Yalnız dik yamaçlar devrilir (en az iki kat boşluk): parçalar şeklini büyük ölçüde korur
          if (nc < 0 || nc >= L.cols || g[r][nc] || g[r + 1][nc] || r + 2 >= L.rows || g[r + 2][nc]) continue;
          g[r + 1][nc] = b; g[r][c] = null; b.moved = it; moves.push([b, r + 1, nc]);
          break;
        }
      }
    }
    if (!moves.length) break;
    any = true;
    await Promise.all(moves.map(([b, r, c]) => Promise.all([
      tween(b.s, { x: fx0(c), y: fy0(r) }, 0.075, Ease.inQuad),
      b.is ? tween(b.is, { x: fx0(c), y: fy0(r) }, 0.075, Ease.inQuad) : null,
    ])));
  }
  if (any && fall) {
    // Oturma: hafif yay + yumuşak ses
    const bp = fall.bump || (fall.bump = { y: 0, v: 0 });
    bp.v += fall.m.cs * 1.4;
    Sound.land();
    for (const row of fall.grid) for (const b of row) if (b) b.moved = undefined;
  }
}
async function fallClear(rows) {
  busy = true;
  const n = rows.length;
  fall.combo++;
  combo = fall.combo;
  const { cs, ox, bw } = fall.m;
  // Şarj: satırdaki bloklar iki kez beyaz yanar
  const charge = [];
  for (const r of rows) for (const b of fall.grid[r]) {
    const g = new Sprite(tex.white);
    g.anchor.set(0.5); g.blendMode = 'add';
    g.width = g.height = cs * 0.96;
    g.position.copyFrom(b.s.position);
    g.alpha = 0;
    fall.fxl.addChild(g);
    charge.push(g);
  }
  Sound.clear(n, fall.combo);
  Haptics.medium();
  if (n >= 2) Haptics.heavy();
  for (let k = 0; k < 2; k++) {
    await Promise.all(charge.map((g) => tween(g, { alpha: 0.7 }, 0.045)));
    await Promise.all(charge.map((g) => tween(g, { alpha: 0.15 }, 0.06)));
  }
  for (const g of charge) g.destroy();
  // Işık süpürmesi: satırın ortasından iki yana açılan parlak bant + üstte ince çizgi
  for (const r of rows) {
    const band = new Sprite(glowTex);
    band.anchor.set(0.5); band.blendMode = 'add';
    band.tint = 0xffffff;
    band.width = cs; band.height = cs * 1.6;
    band.position.set(ox + bw / 2, fy0(r));
    band.alpha = 1;
    fall.fxl.addChild(band);
    tween(band, { width: bw * 1.5, height: cs * 0.5, alpha: 0 }, 0.42, Ease.outCubic).then(() => band.destroy());
    const ln = new Sprite(tex.white);
    ln.anchor.set(0.5); ln.blendMode = 'add';
    ln.width = cs * 0.5; ln.height = Math.max(2, cs * 0.12);
    ln.position.set(ox + bw / 2, fy0(r));
    fall.fxl.addChild(ln);
    tween(ln, { width: bw, alpha: 0 }, 0.35, Ease.outCubic).then(() => ln.destroy());
  }
  shake = Math.max(shake, 0.2 + 0.15 * n);
  const bp = fall.bump || (fall.bump = { y: 0, v: 0 });
  bp.v += cs * (2 + n * 1.5);
  const jobs = [], powers = [], from = [];
  rows.forEach((r) => fall.grid[r].forEach((b, c) => {
    const d = Math.abs(c - (L.cols - 1) / 2) * 0.025;
    from.push([fx0(c), fy0(r) + fall.world.y + fallLayer.y]);
    if (b.power) { powers.push([b, r, c]); fall.grid[r][c] = null; return; }
    jobs.push(wait(d).then(() => popBlock(b.s, b.color, fall.m.cs)));
    if (b.is) jobs.push(wait(d).then(() => collectIcon(b)));
    fall.grid[r][c] = null;
  }));
  // Satır hedefi
  const lg = goals.find((g) => g.icon === 'line');
  if (lg) {
    lg.left = Math.max(0, lg.left - n);
    lg.shown = Math.max(0, lg.shown - n);
    renderGoals();
    const d = $('goal' + goals.indexOf(lg));
    if (d) { d.classList.remove('bump'); void d.offsetWidth; d.classList.add('bump'); }
  }
  mission('lines', n);
  if (n >= 2) mission('multi');
  fall.lines += n;
  fall.speed = Math.max(L.fallMs * 0.75, fall.speed * Math.pow(0.97, n));   // bölüm içinde en fazla %25 hızlanır
  const pts = [0, 100, 250, 450, 700][n] * (1 + (fall.combo - 1) * 0.5);
  addScore(Math.round(pts), ox + bw / 2, fy0(rows[0]));
  // Tetriste güç: aynı anda 2+ satır ya da art arda patlatma (kombo 2 → roket, 3 → bomba, 4+ → yıldırım)
  const pw = L.power ? Math.max(n, fall.combo) : 0;
  if (pw >= 2) praise(POWER_NAME[powerOf(pw)]);
  else if (n >= 2) praise(n >= 4 ? 'Muhteşem!' : n === 3 ? 'Süper!' : 'Harika!');
  else if (fall.combo >= 2) comboText(fall.combo);
  await Promise.all(jobs);
  // Patlayan satırdaki güçler ateşlenir (satırlar kaymadan önce)
  if (powers.length) await Promise.all(powers.map(([b, r, c]) => firePower(b, r, c)));
  if (!fall) return;
  // Üstteki satırlar aşağı kayar
  const keep = fall.grid.filter((_, r) => !rows.includes(r));
  fall.grid = [...Array.from({ length: n }, () => Array(L.cols).fill(null)), ...keep];
  if (fall.hitCols) for (const [c, rm] of fall.hitCols) fall.hitCols.set(c, rm + rows.filter((x) => x > rm).length);
  const moves = [];
  let landed = false;
  fall.grid.forEach((row, r) => row.forEach((b, c) => {
    if (!b) return;
    const y = fy0(r);
    if (Math.abs(b.s.y - y) < 1) return;
    // Yerçekimiyle hızlanarak iner (yukarıdakiler biraz gecikmeli), oturunca hafif ezilir
    const dist = (y - b.s.y) / cs, d = Math.max(0, (L.rows - r) * 0.008);
    const dur = 0.12 + Math.sqrt(dist) * 0.07;
    moves.push(tween(b.s, { y }, dur, Ease.inQuad, d).then(() => {
      const k = b.s.scale.x;
      b.s.scale.set(k * 1.08, k * 0.9);
      landed = true;
      return tween(b.s.scale, { x: k, y: k }, 0.16, Ease.outBack);
    }));
    if (b.is) moves.push(tween(b.is, { y }, dur, Ease.inQuad, d));
  }));
  await Promise.all(moves);
  if (landed) { bp.v += cs * 1.5; Sound.land?.(); }
  if (pw >= 2 && fall) fallSpawnPower(pw, from);
  busy = false;
}
function fallLose() {
  if (!fall) return;
  fall.active = false;
  fall.piece = null;
  fall.dropping = false;
  for (const ch of fall.cur.removeChildren()) ch.destroy();
  fall.curB = null; fall.curG = null; fall.vis = null;
  fall.ghost.clear();
  if (fall.guide) fall.guide.visible = false;
  fall.grid.forEach((row) => row.forEach((b) => { if (b && !b.icon) { b.s.texture = ftex('grey'); b.s.tint = 0xffffff; } }));
  checkGameOver('stack');
}
// Reklamla devam: tahtanın üst yarısı patlar, oyun sürer
async function fallRevive() {
  const cut = Math.ceil(L.rows / 2) + 1;
  const jobs = [];
  fall.grid.forEach((row, r) => row.forEach((b, c) => {
    if (!b) return;
    b.s.texture = b.power ? tex[b.color] : b.kind ? hazardTex(b) : ftex(b.color);   // buz, taş, sayaçlı bomba görünümünü korur
    b.s.tint = 0xffffff;
    if (r < cut) {
      if (b.power) { dropOverlays(b); dropPowerParts(b); if (b.glow && !b.glow.destroyed) b.glow.destroy(); }
      jobs.push(wait(r * 0.02).then(() => popBlock(b.s, b.color, fall.m.cs)));
      if (b.is) { const s = b.is; tween(s, { alpha: 0 }, 0.2).then(() => s.destroy()); }
      fall.grid[r][c] = null;
    }
  }));
  Sound.bomb();
  shake = 0.8;
  await Promise.all(jobs);
  if (!L.swap) fallSpawn();   // kaydırma bölümünde düşen parça yok
  fall.dangerT = 0;
  fall.active = true;
}
// Üstte bir ekran açık mı (giriş ekranı, tanıtım kartı, pencere): açıkken düşen blok oyunu bekler
const screenBlocked = () => $('veil').classList.contains('show') || $('specialIntro').classList.contains('show') || $('levelIntro').classList.contains('show') || !!popupOpen;
function updateFall(dt) {
  if (!fall || !fall.active || !fall.piece || over || busy || screenBlocked()) return;
  for (const s of fall.icons.children) s.scale.set((fall.m.cs / s.texture.width) * (1 + Math.sin(time * 3 + s.x * 0.05) * 0.05));
  const p = fall.piece;
  if (fall.dropping) return;
  const grounded = !fallFits(p.cells, p.x, p.y + 1);
  if (grounded) {
    fall.lockT += dt;
    if (fall.lockT >= 0.45) fallLock();
    return;
  }
  fall.t += dt * 1000;
  const interval = fall.soft ? 45 : fall.speed;
  while (fall.t >= interval && fall.piece) {
    fall.t -= interval;
    if (!fallMove(0, 1)) break;
  }
}
// Alttan yükselen sıralar (kum bölümü): tahta sürekli ve düzenli yavaşça yukarı kayar. Dipte bekleyen
// yeni sıra (bir iki boşluklu) tahtanın altından görünerek girer; tam girince oyuna katılır, yenisi gelir.
// Hız bölüm ilerledikçe artar. Bloklar tepeye itilirse bölüm kaybedilir.
const riseEvery = () => L.rise || 5.5;   // bir sıranın yükselme süresi (sn), bölüm verisinden
function riseRow() {
  const C = L.cols, R = L.rows, [h0, h1] = L.holes || [2, 3], holes = new Set();
  const want = h0 + Math.floor(Math.random() * (h1 - h0 + 1));
  while (holes.size < want) holes.add(Math.floor(Math.random() * C));
  const hz = L.hz || {}, row = [];
  const iceRow = hz.ice && Math.random() < hz.ice;
  let run = 0, runCol = null;
  for (let c = 0; c < C; c++) {
    if (holes.has(c)) continue;
    // Köprü bölümünde aynı renk şeritleri (2-5), diğerlerinde karışık renk
    if (L.swap) {
      // Yan yana ya da üstündeki iki blokla hazır 3'lü oluşmasın
      const bad = new Set(), g = fall.grid, pc = row.length >= 2 && row[row.length - 1].c === c - 1 && row[row.length - 2].c === c - 2 && row[row.length - 1].color === row[row.length - 2].color ? row[row.length - 1].color : null;
      if (pc) bad.add(pc);
      const a = g[R - 1][c], b2 = g[R - 2][c];
      if (a && b2 && a.color === b2.color) bad.add(a.color);
      // 2×2 kare de oluşmasın
      const lp = row[row.length - 1], ul = g[R - 1][c - 1];
      if (lp && lp.c === c - 1 && a && ul && lp.color === ul.color && ul.color === a.color) bad.add(a.color);
      do runCol = bridgeColor(); while (bad.has(runCol) && (L.ncol || 4) > 2);
    } else if (L.bridge) { if (run <= 0) { let nc; do nc = bridgeColor(); while (nc === runCol && (L.ncol || 4) > 1); runCol = nc; run = 1 + Math.floor(Math.random() * 3); } run--; }
    const color = L.bridge ? runCol : TETRO['IOTSZJL'[Math.floor(Math.random() * 7)]].color;
    row.push({ c, color, kind: iceRow ? 'ice' : null, hp: iceRow ? 1 : 0 });
  }
  // Taş blok (1, özel bölümde bazen 2) ve sayaçlı bomba: buzsuz hücrelere
  const free = () => row.filter((q) => !q.kind);
  if (hz.stone && Math.random() < hz.stone) for (let k = 0; k < (L.special && Math.random() < 0.4 ? 2 : 1); k++) {
    const f = free(); if (!f.length) break;
    Object.assign(f[Math.floor(Math.random() * f.length)], { kind: 'stone', hp: 1, color: 'stone' });
  }
  if (hz.bomb && Math.random() < hz.bomb) {
    const f = free();
    if (f.length) Object.assign(f[Math.floor(Math.random() * f.length)], { kind: 'tbomb', hp: 0, timer: hz.timer, color: 'bomb' });
  }
  for (const q of row) {
    const sp = new Sprite(hazardTex(q));
    sp.anchor.set(0.5);
    sp.width = sp.height = fall.m.cs;
    sp.position.set(fx0(q.c), fy0(R));
    sp.tint = 0x8a8a9a;                       // henüz oyunda değil: soluk
    fall.blocks.addChild(sp);
    q.s = sp;
  }
  return row;
}
// HIRS barı ve ÇILGINLIK (renk grubu bölümü)
const FEVER_SEC = 8;
function startFever() {
  fall.feverT = FEVER_SEC;
  fall.fever = 100;
  $('feverFx').classList.add('on');
  bigText('ÇILGINLIK!', ['#fff3c0', '#ff6a1a'], 0xff7a2a, BY + N * cell * 0.42, 3, L.swap ? '8 SN · ×2 PUAN' : '8 SN · JOKER · ×2');
  screenFlash(0.3, '#ffb04a');
  Sound.fire();
  Haptics.heavy();
  setTimeout(() => Haptics.heavy(), 120);
  fallDrawNext();
}
function endFever() {
  fall.feverT = 0;
  fall.fever = 0;
  $('feverFx').classList.remove('on');
  fallDrawNext();
}
function feverGain(n) {
  if (!fall || !L.bridge || L.swap || fall.feverT > 0) return;
  fall.fever = Math.min(100, (fall.fever || 0) + n * 1.5 + (fall.combo - 1) * 10);
  if (fall.fever >= 100) startFever();
}
function updateFever(dt) {
  if (!fall || !fall.fev || !L || !L.bridge) return;
  if (fall.feverT > 0 && !over && !screenBlocked()) { fall.feverT -= dt; if (fall.feverT <= 0) endFever(); }
  const v = fall.feverT > 0 ? fall.feverT / FEVER_SEC : (fall.fever || 0) / 100;
  const F = fall.fev, w = Math.max(0, F.w * v);
  const hot = fall.feverT > 0, near = !hot && v >= 0.8;
  const col = hot ? (Math.sin(time * 30) > 0 ? 0xff7a1a : 0xffc23a) : near ? (Math.sin(time * 12) > 0 ? 0xff7ad8 : 0xffd23a) : 0xc07aff;
  F.fill.clear();
  if (w > 1) F.fill.roundRect(F.x, F.y, w, F.h, 5).fill({ color: col }).roundRect(F.x + 2, F.y + 1.5, Math.max(0, w - 4), F.h * 0.35, 3).fill({ color: 0xffffff, alpha: 0.4 });
  F.lbl.text = hot ? 'ÇILGINLIK' : 'HIRS';
}
function updateRise(dt) {
  if (!fall || !L || !L.sand || !fall.world) return;
  if (!fall.incoming) fall.incoming = riseRow();
  const live = fall.active && !over && !busy && !fall.dropping && !screenBlocked() && !(fall.feverT > 0);   // çılgınlıkta tahta yükselmez
  // Süre azaldıkça orantılı hızlanır: başta 1×, süre biterken 1+riseBoost katı
  const prog = L.timeLimit ? Math.min(1, Math.max(0, 1 - timeLeft / L.timeLimit)) : 0;
  // Kaydırma bölümü: yığın en üst sıraya değdiği anda oyun biter. Bir sıra kala tepedeki bloklar kırmızı yanıp söner (uyarı).
  const full = L.swap && fall.grid[0].some(Boolean);
  if (live && full) { fallLose(); return; }
  const near = L.swap && fall.grid[1].some(Boolean);
  if (live && near) {
    if (!fall.dangerT) Haptics.warning();
    fall.dangerT = (fall.dangerT || 0) + dt;
    const on = Math.sin(time * 14) > 0;
    fall.grid.forEach((row, r) => { for (const b of row) if (b && b.s) b.s.tint = r === 1 && on ? 0xff8a8a : 0xffffff; });
  } else if (fall.dangerT && !near) {
    fall.dangerT = 0;
    for (const row of fall.grid) for (const b of row) if (b && b.s) b.s.tint = 0xffffff;
  }
  // Kaydırma (özel) bölümünde yükseliş baştan sona sabit hızdadır; süre azaldıkça hızlanma yalnız diğer kum bölümlerinde
  if (live && !full) fall.riseOff = (fall.riseOff || 0) + (dt / riseEvery()) * (L.swap ? 1 : 1 + (L.riseBoost || 1.2) * prog);
  if (live) swapBombTick(dt);
  const off = fall.riseOff || 0;
  fall.world.y = -Math.min(1, off) * fall.m.cs;
  if (live && off >= 1) riseCommit();
  // Deprem: 2 sn önceden sarsıntı ve uyarı
  const qe = L.hz && L.hz.quake;
  if (qe && live && !busy) {
    fall.quakeT = (fall.quakeT || 0) + dt;
    if (fall.quakeT >= qe - 2 && !fall.quakeWarn) {
      fall.quakeWarn = true;
      bigText('DEPREM!', ['#ffe3e8', '#ff6b86'], 0xff4d6d, fall.m.oy + fall.m.bh * 0.35);
      Haptics.warning();
    }
    if (fall.quakeWarn) shake = Math.max(shake, 0.25 + 0.25 * Math.min(1, (fall.quakeT - (qe - 2)) / 2));
    if (fall.quakeT >= qe) { fall.quakeT = 0; fall.quakeWarn = false; quakeHit(); }
  }
}
function riseCommit(force = false) {
  const R = L.rows, C = L.cols, cs = fall.m.cs;
  // Tepedeki sırada blok varsa itilecek yer yok: kaybedilir. Kaydırma bölümünde bomba/deprem yığını en çok tepeye kadar
  // iter; oyun yalnız tepeye değip tehlike süresi (2,5 sn) dolunca biter
  if (fall.grid[0].some(Boolean)) {
    if (L.swap && !force) return;
    if (!L.swap) fall.riseOff = 1;
    fallLose();
    return;
  }
  if (L.swap) swapFixRow(fall.incoming);
  fall.grid.shift();
  const row = Array(C).fill(null);
  for (const q of fall.incoming) { q.s.tint = 0xffffff; row[q.c] = { s: q.s, color: q.color, icon: null, is: null, kind: q.kind, hp: q.hp || 0, timer: q.timer }; }
  fall.grid.push(row);
  // Mantıksal satırlar bir yukarı: görüntü aynı kalsın diye her şey bir hücre aşağı alınır, kayma sıfırlanır
  const moving = new Set();
  for (const r2 of fall.grid) for (const b of r2) if (b) { b.s.y -= cs; moving.add(b.s); if (b.is) { b.is.y -= cs; moving.add(b.is); } }
  shiftTweens(moving, 'y', -cs);   // düşmekte olan blokların animasyonu da yeni konuma göre biter
  for (const ch of fall.fxl.children) ch.y -= cs;
  fall.riseOff -= 1;
  fall.world.y = -fall.riseOff * cs;
  const p = fall.piece;
  if (p) {
    p.y--;
    if (fall.vis) fall.vis.y--;
    if (!fallFits(p.cells, p.x, p.y)) { fallLose(); return; }
    fallRender();
  }
  // Yeni sıra katıldı: hafif parlama ve yaylanma
  for (const q of fall.incoming) {
    const fl = new Sprite(tex.white);
    fl.anchor.set(0.5); fl.blendMode = 'add';
    fl.width = fl.height = cs * 0.96;
    fl.position.copyFrom(q.s.position);
    fl.alpha = 0.35;
    fall.fxl.addChild(fl);
    tween(fl, { alpha: 0 }, 0.35, Ease.outQuad).then(() => fl.destroy());
  }
  fall.incoming = riseRow();
}
// Kaydırma bölümü: yükselen sıra tahtaya katılırken üstündekilerle hazır 3'lü ya da 2×2 kare oluşturmasın
// (sıra üretildikten sonra üstteki bloklar değişmiş olabilir): gerekirse o bloğun rengi değişir
function swapFixRow(row) {
  const g = fall.grid, R = L.rows, at = new Map(row.map((q) => [q.c, q]));
  const cOf = (q) => (q && !q.kind ? q.color : q && q.kind === 'ice' ? q.color : null);
  for (const q of row) {
    if (!cOf(q)) continue;
    const c = q.c, bad = new Set();
    const l1 = at.get(c - 1), l2 = at.get(c - 2);
    if (cOf(l1) && cOf(l1) === cOf(l2)) bad.add(cOf(l1));
    const a1 = bridgeCol(g[R - 1][c]), a2 = bridgeCol(g[R - 2][c]);
    if (a1 && a1 === a2) bad.add(a1);
    const ul = c > 0 ? bridgeCol(g[R - 1][c - 1]) : null;
    if (cOf(l1) && a1 && cOf(l1) === ul && ul === a1) bad.add(a1);
    // Sağdaki komşu daha önce seçildiyse onunla da kare/sıra kontrolü
    const r1 = at.get(c + 1), r2 = at.get(c + 2), ur = c + 1 < L.cols ? bridgeCol(g[R - 1][c + 1]) : null;
    if (cOf(r1) && cOf(r1) === cOf(r2)) bad.add(cOf(r1));
    if (cOf(l1) && cOf(l1) === cOf(r1)) bad.add(cOf(l1));
    if (cOf(r1) && a1 && cOf(r1) === ur && ur === a1) bad.add(a1);
    if (!bad.has(q.color)) continue;
    const opts = BRIDGE_COL.slice(0, L.ncol || 4).filter((k) => !bad.has(k));
    if (!opts.length) continue;
    q.color = opts[Math.floor(Math.random() * opts.length)];
    q.s.texture = hazardTex(q);
  }
}
// ---------- Kaydırma kuralı (özel bölüm) ----------
// Parça düşmez; yığın alttan yükselir. Blok sağa-sola çekilince yanındakiyle yer değiştirir (boşsa oraya kayar,
// altı boşsa düşer). Aynı renkten 3+ blok yatay ya da dikey sıralanınca patlar; düşen bloklar zincir yapar.
let swapTouch = null;
function findLines() {
  const R = L.rows, C = L.cols, g = fall.grid, hit = new Map(), runH = new Map(), runV = new Map();   // hücre → yön, sıra boyları
  const run = (cells, dir) => {
    if (cells.length < 3) return;
    for (const [r, c] of cells) { hit.set(r * C + c, hit.get(r * C + c) || dir); (dir === 'h' ? runH : runV).set(r * C + c, cells.length); }
  };
  for (let r = 0; r < R; r++) {
    let cur = [], col = null;
    for (let c = 0; c <= C; c++) {
      const k = c < C ? bridgeCol(g[r][c]) : null;
      if (k && k === col) { cur.push([r, c]); continue; }
      run(cur, 'h'); cur = k ? [[r, c]] : []; col = k;
    }
  }
  for (let c = 0; c < C; c++) {
    let cur = [], col = null;
    for (let r = 0; r <= R; r++) {
      const k = r < R ? bridgeCol(g[r][c]) : null;
      if (k && k === col) { cur.push([r, c]); continue; }
      run(cur, 'v'); cur = k ? [[r, c]] : []; col = k;
    }
  }
  // 2×2 kare de patlar (pervane doğar)
  const sq = new Set();
  for (let r = 0; r + 1 < R; r++) for (let c = 0; c + 1 < C; c++) {
    const k = bridgeCol(g[r][c]);
    if (!k || bridgeCol(g[r][c + 1]) !== k || bridgeCol(g[r + 1][c]) !== k || bridgeCol(g[r + 1][c + 1]) !== k) continue;
    for (const [y, x] of [[r, c], [r, c + 1], [r + 1, c], [r + 1, c + 1]]) { hit.set(y * C + x, hit.get(y * C + x) || 'sq'); sq.add(y * C + x); }
  }
  // Birbirine değen aynı renk sıraları tek grup (L, T, artı şekilleri birlikte patlar)
  const out = [], seen = new Set();
  for (const k0 of hit.keys()) {
    if (seen.has(k0)) continue;
    const col = bridgeCol(g[Math.floor(k0 / C)][k0 % C]), cells = [], q = [k0];
    seen.add(k0);
    while (q.length) {
      const k = q.pop(), r = Math.floor(k / C), c = k % C;
      cells.push([r, c]);
      for (const nk of [k - C, k + C, c > 0 ? k - 1 : -1, c < C - 1 ? k + 1 : -1]) {
        if (nk < 0 || seen.has(nk) || !hit.has(nk) || bridgeCol(g[Math.floor(nk / C)][nk % C]) !== col) continue;
        seen.add(nk); q.push(nk);
      }
    }
    // Şekle göre güç (Royal Match gibi): düz 5+ yıldırım, L/T bomba, düz 4 roket, 2×2 kare pervane
    const mh = Math.max(0, ...cells.map(([r, c]) => runH.get(r * C + c) || 0)), mv = Math.max(0, ...cells.map(([r, c]) => runV.get(r * C + c) || 0));
    const pk = Math.max(mh, mv) >= 5 ? 'bolt' : mh >= 3 && mv >= 3 ? 'bomb' : Math.max(mh, mv) >= 4 ? 'rocket' : cells.some(([r, c]) => sq.has(r * C + c)) ? 'prop' : null;
    out.push({ color: col, cells, dir: mh >= mv ? 'h' : 'v', pk });
  }
  return out;
}
const swapLocal = (e) => ({ x: e.global.x, y: e.global.y - fallLayer.y - fall.world.y });
function swapFind(b) {
  for (let r = 0; r < L.rows; r++) { const c = fall.grid[r].indexOf(b); if (c >= 0) return [r, c]; }
  return null;
}
// Tutulan blok parmağı sürekli izler (yalnız seçilen eksende); hücrenin yarısı geçilince komşusuyla yer değiştirir,
// komşu kayarak eski yerine gider. Gidilemeyen yönde (duvar, boşluk, ateşlenen güç) blok hafifçe esneyip durur.
// Bırakınca yaylanarak hücresine oturur.
function swapDown(e) {
  const { x, y } = swapLocal(e), { cs, ox, oy } = fall.m;
  const r = Math.floor((y - oy) / cs), c = Math.floor((x - ox) / cs);
  if (r < 0 || r >= L.rows || c < 0 || c >= L.cols) return;
  const b = fall.grid[r][c];
  if (!b || b.firing) return;
  const k = cs / b.s.texture.width;
  swapTouch = { b, x0: e.global.x, y0: e.global.y, t: performance.now(), moved: false, k, axis: null, base: 0 };
  killTweenProp(b.s.scale, 'x'); killTweenProp(b.s.scale, 'y');
  tween(b.s.scale, { x: k * 1.1, y: k * 1.1 }, 0.09, Ease.outQuad);
  fall.blocks.addChild(b.s);   // tutulan blok komşularının üstünde görünür
  Haptics.light?.();
}
// Bu yönde adım atılabilir mi: yatayda tahta içi (boş hücreye de kayar), dikeyde yalnız dolu komşuyla
function swapCan(at, d, axis) {
  const [r, c] = at;
  if (axis === 'h') { const nc = c + d; if (nc < 0 || nc >= L.cols) return false; const nb = fall.grid[r][nc]; return !nb || !nb.firing; }
  const nr = r + d;
  if (nr < 0 || nr >= L.rows) return false;
  const nb = fall.grid[nr][c];
  return !!nb && !nb.firing;
}
function swapMove(e) {
  const tch = swapTouch;
  if (!fall || !fall.active || over) return;
  const dx = e.global.x - tch.x0, dy = e.global.y - tch.y0, cs = fall.m.cs;
  if (Math.abs(dx) > 8 || Math.abs(dy) > 8) tch.moved = true;
  // Yön ilk belirgin harekette kilitlenir: yatay ya da dikey
  if (!tch.axis && Math.max(Math.abs(dx), Math.abs(dy)) > cs * 0.2) tch.axis = Math.abs(dy) > Math.abs(dx) ? 'v' : 'h';
  if (!tch.axis || screenBlocked()) return;
  const v = tch.axis === 'h' ? dx : dy;
  // Hücrenin yarısı geçildikçe adım (hızlı çekişte birkaç adım art arda)
  for (let guard = 0; guard < 16 && !busy; guard++) {
    const at = swapFind(tch.b);
    if (!at) { swapTouch = null; return; }
    const off = v - tch.base;
    if (Math.abs(off) < cs * 0.5) break;
    const d = off > 0 ? 1 : -1;
    if (!swapCan(at, d, tch.axis)) break;
    tch.base += d * cs;
    if (swapStep(tch, at, d)) return;   // eşleşme, güç ya da düşüş: sürükleme bitti
  }
  // Parmağı izle: komşu yöne en çok yarım hücre; gidilemeyen yönde yumuşak esneme
  const at = swapFind(tch.b);
  if (!at) { swapTouch = null; return; }
  let off = v - tch.base;
  const d = off > 0 ? 1 : -1;
  if (busy || !swapCan(at, d, tch.axis)) off = d * cs * 0.16 * (1 - Math.exp(-Math.abs(off) / (cs * 0.35)));
  else off = Math.max(-cs * 0.5, Math.min(cs * 0.5, off));
  const prop = tch.axis === 'h' ? 'x' : 'y';
  killTweenProp(tch.b.s, prop);
  tch.b.s[prop] = (prop === 'x' ? fx0(at[1]) : fy0(at[0])) + off;
}
// Tek adım: tutulan blok ile komşusu yer değiştirir (tutulan blok parmağı izlemeye devam eder, komşu kayar).
// Sürükleme bittiyse true döner.
function swapStep(tch, [r, c], d) {
  const h = tch.axis === 'h', nr = h ? r : r + d, nc = h ? c + d : c, nb = fall.grid[nr][nc];
  fall.grid[r][c] = nb; fall.grid[nr][nc] = tch.b;
  const mv = [];
  if (nb) { killTweenProp(nb.s, h ? 'x' : 'y'); mv.push(tween(nb.s, h ? { x: fx0(c) } : { y: fy0(r) }, 0.09, Ease.outQuad)); }
  Sound.pickup?.();
  Haptics.light?.();
  fall.gravP = Promise.all([...mv, h ? fallGravity() : Promise.resolve()]);
  fall.swapBlocks = [tch.b, nb];
  // Güç kaydırılınca (ya da bir blok güçle yer değiştirince) ateşlenir; iki güç birleşince kombo
  if (tch.b.power || (nb && nb.power)) { const a = tch.b; swapEnd(); swapResolve(() => swapFire(a, nb)); return true; }
  if (findLines().length) { swapEnd(); swapResolve(); return true; }
  // Boşluğa kaydı ve altı boş: düşer, sürükleme biter
  if (h && !nb && swapFind(tch.b)?.[0] !== r) { swapEnd(); return true; }
  return false;
}
function swapEnd() {
  const tch = swapTouch;
  swapTouch = null;
  if (!tch || !tch.b.s || tch.b.s.destroyed) return;
  const s = tch.b.s, at = swapFind(tch.b), jobs = [tween(s.scale, { x: tch.k, y: tch.k }, 0.12, Ease.outQuad)];
  // Hücresine yaylanarak oturur (düşmekte olan bloğun dikey animasyonuna dokunulmaz)
  if (at && tch.axis) {
    const prop = tch.axis === 'h' ? 'x' : 'y', to = prop === 'x' ? fx0(at[1]) : fy0(at[0]);
    if (Math.abs(s[prop] - to) > 0.5) { killTweenProp(s, prop); jobs.push(tween(s, { [prop]: to }, 0.16, Ease.outBack)); }
  }
  if (fall) fall.gravP = Promise.all([fall.gravP, ...jobs]);
}
function swapUp() {
  const tch = swapTouch;
  swapEnd();
  if (!tch || !fall || !fall.active || over) return;
  // Güce dokun: ateşlenir
  if (!tch.moved && performance.now() - tch.t < 350 && tch.b.power && !busy && swapFind(tch.b)) { fall.swapBlocks = null; swapResolve(() => swapFire(tch.b, null)); }
}
// Patlatma zinciri: kaydırma (ya da dokunulan güç) sonrası. Zincir sayacı her hamlede sıfırdan başlar.
async function swapResolve(act = null) {
  if (!fall || fall.resolving) return;
  const f = fall, run0 = runId;
  f.resolving = true;
  busy = true;
  f.combo = 0;
  try {
    await f.gravP;
    if (act && fall === f && !over) await act();
    if (fall === f && !over) await bridgeResolve();
  } catch (err) { console.error('Kaydırma çözüm hatası', err); }
  f.resolving = false; f.combo = 0; f.swapBlocks = null;
  if (runId !== run0 || fall !== f) return;   // bu arada bölümden çıkıldıysa yeni oyunun durumuna dokunma
  busy = false;
}
// Pervanenin hedefi: sayaçlı bomba (en az süresi kalan) > taş > buzlu blok > en yüksek sütunun tepesi
function propTarget(r, c, skip = []) {
  const A = PA();
  let best = null, bs = -1e9;
  for (let rr = 0; rr < A.rows; rr++) for (let cc = 0; cc < A.cols; cc++) {
    const t = A.at(rr, cc);
    if (!t || t.firing || Math.abs(rr - r) + Math.abs(cc - c) <= 1 || skip.some(([y, x]) => y === rr && x === cc)) continue;
    const sc = t.kind === 'tbomb' ? 1000 - t.timer : t.kind === 'stone' ? 500 : t.hp > 0 ? 400 : 100 - rr + Math.random() * 0.5;
    if (sc > bs) { bs = sc; best = [rr, cc]; }
  }
  return best;
}
// Gücü (bütün parçalarıyla) başka bir kareye taşır
function movePow(q, r, c) {
  const X = fx0(c), Y = fy0(r);
  for (const k of ['s', 'pi', 'glow', 'spark', 'shineMask', 'shine']) if (q[k] && !q[k].destroyed) { q[k].position.set(X, Y); q[k].visible = true; }
}
// Tahtada en çok bulunan renk(ler)
function swapTopColors() {
  const n = {};
  for (const row of fall.grid) for (const b of row) { const k = bridgeCol(b); if (k) n[k] = (n[k] || 0) + 1; }
  return Object.keys(n).sort((a, b) => n[b] - n[a]);
}
// Güç ateşleme: a kaydırılan, b yer değiştirdiği (boş, blok ya da güç). İki güç birleşince kombo:
// roket+roket artı şeklinde, roket+bomba artı + patlama, bomba+bomba büyük patlama, yıldırım+güç en çok bulunan rengi
// silip gücü ateşler, yıldırım+yıldırım en çok bulunan iki rengi siler. Yıldırım bir blokla yer değiştirirse o rengi siler.
async function swapFire(a, b) {
  const P = [a, b].filter((x) => x && x.power);
  if (!P.length || !fall) return;
  const take = (x) => { const p = swapFind(x); if (p) fall.grid[p[0]][p[1]] = null; return p; };
  const at0 = swapFind(P[0]);
  if (P.length === 1) {
    const p = P[0], other = p === a ? b : a;
    if (p.power === 'bolt') p.boltColor = (other && bridgeCol(other)) || swapTopColors()[0];
    const at = take(p);
    if (at) await firePower(p, at[0], at[1]);
    return;
  }
  const [p, q] = P[0].power === 'bolt' ? [P[0], P[1]] : [P[1], P[0]];   // yıldırım varsa önce o
  const at = take(a) || at0, bt = take(b) || at;
  bigText('SÜPER KOMBO!', ['#fff3c0', '#ff9a2a'], 0xff8a2a, BY + N * cell * 0.42, 2);
  Haptics.heavy();
  if (p.power === 'bolt') {
    const cols = swapTopColors();
    p.boltColor = cols[0];
    await firePower(p, ...at);
    if (q.power === 'bolt') { q.boltColor = swapTopColors()[0]; await firePower(q, ...at); }
    else { q.s.position.set(fx0(at[1]), fy0(at[0])); q.dir = q.dir === 'h' ? 'v' : 'h'; await firePower(q, ...at); }
    return;
  }
  const same = (x) => movePow(x, at[0], at[1]);
  if (p.power === 'prop' || q.power === 'prop') {
    const pr = p.power === 'prop' ? p : q, ot = pr === p ? q : p;
    if (ot.power === 'prop') {
      // İki pervane ayrı hedeflere uçar
      pr.propTarget = propTarget(at[0], at[1]);
      ot.propTarget = propTarget(bt[0], bt[1], pr.propTarget ? [pr.propTarget] : []);
      await Promise.all([firePower(pr, ...at), firePower(ot, ...bt)]);
    } else {
      // Pervane diğer gücü sırtında hedefe taşır, orada ateşlenir
      const tgt = propTarget(at[0], at[1]);
      pr.propTarget = tgt;
      for (const k of ['s', 'pi', 'glow', 'spark', 'shine']) if (ot[k]) ot[k].visible = false;
      await firePower(pr, ...at);
      const t2 = tgt || at;
      movePow(ot, t2[0], t2[1]);
      await firePower(ot, t2[0], t2[1]);
    }
    return;
  }
  if (p.power === 'rocket' && q.power === 'rocket') {
    a.dir = 'h'; b.dir = 'v'; same(b);
    await Promise.all([firePower(a, ...at), firePower(b, ...at)]);
  } else if (p.power === 'bomb' && q.power === 'bomb') {
    await Promise.all([firePower(a, ...at), firePower(b, ...bt)]);
  } else {
    // Roket + bomba: aynı karede iki yönlü roket ve bomba
    const rk = p.power === 'rocket' ? p : q, bm = rk === p ? q : p;
    rk.dir = 'h'; same(rk); same(bm);
    const clone = makePower(at[0], at[1], 'rocket', 'v');
    fall.grid[at[0]][at[1]] = null;
    await Promise.all([firePower(rk, ...at), firePower(clone, ...at), firePower(bm, ...at)]);
  }
}
// Sayaçlı bombalar kaydırma bölümünde zamanla geri sayar
function swapBombTick(dt) {
  if (!L.swap) return;
  fall.tbT = (fall.tbT || 0) + dt;
  if (fall.tbT < 2.5) return;
  fall.tbT = 0;
  if (busy || !fall.grid.some((row) => row.some((b) => b && b.kind === 'tbomb'))) return;
  busy = true;
  const run0 = runId;
  tickTimeBombs().catch((err) => console.error(err)).then(() => {
    if (runId !== run0) return;
    busy = false;
    if (fall && !over && findLines().length) swapResolve();
  });
}

// Dokunmatik: sürükle = kaydır, dokun = döndür, aşağı çek = yumuşak indir, hızlı aşağı fiske = anında indir
let fallTouch = null;
app.stage.on('pointerdown', (e) => {
  if (!fall || !fall.active || over || e.global.y < BY - 30) return;
  if (L.swap) { swapDown(e); return; }
  fallTouch = { x: e.global.x, y: e.global.y, t: performance.now(), mx: 0, my: 0, moved: false, lastY: e.global.y, lastT: performance.now(), vy: 0 };
});
app.stage.on('globalpointermove', (e) => {
  if (swapTouch) { swapMove(e); return; }
  const tch = fallTouch;
  if (!tch || !fall || !fall.active) return;
  const cs = fall.m.cs;
  const dx = e.global.x - tch.x, dy = e.global.y - tch.y;
  const want = Math.round(dx / (cs * 0.9));
  while (tch.mx < want && fallMove(1, 0)) tch.mx++;
  while (tch.mx > want && fallMove(-1, 0)) tch.mx--;
  if (tch.mx !== want) tch.mx = want;   // duvara dayandıysa sapma birikmesin
  const wantY = Math.floor(Math.max(0, dy) / (cs * 0.85));
  while (tch.my < wantY) { if (!fallMove(0, 1)) break; tch.my++; fall.t = 0; }
  if (Math.abs(dx) > 8 || Math.abs(dy) > 8) tch.moved = true;
  const now = performance.now();
  tch.vy = (e.global.y - tch.lastY) / Math.max(1, now - tch.lastT);
  tch.lastY = e.global.y; tch.lastT = now;
});
const fallUp = (e) => {
  if (swapTouch) { swapUp(e); return; }
  const tch = fallTouch;
  fallTouch = null;
  if (!tch || !fall || !fall.active) return;
  const dt = performance.now() - tch.t;
  const dy = e.global.y - tch.y, dx = e.global.x - tch.x;
  if (!tch.moved && dt < 350) fallRotate();
  else if (dy > fall.m.cs * 1.2 && tch.vy > 0.9 && Math.abs(dy) > Math.abs(dx) * 1.5) fallHardDrop();
};
app.stage.on('pointerup', fallUp);
app.stage.on('pointerupoutside', fallUp);

// Satır hedefi simgesi: parlayan bir blok sırası
function lineIconCanvas(S) {
  const c = document.createElement('canvas');
  c.width = c.height = S;
  const x = c.getContext('2d');
  const u = S / 5.2, y = S / 2 - u / 2;
  for (let i = 0; i < 5; i++) x.drawImage(renderTile(['#ff4757', '#ff8c1a', '#ffcf1a', '#2ed573', '#1e90ff'][i], Math.round(u)), S * 0.02 + i * u, y, u * 0.96, u * 0.96);
  const g = x.createLinearGradient(0, 0, S, 0);
  g.addColorStop(0, 'rgba(255,255,255,0)'); g.addColorStop(0.5, 'rgba(255,255,255,0.95)'); g.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = g;
  x.fillRect(0, S / 2 - u * 0.14, S, u * 0.28);
  return c;
}
// Tanıtım kartı görseli: düşen T parçası ve dolmak üzere olan satırlar
function fallTipImage() {
  const S = 160, u = 18, cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  x.fillStyle = '#0d1440'; x.beginPath(); x.roundRect(0, 0, S, S, 18); x.fill();
  const ox = (S - u * 8) / 2, oy = 8;
  const tile = (col, c, r) => x.drawImage(renderTile(col, u), ox + c * u, oy + r * u, u, u);
  ['#ff4757', '#ff8c1a', '#2ed573', '#1e90ff', '#a55eea', '#ffcf1a', '#17d1e6', '#2ed573'].forEach((col, c) => { if (c !== 3) tile(col, c, 7); });
  ['#1e90ff', '#a55eea', '#ff8c1a', '#2ed573', '#ff4757', '#17d1e6', '#ffcf1a', '#1e90ff'].forEach((col, c) => { if (c !== 3 && c !== 4) tile(col, c, 6); });
  [[3, 2], [2, 3], [3, 3], [4, 3]].forEach(([c, r]) => tile('#a55eea', c, r));
  x.strokeStyle = 'rgba(255,255,255,0.8)'; x.lineWidth = 3; x.lineCap = 'round';
  x.beginPath(); x.moveTo(ox + 3.5 * u, oy + 4.6 * u); x.lineTo(ox + 3.5 * u, oy + 5.6 * u); x.moveTo(ox + 3.1 * u, oy + 5.2 * u); x.lineTo(ox + 3.5 * u, oy + 5.6 * u); x.lineTo(ox + 3.9 * u, oy + 5.2 * u); x.stroke();
  return cv.toDataURL();
}
function fallRelayout() {
  const old = fall.grid.map((row) => row.map((b) => (b ? { color: b.color, icon: b.icon, power: b.power, dir: b.dir, kind: b.kind, hp: b.hp, timer: b.timer } : null)));
  const p = fall.piece;
  fallBuild();
  fall.incoming = null;   // yükselen sıra yeni boyutla yeniden oluşur
  fall.grid = Array.from({ length: L.rows }, () => Array(L.cols).fill(null));
  old.forEach((row, r) => row.forEach((b, c) => {
    if (!b) return;
    if (b.power) { makePower(r, c, b.power, b.dir); return; }
    const nb = fallSetCell(r, c, b.color, b.icon, -1);
    if (b.kind) { Object.assign(nb, { kind: b.kind, hp: b.hp || 0, timer: b.timer }); nb.s.texture = hazardTex(nb); }   // buz, taş, sayaçlı bomba korunur
  }));
  fallDrawNext();
  if (p) {
    const v = fall.vis;
    fallMakeCur(p);
    fall.vis = v || { x: p.x, y: p.y };
    fallRender();
  }
}

// ---------- Günlük bulmaca ----------
// Herkes için aynı tahta ve aynı parça dizisi; hamle bitmeden tüm hedefler toplanmalı.
const DAILY_THEME = { name: 'Günlük', scene: 'space', bg: ['#4a1446', '#150515'], board: '#170617', line: '#2e0f2c', frame: '#8c3383', block: '#ff5fae' };
let daily = false, movesLeft = 0, overReason = null;
const hasMoves = () => daily || (mode === 'level' && !!(L && L.moves) && !L.falling);
const todayLabel = () => new Date().toLocaleDateString('tr-TR', { day: 'numeric', month: 'long' }).toLocaleUpperCase('tr-TR');
function startDaily() {
  spendLifeIfRisk();
  $('hud').classList.remove('timed');
  paidRevives = 0;
  freeB = { hammer: 0, bomb: 0, shuffle: 0 };
  daily = true;
  mode = 'level';
  placeTray();
  levelN = -1;
  L = getDaily();
  rnd = seededRnd(L.seed);
  applyTheme(DAILY_THEME);
  reset();
  movesLeft = L.moves;
  goals = L.goals.map((g) => ({ icon: g.icon, left: g.count, shown: g.count }));
  $('goalBar').replaceChildren();
  renderGoals();
  $('levelLabel').innerHTML = `Günlük Bulmaca<small>${todayLabel()}</small>`;
  $('hud').classList.remove('special');
  buildLayout();
}
function updateMoves(quiet = false) {
  const el = $('movesNum');
  if (!el) return;
  el.textContent = Math.max(0, movesLeft);
  const box = el.closest('.goal-mv');
  const lim = daily ? 3 : 5;
  box.classList.toggle('warn', movesLeft <= lim && movesLeft > 2);
  box.classList.toggle('crit', movesLeft <= Math.min(2, lim));
  const fill = $('movesFill');
  if (fill) fill.style.width = `${Math.max(0, Math.min(1, movesLeft / Math.max(1, L.moves || movesLeft))) * 100}%`;
  if (quiet) return;
  el.animate([{ transform: 'scale(1.25)' }, { transform: 'scale(1)' }], { duration: 280, easing: 'ease-out' });
}

// Bölüm başlangıç kartı: tahtanın küçük önizlemesi
function boardPreview(L0, th) {
  const S = 22, cv = document.createElement('canvas');
  cv.width = cv.height = S * 8 + 12;
  const x = cv.getContext('2d');
  x.fillStyle = th.frame; x.beginPath(); x.roundRect(0, 0, cv.width, cv.height, 14); x.fill();
  x.fillStyle = th.board; x.beginPath(); x.roundRect(4, 4, cv.width - 8, cv.height - 8, 11); x.fill();
  const blk = renderTile(th.block, S), wood = renderWood(S), royal = renderRoyal(S), ice = renderIce(S), chain = renderChain(S, 2);
  const ic = { g: renderIcon('gem', S), s: renderIcon('star', S), h: renderIcon('heart', S), k: renderIcon('crown', S) };
  L0.layout.forEach((row, r) => [...row].forEach((ch, c) => {
    if (ch === '.') return;
    const px = 6 + c * S, py = 6 + r * S;
    x.drawImage(ic[ch] ? (ch === 'k' ? royal : wood) : blk, px, py);
    if (ic[ch]) x.drawImage(ic[ch], px, py);
    if (ch === 'i') x.drawImage(ice, px, py);
    if (ch === 'c') x.drawImage(chain, px, py);
  }));
  return cv.toDataURL();
}
let dpuzTick = null;
function openDailyCard() {
  const st = DailyPuzzle.state();
  const D = getDaily();
  const now = new Date();
  const solved = st.solvedToday;
  $('dpuz').classList.toggle('solved', solved);
  $('dzMonth').textContent = now.toLocaleDateString('tr-TR', { month: 'long' }).toLocaleUpperCase('tr-TR');
  $('dzDay').textContent = now.getDate();
  $('dzDate').textContent = now.toLocaleDateString('tr-TR', { weekday: 'long', day: 'numeric', month: 'long' });
  $('dzImg').src = boardPreview(D, DAILY_THEME);
  $('dzMoves').textContent = D.moves;
  $('dzGoals').replaceChildren(...D.goals.map((g) => {
    const el = document.createElement('span');
    el.className = 'dz-goal';
    el.innerHTML = `<img src="${iconURL[g.icon]}" alt=""><b>×${g.count}</b>`;
    return el;
  }));
  // Seri: 7 günlük döngü, 7. gün sandık
  const inCycle = solved ? ((st.streak - 1) % 7) + 1 : st.streak % 7;
  $('dzPips').replaceChildren(...[0, 1, 2, 3, 4, 5, 6].map((k) => {
    const el = document.createElement('i');
    el.className = (k < inCycle ? 'on' : k === inCycle && !solved ? 'next' : '') + (k === 6 ? ' chest' : '');
    el.innerHTML = k === 6 ? '<svg><use href="#c-chest"/></svg>' : `<small>${k + 1}</small>`;
    return el;
  }));
  $('dzStreakText').textContent = st.streak ? `${st.streak} günlük seri` : 'Seriye başla!';
  const next = st.streak + 1;
  $('dzReward').innerHTML = solved
    ? '<svg class="ok"><use href="#i-check"/></svg>Ödül alındı'
    : `<svg><use href="#i-coin"/></svg>${DailyPuzzle.rewardFor(next)}${next % 7 === 0 ? '<svg class="ch"><use href="#c-chest"/></svg>' : ''}`;
  $('dzGoText').textContent = solved ? 'TEKRAR OYNA' : 'BAŞLA';
  $('dzGo').classList.toggle('alt', solved);
  clearInterval(dpuzTick);
  const tick = () => {
    if (!$('dpuz').classList.contains('show')) { clearInterval(dpuzTick); return; }
    const t = new Date(), nx = new Date(t.getFullYear(), t.getMonth(), t.getDate() + 1);
    const sec = Math.max(0, Math.floor((nx - t) / 1000));
    const p2 = (v) => String(v).padStart(2, '0');
    $('dzTimer').textContent = `${solved ? 'Yeni bulmaca' : 'Kalan süre'}: ${p2(Math.floor(sec / 3600))}:${p2(Math.floor((sec % 3600) / 60))}:${p2(sec % 60)}`;
  };
  openPopup('dpuz');
  tick();
  dpuzTick = setInterval(tick, 1000);
}
$('dzGo').addEventListener('click', () => { closePopups(); startDaily(); });
$('dpuzClose').addEventListener('click', closePopups);

// Bölüm tahtasını kur, parçaları dağıt, oyunu göster
function buildLayout() {
  const iconOf = { g: 'gem', s: 'star', h: 'heart', k: 'crown', G: 'gem', S: 'star', H: 'heart' };
  const obsOf = { i: { kind: 'ice' }, c: { kind: 'chain' }, b: { kind: 'bomb', timer: L.bombTimer }, G: { kind: 'cage' }, S: { kind: 'cage' }, H: { kind: 'cage' } };
  let k = 0;
  if (L.dig) buildDig();
  L.layout.forEach((row, r) => [...row].forEach((ch, c) => {
    if (ch === '.') return;
    const icon = L.type === 'score' ? null : iconOf[ch] || null;
    const obs = obsOf[ch] || null;
    const plain = L.special ? 'c' + (r % PALETTE.length) : 'block';   // özel bölümde satır satır gökkuşağı
    if (L.promo && 'pqrtuvw'.includes(ch)) { setBlock(r, c, 'c' + 'pqrtuvw'.indexOf(ch), true, (k++ % 16) * 0.02 + r * 0.03); return; }   // tanıtım videosu: renkli bloklar
    if (L.power && 'RVBY'.includes(ch)) { makePower(r, c, ch === 'B' ? 'bomb' : ch === 'Y' ? 'bolt' : 'rocket', ch === 'V' ? 'v' : 'h'); return; }
    if (ch === 'm') { setBlock(r, c, 'moss', true, (k++ % 16) * 0.02 + r * 0.03); grid[r][c].moss = true; return; }
    if (NEED_COLOR[ch]) { setBlock(r, c, 'need_' + NEED_COLOR[ch], true, (k++ % 16) * 0.02 + r * 0.03); grid[r][c].need = NEED_COLOR[ch]; return; }
    setBlock(r, c, icon ? (icon === 'crown' ? 'royal' : 'wood') : obs && obs.kind === 'bomb' ? 'bomb' : plain, true, (k++ % 16) * 0.02 + r * 0.03, icon, obs);
  }));
  deal();
  renderCombo();
  showScreen('game');
  renderProgress();
  renderBoosters();
  Sound.start();
}

// İlk kez görülen engel ya da yeni dünya için kısa tanıtım kartı (kartlar sırayla gösterilir)
const TIPS = {
  ice: { title: 'Buz Blok', desc: 'İki kez patlatman gerekir: ilk patlamada buz kırılır, ikincisinde blok gider.' },
  chain: { title: 'Zincirli Blok', desc: 'Üç kez patlatman gerekir: zincirler halka halka kopar, sonra blok gider.' },
  bomb: { title: 'Saatli Bomba', desc: 'Her hamlede sayısı azalır. Sıfıra inmeden satırını ya da sütununu patlat!' },
  cage: { title: 'Kafes', desc: 'Simge kafesin içinde! İlk patlatma kafesi kırar, ikincisi simgeyi toplar.' },
  need: { title: 'Renkli Blok', desc: 'Yalnızca aynı renkteki parçayla tamamlanan satır ya da sütunda patlar. Parçaların rengine dikkat et!' },
  moss: { title: 'Yosun', desc: 'Satır patlatmadığın her hamlede yanındaki boş kareye yayılır. Patlatarak temizle, tahtayı sarmasın!' },
};
function tipImage(kind) {
  const S = 160, cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  if (kind === 'bomb') {
    x.drawImage(renderTimerBomb(S, 9, false, FONT), 0, 0);
  } else if (kind === 'moss') {
    x.drawImage(renderMoss(S), 0, 0);
  } else if (kind === 'need') {
    x.drawImage(renderNeed(PALETTE[0], S), 0, 0);
  } else if (kind === 'cage') {
    x.drawImage(renderWood(S), 0, 0);
    x.drawImage(renderIcon('gem', S), 0, 0);
    x.drawImage(renderCage(S), 0, 0);
  } else {
    x.drawImage(renderTile(theme.block, S), 0, 0);
    x.drawImage(kind === 'ice' ? renderIce(S) : renderChain(S, 2), 0, 0);
  }
  return cv.toDataURL();
}
function crownImage() {
  const S = 170, cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  const g = x.createRadialGradient(S / 2, S / 2, 0, S / 2, S / 2, S / 2);
  g.addColorStop(0, 'rgba(255,210,80,0.75)'); g.addColorStop(1, 'rgba(255,210,80,0)');
  x.fillStyle = g; x.fillRect(0, 0, S, S);
  x.drawImage(renderIcon('crown', S), 0, 0);
  return cv.toDataURL();
}
function worldImage(w) {
  const cv = document.createElement('canvas');
  cv.width = 480; cv.height = 240;
  const x = cv.getContext('2d');
  const g = x.createLinearGradient(0, 0, 0, 240); g.addColorStop(0, w.bg[0]); g.addColorStop(1, w.bg[1]);
  x.fillStyle = g; x.fillRect(0, 0, 480, 240);
  paintScene(x, 480, 240, w.scene);
  return cv.toDataURL();
}
const specialShown = new Set();
let tipNext = null;
function showTips(n) {
  tipNext = null;
  const L0 = (L.layout || []).join('');
  const queue = [];
  const showSpecial = L.special && !specialShown.has(n);
  if (showSpecial) specialShown.add(n);
  const wi = worldIndex(n);
  if (n > 0 && n % WORLD_SIZE === 0 && Store.num('world_seen', 0) < wi) {
    Store.set('world_seen', wi);
    const w = WORLDS[wi];
    queue.push({ tag: `DÜNYA ${wi + 1}`, img: worldImage(w), wide: true, title: `${w.name} dünyasına hoş geldin!`, desc: 'Yeni renkler, yeni manzara ve daha zorlu bölümler seni bekliyor.' });
  }
  if (L.falling && Store.get('seen_falling', '') !== '1') {
    Store.set('seen_falling', '1');
    queue.push(L.sand
      ? { tag: 'YENİ BÖLÜM TÜRÜ', img: fallTipImage(), title: 'Düşen Bloklar', desc: L.bridge ? 'Şekiller yukarıdan düşer. Sürükle: kaydır, dokun: döndür, aşağı kaydır: indir. Tahta alttan yükselir; süre bitene kadar tepeye ulaşma!' : 'Şekiller yukarıdan düşer ve yere değince kum gibi akar. Sürükle: kaydır, dokun: döndür, aşağı kaydır: indir. Satırları patlat, süre bitene kadar tepeye ulaşma!' }
      : { tag: 'YENİ BÖLÜM TÜRÜ', img: fallTipImage(), title: 'Düşen Bloklar', desc: 'Şekiller yukarıdan düşer. Parmağınla sürükleyerek kaydır, dokunarak döndür, aşağı kaydırarak hızlıca indir. Satırları tamamla, dipteki simgeleri topla!' });
  }
  // Kum bölümü engelleri: ilk görüldüğünde tanıtım
  if (L.sand && L.hz) {
    const tipImg = (q) => { const S = 160, cv = document.createElement('canvas'); cv.width = cv.height = S; cv.getContext('2d').drawImage(hazardTex(q).source.resource, S * 0.2, S * 0.2, S * 0.6, S * 0.6); return cv.toDataURL(); };
    const SH = [
      ['ice', { kind: 'ice', color: 'c4', hp: 1 }, 'Buzlu Sıra', 'Alttan buzlu sıralar gelir. Satır ilk dolunca buz kırılır ve diğer bloklar patlar; satırı bir kez daha doldurman gerekir.'],
      ['bomb', { kind: 'tbomb', timer: 5, color: 'bomb' }, 'Sayaçlı Bomba', 'Sayı her parçada bir azalır. Sıfırlanmadan satırını patlat (+300). Patlarsa alttan 2 sıra birden fırlar!'],
      ['stone', { kind: 'stone', hp: 1, color: 'stone' }, 'Taş Blok', 'Taşlı satır ilk dolunca taş çatlar, ikinci kez dolunca kırılır. Bomba taşı doğrudan yok eder.'],
      ['quake', null, 'Deprem', '"DEPREM!" uyarısından 2 saniye sonra tahta bir anda birkaç sıra yükselir. Hazırlıklı ol!'],
    ];
    for (const [k, q, title, desc] of SH) {
      if (!L.hz[k] || Store.get('seen_sand_' + k, '') === '1') continue;
      Store.set('seen_sand_' + k, '1');
      queue.push({ tag: 'YENİ ZORLUK', img: q ? tipImg(q) : fallTipImage(), title, desc });
    }
  }
  if (L.swap && Store.get('seen_swap', '') !== '1') {
    Store.set('seen_swap', '1');
    queue.push({ tag: 'YENİ KURAL', img: swapRuleImage(), title: 'Kaydır ve Patlat', desc: 'Parça düşmez, tahta alttan yükselir. Bir bloğu sağa-sola ya da yukarı-aşağı çek: yanındakiyle yer değiştirir. Aynı renkten 3 blok yatay ya da dikey sıralanınca patlar; üstteki bloklar düşer, zincirleme patlar!' });
  } else if (!L.swap && L.bridge && Store.get('seen_group', '') !== '1') {
    Store.set('seen_group', '1');
    queue.push({ tag: 'YENİ KURAL', img: bridgeTipImage(), title: 'Renk Grubu', desc: 'Aynı renkten 8 ya da daha fazla blok birbirine değince patlar! Üstteki bloklar düşer; yeni grup oluşursa zincirleme patlar, kombo büyür.' });
  }
  const powerKey = L.sand ? 'seen_power_fall' : 'seen_power';
  if (L.power && Store.get(powerKey, '') !== '1') {
    Store.set(powerKey, '1');
    queue.push({ tag: 'YENİ ÖZELLİK', img: powerTipImage(), title: 'Güçler', desc: L.swap ? '4\'lü sıra: Roket! L ya da T şekli: Bomba! 5\'li sıra: Yıldırım! 2×2 kare: Pervane! Güce dokun ya da kaydır; iki gücü yan yana getirip birleştir: süper kombo!' : L.sand ? 'Art arda satır patlat ya da aynı anda 2 satır patlat: Roket! 3: Bomba! 4 ve fazlası: Yıldırım! Güç, bulunduğu satır patlayınca ateşlenir; güçler birbirini zincirleme patlatır.' : 'Aynı anda 2 satır patlat: Roket! 3 satır: Bomba! 4 ve fazlası: Yıldırım! Güce dokun ya da satırını patlat, ateşlensin. Güçler birbirini zincirleme patlatır.' });
  }
  if (L.dig && Store.get('seen_dig', '') !== '1') {
    Store.set('seen_dig', '1');
    queue.push({ tag: 'YENİ HEDEF', img: digTipImage(), title: 'Hazine Kazısı', desc: 'Hazineler toprağın altında! Üstündeki satırı ya da sütunu patlattıkça toprak kazılır; koyu toprak iki kez kazılmalı. Hazinenin bütün kareleri açılınca hazine senin!' });
  }
  for (const [ch, kind] of [['i', 'ice'], ['c', 'chain'], ['b', 'bomb'], ['GSH', 'cage'], ['123', 'need'], ['m', 'moss']]) {
    if (![...ch].some((q) => L0.includes(q)) || Store.get('seen_' + kind, '') === '1') continue;
    Store.set('seen_' + kind, '1');
    queue.push({ tag: 'YENİ ENGEL', img: tipImage(kind), title: TIPS[kind].title, desc: TIPS[kind].desc });
  }
  const next = () => {
    const t = queue.shift();
    if (!t) { tipNext = null; return closePopups(); }
    tipNext = next;
    $('tipTag').textContent = t.tag;
    $('tipImg').src = t.img;
    $('tipImg').classList.toggle('wide', !!t.wide);
    $('tipTitle').textContent = t.title;
    $('tipDesc').textContent = t.desc;
    $('tip').classList.remove('closable');
    $('tipOk').textContent = 'ANLADIM';
    openPopup('tip');
    $('tipOk').onclick = next;
  };
  if (L.escape && Store.get('seen_escape', '') !== '1') {
    Store.set('seen_escape', '1');
    queue.push({ tag: 'YENİ BÖLÜM TÜRÜ', img: escTipImage(L.esc), title: 'Blok Kaçışı', desc: 'Bloğu parmağınla sürükle: boş hücrelerde adım adım ilerler. Kendi rengindeki kapıya ittiğin blok parçalanarak çıkar. Buzlu kapıdaki sayı her çıkışta azalır, 0 olunca buz kırılır. Süre bitmeden bütün blokları çıkar!' });
  }
  // Sabit engeller: her tür ilk göründüğü bölümde bir kez tanıtılır (taş, yosunlu taş, deniz taşı, kum taşı, göktaşı, buz, lav)
  if (L.escape) for (const k of escObstKinds(L.esc, n)) {
    const key = k === 'tas' ? 'seen_esc_stone' : 'seen_esc_' + k;
    if (Store.get(key, '') === '1') continue;
    Store.set(key, '1');
    queue.push({ tag: 'YENİ ENGEL', img: escTipImage(L.esc), title: OBST_NAME[k], desc: `${OBST_NAME[k]} yerinden oynamaz ve blokların yolunu keser. Etrafından dolaş ya da çekiç veya bombayla kır!` });
  }
  const showNormal = mode === 'level' && !daily && !L.special && !L.falling && !L.promo;
  if (showSpecial) openSpecialIntro(n, () => { if (queue.length) setTimeout(next, 250); });   // önce giriş ekranı, sonra oyun
  else if (showNormal) openLevelIntro(n, () => { if (queue.length) setTimeout(next, 250); else if (n === 0 && !Store.get('tut_done', '')) setTimeout(startTutorial, 250); });
  else if (queue.length) setTimeout(next, 450);
}

// Özel bölüm giriş ekranı: dönen altın ışınlar, düşen taç, hedef ve ödül rozetleri
// Giriş ekranındaki kural görseli: 8 mavi blok bir grup → patlama
let ruleImg = null;
// Kaydırma kuralı görseli: sarı blok sağa çekilir, üç mavi yan yana gelip patlar
let swapRuleImg = null;
function swapRuleImage() {
  if (swapRuleImg) return swapRuleImg;
  const W0 = 312, H0 = 132, u = 30, cv = document.createElement('canvas');
  cv.width = W0; cv.height = H0;
  const x = cv.getContext('2d');
  const oy = (H0 - u * 2) / 2 + 10, col = { b: '#1e90ff', r: '#ff4757', y: '#ffcf1a', g: '#2ed573' };
  ['gr.ry', 'bbybg'].forEach((row, r) => [...row].forEach((ch, c) => { if (ch !== '.') x.drawImage(renderSymbolTile(col[ch], u * 2), 6 + c * u, oy + r * u, u - 2, u - 2); }));
  // Çift yönlü ok: sarı ↔ mavi
  const ay = oy - 12, ax0 = 6 + 2 * u + u / 2, ax1 = 6 + 3 * u + u / 2;
  x.strokeStyle = '#ffffff'; x.fillStyle = '#ffffff'; x.lineWidth = 4; x.lineCap = 'round';
  x.beginPath(); x.moveTo(ax0, ay + 4); x.quadraticCurveTo((ax0 + ax1) / 2, ay - 16, ax1, ay + 4); x.stroke();
  x.beginPath(); x.moveTo(ax1 + 7, ay - 2); x.lineTo(ax1 + 1, ay + 12); x.lineTo(ax1 - 9, ay + 1); x.closePath(); x.fill();
  x.fillStyle = '#ffffff';
  x.beginPath(); x.moveTo(176, H0 / 2 - 10 + 10); x.lineTo(196, H0 / 2 + 10); x.lineTo(176, H0 / 2 + 20); x.closePath(); x.fill();
  x.fillRect(160, H0 / 2 + 6, 18, 8);
  // Sonuç: üç mavi yan yana, beyaz çerçeve
  const rx = 210, ry = oy + u;
  for (let i = 0; i < 3; i++) x.drawImage(renderSymbolTile(col.b, u * 2), rx + i * u, ry, u - 2, u - 2);
  x.strokeStyle = '#ffffff'; x.lineWidth = 4; x.lineJoin = 'round';
  x.beginPath(); x.roundRect(rx - 4, ry - 4, u * 3 + 6, u + 6, 8); x.stroke();
  x.fillStyle = '#fff6b0';
  for (const [px, py, k] of [[rx + 8, ry - 22, 9], [rx + u * 3 - 4, ry - 30, 12], [rx + u * 1.6, ry - 40, 7]]) {
    x.beginPath(); for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2, rr = i % 2 ? k * 0.35 : k; x.lineTo(px + Math.cos(a) * rr, py + Math.sin(a) * rr); } x.closePath(); x.fill();
  }
  swapRuleImg = cv.toDataURL();
  return swapRuleImg;
}
function groupRuleImage() {
  if (ruleImg) return ruleImg;
  const W0 = 312, H0 = 132, u = 30, cv = document.createElement('canvas');
  cv.width = W0; cv.height = H0;
  const x = cv.getContext('2d');
  const oy = (H0 - u * 3) / 2 + 4, col = { b: '#1e90ff', r: '#ff4757', y: '#ffcf1a', g: '#2ed573' };
  const grid = ['rbbby', 'gbbbb', 'yrbgr'];
  grid.forEach((row, r) => [...row].forEach((ch, c) => x.drawImage(renderTile(col[ch], u * 2), 6 + c * u, oy + r * u, u - 2, u - 2)));
  // Grubun dış çizgisi
  x.strokeStyle = '#ffffff'; x.lineWidth = 4; x.lineJoin = 'round';
  x.beginPath();
  const X = (c) => 6 + c * u - 1, Y = (r) => oy + r * u - 1;
  x.moveTo(X(1), Y(0)); x.lineTo(X(4), Y(0)); x.lineTo(X(4), Y(1)); x.lineTo(X(5), Y(1)); x.lineTo(X(5), Y(2)); x.lineTo(X(1), Y(2)); x.lineTo(X(1), Y(1)); x.lineTo(X(1), Y(0));
  x.stroke();
  x.beginPath(); x.moveTo(X(2), Y(2)); x.lineTo(X(3), Y(2)); x.lineTo(X(3), Y(3)); x.lineTo(X(2), Y(3)); x.closePath(); x.stroke();
  // Ok ve patlama yıldızı
  x.fillStyle = '#ffffff';
  x.beginPath(); x.moveTo(176, H0 / 2 - 10); x.lineTo(196, H0 / 2); x.lineTo(176, H0 / 2 + 10); x.closePath(); x.fill();
  x.fillRect(160, H0 / 2 - 4, 18, 8);
  const bx = 255, by = H0 / 2;
  const g = x.createRadialGradient(bx, by, 0, bx, by, 52);
  g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.3, 'rgba(255,230,120,0.9)'); g.addColorStop(0.7, 'rgba(255,140,30,0.35)'); g.addColorStop(1, 'rgba(255,120,0,0)');
  x.fillStyle = g; x.beginPath(); x.arc(bx, by, 52, 0, 7); x.fill();
  x.fillStyle = '#fff6b0';
  x.beginPath(); for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2, rr = i % 2 ? 12 : 40; x.lineTo(bx + Math.cos(a) * rr, by + Math.sin(a) * rr); } x.closePath(); x.fill();
  for (const [px, py, k] of [[222, 30, 10], [292, 98, 8], [290, 34, 7]]) { x.fillStyle = '#4fb2ff'; x.fillRect(px - k / 2, py - k / 2, k, k); }
  ruleImg = cv.toDataURL();
  return ruleImg;
}
function openSpecialIntro(n, after) {
  const crowns = (L.goals.find((g) => g.icon === 'crown') || { count: 0 }).count;
  const el = $('specialIntro');
  const crownSrc = crownImage();
  $('spCrown').src = crownSrc;
  // Taç üstünde süzülen ışık yalnız tacın şeklinde görünür
  const sh = document.querySelector('#specialIntro .sx-crown-shine');
  if (sh) { sh.style.webkitMaskImage = sh.style.maskImage = `url(${crownSrc})`; }
  $('spGoalIco').src = iconURL.crown;
  $('spGoalIco').style.display = L.sand ? 'none' : '';
  $('spGoalText').textContent = L.sand ? 'DAYAN' : `×${crowns}`;
  $('spGoalSub').textContent = L.sand ? 'Süre bitene kadar' : 'Taçları topla';
  $('spRuleImg').src = L.swap ? swapRuleImage() : groupRuleImage();
  document.querySelector('#specialIntro .sx-stars').style.display = L.bridge ? '' : 'none';
  if (L.star2) $('spStar2').textContent = L.star2.toLocaleString('tr-TR');
  $('spRuleText').innerHTML = L.swap ? 'Bloğu <b>sağa-sola, yukarı-aşağı çek</b>, aynı renkten <b>3 tanesini</b> yan yana getir!' : L.bridge ? `Aynı renkten <b>${L.group || 8} blok</b> birleşince patlar!` : 'Satırları <b>doldur</b>, patlat!';
  if (!$('spPowers').childElementCount) {
    for (const k of ['rocket', 'bomb', 'bolt', 'prop']) { const im = document.createElement('img'); im.src = renderPower(k, 108).toDataURL(); im.alt = ''; $('spPowers').appendChild(im); }
  }
  $('spTime').textContent = clockText(L.timeLimit || 0);
  $('spLevel').textContent = `BÖLÜM ${n + 1}`;
  el.classList.remove('show', 'leaving');
  void el.offsetWidth;
  // Anında tam opak açılır: oyun ekranı arkada önce görünmez (içerik kendi animasyonuyla gelir)
  el.style.transition = 'none';
  el.classList.add('show');
  void el.offsetWidth;
  el.style.transition = '';
  Sound.duck(true);
  Sound.chest();
  Haptics.medium();
  setTimeout(() => Haptics.light(), 450);
  $('spStart').onclick = () => {
    Haptics.light();
    el.classList.add('leaving');
    Sound.duck(false);
    setTimeout(() => { el.classList.remove('show', 'leaving'); after(); }, 300);
  };
}

// Normal bölüm giriş ekranı: tahtanın önizlemesi, görev, hamle hakkı ve yıldız hedefleri
const pvTiles = new Map();
function levelPreview(L0, th) {
  const S = 40, P = 10, cv = document.createElement('canvas');
  cv.width = cv.height = S * 8 + P * 2;
  const x = cv.getContext('2d');
  const fr = x.createLinearGradient(0, 0, 0, cv.height);
  fr.addColorStop(0, th.frame); fr.addColorStop(1, th.board);
  x.fillStyle = fr; x.beginPath(); x.roundRect(0, 0, cv.width, cv.height, 22); x.fill();
  x.fillStyle = th.board; x.beginPath(); x.roundRect(6, 6, cv.width - 12, cv.height - 12, 17); x.fill();
  x.strokeStyle = th.line; x.lineWidth = 1.5;
  for (let i = 1; i < 8; i++) { x.beginPath(); x.moveTo(P + i * S, P); x.lineTo(P + i * S, P + 8 * S); x.moveTo(P, P + i * S); x.lineTo(P + 8 * S, P + i * S); x.stroke(); }
  const score = L0.type === 'score';
  const iconOf = { g: 'gem', s: 'star', h: 'heart', k: 'crown', G: 'gem', S: 'star', H: 'heart' };
  const get = (k, f) => pvTiles.get(k) || (pvTiles.set(k, f()), pvTiles.get(k));   // karolar bölümler arasında da saklanır
  const blk = get('blk' + th.block, () => renderTile(th.block, S)), wood = get('wood', () => renderWood(S)), royal = get('royal', () => renderRoyal(S));
  L0.layout.forEach((row, r) => [...row].forEach((ch, c) => {
    if (ch === '.') return;
    const px = P + c * S, py = P + r * S, ic = score ? null : iconOf[ch];
    if (L0.power && 'RVBY'.includes(ch)) { x.drawImage(get('p' + ch, () => renderPower(ch === 'B' ? 'bomb' : ch === 'Y' ? 'bolt' : 'rocket', S)), px, py, S, S); return; }
    if (ch === 'm') { x.drawImage(get('m', () => renderMoss(S)), px, py); return; }
    if (NEED_COLOR[ch]) { x.drawImage(get('n' + ch, () => renderNeed(PALETTE[+NEED_COLOR[ch].slice(1)], S)), px, py); return; }
    if (ch === 'b') { x.drawImage(get('b' + (L0.bombTimer || 9), () => renderTimerBomb(S, L0.bombTimer || 9, false, FONT)), px, py, S, S); return; }
    x.drawImage(ic ? (ic === 'crown' ? royal : wood) : blk, px, py);
    if (ic) x.drawImage(get('i' + ic, () => renderIcon(ic, S)), px, py);
    if (ch === 'i') x.drawImage(get('ice', () => renderIce(S)), px, py);
    if (ch === 'c') x.drawImage(get('ch', () => renderChain(S, 2)), px, py);
    if ('GSH'.includes(ch)) x.drawImage(get('cage', () => renderCage(S)), px, py);
  }));
  return cv;
}
// Blok Kaçışı önizlemesi: oyundaki tahtanın aynısı (çerçeve, kapılar, oklar, engeller, bloklar) görünmeden çizilip
// resme dönüştürülür; böylece giriş kartı oyunun görünümüyle hep aynı kalır. Bir sorun olursa düz çizime düşer.
function escPreview(lv, th, n = levelN) {
  const T = 480, n0 = escLayer.children.length;
  let v = null;
  try {
    v = createEscape2D(lv, escInit({ ...lv, mask: lv.mask.slice() }), { x: 0, y: 0, w: T, h: T }, true);
    escLayer.removeChild(v.root);   // ekrana hiç çizilmez
    const src = app.renderer.extract.canvas({ target: v.root, resolution: 2 });
    v.dispose(); v = null;
    const cv = document.createElement('canvas'), x = cv.getContext('2d');
    cv.width = cv.height = T;
    const k = Math.min((T - 24) / src.width, (T - 24) / src.height);
    x.drawImage(src, (T - src.width * k) / 2, (T - src.height * k) / 2, src.width * k, src.height * k);
    return cv;
  } catch (e) {
    // Yarım kalan tahta temizlenir (ekranda kalmasın, dokuları birikmesin)
    try { if (v) v.dispose(); else for (const c of escLayer.children.slice(n0)) c.destroy({ children: true }); } catch { /* yok say */ }
    return escPreviewFlat(lv, th, n);
  }
}
function escPreviewFlat(lv, th, n = levelN) {
  const T = 340, S = Math.floor((T - 44) / Math.max(lv.w, lv.h)), cv = document.createElement('canvas');
  cv.width = cv.height = T;
  const x = cv.getContext('2d'), ox = Math.round((T - lv.w * S) / 2), oy = Math.round((T - lv.h * S) / 2);
  const inM = (r, c) => r >= 0 && c >= 0 && r < lv.h && c < lv.w && (lv.mask[r][c] === '#' || lv.mask[r][c] === 'S');
  // Çerçeve: kap hücreleri biraz taşırılarak çerçeve renginde, üstüne tahta rengi
  x.fillStyle = th.frame;
  for (let r = 0; r < lv.h; r++) for (let c = 0; c < lv.w; c++) if (inM(r, c)) { x.beginPath(); x.roundRect(ox + c * S - 4, oy + r * S - 4, S + 8, S + 8, 6); x.fill(); }
  x.fillStyle = th.board;
  for (let r = 0; r < lv.h; r++) for (let c = 0; c < lv.w; c++) if (inM(r, c)) x.fillRect(ox + c * S, oy + r * S, S, S);
  x.strokeStyle = th.line; x.lineWidth = 1.5; x.beginPath();
  for (let r = 0; r < lv.h; r++) for (let c = 0; c < lv.w; c++) {
    if (!inM(r, c)) continue;
    if (inM(r, c + 1)) { x.moveTo(ox + (c + 1) * S, oy + r * S); x.lineTo(ox + (c + 1) * S, oy + (r + 1) * S); }
    if (inM(r + 1, c)) { x.moveTo(ox + c * S, oy + (r + 1) * S); x.lineTo(ox + (c + 1) * S, oy + (r + 1) * S); }
  }
  x.stroke();
  for (let r = 0; r < lv.h; r++) for (let c = 0; c < lv.w; c++) if (lv.mask[r][c] === 'S') x.drawImage(obstacleCanvas(escObstKind(n, r, c), S * 2), ox + c * S + 1, oy + r * S + 1, S - 2, S - 2);
  // Kapılar
  const t = Math.max(7, S * 0.26);
  for (const g of lv.gates) {
    const L0 = g.len * S - 4, col = g.lock ? '#bfe9fb' : PALETTE[+g.col.slice(1)];
    const [gx, gy, gw, gh] = g.side === 'top' ? [ox + g.at * S + 2, oy - t - 1, L0, t] : g.side === 'bottom' ? [ox + g.at * S + 2, oy + lv.h * S + 1, L0, t]
      : g.side === 'left' ? [ox - t - 1, oy + g.at * S + 2, t, L0] : [ox + lv.w * S + 1, oy + g.at * S + 2, t, L0];
    x.fillStyle = col; x.beginPath(); x.roundRect(gx, gy, gw, gh, t / 2); x.fill();
    if (g.lock) { x.strokeStyle = PALETTE[+g.col.slice(1)]; x.lineWidth = 2; x.stroke(); }
  }
  // Bloklar
  for (const b of lv.blocks) {
    const key = 'pv' + b.col + b.s + ':' + S;
    let tile = pvTiles.get(key);
    if (!tile) { tile = renderTile(PALETTE[+b.col.slice(1)], S * b.s); pvTiles.set(key, tile); }
    x.drawImage(tile, ox + b.c * S, oy + b.r * S);
  }
  return cv;
}
const previewCache = new Map();
const TIME_ICO = '<svg viewBox="0 0 24 24"><circle cx="12" cy="13.5" r="8" fill="none" stroke="currentColor" stroke-width="2.6"/><path d="M12 9.5v4.5l2.8 1.8M9.5 2.5h5M12 2.5v3" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/></svg>';
const SKULL = '<path d="M12 3a8 8 0 0 0-8 8c0 2.6 1.2 4.3 3 5.3V19a1 1 0 0 0 1 1h1.5v-2h1v2h3v-2h1v2H16a1 1 0 0 0 1-1v-2.7c1.8-1 3-2.7 3-5.3a8 8 0 0 0-8-8z" fill="currentColor"/><circle cx="8.8" cy="11.5" r="2" fill="#5a0718"/><circle cx="15.2" cy="11.5" r="2" fill="#5a0718"/>';
const GOAL_WORD = { gem: 'elmas', star: 'yıldız', heart: 'kalp', crown: 'taç' };
function openLevelIntro(n, after) {
  const el = $('levelIntro'), w = worldOf(n);
  el.style.setProperty('--li-a', w.frame);
  el.style.setProperty('--li-b', w.bg[0]);
  el.style.setProperty('--li-c', w.bg[1]);
  $('liWorld').textContent = w.name.toLocaleUpperCase('tr-TR');
  const scoreLvl = L.type === 'score', escLvl = !!L.escape;
  $('liType').textContent = escLvl ? 'BLOK KAÇIŞI' : scoreLvl ? 'PUAN' : 'TOPLA';
  $('liType').className = 'sx-tag kind ' + (escLvl ? 'escape' : scoreLvl ? 'score' : 'collect');
  // Tahta önizlemesi PNG'ye kodlanmaz, tuval doğrudan konur; aynı bölüm tekrar açılınca hazırdan gelir
  // Ekran önce açılır, önizleme bir sonraki karede çizilir (açılış karesi takılmasın)
  const L0 = L;
  el.classList.toggle('super', !!L.superHard);   // süper zor: kırmızı zemin, uyarı ve ödül satırı
  $('liBoard').replaceChildren();
  requestAnimationFrame(() => {
    let pv = previewCache.get(n);
    if (!pv) { pv = L0.escape ? escPreview(L0.esc, w, n) : levelPreview(L0, w); if (previewCache.size > 6) previewCache.delete(previewCache.keys().next().value); previewCache.set(n, pv); }
    $('liBoard').replaceChildren(pv);
  });
  $('liTitle').textContent = `BÖLÜM ${n + 1}`;
  const gl = $('liGoals');
  if (escLvl) {
    // Blok Kaçışı: görev = bütün blokları çıkar; sağ sütunda hamle yerine süre
    gl.innerHTML = `<span class="li-g"><span class="li-pt esc">${ESC_ICO}</span><b>${L.esc.blocks.length}</b></span>`;
    $('liGoalSub').textContent = 'Blokları çıkar';
  } else if (scoreLvl) {
    gl.innerHTML = `<span class="li-g"><span class="li-pt">${PT_ICO}</span><b>${L.target.toLocaleString('tr-TR')}</b></span>`;
    $('liGoalSub').textContent = 'Puana ulaş';
  } else {
    gl.replaceChildren(...L.goals.map((g) => { const d = document.createElement('span'); d.className = 'li-g'; d.innerHTML = `<img src="${iconURL[g.icon]}" alt=""><b>${g.count}</b>`; return d; }));
    $('liGoalSub').textContent = L.goals.length === 1 ? `${GOAL_WORD[L.goals[0].icon] || 'simge'} topla`.replace(/^./, (c) => c.toLocaleUpperCase('tr-TR')) : 'Hepsini topla';
  }
  const mv = !!L.moves || escLvl;
  el.classList.toggle('no-moves', !mv);
  if (mv) $('liMoves').textContent = escLvl ? clockText(L.timeLimit) : L.moves;
  el.querySelector('.li-mv-ico').innerHTML = escLvl ? TIME_ICO : MV_ICO;
  el.querySelector('.li-mcol small').textContent = escLvl ? 'SÜRE' : 'HAMLE';
  el.querySelector('.li-mcol em').textContent = escLvl ? 'Süre bitmeden' : 'Hamle hakkın';
  $('liPowers').style.display = L.power && !escLvl ? '' : 'none';
  if (L.power && !$('liPowImgs').childElementCount) {
    for (const k of ['rocket', 'bomb', 'bolt']) { const im = document.createElement('img'); im.src = renderPower(k, 108).toDataURL(); im.alt = ''; $('liPowImgs').appendChild(im); }
  }
  el.classList.remove('show', 'leaving');
  void el.offsetWidth;
  el.style.transition = 'none';
  el.classList.add('show');
  void el.offsetWidth;
  el.style.transition = '';
  Sound.duck(true);
  Haptics.light();
  const close = (go) => {
    el.classList.add('leaving');
    Sound.duck(false);
    setTimeout(() => { el.classList.remove('show', 'leaving'); go(); }, 300);
  };
  $('liStart').onclick = () => { Haptics.light(); Sound.click?.(); close(after); };
  $('liClose').onclick = () => { lifeAtRisk = false; close(() => goHome()); };
}

// ---------- Ekranlar ----------
// Ana ekran dekoru: katmanlı koyu zemin, marka renklerinde yumuşak ışıklar, tahtayı
// andıran silik ızgara; üstünde yavaşça süzülen soluk parçalar ve ışıltılar.
const deco = new Container();
app.stage.addChildAt(deco, 1);
const island = createIsland(app);
app.stage.addChildAt(island.layer, 2);
island.attach($('buildStage'));
island.ghost(true);   // sıradaki adım adanın üstünde yarı saydam görünür
$('buildStage').addEventListener('pointerdown', () => {
  if (Store.get('rot_seen', '')) return;
  Store.set('rot_seen', '1');
  $('rotHint').classList.add('gone');
}, { once: true });
if (Store.get('rot_seen', '')) $('rotHint').classList.add('gone');
let decoItems = [], sparkles = [], decoBg = null;

// Ana sayfa arka planı: oyuncunun bulunduğu dünyanın gökyüzü ve uzak manzarası (haritadaki dünya çizimleri),
// ışık lekeleri, kenar kararması. Üstünde dünyaya özel canlı parçacıklar ve adanın altında süzülen bulutlar.
function homeBackground() {
  const k = 0.5;
  const c = document.createElement('canvas');
  const cw = (c.width = Math.ceil(W * DPR * k)), ch = (c.height = Math.ceil(H * DPR * k));
  const x = c.getContext('2d');
  const g = x.createLinearGradient(0, 0, 0, ch);
  g.addColorStop(0, '#3243b0');      // açık kraliyet mavisi (açılış ekranına yakın)
  g.addColorStop(0.45, '#23308f');
  g.addColorStop(1, '#141d52');
  x.fillStyle = g;
  x.fillRect(0, 0, cw, ch);
  // Renkli ışık lekeleri
  const blob = (fx, fy, fr, color, a) => {
    const r = Math.max(cw, ch) * fr;
    const rg = x.createRadialGradient(cw * fx, ch * fy, 0, cw * fx, ch * fy, r);
    rg.addColorStop(0, `rgba(${color},${a})`);
    rg.addColorStop(1, `rgba(${color},0)`);
    x.fillStyle = rg;
    x.fillRect(0, 0, cw, ch);
  };
  blob(0.05, 0.08, 0.55, '47,123,255', 0.38);
  blob(0.98, 0.2, 0.5, '150,70,255', 0.3);
  blob(0.0, 0.7, 0.45, '0,190,210', 0.12);
  blob(1.0, 0.92, 0.5, '255,60,130', 0.13);
  blob(0.5, 0.25, 0.42, '255,255,255', 0.1);       // logonun arkasında ışık
  // Silik tahta ızgarası: ortada belirgin, kenarlara doğru kaybolur
  const gc = document.createElement('canvas');
  gc.width = cw; gc.height = ch;
  const gx = gc.getContext('2d');
  const step = cw / 7.5, gap = step * 0.1;
  gx.strokeStyle = 'rgba(255,255,255,0.045)';
  gx.lineWidth = Math.max(1, DPR * k);
  const ox = (cw % step) / 2 - step / 2;
  for (let yy = -step / 2; yy < ch; yy += step) {
    for (let xx = ox; xx < cw; xx += step) {
      gx.beginPath();
      gx.roundRect(xx + gap / 2, yy + gap / 2, step - gap, step - gap, step * 0.16);
      gx.stroke();
    }
  }
  gx.globalCompositeOperation = 'destination-in';
  const m = gx.createRadialGradient(cw / 2, ch * 0.58, 0, cw / 2, ch * 0.58, Math.max(cw, ch) * 0.42);
  m.addColorStop(0, 'rgba(0,0,0,1)');
  m.addColorStop(1, 'rgba(0,0,0,0)');
  gx.fillStyle = m;
  gx.fillRect(0, 0, cw, ch);
  x.drawImage(gc, 0, 0);
  // Kenar kararması
  const vg = x.createRadialGradient(cw / 2, ch * 0.45, Math.min(cw, ch) * 0.4, cw / 2, ch * 0.45, Math.max(cw, ch) * 0.78);
  vg.addColorStop(0, 'rgba(0,0,10,0)');
  vg.addColorStop(1, 'rgba(0,0,10,0.5)');
  x.fillStyle = vg;
  x.fillRect(0, 0, cw, ch);
  // İnce gren: renk geçişinde bantlaşmayı önler
  const img = x.getImageData(0, 0, cw, ch), d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const n = (Math.random() - 0.5) * 7;
    d[i] += n; d[i + 1] += n; d[i + 2] += n;
  }
  x.putImageData(img, 0, 0);
  const sp = new Sprite(Texture.from(c));
  sp.width = W; sp.height = H;
  return sp;
}

const DECO_SHAPES = [
  [[0, 0], [1, 0], [0, 1], [1, 1]],
  [[0, 0], [0, 1], [0, 2], [1, 2]],
  [[0, 0], [1, 0], [2, 0], [1, 1]],
  [[1, 0], [2, 0], [0, 1], [1, 1]],
  [[0, 0], [1, 0], [2, 0]],
  [[0, 0], [0, 1]],
  [[0, 0]],
];
function buildDeco() {
  // Eskiler yok edilir: her yeniden yerleşimde (klavye, güvenli alan) arka plan dokusu ve bulanıklık süzgeçleri birikiyordu
  for (const c of deco.removeChildren()) {
    if (c.filters) for (const f of c.filters) f.destroy();
    c.destroy(c === decoBg ? { children: true, texture: true, textureSource: true } : { children: true });
  }
  decoItems = [];
  sparkles = [];
  decoBg = deco.addChild(homeBackground());
  // Kenarlarda canlı renkli parçalar; uzaktakiler küçük ve bulanık (alan derinliği)
  for (let i = 0; i < 7; i++) {
    const depth = i / 6;                              // 0 uzak, 1 yakın
    const t = cell * (0.38 + depth * 0.42);
    const shape = DECO_SHAPES[i % DECO_SHAPES.length];
    const color = 'c' + ((i * 3) % PALETTE.length);
    const piece = new Container();
    const w = Math.max(...shape.map((q) => q[0])) + 1, h = Math.max(...shape.map((q) => q[1])) + 1;
    for (const [qx, qy] of shape) {
      const s = new Sprite(tex[color]);
      s.width = s.height = t;
      s.position.set((qx - w / 2) * t, (qy - h / 2) * t);
      piece.addChild(s);
    }
    piece.alpha = 0.32 + depth * 0.3;
    piece.filters = [new BlurFilter({ strength: 6 - depth * 4.5, quality: 2 })];
    const side = i % 2 ? 1 : 0;
    piece.position.set(side ? W * (0.86 + Math.random() * 0.12) : W * (0.02 + Math.random() * 0.12), (i / 7) * H + Math.random() * H * 0.08);
    piece.rotation = (Math.random() - 0.5) * 0.9;
    deco.addChild(piece);
    decoItems.push({ s: piece, v: 4 + depth * 9, vr: (Math.random() - 0.5) * 0.12, drift: Math.random() * 6, side });
  }
  for (let i = 0; i < 26; i++) {
    const g = new Graphics();
    const r = 0.7 + Math.random() * 1.5;
    g.circle(0, 0, r * 2.5).fill({ color: 0xffffff, alpha: 0.12 });
    g.circle(0, 0, r).fill({ color: 0xffffff, alpha: 0.9 });
    g.position.set(Math.random() * W, Math.random() * H);
    deco.addChild(g);
    sparkles.push({ s: g, a: 0.25 + Math.random() * 0.5, sp: 0.6 + Math.random() * 1.6, ph: Math.random() * 6.3, v: 3 + Math.random() * 6 });
  }
}

function showScreen(name) {
  deco.visible = name === 'home';
  if (name === 'home' && !island.layer.visible) {
    island.layer.alpha = 0; island.layer.y = 40;
    tween(island.layer, { alpha: 1, y: 0 }, 0.6, Ease.outCubic, 0.12);
  }
  island.layer.visible = name === 'home';
  $('home').classList.toggle('show', name === 'home');
  $('map').classList.toggle('show', name === 'map');
  $('hud').classList.toggle('show', name === 'game');
  $('hud').classList.toggle('level', mode === 'level');
  $('hud').classList.toggle('scoretype', mode === 'level' && L && L.type === 'score');
  for (const l of [boardLayer, digLayer, hintLayer, blockLayer, ovLayer, iconLayer, fireShaderLayer, fireLayer, ghostLayer, trayLayer, dragLayer]) l.visible = name === 'game';
  fallLayer.visible = name === 'game';
  escLayer.visible = name === 'game';
  if (fall || esc) boardLayer.visible = false;
  // Blok Kaçışı: 3D sahnenin üstünde kullanılmayan katman kalmasın (ateş gölgelendiricisi vb. renkleri soldurmasın)
  if (esc) for (const l of [fireShaderLayer, fireLayer, hintLayer, ghostLayer, digLayer, ovLayer, iconLayer, blockLayer]) l.visible = false;
}
// Android geri tuşu: true dönerse oyun işledi, false ise uygulama arka plana alınır
window.__androidBack = () => {
  const pop = [...document.querySelectorAll('.popup.show')].pop();
  if (pop) {
    const x = pop.querySelector('.pop-close');
    if (x && getComputedStyle(x).display !== 'none') x.click();
    else if (pop.id === 'quitPop') $('qtStay').click();
    return true;                                   // kapatılamayan pencerede geri tuşu yok sayılır
  }
  // Tam ekran kartlar: bölüm girişi ve adalar kapanır; özel bölüm girişinde kapatma yok, geri tuşu yok sayılır
  // (yoksa duraklat penceresi kartın altında görünmeden açılıyor, adalar ekranında da uygulama arka plana gidiyordu)
  if ($('levelIntro').classList.contains('show')) { if (!$('levelIntro').classList.contains('leaving')) $('liClose').click(); return true; }
  if ($('islandsScr').classList.contains('show')) { if (!$('islandsScr').classList.contains('leaving')) $('islClose').click(); return true; }
  if ($('specialIntro').classList.contains('show')) return true;
  if ($('map').classList.contains('show')) { $('mapBack').click(); return true; }
  if ($('hud').classList.contains('show')) {
    if (over) { goHome(); return true; }
    $('menuBtn').click();
    return true;
  }
  return false;
};
// Pencere zemini (#popBg) için gövde sınıfları: pb-on (bölüm tamam / bitti / çıkış / sandık açık), pb-win, pb-lose.
// Eskiden CSS'te body:has(...) ile seçiliyordu; :has her DOM değişiminde (sayaç, konfeti) tüm sayfanın stilini yeniden
// hesaplattığı için Android'de bölüm tamam ekranı takılıyordu.
function syncPopBg() {
  const on = (id) => $(id).classList.contains('show');
  const w = on('win') || on('chest'), l = on('over') || on('quitPop'), b = document.body.classList;
  b.toggle('pb-on', w || l); b.toggle('pb-win', w); b.toggle('pb-lose', l);
  // Tahta bu pencerelerin arkasında görünmez: oyun döngüsü 30 kareye iner (yalnız bekleme/ara geçiş zamanlaması için çalışır)
  app.ticker.maxFPS = w || l ? 30 : 0;
}
{
  const mo = new MutationObserver(syncPopBg);
  for (const id of ['win', 'over', 'quitPop', 'chest']) mo.observe($(id), { attributes: true, attributeFilter: ['class'] });
}
// Açık pencere var mı: her karede seçiciyle aranmaz, pencerelerin sınıfı değişince güncellenir
let popupOpen = false;
{
  const pops = [...document.querySelectorAll('.popup')];
  const upd = () => { popupOpen = pops.some((p) => p.classList.contains('show')); };
  const mo = new MutationObserver(upd);
  for (const p of pops) mo.observe(p, { attributes: true, attributeFilter: ['class'] });
  upd();
}
function openPopup(id) { $('veil').classList.add('show'); $(id).classList.add('show'); Sound.duck(true); }
function closePopups() {
  if (bdDone) { const r = bdDone; bdDone = null; r(); }
  $('veil').classList.remove('show');
  for (const p of document.querySelectorAll('.popup')) p.classList.remove('show');
  Sound.duck(false);
}

// Game Center'a en iyi skorlar gönderilir (bağlı değilse sessizce atlanır)
// Sıralama penceresi: Game Center açılamazsa nedenini ve oyuncunun kendi skorlarını gösterir
function openRankInfo(reason) {
  let stars = 0;
  for (let i = 0; i <= unlocked; i++) stars += starsOf(i);
  $('riMsg').innerHTML = reason === 'nosign'
    ? (RANK_PLATFORM === 'android'
      ? '<b>Google Play Games’e giriş yap</b><small>Giriş yapınca dünya sıralaması açılır. Tekrar dene’ye basabilirsin.</small>'
      : '<b>Game Center’a giriş yap</b><small>Ayarlar › Game Center’dan giriş yapınca dünya sıralaması açılır.</small>')
    : reason === 'web'
      ? '<b>Dünya sıralaması uygulamada</b><small>Sıralama, uygulamanın iPhone ve Android sürümlerinde çalışır.</small>'
      : '<b>Sıralama şu an açılamadı</b><small>Bağlantını kontrol edip tekrar dene.</small>';
  $('riRetry').style.display = reason === 'web' ? 'none' : '';
  $('riBest').textContent = '0'; $('riStars').textContent = '0'; $('riLevel').textContent = '0';
  openPopup('rankInfo');
  setTimeout(() => { countUp($('riBest'), best); countUp($('riStars'), stars); countUp($('riLevel'), Math.min(TOTAL_LEVELS, unlocked + 1)); }, 300);
}
$('riClose').addEventListener('click', closePopups);
$('riRetry').addEventListener('click', () => { closePopups(); setTimeout(() => $('homeRank').click(), 250); });
function syncScores() {
  if (!GameCenter.signedIn) return;
  let stars = 0;
  for (let i = 0; i <= unlocked; i++) stars += starsOf(i);
  GameCenter.submit(LB.endless, best);
  GameCenter.submit(LB.stars, stars);
  GameCenter.submit(LB.level, unlocked);
}

function goHome() {
  if (tut) endTutorial();
  hideTutTip();
  runId++;
  closePopups();
  exitFire();
  over = true;
  spendLifeIfRisk();
  syncScores();
  if (theme !== BASE) applyTheme(BASE);
  const s = Store.get('save', '');
  $('endlessBtn').classList.toggle('resume', !!s);
  $('endlessLabel').textContent = s ? 'DEVAM' : 'SONSUZ';
  $('homeBest').textContent = best >= 100000 ? `${Math.floor(best / 1000)}B` : best.toLocaleString('tr-TR');
  const allDone = unlocked >= TOTAL_LEVELS;
  $('streakTagN').textContent = streakN;
  $('streakTag').classList.toggle('hidden', !(streakN > 0) || allDone);
  $('levelNum').textContent = Math.min(unlocked + 1, TOTAL_LEVELS);
  $('levelsLabel').textContent = allDone ? 'TAMAMLANDI' : isSpecial(unlocked) ? 'ÖZEL BÖLÜM' : isFalling(unlocked) ? 'DÜŞEN BLOK' : isEscape(unlocked) ? 'BLOK KAÇIŞI' : worldOf(unlocked).name.toLocaleUpperCase('tr-TR');
  $('levelsBtn').classList.toggle('special', !allDone && isSpecial(unlocked));
  $('levelsBtn').classList.toggle('falling', !allDone && isFalling(unlocked));
  let st = 0;
  for (let i = 0; i < unlocked + 1; i++) st += starsOf(i);
  $('homeStars').textContent = st;
  updateCoins();
  $('homeGift').classList.toggle('ready', dailyState().canClaim);
  updateMissionDot();
  const now = new Date();
  $('dailyDay').textContent = now.getDate();
  $('dailyMonth').textContent = now.toLocaleDateString('tr-TR', { month: 'long' }).toLocaleUpperCase('tr-TR');
  const solved = DailyPuzzle.state().solvedToday;
  const cal = document.querySelector('#homeDaily .sb-ico');
  cal.classList.toggle('ready', !solved);
  cal.classList.toggle('solved', solved);
  const prog = unlocked % CHEST_EVERY;
  // Sandık kartı: her geçilen bölüm bir dilimi doldurur, sıradaki dilim nabız gibi atar
  $('chestLabel').textContent = `${prog}/${CHEST_EVERY}`;
  $('homeChest').style.setProperty('--fill', `${(prog / CHEST_EVERY) * 360}deg`);
  const leftN = CHEST_EVERY - prog;
  $('homeChest').dataset.left = leftN;
  $('homeChest').classList.toggle('almost', leftN === 1);
  showScreen('home');
  renderPath();
  renderBuild(true);
}
// Dar ekranda büyük sayılar kısalır (12.880 → 12,8B) ki üst çubuk taşmasın
const narrow = (w = 360) => window.innerWidth <= w;
function updateCoins() {
  const n = Wallet.coins;
  $('homeCoins').textContent = narrow(420) && n >= 10000 ? `${(Math.floor(n / 100) / 10).toLocaleString('tr-TR')}B` : n.toLocaleString('tr-TR');
}

// Bölüm yolu: geçilen bölümler yıldızlı, sıradaki büyük ve parlak, sonrakiler kilitli
function renderPath() {
  const box = $('levelPath');
  const w = box.clientWidth, h = box.clientHeight;
  box.replaceChildren();
  if (!w || !h) return;
  const cur = unlocked;
  const start = Math.max(0, cur - 2);
  const items = [4, 3, 2, 1, 0].map((k) => start + k);   // yukarıdan aşağı
  const xs = [0.32, 0.68, 0.36, 0.66, 0.4];
  const step = h / items.length;
  const pts = items.map((_, k) => [w * xs[k], step * (k + 0.5)]);
  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('class', 'trail');
  const path = document.createElementNS(NS, 'path');
  let d = `M${pts[0][0]},${pts[0][1]}`;
  for (let k = 1; k < pts.length; k++) {
    const [x0, y0] = pts[k - 1], [x1, y1] = pts[k], my = (y0 + y1) / 2;
    d += ` C${x0},${my} ${x1},${my} ${x1},${y1}`;
  }
  path.setAttribute('d', d);
  svg.append(path);
  box.append(svg);
  items.forEach((i, k) => {
    const state = i < cur ? 'done' : i === cur ? 'current' : 'locked';
    const size = state === 'current' ? Math.min(100, step * 1.1) : Math.min(64, step * 0.74);
    const n = document.createElement('button');
    n.className = 'path-node ' + state + (isSpecial(i) ? ' special' : '');
    n.style.left = `${pts[k][0]}px`;
    n.style.top = `${pts[k][1]}px`;
    n.style.width = n.style.height = `${size}px`;
    const color = state === 'done' ? worldOf(i).block : state === 'current' ? '#ffbe1f' : '#5d6488';
    n.style.backgroundImage = `url(${isSpecial(i) && state !== 'current' ? royalImg() : tileImg(color)})`;
    if (state === 'locked') {
      n.innerHTML = '<svg><use href="#i-lock"/></svg>';
      n.addEventListener('click', () => { Haptics.warning(); n.animate([{ marginLeft: '0' }, { marginLeft: '-6px' }, { marginLeft: '6px' }, { marginLeft: '0' }], { duration: 260 }); });
    } else {
      n.innerHTML = `<span class="num">${i + 1}</span>`;
      if (state === 'done') {
        const st = starsOf(i);
        n.insertAdjacentHTML('beforeend', `<span class="mini-stars">${[0, 1, 2].map((q) => `<i class="${q < st ? 'on' : ''}"></i>`).join('')}</span>`);
      } else {
        n.insertAdjacentHTML('beforeend', '<span class="you">SIRADAKİ</span>');
      }
      n.addEventListener('click', () => startLevel(i));
    }
    if (isSpecial(i)) n.insertAdjacentHTML('beforeend', `<img class="crown-badge" src="${iconURL.crown}" alt="">`);
    if (isFalling(i)) n.insertAdjacentHTML('beforeend', '<svg class="fall-badge"><use href="#m-fall"/></svg>');
    if (isEscape(i)) n.insertAdjacentHTML('beforeend', '<svg class="esc-badge"><use href="#m-esc"/></svg>');   // Blok Kaçışı
    box.append(n);
  });
}

// ---------- Blok Adası ----------
// Bölümlerden gelen yapı taşlarıyla ana sayfadaki yapı adım adım inşa edilir.
let building = false;
function layoutIsland() {
  const el = $('buildStage');
  if (!el) return;
  const r = el.getBoundingClientRect();
  if (r.width < 10 || r.height < 10) return;
  island.layout({ x: r.left, y: r.top, w: r.width, h: r.height });
}
function renderBuild(show = false, view = null) {
  // İlk kez: şimdiye kadar kazanılan yıldızlar kadar başlangıç taşı
  if (!Store.get('bricks_init', '')) {
    let st = 0;
    for (let i = 0; i <= unlocked; i++) st += starsOf(i);
    Build.addBricks(Math.max(3, st));
    Store.set('bricks_init', '1');
  }
  const st = view || Build.state();
  const bd = BUILDINGS[st.b % BUILDINGS.length];
  const cost = Build.cost(Build.state().b);
  $('bxName').textContent = bd.name + (st.b >= BUILDINGS.length ? ` ${Math.floor(st.b / BUILDINGS.length) + 1}` : '');
  $('bxIdx').textContent = `${(st.b % BUILDINGS.length) + 1}/${BUILDINGS.length}`;
  $('bxProg').replaceChildren(...Array.from({ length: BUILD_STEPS }, (_, i) => { const e = document.createElement('i'); if (i < st.step) e.className = 'on'; return e; }));
  const have = Build.bricks;
  $('bbHave').textContent = have;
  $('bbCost').textContent = cost;
  $('buildBtn').classList.toggle('ready', have >= cost);
  // Halkadaki bölmeler: maliyet kadar bölme, elindeki her taş bir bölmeyi yakar
  const gap = 16, seg = 360 / cost, R = 43;
  const pt = (a) => [50 + R * Math.cos(((a - 90) * Math.PI) / 180), 50 + R * Math.sin(((a - 90) * Math.PI) / 180)];
  $('bfSegs').innerHTML = Array.from({ length: cost }, (_, i) => {
    const a0 = i * seg + gap / 2, a1 = (i + 1) * seg - gap / 2;
    const [x0, y0] = pt(a0), [x1, y1] = pt(a1);
    return `<path class="${i < have ? 'on' : ''}" d="M${x0.toFixed(2)} ${y0.toFixed(2)} A${R} ${R} 0 ${a1 - a0 > 180 ? 1 : 0} 1 ${x1.toFixed(2)} ${y1.toFixed(2)}"/>`;
  }).join('');
  renderBuildCard(st, have, cost);
  if (show) requestAnimationFrame(() => {
    layoutIsland();
    island.show(st.b, st.step);
    if (show === 'fade') { island.layer.alpha = 0; tween(island.layer, { alpha: 1 }, 0.6, Ease.outCubic); }
  });
}
// İnşa kartı (ana sayfa): yapı adı, 8 adımlık ilerleme, eldeki / gereken yapı taşı
function renderBuildCard(st, have, cost) {
  const bd = BUILDINGS[st.b % BUILDINGS.length];
  $('bcName').textContent = bd.name;
  $('bcIdx').textContent = `${(st.b % BUILDINGS.length) + 1}/${BUILDINGS.length}`;
  $('bcSteps').replaceChildren(...Array.from({ length: BUILD_STEPS }, (_, i) => { const e = document.createElement('i'); e.className = i < st.step ? 'on' : i === st.step ? 'next' : ''; return e; }));
  $('bcStepN').textContent = `${st.step}/${BUILD_STEPS}`;
  $('bcHave').textContent = Math.min(have, 99);
  $('bcCost').textContent = cost;
  $('bcFill').style.width = `${Math.min(1, have / cost) * 100}%`;
  $('buildCard').classList.toggle('ready', have >= cost);
}
$('bcBtn').addEventListener('click', () => $('buildBtn').click());
// ---------- Adalarım: yapı koleksiyonu ----------
// Biten yapılar renkli, şu an yapılan hologram + adım ilerlemesi, sonrakiler kilitli siluet.
// İkinci turdan itibaren her yapı kaç kez tamamlandıysa ×n rozeti taşır.
const islImg = new Map();
// Ada resmi bir kez üretilir; PNG'ye çevirme toBlob ile ana iş parçacığının dışında yapılır (toDataURL Android'de takılıyordu)
function islandImage(i, done) {
  if (islImg.has(i)) { done(islImg.get(i)); return; }
  let c;
  try { c = island.snapshotOf(i, 260); } catch { islImg.set(i, ''); done(''); return; }
  c.toBlob((b) => { const u = b ? URL.createObjectURL(b) : ''; islImg.set(i, u); done(u); });
}
function openIslands() {
  const st = Build.state(), N = BUILDINGS.length, cyc = Math.floor(st.b / N), curI = st.b % N;
  const doneN = Math.min(N, st.b);
  $('islDone').textContent = cyc ? N : st.b;
  $('islAll').textContent = N;
  $('islFill').style.width = '0%';
  $('islGrid').innerHTML = BUILDINGS.map((bd, i) => {
    const times = cyc + (i < curI ? 1 : 0);
    const cur = i === curI, lock = !cur && times === 0;
    const w = WORLDS[i % WORLDS.length];
    const pips = cur ? `<span class="ic-pips">${Array.from({ length: BUILD_STEPS }, (_, k) => `<i class="${k < st.step ? 'on' : k === st.step ? 'next' : ''}"></i>`).join('')}</span>` : '';
    const stTxt = cur ? `<small class="ic-st">ŞU AN · ${st.step}/${BUILD_STEPS}</small>` : lock ? '<small class="ic-st">KİLİTLİ</small>' : '<small class="ic-st ok">✓ TAMAMLANDI</small>';
    return `<div class="isl-card ${cur ? 'cur' : lock ? 'lock' : 'done'}" style="--wa:${w.frame};--wb:${w.bg[1]};--d:${0.15 + i * 0.06}s">
      <span class="ic-num">${i + 1}</span>${times > 1 || (times === 1 && cyc) ? `<span class="ic-times">×${times}</span>` : ''}
      <div class="ic-img"><img ${islImg.has(i) ? `src="${islImg.get(i)}"` : `data-isl="${i}"`} alt="">${lock ? '<b class="ic-q">?</b>' : ''}</div>
      <b class="ic-name">${lock ? '???' : bd.name}</b>${pips}${stTxt}
    </div>`;
  }).join('');
  const nextName = BUILDINGS[curI].name;
  $('islFoot').innerHTML = `Bölüm geçtikçe kazandığın <b>yapı taşlarıyla</b> ${nextName} yapısını tamamla`;
  const el = $('islandsScr');
  el.classList.remove('show', 'leaving'); void el.offsetWidth;
  el.style.transition = 'none'; el.classList.add('show'); void el.offsetWidth; el.style.transition = '';
  setTimeout(() => { $('islFill').style.width = `${((cyc ? N : doneN) / N) * 100}%`; }, 350);
  // Ada resimleri ilk açılışta pencere açılırken topluca değil, her karede bir tane üretilir (Android'de takılıyordu)
  const pend = [...$('islGrid').querySelectorAll('img[data-isl]')];
  const fill = () => {
    const im = pend.shift();
    if (!im || !el.classList.contains('show')) return;
    islandImage(+im.dataset.isl, (u) => { if (u) im.src = u; });
    requestAnimationFrame(fill);
  };
  if (pend.length) setTimeout(() => requestAnimationFrame(fill), 120);
  Sound.click(); Haptics.light();
}
function closeIslands() {
  const el = $('islandsScr');
  el.classList.add('leaving');
  setTimeout(() => el.classList.remove('show', 'leaving'), 300);
}
$('islClose').addEventListener('click', closeIslands);
document.querySelector('#buildCard .bc-plate').addEventListener('click', openIslands);
$('buildBtn').addEventListener('click', async () => {
  if (building) return;
  const st = Build.state();
  const cost = Build.cost(st.b);
  if (Build.bricks < cost) {
    Haptics.light();
    openBuildInfo();
    return;
  }
  const res = Build.buildStep(BUILD_STEPS);
  if (!res) return;
  building = true;
  Haptics.medium();
  renderBuild(false, { b: res.b, step: res.step + 1 });
  await island.buildStep(res.b, res.step, (i) => { Sound.place(); Haptics.light(); if (i === 0) Sound.click(); });
  Sound.star(Math.min(2, res.step % 3));
  if (res.done) {
    await island.celebrate();
    await showBuildDone(res.b);
  }
  building = false;
  renderBuild(res.done ? 'fade' : false);
});
// İnşa bilgi penceresi: yapının adımları, eldeki/gereken taş, bitince ödül, bölüme kısayol
function openBuildInfo() {
  const st = Build.state(), cost = Build.cost(st.b), have = Build.bricks;
  const bd = BUILDINGS[st.b % BUILDINGS.length];
  try { $('biImg').src = island.snapshot(240); } catch { /* görüntü alınamazsa boş kalır */ }
  $('biTag').textContent = `YAPI ${(st.b % BUILDINGS.length) + 1} / ${BUILDINGS.length}`;
  $('biTitle').textContent = bd.name;
  $('biPips').replaceChildren(...Array.from({ length: BUILD_STEPS }, (_, i) => {
    const d = document.createElement('i');
    d.className = i < st.step ? 'on' : i === st.step ? 'next' : '';
    d.style.animationDelay = `${0.25 + i * 0.05}s`;
    if (i < st.step) d.innerHTML = '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    return d;
  }));
  $('biFill').style.width = '0%';
  setTimeout(() => { $('biFill').style.width = `${Math.min(100, (have / cost) * 100)}%`; }, 250);
  $('biCount').textContent = `${Math.min(have, cost)} / ${cost}`;
  const need = cost - have;
  $('biInfo').innerHTML = need > 0 ? `Sıradaki adım için <b>${need} yapı taşı</b> daha gerekli<span class="bi-sub">Bölüm geçtikçe her yıldız 1 taş kazandırır</span>` : '<b>Taşın hazır!</b> Bir sonraki adımı inşa et.';
  $('biCoins').textContent = `+${40 + 20 * Math.min(st.b, 6)}`;
  const canBuild = need <= 0, all = unlocked >= TOTAL_LEVELS;
  $('biGoTxt').textContent = canBuild ? 'İNŞA ET' : all ? 'BÖLÜMLER' : `OYNA · BÖLÜM ${unlocked + 1}`;
  $('biGo').onclick = () => { closePopups(); if (canBuild) $('buildBtn').click(); else if (all) openMap(); else startLevel(unlocked); };
  openPopup('buildInfo');
}
$('biClose').addEventListener('click', closePopups);
async function showBuildDone(b) {
  const bd = BUILDINGS[b % BUILDINGS.length];
  const coins = 40 + 20 * Math.min(b, 6);
  Wallet.addCoins(coins);
  const chest = openChest();
  $('bdImg').src = island.snapshot(300);
  $('bdTitle').textContent = bd.name;
  $('bdCoins').textContent = (coins + chest.coins).toLocaleString('tr-TR');
  $('bdChest').textContent = `${BOOSTERS[chest.booster].name} ×1`;
  $('bdNext').textContent = `Sıradaki: ${BUILDINGS[(b + 1) % BUILDINGS.length].name}`;
  Sound.win();
  Haptics.success();
  confetti(110);
  openPopup('buildDone');
  updateCoins();
  await new Promise((res) => { bdDone = res; $('bdOk').onclick = () => { closePopups(); Sound.coin(); }; });
}

// ---------- Büyük final ----------
// Son bölüm bitince: toplam yıldız, bir kerelik final ödülü, sonsuz mod ya da 3 yıldız avı
function openFinale() {
  runId++;
  closePopups();
  goHome();
  let stars = 0;
  for (let i = 0; i < TOTAL_LEVELS; i++) stars += starsOf(i);
  const prof = Profile.get();
  $('fnTitle').textContent = prof && prof.name ? `Efsane ${prof.name}!` : 'Efsane!';
  $('fnStars').textContent = '0';
  $('fnBar').style.width = '0%';
  const first = Store.get('finale_done', '') !== '1';
  $('fnGift').classList.toggle('hidden', !first);
  if (first) { Store.set('finale_done', '1'); Wallet.addCoins(500); updateCoins(); }
  openPopup('finale');
  confetti(160);
  Sound.win();
  Haptics.success();
  setTimeout(() => { countUp($('fnStars'), stars); $('fnBar').style.width = `${(stars / (TOTAL_LEVELS * 3)) * 100}%`; }, 450);
}
$('fnEndless').addEventListener('click', () => { closePopups(); newGame(); });
$('fnMap').addEventListener('click', openMap);

// ---------- Süreli özel bölüm ----------
// Her 10. bölüm zor ve süreli: taçlar süre bitmeden toplanmalı. Sayaç yalnız oyun gerçekten
// oynanırken işler (giriş kartı, pencereler, animasyonlar sırasında durur).
let timeLeft = 0;
const timed = () => mode === 'level' && !daily && !!L && !!L.timeLimit && (!L.falling || !!L.sand);
const clockText = (t) => { t = Math.max(0, Math.ceil(t)); return `${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}`; };
function renderClock() {
  const t = Math.max(0, Math.ceil(timeLeft));
  $('timeTxt').textContent = clockText(t);
  $('timeFill').style.width = `${Math.min(100, (timeLeft / L.timeLimit) * 100)}%`;
  $('timeChip').classList.toggle('warn', t <= 15);
  $('timeChip').classList.toggle('crit', t <= 5);
}
// Gerilim: son 20 sn'de kalp atışı sıklaşır, müzik hızlanır, ekran kenarları kızarır; son 10 sn tik-tak
let beatIn = 0, tensionOn = false, tenseOp = -1;
function calmClock() {
  if (!tensionOn) return;
  tensionOn = false; tenseOp = -1;
  Sound.tension(0);
  $('tenseFx').classList.remove('on');
}
function updateClock(dt) {
  const live = timed() && !over && $('hud').classList.contains('show')
    && !$('veil').classList.contains('show') && !$('specialIntro').classList.contains('show') && !$('levelIntro').classList.contains('show') && !popupOpen;
  if (!live) { calmClock(); return; }
  if (busy) return;   // patlatma animasyonu sırasında sayaç bekler, gerilim sürer
  if (escTut) return;   // Blok Kaçışı öğreticisi sürerken süre işlemez
  if (esc && !esc.st.blocks.length) return;   // son blok kapıdan çıkıyor: kazanma bekleniyor, süre bitip kaybettirmesin
  const before = Math.ceil(timeLeft);
  timeLeft -= dt;
  const now = Math.ceil(timeLeft);
  if (now !== before) {
    renderClock();
    if (now <= 10 && now > 0) {
      Sound.tick(now % 2 === 0, now <= 3);
      // Renk grubu bölümünde son 10 saniye finali: duyuru, puan ×2 (sayaç yalnız üstteki süre bölmesinde)
      if (L.bridge && now === 10) bigText('SON 10 SANİYE!', ['#ffe3e8', '#ff6b86'], 0xff4d6d, BY + N * cell * 0.42, 2, 'PUAN ×2');
      $('timeChip').animate([{ transform: 'scale(1.14)' }, { transform: 'scale(1)' }], { duration: 260, easing: 'ease-out' });
    }
  } else $('timeFill').style.width = `${Math.min(100, (timeLeft / L.timeLimit) * 100)}%`;
  if (timeLeft <= 20 && timeLeft > 0) {
    const k = 1 - timeLeft / 20;
    if (!tensionOn) { tensionOn = true; beatIn = 0; $('tenseFx').classList.add('on'); }
    Sound.tension(k);
    const op = Math.round((0.12 + 0.4 * k) * 100);   // yalnız değişince yazılır (her karede yazmak telefonda takılma yapıyordu)
    if (op !== tenseOp) { tenseOp = op; $('tenseFx').style.opacity = op / 100; }
    beatIn -= dt;
    if (beatIn <= 0) {
      beatIn = 1.05 - 0.55 * k;
      Sound.heartbeat(k);
      if (k > 0.5) Haptics.light();
      $('tenseFx').animate([{ opacity: 0.35 + 0.65 * k }, { opacity: 0.12 + 0.4 * k }], { duration: Math.min(500, beatIn * 1000), easing: 'ease-out' });
    }
  } else calmClock();
  if (timeLeft <= 0) {
    timeLeft = 0; renderClock(); calmClock();
    if (L.sand) { fall.active = false; fall.piece = null; for (const ch of fall.cur.removeChildren()) ch.destroy(); fall.ghost.clear(); if (fall.guide) fall.guide.visible = false; win(); }   // süre boyunca dayandın
    else checkGameOver('time');
  }
}

// ---------- Galibiyet serisi ----------
// Kaybetmeden geçilen her bölüm seriyi artırır; bölümde can giderse seri bozulur.
// Seri, sonraki blok bölümüne bedava güçlendirici verir (önce bunlar harcanır).
// Ödül eşikleri: 5 seri çekiç, 7 seri + bomba, 10 seri + yenile (kolay verilmesin)
const STREAK_TIERS = [[10, ['hammer', 'bomb', 'shuffle']], [7, ['hammer', 'bomb']], [5, ['hammer']]];
const streakBonus = (n) => (STREAK_TIERS.find(([t]) => n >= t) || [0, []])[1];
const nextTier = (n) => [...STREAK_TIERS].reverse().find(([t]) => n < t);
let streakN = Store.num('streak', 0);
let freeB = { hammer: 0, bomb: 0, shuffle: 0 };
function setStreak(n) { streakN = n; Store.set('streak', n); }
const boostCount = (k) => Wallet.count(k) + (freeB[k] || 0);
function useBoost(k) {
  if (freeB[k] > 0) { freeB[k]--; return true; }
  return Wallet.useBooster(k);
}
const bonusText = (n) => streakBonus(n).map((k) => '+' + BOOSTERS[k].name).join(' ');
const B_ICO = { hammer: 'i-hammer', bomb: 'i-bomb', shuffle: 'i-shuffle' };
const miniBoost = (k, plus = '') => `<span class="sbg"><span class="bo-ico ${k}"><svg><use href="#${B_ICO[k]}"/></svg></span>${plus ? `<b>${plus}</b>` : ''}</span>`;
// Bölüm başında seri ödülü kartı: alevli madalya, ödül güçlendiricileri; sonra her biri alttaki düğmesine uçar
function showStreakBanner() {
  const el = $('streakBanner');
  const ks = streakBonus(streakN);
  $('sbN').textContent = streakN;
  $('sbText').textContent = `${streakN} bölümdür kaybetmedin!`;
  $('sbGifts').innerHTML = ks.map((k) => miniBoost(k, '+1')).join('');
  el.classList.remove('show', 'out'); void el.offsetWidth; el.classList.add('show');
  Sound.chest();
  Haptics.medium();
  const run = runId;
  setTimeout(() => {
    if (run !== runId) return;
    [...$('sbGifts').children].forEach((chip, i) => {
      const k = ks[i], btn = document.querySelector(`.boost[data-k="${k}"] .bo-ico`);
      const ico = chip.querySelector('.bo-ico');
      if (!btn || !ico) return;
      const a = ico.getBoundingClientRect(), b = btn.getBoundingClientRect();
      const fly = ico.cloneNode(true);
      fly.className += ' sbn-fly';
      fly.style.cssText = `left:${a.left}px;top:${a.top}px;width:${a.width}px;height:${a.height}px`;
      document.body.appendChild(fly);
      ico.style.visibility = 'hidden';
      const dx = b.left + b.width / 2 - (a.left + a.width / 2), dy = b.top + b.height / 2 - (a.top + a.height / 2), sc = b.width / a.width;
      fly.animate([
        { transform: 'translate(0,0) scale(1)' },
        { transform: `translate(${dx * 0.5}px, ${dy * 0.5 - 70}px) scale(${(1 + sc) / 2 * 1.15}) rotate(-12deg)`, offset: 0.5 },
        { transform: `translate(${dx}px, ${dy}px) scale(${sc})` },
      ], { duration: 620, delay: i * 120, easing: 'cubic-bezier(0.45, 0, 0.3, 1)', fill: 'forwards' }).onfinish = () => {
        fly.remove();
        const bo = btn.closest('.boost');
        bo.classList.remove('gifted'); void bo.offsetWidth; bo.classList.add('gifted');
        renderBoosters();
        Sound.coin();
        Haptics.light();
      };
    });
    setTimeout(() => { if (run === runId) el.classList.add('out'); }, 250);
  }, 1500);
  setTimeout(() => el.classList.remove('show', 'out'), 2600);
}
// Bölüm tamam penceresinde seri yolu: 5 · 7 · 10 durakları ve ödülleri; çizgi bir önceki seriden yenisine dolar
function renderStreakTrack(n) {
  const max = STREAK_TIERS[0][0];
  const stops = [...STREAK_TIERS].reverse();   // 5, 7, 10
  const newOf = (i) => stops[i][1].filter((k) => !(i ? stops[i - 1][1] : []).includes(k));   // durakta yeni eklenen
  $('stkNodes').innerHTML = stops.map(([t], i) => `<span class="stk-node${n - 1 >= t ? ' on' : ''}" data-t="${t}" style="left:${(t / max) * 100}%">${newOf(i).map((k) => miniBoost(k)).join('')}<em>${t}</em></span>`).join('');
  const f = (v) => `${Math.min(1, v / max) * 100}%`;
  $('stkFill').style.transition = 'none';
  $('stkFill').style.width = f(n - 1);
  return () => {
    $('stkFill').style.transition = '';
    $('stkFill').style.width = f(n);
    const node = document.querySelector(`.stk-node[data-t="${n}"]`);
    if (node) setTimeout(() => { node.classList.add('on', 'hit'); Sound.star(2); Haptics.success(); }, 450);
  };
}

// ---------- Canlar ----------
// Bölüme girildikten sonra kaybedilir ya da yarıda bırakılırsa bir can gider; sonsuz oyunda oyun bitince gider.
let lifeAtRisk = false;
function spendLifeIfRisk() {
  if (!lifeAtRisk) return;
  lifeAtRisk = false;
  if (mode === 'level' && !daily) setStreak(0);
  Lives.lose();
  renderLives();
}
// Bölüm yarıdayken çıkmadan / yeniden başlamadan önce can kaybını sor
let quitAction = null;
function confirmLeave(action, again = false) {
  // Sonsuz oyun: can gitmez ama oyuncu yine uyarılır (skor ve kaydın ne olacağı)
  const endless = mode === 'endless' && !daily && !over && placed > 0;
  if (!endless && (!lifeAtRisk || over)) return action();
  quitAction = action;
  closePopups();
  $('quitPop').classList.toggle('endless', endless);
  $('qtHeadUse').setAttribute('href', endless ? '#c-infinity' : '#c-heart');
  $('qtLeaveTxt').textContent = again ? 'BAŞTAN' : 'ÇIK';
  $('qtLeaveIco').innerHTML = `<use href="#${again ? 'i-replay' : 'i-home'}"/>`;
  $('qtStreak').classList.add('hidden');
  if (endless) {
    $('qtTitle').textContent = again ? 'BAŞTAN BAŞLA?' : 'OYUNDAN ÇIK?';
    $('qtInfo').innerHTML = again
      ? `<b>${score.toLocaleString('tr-TR')}</b> puanlık bu oyun silinir<span class="qt-note">Yeni oyun 1 can harcar</span>`
      : `Skorun <b>${score.toLocaleString('tr-TR')}</b><span class="qt-note">Oyunun kaydedilir · devam etmek 1 can harcar</span>`;
    $('qtProg').replaceChildren();
    openPopup('quitPop');
    return;
  }
  const n = Lives.state().n;
  $('qtTitle').textContent = again ? 'YENİDEN BAŞLA?' : 'BÖLÜMDEN ÇIK?';
  $('qtInfo').innerHTML = `${again ? 'Yeniden başlarsan' : 'Şimdi çıkarsan'} <b>1 can</b> kaybedersin`;
  $('qtHearts').replaceChildren(...Array.from({ length: LIVES_MAX }, (_, k) => {
    const el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    el.innerHTML = '<use href="#c-heart"/>';
    el.setAttribute('class', k < n - 1 ? '' : k === n - 1 ? 'lose' : 'off');
    return el;
  }));
  // Bu bölümde kaybedilecek ilerleme: toplanan hedefler, puan ve kalan süre
  const chips = [];
  const chip = (ico, val, of, f) => `<div class="qp-chip">${ico}<span class="qp-txt"><b>${val}<small> / ${of}</small></b><i class="qp-bar"><i style="width:${Math.round(Math.min(1, f) * 100)}%"></i></i></span></div>`;
  if (mode === 'level' && L && !L.falling && L.type !== 'score') {
    L.goals.forEach((g, i) => {
      const got = g.count - Math.max(0, goals[i] ? goals[i].left : g.count);
      chips.push(chip(`<img src="${iconURL[g.icon]}" alt="">`, got, g.count, got / g.count));
    });
  } else if (mode === 'level' && L && L.type === 'score') {
    chips.push(chip('<span class="qp-ico star"><svg><use href="#c-star"/></svg></span>', score.toLocaleString('tr-TR'), L.target.toLocaleString('tr-TR'), score / L.target));
  }
  if (timed()) chips.push(`<div class="qp-chip"><span class="qp-ico"><svg viewBox="0 0 24 24"><circle cx="12" cy="13.5" r="8" fill="none" stroke="currentColor" stroke-width="2.6"/><path d="M12 9.5v4.5l2.8 1.8M9.5 2.5h5" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"/></svg></span><span class="qp-txt"><b>${clockText(timeLeft)}</b></span></div>`);
  $('qtProg').innerHTML = chips.length && placed > 0 ? `<small>BU BÖLÜMDEKİ İLERLEMEN</small><div class="qp-row">${chips.join('')}</div>` : '';
  if (mode === 'level' && !daily && streakN > 0) {
    $('qtStreakT').textContent = `${streakN} bölümlük serin bozulur!`;
    $('qtStreak').classList.remove('hidden');
  }
  openPopup('quitPop');
}
const clock = (ms) => {
  const sec = Math.max(0, Math.ceil(ms / 1000));
  const p2 = (v) => String(v).padStart(2, '0');
  return `${p2(Math.floor(sec / 3600))}:${p2(Math.floor((sec % 3600) / 60))}:${p2(sec % 60)}`;
};
function renderLives() {
  const st = Lives.state();
  const pill = $('homeLives');
  $('livesN').textContent = st.n;
  const left = st.refillAt - Date.now();
  $('livesT').textContent = !st.refillAt ? 'DOLU' : narrow(380) ? (() => { const m = Math.ceil(left / 60000); return `${Math.floor(m / 60)}:${String(m % 60).padStart(2, '0')}`; })() : clock(left).replace(/^0/, '');
  pill.classList.toggle('full', !st.refillAt);
  pill.classList.toggle('empty', st.n === 0);
  if ($('livesPop').classList.contains('show')) renderLivesPop();
}
let livesPending = null; // can bittiği için bekleyen bölüm
function renderLivesPop(pop = false) {
  const st = Lives.state();
  $('lvBig').textContent = st.n;
  $('lvHearts').replaceChildren(...Array.from({ length: LIVES_MAX }, (_, k) => {
    const el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    el.innerHTML = '<use href="#c-heart"/>';
    el.setAttribute('class', (k < st.n ? '' : 'off') + (pop ? ' pop' : ''));
    if (pop) el.style.animationDelay = `${k * 0.08}s`;
    return el;
  }));
  $('lvTitle').textContent = st.n === 0 ? 'Canın kalmadı!' : 'Canlar';
  $('lvInfo').innerHTML = st.refillAt
    ? `Tüm canlar <b>&nbsp;${clock(st.refillAt - Date.now())}&nbsp;</b> sonra dolar`
    : 'Canların dolu, iyi oyunlar!';
  $('lvAd').classList.toggle('off', !st.refillAt);
}
function openLives(pendingLevel = null) {
  livesPending = pendingLevel;
  closePopups();
  renderLivesPop();
  openPopup('livesPop');
}
$('lvAd').addEventListener('click', async () => {
  if (!Lives.state().refillAt) return;
  const ok = await Ads.rewarded();
  if (!ok) return;
  Lives.fill();
  Sound.chest();
  Haptics.success();
  renderLivesPop(true);
  renderLives();
  $('homeLives').classList.remove('bump'); void $('homeLives').offsetWidth; $('homeLives').classList.add('bump');
  if (livesPending !== null) {
    const n = livesPending;
    livesPending = null;
    await wait(0.9);
    closePopups();
    startLevel(n);
  }
});
$('livesClose').addEventListener('click', () => { livesPending = null; closePopups(); });
$('homeLives').addEventListener('click', () => openLives());
setInterval(renderLives, 1000);

// ---------- Profil ----------
let pfAvatar = 0;
function renderProfile() {
  const p = Profile.get();
  const col = AVATARS[(p && p.avatar) || 0];
  $('homeAv').style.color = col;
}
function pfStat(icon, value, label) {
  return `<div class="pf-stat"><svg><use href="#${icon}"/></svg><span><b>${value}</b><small>${label}</small></span></div>`;
}
function openProfile(first = false) {
  closePopups();
  const p = Profile.get();
  pfAvatar = p ? p.avatar : Math.floor(Math.random() * AVATARS.length);
  const pop = $('profilePop');
  pop.classList.toggle('first', first);
  pop.classList.toggle('edit', !first);
  $('pfTitle').textContent = first ? 'Hoş geldin!' : 'Profil';
  $('pfDesc').textContent = first ? 'Kendine bir kullanıcı adı ve karakter seç' : 'Adını ve karakterini değiştirebilirsin';
  $('pfSaveText').textContent = first ? 'BAŞLA' : 'KAYDET';
  $('pfName').value = p ? p.name : '';
  $('pfErr').textContent = '';
  const drawAv = () => {
    $('pfAv').style.color = AVATARS[pfAvatar];
    [...$('pfAvatars').children].forEach((b, k) => b.classList.toggle('sel', k === pfAvatar));
  };
  $('pfAvatars').replaceChildren(...AVATARS.map((c, k) => {
    const b = document.createElement('button');
    b.type = 'button';
    b.innerHTML = `<svg style="color:${c}"><use href="#av-face"/></svg>`;
    b.addEventListener('click', () => { pfAvatar = k; Sound.click(); Haptics.light(); drawAv(); });
    return b;
  }));
  drawAv();
  let stars = 0;
  for (let i = 0; i <= unlocked; i++) stars += starsOf(i);
  $('pfStats').innerHTML = pfStat('c-map', Math.min(unlocked + 1, TOTAL_LEVELS), 'BÖLÜM') + pfStat('c-star', stars, 'TOPLAM YILDIZ')
    + pfStat('c-infinity', best.toLocaleString('tr-TR'), 'SONSUZ REKOR') + pfStat('c-flame', streakN, 'GALİBİYET SERİSİ');
  openPopup('profilePop');
}
$('pfDice').addEventListener('click', () => { $('pfName').value = Profile.suggest(); $('pfErr').textContent = ''; Sound.click(); Haptics.light(); });
$('pfName').addEventListener('input', () => { $('pfErr').textContent = ''; });
$('pfName').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('pfSave').click(); } });
// Klavye açıkken profil kartı ekranın üstüne kayar ve sadeleşir; sayfa kendiliğinden kaymaz (iOS odak kaydırması geri alınır)
const kbFix = () => { window.scrollTo(0, 0); document.documentElement.scrollTop = 0; document.body.scrollTop = 0; };
// Panelin alt kenarı klavyenin üst kenarına oturur: klavye yüksekliği görünür alandan ölçülür
// (henüz ölçülemezse iPhone klavyesinin yaklaşık yüksekliği kullanılır)
function kbLayout() {
  const pop = $('profilePop');
  if (!pop.classList.contains('kb')) return;
  kbFix();
  const vv = window.visualViewport;
  const H0 = window.innerHeight;
  let kbTop = vv && vv.height < H0 - 80 ? vv.offsetTop + vv.height : H0 * 0.6;
  kbTop = Math.max(pop.offsetHeight + safeT + 8, kbTop);
  pop.style.top = `${kbTop - pop.offsetHeight}px`;
}
$('pfName').addEventListener('focus', () => {
  $('profilePop').classList.add('kb');
  document.body.classList.add('kb-open');
  kbFix();
  kbLayout(); setTimeout(kbLayout, 120); setTimeout(kbLayout, 400);
});
$('pfName').addEventListener('blur', () => {
  $('profilePop').classList.remove('kb');
  $('profilePop').style.top = '';
  document.body.classList.remove('kb-open');
  setTimeout(kbFix, 50); setTimeout(kbFix, 400);
});
if (window.visualViewport) { visualViewport.addEventListener('resize', kbLayout); visualViewport.addEventListener('scroll', () => { if (document.body.classList.contains('kb-open')) kbFix(); }); }
window.addEventListener('scroll', () => { if (window.scrollY) kbFix(); });
// Kartın boş bir yerine dokununca klavye kapanır
$('profilePop').addEventListener('pointerdown', (e) => { if (e.target.closest('input, button, .pf-avatars')) return; $('pfName').blur(); });
$('pfSave').addEventListener('click', () => {
  const r = Profile.check($('pfName').value);
  if (!r.ok) {
    $('pfErr').textContent = r.msg;
    Haptics.warning();
    $('pfName').animate([{ transform: 'translateX(0)' }, { transform: 'translateX(-8px)' }, { transform: 'translateX(8px)' }, { transform: 'translateX(0)' }], { duration: 260 });
    return;
  }
  const pop = $('profilePop'), btn = $('pfSave');
  if (pop.classList.contains('saved')) return;   // onay animasyonu sürerken ikinci dokunuş yok sayılır
  const first = pop.classList.contains('first');
  $('pfName').blur();
  Profile.save(r.name, pfAvatar);
  renderProfile();
  // Onay anı: düğme "✓ KAYDEDİLDİ" olur, karakter zıplar ve etrafında halka açılır; sonra pencere kapanır
  pop.classList.add('saved');
  $('pfSaveText').innerHTML = '<svg class="pf-ok"><use href="#i-check"/></svg>KAYDEDİLDİ';
  Sound.coin();
  Haptics.success();
  setTimeout(() => {
    closePopups();
    setTimeout(() => { pop.classList.remove('saved'); }, 350);
    showProfileToast(first ? `Hoş geldin, ${r.name}!` : 'Profil kaydedildi', first ? 'Profilin hazır, iyi oyunlar' : r.name);
    const hp = $('homeProfile');
    hp.classList.remove('pf-pulse'); void hp.offsetWidth; hp.classList.add('pf-pulse');
    // İlk girişte günlük ödül, kullanıcı adı oluşturulduktan sonra açılır (ekranlar üst üste binmesin)
    if (first && dailyState().canClaim) setTimeout(() => { if ($('home').classList.contains('show') && !popupOpen) openDaily(); }, 1400);
  }, 900);
});
// Profil onay kartı: karakter + yeşil onay rozeti, başlık ve ad; üstten kayarak gelir
let pfToastTimer = null;
function showProfileToast(title, sub) {
  const p = Profile.get();
  $('pftAv').style.color = AVATARS[(p && p.avatar) || 0];
  $('pftTitle').textContent = title;
  $('pftSub').textContent = sub;
  const el = $('pfToast');
  el.classList.remove('show'); void el.offsetWidth; el.classList.add('show');
  clearTimeout(pfToastTimer);
  pfToastTimer = setTimeout(() => el.classList.remove('show'), 2600);
}
$('profileClose').addEventListener('click', closePopups);
$('homeProfile').addEventListener('click', () => openProfile(false));

// ---------- Günlük görevler ----------
let toastTimer = null;
Ads.onNoAd = (msg) => toast(msg);
// Ayarlar › Reklam izinleri: Google'ın gizlilik seçenekleri penceresi (yalnız Avrupa'da görünür)
$('adPrivacyLink').addEventListener('click', (e) => { e.preventDefault(); Ads.showPrivacyOptions(); });
function toast(text) {
  $('toastText').textContent = text;
  const el = $('toast');
  el.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove('show'), 2400);
}
function mission(id, amount = 1) {
  const done = Missions.track(id, amount);
  for (const m of done) { toast(`Görev tamam: ${Missions.text(m)}`); Sound.coin(); Haptics.success(); }
  if (done.length) updateMissionDot();
}
function updateMissionDot() { document.querySelector('#homeMissions .sb-ico').classList.toggle('ready', Missions.hasClaimable()); }
// Görev türüne göre simge ve renk
const MISSION_LOOK = {
  lines: ['#m-lines', 'blue'], combo: ['#m-combo', 'purple'], icons: ['gem', 'cyan'], levels: ['#c-star', 'gold'],
  place: ['#m-place', 'green'], multi: ['#m-multi', 'pink'], fire: ['#c-flame', 'red'], endless: ['#c-infinity', 'indigo'],
  booster: ['#i-hammer', 'orange'],
};
const TIER_NAME = ['KOLAY', 'ORTA', 'ZOR'];
function missionIcon(id) {
  const [ico, bg] = MISSION_LOOK[id] || MISSION_LOOK.lines;
  const inner = ico.startsWith('#') ? `<svg><use href="${ico}"/></svg>` : `<img src="${iconURL[ico]}" alt="">`;
  return `<span class="m-ico c-${bg}">${inner}</span>`;
}
function renderMissions(animate = false) {
  const st = Missions.load();
  $('missionCoins').textContent = Wallet.coins.toLocaleString('tr-TR');
  $('missionList').replaceChildren(...st.list.map((m, i) => {
    const d = document.createElement('div');
    const ready = !m.claimed && m.p >= m.n;
    d.className = `mission t${m.tier}${ready ? ' ready' : ''}${m.claimed ? ' claimed' : ''}${animate ? ' enter' : ''}`;
    d.style.setProperty('--d', `${0.08 + i * 0.07}s`);
    const fmt = (v) => v.toLocaleString('tr-TR');
    const pct = Math.min(100, (m.p / m.n) * 100);
    const reward = MISSION_REWARD[m.tier];
    const btn = m.claimed
      ? '<svg class="m-done"><use href="#i-check"/></svg>'
      : ready
        ? `<small>AL</small><b><svg><use href="#i-coin"/></svg>${reward}</b>`
        : `<b><svg><use href="#i-coin"/></svg>${reward}</b>`;
    d.innerHTML = missionIcon(m.id)
      + `<div class="m-body"><span class="m-tier">${TIER_NAME[m.tier]}</span><div class="m-text">${Missions.text(m)}</div>`
      + `<div class="m-bar"><i style="width:${pct}%"></i><span>${m.claimed ? 'TAMAMLANDI' : `${fmt(m.p)} / ${fmt(m.n)}`}</span></div></div>`
      + `<button class="m-claim"${ready ? '' : ' disabled'}>${btn}</button>`;
    d.querySelector('.m-claim').addEventListener('click', (e) => {
      const from = e.currentTarget.getBoundingClientRect();
      const before = Wallet.coins;
      const coins = Missions.claim(i);
      if (!coins) return;
      Sound.coin();
      Haptics.success();
      flyCoinsTo(from, $('missionCoins'), before, coins);
      updateCoins();
      renderMissions();
      const card = $('missionList').children[i];
      card.classList.add('stamp');
      updateMissionDot();
    });
    return d;
  }));
  const done = st.list.filter((m) => m.claimed).length;
  const claimedAll = done === st.list.length;
  const pips = $('missionBonus').querySelectorAll('.mb-pips i');
  pips.forEach((p, k) => p.classList.toggle('on', k < done));
  $('missionBonus').classList.toggle('ready', claimedAll && !st.bonus);
  $('missionBonus').classList.toggle('got', st.bonus);
  $('bonusBtn').disabled = !(claimedAll && !st.bonus);
  $('bonusBtn').firstElementChild.textContent = st.bonus ? 'ALINDI' : 'AÇ';
  $('bonusSub').textContent = st.bonus ? 'Yarın yeni görevler gelecek' : claimedAll ? 'Sandığın hazır!' : `${done}/3 görev tamamlandı`;
}
// Altınlar düğmeden cüzdana uçar, sayı yukarı sayar
function flyCoinsTo(fromRect, target, before, amount) {
  const to = target.getBoundingClientRect();
  const n = 7;
  for (let k = 0; k < n; k++) {
    const c = document.createElement('div');
    c.className = 'fly-coin';
    c.innerHTML = '<svg><use href="#i-coin"/></svg>';
    document.body.appendChild(c);
    const x0 = fromRect.left + fromRect.width / 2 - 13, y0 = fromRect.top + fromRect.height / 2 - 13;
    const x1 = to.left + 4, y1 = to.top + to.height / 2 - 13;
    const mx = x0 + (Math.random() - 0.5) * 90, my = y0 - 30 - Math.random() * 50;
    c.animate([
      { transform: `translate(${x0}px, ${y0}px) scale(0.4)`, opacity: 0 },
      { transform: `translate(${mx}px, ${my}px) scale(1.1)`, opacity: 1, offset: 0.35 },
      { transform: `translate(${x1}px, ${y1}px) scale(0.7)`, opacity: 1 },
    ], { duration: 650 + k * 45, delay: k * 35, easing: 'cubic-bezier(0.45, 0, 0.3, 1)', fill: 'forwards' })
      .finished.then(() => c.remove(), () => c.remove());
  }
  const wallet = target.parentElement;
  const t0 = performance.now() + 550, dur = 500;
  const step = (now) => {
    const f = Math.max(0, Math.min(1, (now - t0) / dur));
    target.textContent = Math.round(before + amount * f).toLocaleString('tr-TR');
    if (f < 1) requestAnimationFrame(step);
    else { wallet.classList.remove('bump'); void wallet.offsetWidth; wallet.classList.add('bump'); }
  };
  requestAnimationFrame(step);
  setTimeout(() => { target.textContent = (before + amount).toLocaleString('tr-TR'); }, 1400);
}
let missionTick = null;
function openMissions() {
  renderMissions(true);
  openPopup('missions');
  clearInterval(missionTick);
  const tick = () => {
    if (!$('missions').classList.contains('show')) { clearInterval(missionTick); return; }
    const now = new Date(), next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    const sec = Math.max(0, Math.floor((next - now) / 1000));
    const p2 = (v) => String(v).padStart(2, '0');
    $('missionTimer').textContent = `Yeni görevler: ${p2(Math.floor(sec / 3600))}:${p2(Math.floor((sec % 3600) / 60))}:${p2(sec % 60)}`;
    if (sec === 0) renderMissions();
  };
  tick();
  missionTick = setInterval(tick, 1000);
}

// ---------- Günlük ödül ----------
const rewardIcons = (r) => (r.coins ? '<svg><use href="#i-coin"/></svg>' : '')
  + (r.booster ? `<span class="bo-ico ${r.booster}"><svg><use href="#i-${r.booster}"/></svg></span>` : '');
const rewardText = (r) => [r.coins || '', r.booster ? '×1' : ''].filter(Boolean).join(' + ');
let dailyTick = null;
function openDaily() {
  const st = dailyState();
  const last = DAILY.length - 1;
  $('dailyGrid').replaceChildren(...DAILY.map((r, i) => {
    const d = document.createElement('div');
    const state = i < st.day ? 'got' : i === st.day && st.canClaim ? 'today' : 'next';
    d.className = `day ${state}${i === last ? ' big' : ''}`;
    const label = state === 'today' ? 'BUGÜN' : `${i + 1}. GÜN`;
    const icons = i === last ? '<svg class="chest"><use href="#c-chest"/></svg>' : rewardIcons(r);
    d.innerHTML = `<small>${label}</small><span class="rw">${icons}</span><b>${i === last ? 'BÜYÜK ÖDÜL' : rewardText(r)}</b><i class="day-check"></i>`
;
    return d;
  }));
  $('dailyStreak').textContent = st.canClaim
    ? (st.day ? `Seri: ${st.day} gün · Bugün ${st.day + 1}. gün` : 'Her gün gel, ödüller büyüsün!')
    : `Seri: ${st.day} gün · Yarın yine gel!`;
  setDailyButton(st.canClaim);
  openPopup('daily');
}
// Toplanınca düğme kapanır ve gece yarısına geri sayım başlar
function setDailyButton(canClaim) {
  $('dailyClaim').classList.toggle('off', !canClaim);
  $('dailyClaim').firstElementChild.textContent = canClaim ? 'TOPLA' : 'YARIN GEL';
  clearInterval(dailyTick);
  const tick = () => {
    if (!$('daily').classList.contains('show')) { clearInterval(dailyTick); return; }
    const now = new Date(), next = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
    const sec = Math.max(0, Math.floor((next - now) / 1000));
    const p2 = (v) => String(v).padStart(2, '0');
    $('dailyTimer').textContent = `Yeni ödül: ${p2(Math.floor(sec / 3600))}:${p2(Math.floor((sec % 3600) / 60))}:${p2(sec % 60)}`;
  };
  $('dailyTimer').textContent = '';
  if (!canClaim) { tick(); dailyTick = setInterval(tick, 1000); }
}

// Bölüm haritası: her bölüm pahlı bir blok; 20'şerli gruplar halinde ızgara
const tileURL = {};
const tileImg = (color) => (tileURL[color] ??= renderTile(color, 160).toDataURL());
const royalImg = () => (tileURL.royal ??= renderRoyal(160).toDataURL());

// Bölüm haritası: dünya başlıkları altında 4 sütunlu blok ızgara
const WORLD_ICON = { forest: 'w-forest', ocean: 'w-ocean', desert: 'w-desert', space: 'w-space', ice: 'w-ice', volcano: 'w-volcano' };
function openMap() {
  runId++;
  closePopups();
  spendLifeIfRisk();
  if (theme !== BASE) applyTheme(BASE);
  const list = $('mapList');
  const count = TOTAL_LEVELS;   // bütün dünyalar görünür; açılmamış olanlar kilitli
  // Performans: ilerleme değişmediyse harita yeniden kurulmaz
  let sig = String(unlocked);
  for (let i = 0; i < count; i++) sig += starsOf(i);
  if (list.dataset.sig === sig && list.childElementCount) { over = true; showScreen('map'); scrollMapToCurrent(list); return; }
  list.dataset.sig = sig;
  list.replaceChildren();
  let total = 0;
  for (let g = 0; g < count; g += WORLD_SIZE) {
    const w = worldOf(g);
    const open = g <= unlocked;
    let got = 0;
    for (let i = g; i < g + WORLD_SIZE; i++) got += starsOf(i);
    total += got;
    const sec = document.createElement('section');
    sec.className = 'world-sec' + (open ? '' : ' locked');
    sec.style.setProperty('--wc', w.block);
    sec.style.setProperty('--wf', w.frame);
    sec.style.setProperty('--wb0', w.bg[0]);
    sec.style.setProperty('--wb1', w.bg[1]);
    const card = document.createElement('div');
    card.className = 'world-card';
    card.innerHTML = `<span class="wc-emblem"><svg><use href="#${WORLD_ICON[w.scene] || 'w-forest'}"/></svg></span>`
      + `<span class="wc-text"><small>DÜNYA ${g / WORLD_SIZE + 1}</small><b>${w.name}</b><em>Bölüm ${g + 1}–${g + WORLD_SIZE}</em></span>`
      + (open
        ? `<span class="wc-prog"><span class="wc-stars"><svg><use href="#c-star"/></svg>${got}<i>/${WORLD_SIZE * 3}</i></span><span class="wc-bar"><i style="width:${(got / (WORLD_SIZE * 3)) * 100}%"></i></span></span>`
        : `<span class="wc-lock"><svg><use href="#i-lock"/></svg><small>Bölüm ${g + 1}'de açılır</small></span>`);
    const grid = document.createElement('div');
    grid.className = 'level-grid';
    for (let i = g; i < g + WORLD_SIZE; i++) {
      const st = starsOf(i);
      const state = i < unlocked ? 'done' : i === unlocked ? 'current' : 'locked';
      const node = document.createElement('button');
      node.className = 'lvl-tile ' + state + (isSpecial(i) ? ' special' : '');
      node.style.setProperty('--k', String(i - g));
      if (state === 'locked') {
        node.innerHTML = `<span class="num">${i + 1}</span><svg class="lock"><use href="#i-lock"/></svg>`;
      } else {
        const color = state === 'done' ? w.block : '#ffbe1f';
        node.style.backgroundImage = `url(${isSpecial(i) && state !== 'current' ? royalImg() : tileImg(color)})`;
        node.innerHTML = `<span class="num">${i + 1}</span>`;
        if (state === 'done') node.insertAdjacentHTML('beforeend', `<span class="mini-stars">${[0, 1, 2].map((q) => `<i class="${q < st ? 'on' : ''}"></i>`).join('')}</span>`);
        else node.insertAdjacentHTML('beforeend', '<span class="play-tag">OYNA</span>');
        node.addEventListener('click', () => startLevel(i));
      }
      if (isSpecial(i)) node.insertAdjacentHTML('beforeend', `<img class="crown-badge" src="${iconURL.crown}" alt="">`);
      if (isSuperHard(i)) { node.classList.add('superhard'); node.insertAdjacentHTML('beforeend', `<svg class="sh-badge" viewBox="0 0 24 24">${SKULL}</svg>`); }
      if (isFalling(i)) { node.classList.add('falling'); node.insertAdjacentHTML('beforeend', '<svg class="fall-badge"><use href="#m-fall"/></svg>'); }
      if (isEscape(i)) { node.classList.add('escape'); node.insertAdjacentHTML('beforeend', '<svg class="esc-badge"><use href="#m-esc"/></svg>'); }
      grid.append(node);
    }
    sec.append(card, grid);
    list.append(sec);
  }
  $('mapStars').textContent = total;
  over = true;
  showScreen('map');
  scrollMapToCurrent(list);
}
// Bulunduğun dünyanın kartı üstte görünsün; şu anki bölüm de ekranda kalsın
function scrollMapToCurrent(list) {
  requestAnimationFrame(() => {
    const cur = list.querySelector('.current');
    if (!cur) return;
    const base = list.getBoundingClientRect().top - list.scrollTop;
    const top = cur.closest('.world-sec').querySelector('.world-card').getBoundingClientRect().top - base - 10;
    const bottom = cur.getBoundingClientRect().bottom - base + 30;
    list.scrollTop = bottom - top <= list.clientHeight ? top : bottom - list.clientHeight;
  });
}

$('levelsBtn').addEventListener('click', () => (unlocked >= TOTAL_LEVELS ? openMap() : startLevel(unlocked)));
$('homeMap').addEventListener('click', openMap);
$('homeChest').addEventListener('click', () => {
  const n = Number($('homeChest').dataset.left || CHEST_EVERY);
  Haptics.light();
  $('homeChest').querySelector('svg').animate([{ transform: 'rotate(0)' }, { transform: 'rotate(-12deg)' }, { transform: 'rotate(10deg)' }, { transform: 'rotate(0)' }], { duration: 420 });
  openChestInfo(n);
});
// Ödül sandığı bilgi penceresi: kaç bölüm kaldığı, içinden çıkanlar, sıradaki bölüme kısayol
function openChestInfo(left) {
  const done = CHEST_EVERY - left;
  $('ciPips').replaceChildren(...Array.from({ length: CHEST_EVERY }, (_, i) => {
    const d = document.createElement('i');
    d.className = i < done ? 'on' : i === done ? 'next' : '';
    d.style.animationDelay = `${0.25 + i * 0.07}s`;
    if (i < done) d.innerHTML = '<svg viewBox="0 0 24 24"><path d="M5 12.5l4.5 4.5L19 7.5" fill="none" stroke="currentColor" stroke-width="3.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    return d;
  }));
  $('ciInfo').innerHTML = left === 1 ? 'Bir sonraki bölümü geç, <b>sandık açılsın!</b>' : `<b>${left} bölüm</b> daha geç, sandık açılsın!`;
  const all = unlocked >= TOTAL_LEVELS;
  $('ciPlayTxt').textContent = all ? 'BÖLÜMLER' : `OYNA · BÖLÜM ${unlocked + 1}`;
  openPopup('chestInfo');
}
$('ciClose').addEventListener('click', closePopups);
$('ciPlay').addEventListener('click', () => { closePopups(); if (unlocked >= TOTAL_LEVELS) openMap(); else startLevel(unlocked); });
$('homeRank').addEventListener('click', async () => {
  Haptics.light();
  const r = await GameCenter.show();
  if (r === 'web' || r === 'nosign' || r === 'fail') openRankInfo(r);
  else syncScores();
});
$('homeMissions').addEventListener('click', openMissions);
$('missionsClose').addEventListener('click', closePopups);
$('bonusBtn').addEventListener('click', () => {
  const res = Missions.claimBonus();
  if (!res) return;
  closePopups();
  updateMissionDot();
  updateCoins();
  showChestReward(res);
});
$('homeGift').addEventListener('click', openDaily);
$('dailyClose').addEventListener('click', closePopups);
$('dailyClaim').addEventListener('click', () => {
  const res = claimDaily();
  if (!res) return;
  Sound.coin();
  Haptics.success();
  confetti(40);
  const tile = $('dailyGrid').children[res.index];
  tile.className = `day got stamp${res.index === DAILY.length - 1 ? ' big' : ''}`;
  tile.querySelector('small').textContent = `${res.index + 1}. GÜN`;
  updateCoins();
  $('homeGift').classList.remove('ready');
  $('dailyStreak').textContent = `Seri: ${res.index + 1} gün · Yarın yine gel!`;
  setDailyButton(false);
  setTimeout(closePopups, 1600);
});
for (const el of document.querySelectorAll('.boost[data-k]')) el.addEventListener('click', () => onBoost(el.dataset.k));
// Basma hissi: dokununca tuş çöker (iOS'ta :active güvenilmez), hafif titreşim; bırakınca yaylanarak çıkar
for (const el of document.querySelectorAll('.boost[data-k]')) {
  el.addEventListener('pointerdown', () => { el.classList.remove('release'); el.classList.add('pressed'); Haptics.light(); });
  const up = () => { if (!el.classList.contains('pressed')) return; el.classList.remove('pressed'); void el.offsetWidth; el.classList.add('release'); };
  el.addEventListener('pointerup', up);
  el.addEventListener('pointerleave', up);
  el.addEventListener('pointercancel', up);
}
$('boostCancel').addEventListener('click', () => setTargeting(null));
$('giveUp').addEventListener('click', () => { gaveUp = true; setStuck(false); checkGameOver(); });
$('shopClose').addEventListener('click', closePopups);
$('shopBuy3').addEventListener('click', () => {
  if (!Wallet.spend(bundlePrice(shopKey))) return;
  grantBooster(shopKey, 3);
});
$('shopBuy').addEventListener('click', () => {
  if (!Wallet.spend(BOOSTERS[shopKey].price)) return;
  grantBooster(shopKey);
});
let shopAdBusy = false;
$('shopAd').addEventListener('click', async () => {
  // Reklam bitene kadar mağaza açık kalır: arkada süre ve düşen bloklar durur, oyun bitip penceresi kapanmaz
  if (shopAdBusy) return;
  const k = shopKey;
  shopAdBusy = true;
  try { if (await Ads.rewarded()) grantBooster(k, 1, $('shop').classList.contains('show')); } finally { shopAdBusy = false; }
});
let chestFromWin = false;
$('chestTake').addEventListener('click', () => {
  if (chestFromWin) { $('chest').classList.remove('show'); $('win').classList.add('show'); } else closePopups();
  renderBoosters();
  updateCoins();
});
// Ayarlar: ✕ ile ya da dışarıya dokunarak kapanır (oyun sonu pencereleri dışarı dokununca kapanmaz)
$('settingsClose').addEventListener('click', closePopups);
$('veil').addEventListener('click', () => {
  if (['pause', 'shop', 'daily', 'missions', 'dpuz', 'livesPop', 'quitPop', 'finale', 'chestInfo', 'buildInfo', 'rankInfo'].some((id) => $(id).classList.contains('show')) || $('tip').classList.contains('closable')
    || ($('profilePop').classList.contains('show') && !$('profilePop').classList.contains('first'))) closePopups();
});
$('homeSettings').addEventListener('click', () => { $('pause').classList.add('from-home'); $('pause').classList.remove('cost'); renderProfile(); renderLives(); openPopup('pause'); });
$('menuBtn').addEventListener('click', () => { $('pause').classList.remove('from-home'); $('pause').classList.toggle('cost', lifeAtRisk && !over); });
$('endlessBtn').addEventListener('click', () => {
  const s = Store.get('save', '');
  if (s) { try { return newGame(JSON.parse(s)); } catch { /* bozuk kayıt */ } }
  newGame();
});
$('mapBack').addEventListener('click', goHome);
let againBusy = false;
$('againBtn').addEventListener('click', async () => {
  if (againBusy) return;
  againBusy = true;
  try {
    if (gamesPlayed > 0 && gamesPlayed % 3 === 0) await Ads.interstitial();
    if (daily) startDaily(); else if (mode === 'level') startLevel(levelN); else newGame();
  } finally { againBusy = false; }
});
$('reviveBtn').addEventListener('click', () => revive(false));
$('menuBtn').addEventListener('click', () => openPopup('pause'));
$('backBtn').addEventListener('click', () => confirmLeave(goHome));
$('resumeBtn').addEventListener('click', closePopups);
const restart = () => { if (daily) startDaily(); else if (mode === 'level') startLevel(levelN); else { if (Lives.count > 0) Store.set('save', ''); newGame(); } };   // can yoksa kayıt silinmez
$('restartBtn').addEventListener('click', () => confirmLeave(restart, true));
$('homeBtn').addEventListener('click', () => confirmLeave(goHome));
$('qtStay').addEventListener('click', closePopups);
$('qtLeave').addEventListener('click', () => { const go = quitAction; quitAction = null; closePopups(); go?.(); });
$('overHome').addEventListener('click', goHome);
$('winNext').addEventListener('click', () => (daily ? goHome() : levelN + 1 >= TOTAL_LEVELS ? openFinale() : startLevel(levelN + 1)));
$('homeDaily').addEventListener('click', openDailyCard);
// Sırada başka tanıtım kartı varsa ✕ de sıradakine geçer (yeni engel kartı atlanmasın)
$('tipClose').addEventListener('click', () => (tipNext ? tipNext() : closePopups()));
$('winMap').addEventListener('click', openMap);

// Ses: ilk dokunuşta açılır; butonlar tık sesi çıkarır; uygulama arka plana geçince durur
document.addEventListener('pointerdown', () => Sound.unlock(), { capture: true });
document.addEventListener('click', (e) => { if (e.target.closest('button')) Sound.click(); }, { capture: true });
document.addEventListener('visibilitychange', () => (document.hidden ? Sound.suspend() : Sound.resume()));
// Bölüm yarıdayken arka plana geçilip uygulama orada kapatılırsa can ve seri yine gider: bayrak arka plana geçerken
// yazılır, geri dönülünce silinir; bir sonraki açılışta duruyorsa can düşülür
document.addEventListener('visibilitychange', () => Store.set('risk', document.hidden && lifeAtRisk && mode === 'level' && !daily && !$('levelIntro').classList.contains('show') && !$('specialIntro').classList.contains('show') ? '1' : ''));
// Bildirimler: oyundan çıkınca planlanır, oyuna dönünce silinir (oynarken bildirim gelmez)
document.addEventListener('visibilitychange', () => (document.hidden ? Notify.plan(Math.min(unlocked, TOTAL_LEVELS - 1)) : Notify.clear()));
Notify.clear();
function renderToggles() {
  $('musicToggle').classList.toggle('off', !Sound.musicOn);
  $('sfxToggle').classList.toggle('off', !Sound.sfxOn);
  $('hapticToggle').classList.toggle('off', !Haptics.enabled);
  $('notifyToggle').classList.toggle('off', !Notify.enabled);
}
$('notifyToggle').addEventListener('click', () => { Notify.toggle(); renderToggles(); });
$('musicToggle').addEventListener('click', () => { Sound.toggleMusic(); renderToggles(); });
$('sfxToggle').addEventListener('click', () => { Sound.toggleSfx(); renderToggles(); });
$('hapticToggle').addEventListener('click', () => { if (Haptics.toggle()) Haptics.medium(); renderToggles(); });
renderToggles();

// ---------- Yeniden yerleşim ----------
// iOS'ta güvenli alan (çentik) değeri açılıştan sonra gelir; değişince her şeyi yeniden konumla
function relayout() {
  hintSig = '';   // ipucu çizgileri yeni ölçüyle yeniden çizilsin
  measure();
  buildTextures();
  buildBackground();
  buildBoard();
  digLayout();
  for (let r = 0; r < N; r++) {
    for (let c = 0; c < N; c++) {
      const b = grid[r] && grid[r][c];
      if (!b) continue;
      b.s.texture = tex[b.color];
      b.s.width = b.s.height = cell;
      b.s.position.set(cx(c), cy(r));
      if (b.is) { b.is.texture = iconTex[b.icon]; b.is.width = b.is.height = cell; b.is.position.set(cx(c), cy(r)); }
      if (b.glow) { b.glow.width = b.glow.height = cell * 1.8; b.glow.position.set(cx(c), cy(r)); }
      if (b.pi) { b.pi.texture = powerIconTex[b.power]; b.pi.width = b.pi.height = cell; b.pi.position.set(cx(c), cy(r)); placeSpark(b); }
      if (b.shine) { shineMaskDraw(b, cell); b.shine.width = cell * 1.9; b.shine.height = cell * 0.55; }
      if (b.ov) { b.ov.texture = b.kind === 'cage' ? tex.cage : b.kind === 'ice' ? (b.hp > 0 ? tex.iceOv : tex.iceCrack) : b.hp > 1 ? tex.chain2 : tex.chain1; b.ov.width = b.ov.height = cell; b.ov.position.set(cx(c), cy(r)); }
      if (b.tx) { const n = b.bomb; b.tx.destroy(); b.tx = bombText(n); b.tx.position.set(cx(c), cy(r) + cell * 0.06); ovLayer.addChild(b.tx); }
    }
  }
  tray.forEach((t, i) => {
    if (!t) return;
    t.view.destroy({ children: true });
    tray[i] = null;
    makeTrayPiece(i, t.shape, t.color);
  });
  renderProgress();
  buildDeco();
  emitters = [];
  if (fall) fallRelayout();
  layoutIsland();
}
let lastSafe = -1, lastW = 0, lastH = 0, safeCheck = 0;
function checkLayout() {
  const st = parseFloat(getComputedStyle($('safeProbe')).paddingTop) || 0;
  if (st !== lastSafe || window.innerWidth !== lastW || window.innerHeight !== lastH) {
    const first = lastSafe < 0;
    if (!first && (drag || busy)) { setTimeout(checkLayout, 300); return; }   // meşgulken ertele, sonra yeniden dene
    lastSafe = st; lastW = window.innerWidth; lastH = window.innerHeight;
    if (!first) relayout();
  }
}
window.addEventListener('resize', () => setTimeout(checkLayout, 50));

// ---------- Döngü ----------
// Tam ekran örtü (giriş ekranı, bölüm tamam / bitti / çıkış / sandık zemini) açıkken tahta görünmez:
// sahne çizimi atlanır, tuval son kareyi gösterir. Mantık, ara geçişler ve sayaçlar işlemeye devam eder.
// Örtü durumu her karede seçiciyle aranmaz (Android'de pahalıydı): pencerelerin sınıfı değişince güncellenir.
const coverSel = '#intro:not(.done), #levelIntro.show:not(.leaving), #specialIntro.show:not(.leaving), #islandsScr.show:not(.leaving), #win.show, #over.show, #quitPop.show, #chest.show';
let covered = false;
{
  const upd = () => { covered = !!document.querySelector(coverSel); };
  const mo = new MutationObserver(upd);
  for (const id of ['intro', 'levelIntro', 'specialIntro', 'islandsScr', 'win', 'over', 'quitPop', 'chest']) if ($(id)) mo.observe($(id), { attributes: true, attributeFilter: ['class'] });
  upd();
}
app.ticker.remove(app.render, app);
app.ticker.add(() => { if (!covered) app.render(); }, null, -25);
let shake = 0, time = 0;
app.ticker.add((tk) => {
  const dt = Math.min(0.05, tk.deltaMS / 1000);
  time += dt;
  updateTweens(dt);
  if (!covered && ++safeCheck % 20 === 0) checkLayout();   // örtü açıkken stil okutma (zorunlu stil hesabı) yapılmaz
  if (shownScore < score) {
    shownScore = Math.min(score, shownScore + Math.max(1, Math.ceil((score - shownScore) * dt * 8)));
    $('score').textContent = shownScore.toLocaleString('tr-TR');
    renderProgress();
  } else if (shownScore > score) { shownScore = score; $('score').textContent = score.toLocaleString('tr-TR'); }
  if (deco.visible) for (const d of decoItems) {
    d.s.y += d.v * dt;
    d.s.x += Math.sin(time * 0.5 + d.drift) * 6 * dt;
    d.s.rotation += d.vr * dt;
    if (d.s.y > H + cell * 2) { d.s.y = -cell * 2; d.s.x = d.side ? W * (0.86 + Math.random() * 0.12) : W * (0.02 + Math.random() * 0.12); }
  }
  if (deco.visible) for (const p of sparkles) {
    p.s.alpha = p.a * (0.55 + 0.45 * Math.sin(time * p.sp + p.ph));
    p.s.y -= p.v * dt;
    if (p.s.y < -10) { p.s.y = H + 10; p.s.x = Math.random() * W; }
  }
  for (const b of bokeh) {
    b.x += b.vx * dt; b.y += b.vy * dt;
    if (b.y < -100) { b.y = H + 100; b.x = Math.random() * W; }
  }
  for (let i = parts.length - 1; i >= 0; i--) {
    const p = parts[i];
    p.t += dt;
    if (p.t > p.life) { p.s.destroy(); parts.splice(i, 1); continue; }
    p.vy += cell * (p.conf ? 3 : 22) * dt;
    if (p.conf) p.vx += Math.sin(time * 3 + p.t * 5) * cell * 2 * dt;
    p.s.x += p.vx * dt; p.s.y += p.vy * dt;
    p.s.rotation += p.vr * dt;
    p.s.alpha = p.conf ? Math.min(1, (p.life - p.t) * 2) : 1 - p.t / p.life;
    if (p.k0) p.s.scale.set(p.k0 * (1 - 0.5 * (p.t / p.life)));
  }
  for (const b of preview.painted) if (!b.s.destroyed) b.s.alpha = 0.75 + Math.sin(time * 12) * 0.25;
  ghostLayer.alpha = 0.85 + Math.sin(time * 9) * 0.15;
  // Simgeler hafifçe nabız gibi atar
  for (const s of iconLayer.children) s.scale.set((cell / s.texture.width) * (1 + Math.sin(time * 3 + s.x * 0.05) * 0.05));
  updateFlames(dt);
  updateAim(dt);
  updateFall(dt);
  fallAnim(dt);
  updateRise(dt);
  updateFever(dt);
  updateClock(dt);
  fallFx(dt);
  island.update(dt);
  updateGold(dt);
  // Ateş çemberi yavaşça tutuşur ve söner
  fireLevel += ((fire && boardLayer.visible && !over ? 1 : 0) - fireLevel) * Math.min(1, dt * 2.6);
  // Tutuşma çerçeve boyunca koşar; kombo büyüdükçe ateş ısınır, her yeni komboda alevler kabarır
  fireIgnite = Math.min(1, fireIgnite + dt / 0.7);
  if (fire && combo > fireCombo) firePulse = 1;
  fireCombo = fire ? combo : 0;
  firePulse = Math.max(0, firePulse - dt * 2.2);
  fireHeat += ((fire ? Math.min(1, Math.max(0, (combo - 3) / 5)) : fireHeat) - fireHeat) * Math.min(1, dt * 3);
  if (fireFx) fireFx.update(time, fireLevel, fireIgnite, fireHeat, firePulse);
  // Sönümlenen titreşim (rastgele zıplama yerine yumuşak salınım)
  const off = shake > 0 ? [Math.sin(time * 58) * shake * 7, Math.cos(time * 47) * shake * 6] : [0, 0];
  updateDrag(dt);
  updatePlayHints(dt);
  updateIdleHint(dt);
  if (dig) digTick(dt);
  if (L && L.power) powerTick();
  boardBump.v += (-boardBump.y * 340 - boardBump.v * 18) * dt; boardBump.y += boardBump.v * dt;
  for (const l of [boardLayer, digLayer, hintLayer, blockLayer, ovLayer, iconLayer, fireShaderLayer, fireLayer, ghostLayer]) l.position.set(off[0], off[1] + boardBump.y);
  escLayer.position.set(off[0], off[1]);
  shake = Math.max(0, shake - dt * 2.6);
  if (aura) {
    const target = fire ? 0.7 + Math.sin(time * 17) * 0.12 + Math.sin(time * 29) * 0.08 : combo >= 2 ? 0.28 + Math.min(combo, 6) * 0.06 : theme.special ? 0.32 : 0;
    if (combo < 2 && theme.special) aura.tint = 0xffc23a;
    auraBase += (target - auraBase) * Math.min(1, dt * 4);
    if (combo >= 2) aura.tint = fire ? 0xff7a1a : COMBO_HEX[Math.min(combo, 6)];
    aura.alpha = Math.min(1, auraBase * (0.8 + 0.2 * Math.sin(time * 5)) + auraBoost);
    auraBoost = Math.max(0, auraBoost - dt * 2.2);
  }
});

// ---------- Açılış animasyonu ----------
// Logonun renkli parçaları dört yandan dönerek gelir ve yerine oturur; logo parlar ve kaybolur,
// ardından ana ekran öğeleri sırayla belirir. Dokununca atlanır.
let introDone = false;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
async function playIntro() {
  const home = $('home');
  home.style.visibility = 'hidden';
  Sound.unlock();   // ses motorunu hemen hazırla (uygulamada dokunuş beklemeden çalar)
  $('intro').addEventListener('pointerdown', finishIntro);
  setTimeout(finishIntro, 4500); // ne olursa olsun açılış takılı kalmasın
  let meta = null;
  try { meta = await (await fetch('img/intro/parcalar.json')).json(); } catch { /* parça yoksa atla */ }
  if (!meta) return finishIntro();
  const box = $('introLogo');
  box.style.aspectRatio = `${meta.w} / ${meta.h}`;
  const shine = box.querySelector('.intro-shine');
  const maskURL = `url(${new URL('img/logo.png', location.href)})`;
  shine.style.webkitMaskImage = shine.style.maskImage = maskURL;
  const imgs = await Promise.all(meta.parts.map((p) => new Promise((res) => {
    const im = new Image();
    im.onload = im.onerror = () => res(im);
    im.src = `img/intro/p${p.id}.png`;
  })));
  if (introDone) return;
  meta.parts.forEach((p, i) => {
    const im = imgs[i];
    im.style.left = `${(p.x / meta.w) * 100}%`;
    im.style.top = `${(p.y / meta.h) * 100}%`;
    im.style.width = `${(p.w / meta.w) * 100}%`;
    im.style.opacity = '0';
    box.append(im);
  });
  // Soldan sağa, hafif karışık sırayla
  const order = meta.parts.map((_, i) => i).sort((a, b) => meta.parts[a].x + Math.random() * 120 - (meta.parts[b].x + Math.random() * 120));
  const dist = Math.max(W, H) * 0.75;
  let landed = 0;
  Sound.introRise((200 + (order.length - 1) * 80 + 700) / 1000);   // son parça oturduğu an zirve
  await Promise.all(order.map((i, n) => {
    const p = meta.parts[i];
    const px = (p.x + p.w / 2) / meta.w - 0.5, py = (p.y + p.h / 2) / meta.h - 0.5;
    const ang = Math.atan2(py * 1.2 + (Math.random() - 0.5) * 1.2, px + (Math.random() - 0.5) * 0.5);
    const rot = (Math.random() - 0.5) * 240;
    const a = imgs[i].animate([
      { transform: `translate(${Math.cos(ang) * dist}px, ${Math.sin(ang) * dist}px) rotate(${rot}deg) scale(0.5)`, opacity: 0 },
      { opacity: 1, offset: 0.3 },
      { transform: 'translate(0, 0) rotate(0deg) scale(1)', opacity: 1 },
    ], { duration: 700, delay: 200 + n * 80, easing: 'cubic-bezier(0.18, 1.3, 0.35, 1)', fill: 'both' });
    return a.finished.then(() => {
      if (introDone) return;
      Haptics.light();
      Sound.introPiece(landed++);
      imgs[i].animate([{ transform: 'scale(1.12)' }, { transform: 'scale(1)' }], { duration: 260, easing: 'ease-out' });   // filtre animasyonu Android'de pahalıydı
    }).catch(() => {});
  }));
  if (introDone) return;
  box.animate([{ transform: 'scale(1)' }, { transform: 'scale(1.07)' }, { transform: 'scale(1)' }], { duration: 460, easing: 'cubic-bezier(0.3, 1.4, 0.5, 1)' });
  box.classList.add('shine');
  Haptics.medium();
  Sound.introDone();
  await sleep(1050);
  if (introDone) return;
  box.classList.add('out');
  await sleep(300);
  finishIntro();
}
function finishIntro() {
  if (introDone) return;
  introDone = true;
  // Müzik açılış sesinden sonra yavaşça başlar
  setTimeout(() => Sound.allowMusic(), 350);
  renderProfile();
  renderLives();
  if (!Profile.get()) setTimeout(() => openProfile(true), 700);
  // Açılıştan sonra Game Center'a sessizce bağlan (giriş yoksa Apple kendi ekranını gösterir)
  setTimeout(() => GameCenter.signIn().then((ok) => { if (ok) syncScores(); }), 800);
  const el = $('intro');
  el.classList.add('done');
  setTimeout(() => el.remove(), 600);
  const home = $('home');
  home.style.visibility = '';
  home.classList.add('enter');
  setTimeout(() => home.classList.remove('enter'), 1100);
  // Ana sayfa açılışı şimdi oynar: üst çubuk, yan düğmeler ve alt düğmeler sırayla gelir, ada aşağıdan süzülür
  home.classList.remove('show'); void home.offsetWidth; home.classList.add('show');
  island.layer.alpha = 0; island.layer.y = 40;
  tween(island.layer, { alpha: 1, y: 0 }, 0.7, Ease.outCubic, 0.15);
  renderPath();
  // Reklam onayı ve Apple takip izni: ana sayfa açıldıktan kısa süre sonra (yalnız ilk açılışta pencere çıkar)
  setTimeout(() => Ads.init().then(() => { $('adPrivacy').hidden = !Ads.privacyOptions; }), 1500);
  if (/kazi/.test(location.search)) setTimeout(() => window.__dbg.kazi(), 600);
  if (/kacis/.test(location.search)) setTimeout(() => window.__dbg.escape(+((location.search.match(/kacis=(\d+)/) || [0, 6])[1])), 600);
  if (/guct/.test(location.search)) setTimeout(() => window.__dbg.guct(), 600);
  else if (/guc/.test(location.search)) setTimeout(() => window.__dbg.guc(), 600);
  // Kullanıcı adı yoksa önce o; günlük ödül profil kaydedilince açılır
  if (Profile.get() && dailyState().canClaim) setTimeout(() => { if ($('home').classList.contains('show') && !popupOpen) openDaily(); }, 900);
}

// ---------- Başlangıç ----------
if (!window.innerWidth) await new Promise((r) => requestAnimationFrame(r));
measure();
applyTheme(BASE);
buildDeco();
checkLayout();
$('best').textContent = best.toLocaleString('tr-TR');
// Uygulama her açılışta sonsuz oyun sıfırdan başlar (yarım oyun silinir, rekor korunur)
Store.set('save', '');
if (Store.get('risk', '')) { Store.set('risk', ''); setStreak(0); Lives.lose(); renderLives(); }   // bölüm yarıda kapatılmıştı
goHome();
playIntro();
// Tanıtım videosu kaydı için iç yardımcılar (yalnız ?promo ile kullanılır)
window.__promo = {
  geom: () => ({ BX, BY, cell, W, H, trayY, slots: [0, 1, 2].map(slotX) }),
  start(n, Lp) { forceL = (k) => (k === n ? Lp : null); startLevel(n); forceL = null; },
  // Tepsiyi verilen parçalarla doldur: [{ cells: [[x,y],...], color: 'c3' }, ...]
  setTray(list, anim = 'center') {
    for (const t of tray) if (t && t.view && !t.view.destroyed) t.view.destroy({ children: true });
    tray = [null, null, null];
    list.forEach((q, i) => { if (q) makeTrayPiece(i, { cells: q.cells, w: 1, n: q.cells.length }, q.color, anim); });
  },
  // i. parçayı (r,c)'ye bırakmak için parmağın başlangıç ve bitiş noktası
  dragPts(i, r, c) {
    const p = tray[i];
    const [w, h] = size(p.shape.cells);
    const lift = (h * cell) / 2 + cell * 1.1;
    return { sx: p.view.x, sy: p.view.y, ex: BX + c * cell + (w * cell) / 2, ey: BY + r * cell + (h * cell) / 2 + lift };
  },
  win: () => win(),
  get L() { return L; },
  get fall() { return fall; },
  fallTest: (n) => window.__dbg.fallTest(n),
  fallMove: (x, y) => fallMove(x, y), fallHardDrop: () => fallHardDrop(),
  // Deneme: yığının r. sırasını (alttan) tek renge boyayıp köprü çözümünü çalıştır
  // Tanıtım: yığındaki bir kareyi boya (r üstten, c soldan), ardından grup çözümlemesini çalıştır (zincirler dahil)
  paint(r, c, color) { const b = fall && fall.grid[r] && fall.grid[r][c]; if (b && !b.kind && !b.power) { b.color = color; b.s.texture = tex[color]; } },
  async resolve() { busy = true; await bridgeResolve(); busy = false; },
  fever: () => startFever(),
  power(r, c, kind, dir = 'h') { const b = fall && fall.grid[r] && fall.grid[r][c]; if (!b) return; b.s.destroy(); fall.grid[r][c] = null; makePower(r, c, kind, dir); },
  get rows() { return L && L.rows; },
  // Tanıtım: yığının üst yüzeyinde, tek blokla en büyük renk grubunu (≥min) oluşturacak yeri bulur; blok yukarıdan
  // düşüp oraya oturur ve grup çözümlemesi (zincirler, güçler) çalışır. Bulamazsa false döner.
  async autoPop(min = 8) {
    if (!fall || busy) return false;
    const G = fall.grid, R = L.rows, C = L.cols;
    const colorOf = (r, c) => { const b = G[r] && G[r][c]; return b && !b.kind && !b.power ? b.color : null; };
    const cols = [...new Set(G.flat().filter((b) => b && !b.kind && !b.power && /^c\d$/.test(b.color)).map((b) => b.color))];
    // Önce tek blok, olmazsa üst üste 2–3 blok (dikey parça gibi) dene; en küçük parçayla en büyük grup
    let best = null;
    for (let h = 1; h <= 3 && !(best && best.n >= min); h++) {
      for (let c = 0; c < C; c++) {
        let r0 = 0; while (r0 < R && !G[r0][c]) r0++;
        if (r0 - h < 1) continue;
        const stack = Array.from({ length: h }, (_, i) => [r0 - 1 - i, c]);
        for (const col of cols) {
          const seen = new Set(stack.map(([y, x]) => y * C + x)), q = stack.slice();
          while (q.length) {
            const [y, x] = q.pop();
            for (const [dy, dx] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
              const ny = y + dy, nx = x + dx, k = ny * C + nx;
              if (ny < 0 || nx < 0 || ny >= R || nx >= C || seen.has(k) || colorOf(ny, nx) !== col) continue;
              seen.add(k); q.push([ny, nx]);
            }
          }
          if (!best || seen.size > best.n || (best.h > h && seen.size >= min)) best = { stack, col, n: seen.size, h };
        }
      }
    }
    if (!best || best.n < min) return false;
    const drops = best.stack.map(([r, c]) => { fallSetCell(r, c, best.col, null, -1); const bb = G[r][c]; const y1 = bb.s.y; bb.s.y = y1 - fall.m.cs * 6; return tween(bb.s, { y: y1 }, 0.22, Ease.inQuad); });
    Sound.place();
    await Promise.all(drops);
    Haptics.light();
    busy = true; await bridgeResolve(); busy = false;
    return best.n;
  },
  // Tanıtım (kaydırma bölümü): en büyük eşleşmeyi yaratan kaydırmanın ekran noktaları (parmak gerçekten sürükler)
  swapBest() {
    if (!fall || !L.swap || busy) return null;
    const G = fall.grid, m = fall.m, wy = fall.world ? fall.world.y : 0;
    let best = null;
    for (let r = 0; r < L.rows; r++) for (let c = 0; c < L.cols; c++) for (const [dr, dc] of [[0, 1], [1, 0]]) {
      const r2 = r + dr, c2 = c + dc;
      if (r2 >= L.rows || c2 >= L.cols) continue;
      const a = G[r][c], b = G[r2][c2];
      if (!a || !b || a.power || b.power || a.kind || b.kind || a.color === b.color) continue;
      G[r][c] = b; G[r2][c2] = a;
      const n = findLines().reduce((t, k) => t + k.cells.length, 0);
      G[r][c] = a; G[r2][c2] = b;
      if (n && (!best || n > best.n)) best = { r, c, r2, c2, n };
    }
    if (!best) return null;
    const pt = (r, c) => ({ x: m.ox + (c + 0.5) * m.cs, y: m.oy + (r + 0.5) * m.cs + wy });
    return { from: pt(best.r, best.c), to: pt(best.r2, best.c2), n: best.n };
  },
  // Tanıtım (Blok Kaçışı): kapısına yolu açık bir bloğun ekran yolu (kapıdan dışarı kadar); en uzun yolu seçer
  escNext() {
    if (!esc || !esc.v3) return null;
    const lv = esc.lv, st = esc.st, W = lv.w;
    const occ = new Int32Array(lv.w * lv.h).fill(-1);
    for (const q of st.blocks) for (let i = 0; i < q.s; i++) for (let j = 0; j < q.s; j++) occ[(q.r + i) * W + q.c + j] = q.id;
    const inM = (r, c) => r >= 0 && c >= 0 && r < lv.h && c < lv.w && lv.mask[r][c] === '#';
    const gateAt = (b, r, c) => lv.gates.find((g, k) => {
      if (g.col !== b.col || st.locks[k] > 0) return false;
      const o = g.side === 'top' || g.side === 'bottom' ? c : r;
      if (o < g.at || o + b.s - 1 > g.at + g.len - 1) return false;
      return (g.side === 'top' && r === 0) || (g.side === 'bottom' && r + b.s === lv.h) || (g.side === 'left' && c === 0) || (g.side === 'right' && c + b.s === lv.w);
    });
    let best = null;
    for (const b of st.blocks) {
      const ok = (r, c) => { for (let i = 0; i < b.s; i++) for (let j = 0; j < b.s; j++) { if (!inM(r + i, c + j)) return false; const x = occ[(r + i) * W + c + j]; if (x >= 0 && x !== b.id) return false; } return true; };
      const prev = new Map([[b.r * 100 + b.c, null]]), q = [[b.r, b.c]];
      while (q.length) {
        const [r, c] = q.shift(), g = gateAt(b, r, c);
        if (g) {
          const p = []; let k = r * 100 + c;
          while (k !== null) { p.unshift([Math.floor(k / 100), k % 100]); k = prev.get(k); }
          if (!best || p.length > best.p.length) best = { b, p, g };
          break;
        }
        for (const [dr, dc] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
          const nr = r + dr, nc = c + dc;
          if (prev.has(nr * 100 + nc) || !ok(nr, nc)) continue;
          prev.set(nr * 100 + nc, r * 100 + c); q.push([nr, nc]);
        }
      }
    }
    if (!best) return null;
    const { b, p, g } = best, h = b.s / 2;
    const pts = p.map(([r, c]) => esc.v3.toScreen(c + h, r + h));
    const [er, ec] = p[p.length - 1], out = b.s + 1.5;
    const [dx, dz] = g.side === 'top' ? [0, -out] : g.side === 'bottom' ? [0, out] : g.side === 'left' ? [-out, 0] : [out, 0];
    pts.push(esc.v3.toScreen(ec + h + dx, er + h + dz));
    return pts.map(([x, y]) => ({ x, y }));
  },
  // Tanıtım (kaydırma bölümü): en büyük eşleşmeyi yaratan yatay kaydırmayı bulur ve yapar; patlama başlar (beklemez)
  swapShot() {
    if (!fall || !L.swap || busy) return false;
    const G = fall.grid;
    let best = null;
    for (let r = 0; r < L.rows; r++) for (let c = 0; c < L.cols - 1; c++) {
      const a = G[r][c], b = G[r][c + 1];
      if (!a || !b || a.power || b.power || a.kind || b.kind || a.color === b.color) continue;
      G[r][c] = b; G[r][c + 1] = a;
      const n = findLines().reduce((t, k) => t + k.cells.length, 0);
      G[r][c] = a; G[r][c + 1] = b;
      if (n && (!best || n > best.n)) best = { r, c, n };
    }
    if (!best) return false;
    const { r, c } = best, a = G[r][c], b = G[r][c + 1];
    G[r][c] = b; G[r][c + 1] = a;
    fall.gravP = Promise.all([tween(a.s, { x: fx0(c + 1) }, 0.09, Ease.outQuad), tween(b.s, { x: fx0(c) }, 0.09, Ease.outQuad)]);
    fall.swapBlocks = [a, b];
    swapResolve();
    return best.n;
  },
  async bridgeTest(fromBottom = 1, color = 'c4') {
    const r = L.rows - fromBottom;
    fall.grid[r].forEach((b) => { if (b && !b.kind) { b.color = color; b.s.texture = tex[color]; } });
    busy = true; await bridgeResolve(); busy = false;
  },
};
if (/promo/.test(location.search)) import('./promo.js');
window.__dbg = { get movesLeft() { return movesLeft; }, get esc() { return esc; }, escDragPath: (id, pts) => { const b = escBlock(id); esc.drag = { id, pid: 1, offX: 0, offZ: 0, px: b.c, pz: b.r }; for (const [x, z] of pts) { escDragTo(x, z); if (!esc.drag) break; } if (esc.drag) escRelease({ pointerId: 1 }); return escBlock(id); }, escDrag: (id, x, z) => { const b = escBlock(id); esc.drag = { id, pid: 1, offX: 0, offZ: 0, px: b.c, pz: b.r }; escDragTo(x, z); const d = esc.drag; if (d) escRelease({ pointerId: 1 }); return escBlock(id); }, escape: (no = 6) => { Store.set('seen_escape', ''); startLevel(no - 1); }, guct: () => {
  Store.set('seen_power_fall', ''); forceL = (n) => (n === 9 ? { ...getLevel(9), power: true } : null); startLevel(9);
  // Deneme: yığının üstüne hazır bir roket, bomba ve yıldırım koy
  setTimeout(() => { if (!fall) return; [[3, 'rocket'], [8, 'bomb'], [13, 'bolt']].forEach(([c, k]) => { let r = 0; while (r < L.rows && !fall.grid[r][c]) r++; if (r >= L.rows) return; fall.grid[r][c].s.destroy(); fall.grid[r][c] = null; makePower(r, c, k, 'v'); }); }, 800);
}, swapFire: (a, b) => swapResolve(() => swapFire(a, b)), findLines: () => findLines(), makePower: (r, c, k, d) => makePower(r, c, k, d), powerA: () => PA(), fallTest: async (n = 2) => {   // deneme: en üstteki n dolu satırı tamamlayıp patlat
  let top = 0; while (top < L.rows && !fall.grid[top].some(Boolean)) top++;
  for (let r = top; r < top + n; r++) for (let c = 0; c < L.cols; c++) { const b = fall.grid[r][c]; if (b) b.hp = 0; else fallSetCell(r, c, 'c1', null, -1); }
  fall.lastCol = 8; busy = true; await fallResolve(new Set()); busy = false;
}, guc: () => { Store.set('seen_power', ''); forceL = (n) => (n === 11 ? POWER_DEMO() : null); startLevel(11); }, kazi: () => { Store.set('seen_dig', ''); forceL = (n) => (n === 11 ? DIG_DEMO() : null); startLevel(11); }, app, addScore, fireOn: (c = 3) => { combo = c; streak = c; if (!fire) { fire = true; enterFire(); } renderCombo(); }, fireOff: () => { combo = 0; exitFire(); renderCombo(); }, openFinale, timer: { get left() { return timeLeft; }, set: (v) => { timeLeft = v; renderClock(); } }, win: () => win(), get streakN() { return streakN; }, get freeB() { return freeB; }, gameOver: (r) => checkGameOver(r || "stack"), get lifeAtRisk() { return lifeAtRisk; }, get levelN() { return levelN; }, get L() { return L; }, get grid() { return grid; }, get tray() { return tray; }, get goals() { return goals; }, place, canPlace, newGame, startLevel, openMap, get score() { return score; }, get fall() { return fall; }, island, fallMove: (x, y) => fallMove(x, y), fallRotate: () => fallRotate(), fallHardDrop: () => fallHardDrop() };
// Oyun açıldı: canlı güncelleme paketin sağlam olduğunu bildirir ve yeni paket var mı bakar (yalnız uygulamada)
canliGuncelleme();
