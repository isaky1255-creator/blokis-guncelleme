// Canlı güncelleme (mağaza sürümü çıkarmadan): oyunun web dosyaları GitHub'daki depodan yeni paket olarak iner.
// Akış: açılıştan biraz sonra surum.json okunur → daha yeni paket varsa arka planda indirilir → oyun bir sonraki
// açılışında (uygulama kapatılıp açılınca) yeni paketle başlar. Oyun ortasında yeniden yükleme yapılmaz.
// Yeni paket açılışta bozulursa (basla() çağrılamazsa) eklenti kendiliğinden önceki sağlam pakete döner.
// Paket hazırlama: tools/canli-guncelle.sh
import { WEB_SURUM } from './surum.js';

// Paketler GitHub'daki herkese açık depoda (isaky1255-creator/blokis-guncelleme); ulaşılamazsa site yedeğine bakılır.
const MANIFESTLER = [
  'https://raw.githubusercontent.com/isaky1255-creator/blokis-guncelleme/main/surum.json',
  'https://www.isteksoft.com/blokis/guncelleme/surum.json',
];
async function manifestOku() {
  let enIyi = null;
  for (const u of MANIFESTLER) {
    try {
      const r = await fetch(`${u}?t=${Date.now()}`, { cache: 'no-store' });
      if (!r.ok) continue;
      const m = await r.json();
      if (!enIyi || +m.surum > +enIyi.surum) enIyi = m;
    } catch { /* bu kaynak yok, diğerine bak */ }
  }
  return enIyi;
}

const C = window.Capacitor;
const aktif = () => !!(C && C.isNativePlatform && C.isNativePlatform() && C.isPluginAvailable && C.isPluginAvailable('CapacitorUpdater'));
const U = (m, o = {}) => C.nativePromise('CapacitorUpdater', m, o);

// "1.0.10" > "1.0.9" gibi sürüm karşılaştırması
const kars = (a, b) => {
  const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d; }
  return 0;
};

let son = 0;
async function denetle() {
  if (Date.now() - son < 6 * 3600e3) return;   // en fazla 6 saatte bir
  son = Date.now();
  try {
    const m = await manifestOku();
    if (!m || !(+m.surum > WEB_SURUM) || !m.url) return;
    // Paket daha yeni bir mağaza sürümü gerektiriyorsa (yeni yerel eklenti vb.) bu cihaz almaz
    if (m.enAz) { const { version } = await U('getBuiltinVersion'); if (kars(version, m.enAz) < 0) return; }
    const v = String(m.surum);
    const { bundles } = await U('list');
    let b = bundles.find((x) => x.version === v && x.status !== 'error');
    if (!b) b = await U('download', { url: m.url, version: v, ...(m.checksum ? { checksum: m.checksum } : {}) });
    await U('next', { id: b.id });
    await U('setMultiDelay', { delayConditions: [{ kind: 'kill' }] });   // yalnız yeniden açılışta uygulanır
  } catch (e) { console.warn('canlı güncelleme:', e && e.message ? e.message : e); }
}

// Oyun açılıp hazır olunca main.js çağırır: paketin sağlam olduğunu bildirir, sonra güncellemeye bakar
export function basla() {
  // Ayarlar ekranının altında sürüm + web paketi (canlı güncellemenin geldiğini görmek için)
  const yaz = (v) => { const el = document.getElementById('appVer'); if (el) el.textContent = `sürüm ${v} · paket ${WEB_SURUM}`; };
  yaz('1.0');
  if (!aktif()) return;
  U('getBuiltinVersion').then(({ version }) => yaz(version)).catch(() => {});
  U('notifyAppReady').catch(() => {});
  setTimeout(denetle, 5000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) setTimeout(denetle, 3000); });
}
