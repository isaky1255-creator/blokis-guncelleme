// Bölümler: 180 sabit bölüm (6 dünya × 30). Hepsi leveldata.js'de; her biri simülasyonla
// (sıradan ve iyi oyuncu botlarıyla yüzlerce kez oynatılarak) zorluk eğrisine oturtuldu.
// Desen harfleri: '.' boş, '#' dolu blok, 'g' elmaslı, 's' yıldızlı, 'h' kalpli, 'k' taçlı blok,
// engeller: 'i' buz (2 vuruş), 'c' zincir (3 vuruş), 'b' saatli bomba (sayaç bitmeden patlatılmalı),
// 'G'/'S'/'H' kafesli simge (2 vuruş), '1'/'2'/'3' renkli blok (aynı renk parçayla), 'm' yayılan yosun.
// Bölüm türleri: 5, 15, 25… düşen blok (tetris), 10'un katları özel bölüm, kalanlar blok bölümü (3'ün katları puan hedefli).
// Yıldız 11., kalp 23. bölümde; buz 31., zincir 61., bomba 91., kafes 121., renkli blok 141., yosun 151. bölümde tanıtılır.
// Aşağıdaki üretici yalnız günlük bulmaca için kullanılır.
import { LEVELS } from './leveldata.js';
import { ESC_LEVELS } from './escapedata.js';

export const TOTAL_LEVELS = LEVELS.length;

// Tekrarlanabilir rastgelelik
function rng(seed) {
  let s = seed * 9301 + 49297;
  return () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
}

// Büyük harf (G, S, H) kafesli simgedir; hedefte küçük harfiyle sayılır
const isIcon = (ch) => 'gshkGSH'.includes(ch);
// İki simge türlü sıra: türler dönüşümlü değişir, bazen tek tür
const KIND_SETS = [['g', 's'], ['s', 'h'], ['g', 'h'], ['g'], ['s', 'g'], ['h', 's'], ['h']];

// Dolu satır/sütunu simetriyi bozmadan aç: simge olmayan ayna çift bloğu boşalt
function openFullLines(g) {
  for (let y = 0; y < 8; y++) {
    if (g[y].some((ch) => ch === '.')) continue;
    const x = [3, 2, 1, 0].find((q) => !isIcon(g[y][q])) ?? 3; // hep simgeliyse bir simge çifti boşalır
    g[y][x] = g[y][7 - x] = '.';
  }
  for (let x = 0; x < 4; x++) {
    if (!g.every((row) => row[x] !== '.') && !g.every((row) => row[7 - x] !== '.')) continue;
    const y = [3, 4, 2, 5, 1, 6, 0, 7].find((q) => !isIcon(g[q][x])) ?? 3;
    g[y][x] = g[y][7 - x] = '.';
  }
}

// Sol yarıya yerleştirilip sağa yansıtılan blok kalıpları (dağınık nokta yerine düzenli şekiller)
const STAMPS = [
  [[0, 0], [1, 0], [0, 1], [1, 1]], [[0, 0], [1, 0], [2, 0]], [[0, 0], [0, 1], [0, 2]],
  [[0, 0], [1, 0], [0, 1]], [[0, 0], [1, 0], [1, 1]], [[0, 0], [1, 0]], [[0, 0], [0, 1]],
];

function generate(n, seed = n * 31 + 7, gemsOnly = false, kindSet = null) {
  const r = rng(seed);
  const score = !gemsOnly && n % 3 === 2;
  // Zorluk dalgalı artar: her 5 bölümde bir nefes aldıran daha kolay bölüm
  const breather = n % 5 === 4;
  const target = Math.min(36, 22 + Math.floor((n - 30) / 4)) - (breather ? 6 : 0);
  const g = Array.from({ length: 8 }, () => Array(8).fill('.'));
  let blocks = 0, tries = 0;
  while (blocks < target && tries++ < 300) {
    const st = STAMPS[Math.floor(r() * STAMPS.length)];
    const ox = Math.floor(r() * 4), oy = Math.floor(r() * 8);
    for (const [dx, dy] of st) {
      const x = ox + dx, y = oy + dy;
      if (x > 3 || y > 7 || g[y][x] !== '.') continue;
      g[y][x] = g[y][7 - x] = '#';
      blocks += 2;
    }
  }
  if (!score) {
    const kinds = kindSet || KIND_SETS[Math.floor(n / 3) % KIND_SETS.length];
    const pairs = Math.min(6, 3 + Math.floor((n - 30) / 12)) - (breather ? 1 : 0);
    // Simgeler ayna çiftleri halinde yalnız bloklu hücrelere
    const cand = [];
    for (let y = 0; y < 8; y++) for (let x = 0; x < 4; x++) if (g[y][x] === '#') cand.push([y, x]);
    for (let i = cand.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [cand[i], cand[j]] = [cand[j], cand[i]]; }
    for (let k = 0; k < Math.min(pairs, cand.length); k++) {
      const [y, x] = cand[k];
      g[y][x] = g[y][7 - x] = kinds[k % kinds.length];
    }
  }
  // Engeller: simgesiz bloklara, ayna çiftleri halinde
  const free = [];
  for (let y = 0; y < 8; y++) for (let x = 0; x < 4; x++) if (g[y][x] === '#') free.push([y, x]);
  for (let i = free.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [free[i], free[j]] = [free[j], free[i]]; }
  const put = (ch, count) => { for (let k = 0; k < count && free.length; k++) { const [y, x] = free.pop(); g[y][x] = g[y][7 - x] = ch; } };
  if (n >= 30) put('i', Math.min(3, 1 + Math.floor((n - 30) / 10)) - (breather ? 1 : 0));
  if (n >= 40 && !breather) put('c', Math.min(2, 1 + Math.floor((n - 40) / 15)));
  if (n >= 50 && n % 2 === 0 && !breather) put('b', 1);
  openFullLines(g);
  return g.map((row) => row.join(''));
}

// Desen kurallarını denetler; geliştirme sırasında hatalı bölümü konsolda bildirir
export function validate(n, layout, type) {
  const errs = [];
  layout.forEach((row, y) => {
    if (row.length !== 8) errs.push(`satır ${y} uzunluğu ${row.length}`);
    if ([...row].some((ch, x) => (ch === '.') !== (row[7 - x] === '.') || ch !== row[7 - x])) errs.push(`satır ${y} simetrik değil`);
    if (!row.includes('.')) errs.push(`satır ${y} dolu`);
  });
  for (let x = 0; x < 8; x++) if (layout.every((row) => row[x] !== '.')) errs.push(`sütun ${x} dolu`);
  const kinds = new Set([...layout.join('')].filter(isIcon).map((ch) => ch.toLowerCase()));
  if (type === 'score' && kinds.size) errs.push('puan bölümünde simge var');
  if (type === 'gems' && !kinds.size) errs.push('toplama bölümünde simge yok');
  if (kinds.size > 2) errs.push('ikiden fazla simge türü');
  return errs;
}

const ORDER = ['k', 'g', 's', 'h'];
const ICON = { g: 'gem', s: 'star', h: 'heart', k: 'crown' };

const goalsOf = (layout, type) => {
  if (type === 'score') return [];
  const counts = {};
  for (const ch of layout.join('')) if (isIcon(ch)) counts[ch.toLowerCase()] = (counts[ch.toLowerCase()] || 0) + 1;
  // Hedef çubuğu her zaman aynı sırada: taç, elmas, yıldız, kalp
  return ORDER.filter((k) => counts[k]).map((k) => ({ icon: ICON[k], count: counts[k] }));
};

export const isSpecial = (n) => (n + 1) % 10 === 0;
// Blok Kaçışı: her 6. bölüm (özel bölümler hariç) — 6, 12, 18, 24, 36 … 174
const ESC_BY_NO = new Map(ESC_LEVELS.map((e) => [e.n, e]));
export const isEscape = (n) => ESC_BY_NO.has(n + 1);
const SIDE = { t: 'top', b: 'bottom', l: 'left', r: 'right' };
// Blok Kaçışı süreleri üretilen verinin bu kadar katı (5 sn'ye yuvarlanır); yıldız eşikleri aynı oranda büyür
const ESC_TIME = 1.6;
export function getEscape(n) {
  const e = ESC_BY_NO.get(n + 1);
  const t = Math.round((e.t * ESC_TIME) / 5) * 5, k = t / e.t;
  return {
    escape: true, type: 'escape', goals: [], layout: [], timeLimit: t, star3: Math.round(e.s3 * k), star2: Math.round(e.s2 * k),
    esc: { w: e.w, h: e.h, mask: e.m, blocks: e.b.map(([r, c, s, k]) => ({ r, c, s, col: 'c' + k })), gates: e.g.map(([sd, at, len, k, lock]) => ({ side: SIDE[sd], at, len, col: 'c' + k, lock })) },
  };
}
// Süper zor bölümler: 25, 35, 45 … (16. bölümden sonra her 10'da bir; aradaki 10'lar özel bölüm)
export const isSuperHard = (n) => n + 1 >= 25 && (n + 1) % 10 === 5;

export function getLevel(n) {
  const d = LEVELS[Math.min(n, TOTAL_LEVELS - 1)];
  const type = d.t === 's' ? 'score' : 'gems';
  // Özel bölüm (her 10.): kum bölümünün daha kalabalık ve zor hâli
  // Bütün özel bölümler (10, 20, … 180) kum (tetris) bölümü; bölüm ilerledikçe zorlaşır
  if (d.t === 'k' && SAND) {
    const k = Math.max(0, Math.round((n + 1) / 10) - 1);   // 0..17
    // Seviye arttıkça: daha yüksek başlangıç yığını, daha hızlı yükselme ve düşüş, daha çok boşluklu sıralar,
    // süre sonunda daha sert hızlanma
    // Renk köprüsü: 16 sütun ekranı doldurur (satır sayısı ekran boyuna göre), 4 renk; ileride 5 renk
    const L = bridgeLevel(n, { cols: 16, depth: Math.min(9, 5 + Math.floor(k / 3)), ncol: k >= 9 ? 5 : 4,
      // Yükselme ve parça düşüşü: 10–50. bölümler 50. bölümün hızında (aynı), sonrası bölüm bölüm hızlanır
      rise: Math.max(1.8, 3.9 - 0.13 * Math.max(k, 4)), fallMs: Math.max(230, 430 - 11 * Math.max(k, 4)), time: 60 + k * 5, par: d.p,
      riseBoost: 1.2 + 0.04 * Math.max(k, 4), special: true });
    L.special = true;
    L.power = true;   // güçler: 2+ satır birden patlatınca roket/bomba/yıldırım doğar
    if (SWAP) {
      // Kaydırma kuralı: parça düşmez; yükselen yığında blok sağa-sola çekilir, aynı renkten 3+ sıra patlar
      Object.assign(L, { swap: true, cols: 8, group: 3, garbage: swapGarbage(n, 8, Math.min(7, 5 + Math.floor(k / 5)), L.ncol),
        rise: Math.max(2.2, 3.45 - 0.07 * Math.max(k, 4)), star2: Math.round((L.timeLimit * 18) / 100) * 100 });
    }
    return L;
  }
  const L = { type, layout: d.l, goals: goalsOf(d.l, type), par: d.p, bombTimer: d.b || 12 };
  if (d.t === 'k') L.special = true;
  // Özel bölüm süreli: süre bitmeden taçlar toplanmalı
  if (d.t === 'k') L.timeLimit = d.tl || Math.max(60, Math.min(180, Math.round((d.p * 5 + 25) / 5) * 5));
  if (type === 'score') L.target = d.s;
  if (d.m) L.moves = d.m;   // hamle sınırı (6. bölümden itibaren, özel bölümler hariç)
  if (d.k) L.dealK = d.k;   // parça dağıtımı daha az yardımcı (16. bölümden itibaren giderek)
  if (d.x) L.superHard = true;   // süper zor bölüm (25, 35, 45 …)
  // Güç oluşturma (roket/bomba/yıldırım) 3. bölümden itibaren bütün normal bölümlerde
  if (n >= 2) L.power = true;
  return L;
}

// Kum (hayatta kalma) bölümü: süre bitene kadar tepeye ulaşmadan dayan. Tahta alttan sürekli yükselir.
// cols/rows: tahta; depth: başlangıç yığını; rise: bir sıranın yükselme süresi (sn); fallMs: parçanın hücre başına düşüşü
// Dünyaya göre ek zorluklar (Orman yok → Okyanus buz → Çöl sayaçlı bomba → Uzay taş → Buzul/Volkan deprem).
// Özel bölümde hepsi daha sık. Değerler: yükselen sırada görünme olasılığı / deprem aralığı (sn)
function sandHazards(n, special) {
  const w = Math.floor(n / 30), sp = special ? 1 : 0;
  return {
    ice: w >= 1 ? Math.min(0.3, 0.12 + 0.03 * (w - 1) + 0.06 * sp) : 0,
    // Sayaçlı bomba: 10–79. bölümler arası sabit %20, sonrasında dünyaya göre artar
    bomb: n >= 9 && n <= 78 ? 0.2 : w >= 2 ? Math.min(0.3, 0.14 + 0.03 * (w - 2) + 0.06 * sp) : 0,
    timer: special ? 5 : 6,
    stone: w >= 3 ? Math.min(0.4, 0.18 + 0.06 * (w - 3) + 0.1 * sp) : 0,
    quake: w >= 4 ? (special ? 18 : 24) - (w - 4) * 3 : 0,
    quakeRows: w >= 5 && special ? 3 : 2,
  };
}
function sandLevel(n, { cols, rows, depth, rise, fallMs, time, par, holes = [2, 3], riseBoost = 1.2, special = false }) {   // holes: sıra başına boşluk (en az, en çok)
  let seed = (n + 1) * 7919;
  const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;   // tohumlu: aynı bölüm her açılışta aynı başlar
  const garbage = Array.from({ length: depth }, () => {
    const row = Array(cols).fill('x');
    const want = holes[0] + Math.floor(rnd() * (holes[1] - holes[0] + 1));
    for (let h = 0, guard = 0; h < want && guard < 50; guard++) { const c = Math.floor(rnd() * cols); if (row[c] === 'x') { row[c] = '.'; h++; } }
    return row.join('');
  });
  return { type: 'falling', falling: true, sand: true, cols, rows, garbage, goals: [], fallMs, par, timeLimit: time, rise, holes, riseBoost, hz: sandHazards(n, special) };
}

// Renk grubu: aynı renkten bu kadar blok birbirine değince patlar
const GROUP = 8;
// Özel bölüm kaydırma kuralıyla oynanır (false: düşen parça + 8'li renk grubu)
export const SWAP = true;
// Kaydırma bölümü başlangıç yığını: hiçbir yerde yatay ya da dikey 3 aynı renk yok; üst kenar engebeli
function swapGarbage(n, cols, depth, ncol) {
  let seed = (n + 1) * 104729;
  const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
  const h = Array.from({ length: cols }, () => depth - Math.floor(rnd() * 3));   // sütun yükseklikleri
  const g = Array.from({ length: depth }, () => Array(cols).fill('.'));
  for (let r = depth - 1; r >= 0; r--) for (let c = 0; c < cols; c++) {
    if (depth - r > h[c]) continue;
    const bad = new Set();
    if (c >= 2 && g[r][c - 1] !== '.' && g[r][c - 1] === g[r][c - 2]) bad.add(g[r][c - 1]);
    if (r <= depth - 3 && g[r + 1][c] === g[r + 2][c]) bad.add(g[r + 1][c]);
    if (c >= 1 && r <= depth - 2 && g[r][c - 1] !== '.' && g[r][c - 1] === g[r + 1][c - 1] && g[r + 1][c - 1] === g[r + 1][c]) bad.add(g[r][c - 1]);   // 2×2 kare
    let col;
    do col = String(Math.floor(rnd() * ncol)); while (bad.has(col));
    g[r][c] = col;
  }
  return g.map((r) => r.join(''));
}
// En az min hücrelik ilk aynı renk grubunu döndürür (yoksa null)
function groupIn(g, cols, min) {
  const R = g.length, seen = new Set();
  for (let r = 0; r < R; r++) for (let c0 = 0; c0 < cols; c0++) {
    const col = g[r][c0];
    if (col === '.' || seen.has(r * cols + c0)) continue;
    const comp = [], q = [[r, c0]];
    seen.add(r * cols + c0);
    while (q.length) {
      const [y, x] = q.pop();
      comp.push([y, x]);
      for (const [dy, dx] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) {
        const ny = y + dy, nx = x + dx;
        if (ny < 0 || ny >= R || nx < 0 || nx >= cols || seen.has(ny * cols + nx) || g[ny][nx] !== col) continue;
        seen.add(ny * cols + nx);
        q.push([ny, nx]);
      }
    }
    if (comp.length >= min) return comp;
  }
  return null;
}
// Renk köprüsü bölümü: aynı renkteki bloklar soldan sağa bağlanınca o renkteki bağlı grubun tamamı patlar.
// Başlangıç yığını aynı renk şeritlerinden oluşur (köprü kurmaya fırsat), tek sırada köprü olmaz (şerit en çok 5).
// garbage: renk numaraları ('0'…), satır sayısı oyunda ekran boyuna göre belirlenir (rows: 0 = otomatik)
function bridgeLevel(n, { cols, depth, ncol, rise, fallMs, time, par, riseBoost = 1.2, special = false }) {
  let seed = (n + 1) * 7919;
  const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
  const garbage = [];
  for (let i = 0; i < depth; i++) {
    let row = '', last = -1;
    while (row.length < cols) {
      let col = Math.floor(rnd() * ncol);
      if (col === last) col = (col + 1) % ncol;
      // Üstteki sırayla kısmen aynı renk: dikey bağlantılar köprüye yardım eder
      if (garbage.length && rnd() < 0.25) col = +garbage[garbage.length - 1][row.length] || col;
      const run = Math.min(cols - row.length, 1 + Math.floor(rnd() * 3));
      row += String(col).repeat(run);
      last = col;
    }
    garbage.push(row);
  }
  // Başta hazır grup kalmasın (8+ aynı renk): varsa ortasındaki bir hücrenin rengi değiştirilir
  const g = garbage.map((r) => [...r]);
  for (let guard = 0; guard < 400; guard++) {
    const comp = groupIn(g, cols, GROUP);
    if (!comp) break;
    const mid = comp[Math.floor(comp.length / 2)];
    g[mid[0]][mid[1]] = String((+g[mid[0]][mid[1]] + 1 + Math.floor(rnd() * (ncol - 1))) % ncol);
  }
  garbage.splice(0, garbage.length, ...g.map((r) => r.join('')));
  // ★★ hedefi: süreye göre puan (★ hayatta kal, ★★★ 3'lü zincir)
  return { type: 'falling', falling: true, sand: true, bridge: true, group: GROUP, star2: Math.round((time * 30) / 100) * 100, ncol, cols, rows: 0, garbage, goals: [], fallMs, par, timeLimit: time, rise, holes: [0, 0], riseBoost, hz: sandHazards(n, special) };
}

// ---------- Günlük bulmaca ----------
// Tarihe göre herkes için aynı tahta; hamle sınırı içinde tüm hedef simgeler toplanmalı.
export function dailySeed(d = new Date()) { return d.getFullYear() * 400 + d.getMonth() * 32 + d.getDate(); }
export function getDaily(d = new Date()) {
  const seed = dailySeed(d);
  const n = [34, 38, 42][seed % 3];           // zorluk günden güne değişir
  let layout = null;
  for (let k = 0; k < 20 && !layout; k++) {
    const cand = generate(n, seed * 7 + k * 131, true, KIND_SETS[(seed * 5 + 3) % KIND_SETS.length]);
    if (!validate(n, cand, 'gems').length) layout = cand;
  }
  const counts = {};
  for (const ch of layout.join('')) if (isIcon(ch)) counts[ch] = (counts[ch] || 0) + 1;
  const goals = ORDER.filter((k) => counts[k]).map((k) => ({ icon: ICON[k], count: counts[k] }));
  const total = goals.reduce((s, x) => s + x.count, 0);
  const moves = Math.ceil(8 + total * 1.3);
  return { type: 'gems', daily: true, seed, layout, goals, moves, par: Math.ceil(moves * 0.6), bombTimer: 12 };
}

// ---------- Düşen blok bölümleri: 5, 15, 25, 35… (her 10 bölümde bir) ----------
// 8×12 tahta, yukarıdan dörtlü şekiller düşer. Dipte boşluklu "çöp" satırlar ve içlerinde hedef simgeleri vardır.
// Her satırın boşlukları üstündeki satırın boşluklarından gelir: hiçbir boşluk üstten kapalı değildir.
// Ayrı düşen blok bölümü yok: 5, 15, 25… normal bölüm; tetris (kum) yalnız 10'un katı özel bölümlerde
export const isFalling = () => false;
export const FALL_COLS = 8, FALL_ROWS = 12;
// Düşen blok bölümleri kum kuralıyla oynanır (false: klasik satır patlatma)
export const SAND = true;
const SAND_COLS = 15, SAND_ROWS = 24;
export function getFalling(n) {
  const d = LEVELS[Math.min(n, TOTAL_LEVELS - 1)];
  const counts = {};
  for (const ch of d.g.join('')) if (ICON[ch]) counts[ch] = (counts[ch] || 0) + 1;
  const goals = [{ icon: 'line', count: d.n }, ...ORDER.filter((q) => counts[q]).map((q) => ({ icon: ICON[q], count: counts[q] }))];
  // Kum bölümü: hedef süre bitene kadar dayanmak. Süre bölüm ilerledikçe uzar (5. bölüm 45 sn → 175. bölüm ~2,5 dk)
  const k = Math.max(0, Math.round((n + 1 - 5) / 10));
  if (SAND) return sandLevel(n, { cols: SAND_COLS, rows: SAND_ROWS, depth: Math.min(9, 5 + Math.floor(k / 4)), rise: Math.max(3, 5.5 - 0.15 * k),
    fallMs: Math.round(d.ms * 0.6), time: 45 + k * 6, par: d.p });
  // Düşüş, tasarım hızından %20 yavaş (oyuncuya daha rahat bir tempo)
  return { type: 'falling', falling: true, cols: FALL_COLS, rows: FALL_ROWS, garbage: d.g, goals, fallMs: Math.round(d.ms * 1.2), par: d.p };
}
