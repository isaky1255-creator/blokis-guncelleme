// Platforma özel küçük yardımcılar: kayıt, titreşim, paylaşım.
// Capacitor eklentileri varsa onları, yoksa tarayıcı API'lerini kullanır.

const Cap = () => window.Capacitor && window.Capacitor.Plugins ? window.Capacitor.Plugins : null;

export const Store = {
  get(key, fallback = null) {
    try {
      const v = localStorage.getItem('blok.' + key);
      return v === null ? fallback : v;
    } catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem('blok.' + key, String(value)); } catch { /* yok say */ }
    Backup.soon();
  },
  num(key, fallback = 0) {
    const n = Number(this.get(key, fallback));
    return Number.isFinite(n) ? n : fallback;
  },
};

// Kayıt yedeği (iOS): bütün 'blok.' anahtarları kısa bir gecikmeyle uygulamanın kalıcı klasörüne yazılır
// (SaveStore eklentisi, AppDelegate.swift). Geri yükleme index.html'deki açılış betiğinde yapılır.
export const Backup = {
  t: 0,
  soon() { clearTimeout(this.t); this.t = setTimeout(() => this.now(), 1500); },
  now() {
    clearTimeout(this.t);
    if (window.__restoring) { this.soon(); return; }   // açılışta geri yükleme bitmeden yedeğin üstüne yazılmasın
    // Uygulamanın kendi eklentisi Capacitor.Plugins'te listelenmez; doğrudan yerel çağrıyla ulaşılır
    const C = window.Capacitor;
    if (!C || !C.isNativePlatform || !C.isNativePlatform() || !C.nativePromise) return;
    const S = { save: (o) => C.nativePromise('SaveStore', 'save', o) };
    try {
      const o = {};
      for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (k && k.startsWith('blok.') && k !== 'blok.save') o[k] = localStorage.getItem(k); }
      o['blok.bk'] = '1';
      localStorage.setItem('blok.bk', '1');
      S.save({ data: JSON.stringify(o) }).catch(() => {});
    } catch { /* yok say */ }
  },
};
document.addEventListener('visibilitychange', () => { if (document.hidden) Backup.now(); });

export const Haptics = {
  // Ayarlardan kapatılabilir
  enabled: Store.get('haptics', '1') === '1',
  toggle() { this.enabled = !this.enabled; Store.set('haptics', this.enabled ? '1' : '0'); return this.enabled; },
  // Seçim değişimi: sürüklerken hücre geçişlerinde ince "tık"
  tick() {
    if (!this.enabled) return;
    const p = Cap();
    if (p && p.Haptics) { p.Haptics.selectionChanged().catch(() => {}); return; }
    if (navigator.vibrate) try { navigator.vibrate(4); } catch { /* yok say */ }
  },
  selectStart() { if (!this.enabled) return; const p = Cap(); if (p && p.Haptics) p.Haptics.selectionStart().catch(() => {}); },
  selectEnd() { if (!this.enabled) return; const p = Cap(); if (p && p.Haptics) p.Haptics.selectionEnd().catch(() => {}); },
  success() { this._notify('SUCCESS', [12, 40, 18]); },
  warning() { this._notify('WARNING', [20, 60, 20]); },
  error() { this._notify('ERROR', [40, 50, 40, 50, 60]); },
  _notify(type, fallback) {
    if (!this.enabled) return;
    const p = Cap();
    if (p && p.Haptics) { p.Haptics.notification({ type }).catch(() => {}); return; }
    if (navigator.vibrate) try { navigator.vibrate(fallback); } catch { /* yok say */ }
  },
  light() { this._impact('LIGHT', 8); },
  medium() { this._impact('MEDIUM', 18); },
  heavy() { this._impact('HEAVY', [30, 40, 60]); },
  _impact(style, fallback) {
    if (!this.enabled) return;
    const p = Cap();
    if (p && p.Haptics) {
      p.Haptics.impact({ style }).catch(() => {});
      return;
    }
    if (navigator.vibrate) {
      try { navigator.vibrate(fallback); } catch { /* yok say */ }
    }
  },
};

// Oyun sonu desenini paylaş. Native'de Capacitor Share + Filesystem, web'de Web Share API.
export async function shareImage(canvas, text) {
  const p = Cap();
  if (p && p.Share && p.Filesystem) {
    const data = canvas.toDataURL('image/png').split(',')[1];
    const file = await p.Filesystem.writeFile({ path: 'blokis.png', data, directory: 'CACHE' });
    await p.Share.share({ text, files: [file.uri] });
    return;
  }
  const blob = await new Promise((res) => canvas.toBlob(res, 'image/png'));
  const file = new File([blob], 'blokis.png', { type: 'image/png' });
  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    await navigator.share({ files: [file], text });
    return;
  }
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'blokis.png';
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

// Sıralamalar: iPhone'da Game Center, Android'de Google Play Games (ikisi de uygulamaya gömülü yerel köprü,
// JS'te aynı "GameCenter" adı ve yöntemleriyle). Oyun çevrimdışı oynanır; skorlar bağlıyken gönderilir.
const PLAT = (() => { const C = window.Capacitor; return C ? (C.getPlatform ? C.getPlatform() : C.platform) : 'web'; })();
export const RANK_PLATFORM = PLAT === 'ios' ? 'ios' : PLAT === 'android' ? 'android' : 'web';
export const LB = PLAT === 'android'
  ? { endless: 'CgkI46XZzKIHEAIQAg', stars: 'CgkI46XZzKIHEAIQAw', level: 'CgkI46XZzKIHEAIQBA' }   // Play Console › Skor tabloları
  : { endless: 'blokis_endless', stars: 'blokis_stars', level: 'blokis_level' };                // App Store Connect › Game Center
let gcPlugin = null;
const gc = () => {
  if (gcPlugin) return gcPlugin;
  const C = window.Capacitor;
  if (RANK_PLATFORM === 'web') return null;   // tarayıcıda sıralama yok
  gcPlugin = (C.Plugins && C.Plugins.GameCenter) || (C.registerPlugin ? C.registerPlugin('GameCenter') : null);
  return gcPlugin;
};
export const GameCenter = {
  signedIn: false,
  available() { return !!gc(); },
  // interactive: oturum yoksa giriş ekranını aç (Android; iPhone'da Apple kendi ekranını kendisi gösterir)
  async signIn(interactive = false) {
    const p = gc();
    if (!p) return false;
    try { const r = await p.signIn({ interactive }); this.signedIn = !!(r && r.authenticated); } catch { this.signedIn = false; }
    return this.signedIn;
  },
  submit(id, score) {
    const p = gc();
    if (!p || !this.signedIn || !(score > 0)) return;
    p.submitScore({ leaderboardId: id, score: Math.floor(score) }).catch(() => {});
  },
  // 'ok' | 'web' (tarayıcı) | 'nosign' (giriş yok) | 'fail'
  async show() {
    const p = gc();
    if (!p) return 'web';
    if (!this.signedIn && !(await this.signIn(true))) return 'nosign';
    try { await p.showLeaderboard({}); return 'ok'; } catch { return 'fail'; }
  },
};
