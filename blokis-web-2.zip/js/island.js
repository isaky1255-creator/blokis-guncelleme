// Blok Adası: ana sayfada adım adım inşa edilen, 360° döndürülebilen 3D voksel yapılar.
// Çizim tek bir GPU örgüsüyle yapılır (binlerce blok tek seferde). Her yüzün köşeleri komşu bloklara
// göre ayrı ayrı kararır (köşe ortam gölgesi), yan yüzler sabit bir ışığa göre tonlanır, yapılar
// adaya gölge düşürür. Açıya bağlı olmayan her şey önceden hesaplanır; döndürürken yalnız
// yansıtma ve sıralama yapılır.
import { Container, Graphics, Mesh, Geometry, Shader } from '../lib/pixi.min.mjs';
import { tween, Ease } from './tween.js';

export const BUILD_STEPS = 8;

// ---------- Yardımcılar ----------
const hex = (s) => parseInt(s.slice(1), 16);
const hash = (x, y, z) => {
  let h = (x * 374761393 + y * 668265263 + z * 1274126177) | 0;
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  return ((h ^ (h >>> 16)) >>> 0) / 4294967295;
};
const pick = (arr, x, y, z) => arr[Math.floor(hash(x, y, z) * arr.length) % arr.length];
const K = (x, y, z) => ((x + 128) * 256 + (y + 128)) * 256 + (z + 128);   // sayısal anahtar (hızlı arama)

// ---------- Model kurucu ----------
function makeModel() {
  const vox = new Map();
  const m = {
    vox, fx: [],
    set(x, y, z, c, step) {
      x = Math.round(x); y = Math.round(y); z = Math.round(z);
      const col = typeof c === 'function' ? c(x, y, z) : c;
      if (col == null) return;
      vox.set(K(x, y, z), { x, y, z, c: typeof col === 'string' ? hex(col) : col, step });
    },
    del(x, y, z) { vox.delete(K(x, y, z)); },
    has(x, y, z) { return vox.has(K(x, y, z)); },
    box(x0, x1, y0, y1, z0, z1, c, step) { for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) m.set(x, y, z, c, step); },
    ring(x0, x1, y0, y1, z0, z1, c, step) {
      for (let x = x0; x <= x1; x++) for (let y = y0; y <= y1; y++) for (let z = z0; z <= z1; z++) if (x === x0 || x === x1 || y === y0 || y === y1) m.set(x, y, z, c, step);
    },
    disk(cx, cy, r, z, c, step, hollow = -1) {
      for (let x = Math.floor(cx - r - 1); x <= Math.ceil(cx + r + 1); x++) for (let y = Math.floor(cy - r - 1); y <= Math.ceil(cy + r + 1); y++) {
        const d = Math.hypot(x - cx, y - cy);
        if (d <= r + 0.3 && d > hollow + 0.3) m.set(x, y, z, c, step);
      }
    },
    cyl(cx, cy, r, z0, z1, c, step, hollow = -1) { for (let z = z0; z <= z1; z++) m.disk(cx, cy, typeof r === 'function' ? r(z) : r, z, c, step, hollow); },
    ball(cx, cy, cz, r, c, step, sq = 1.1) {
      for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) for (let z = Math.floor(cz - r); z <= Math.ceil(cz + r); z++) {
        if (Math.hypot(x - cx, y - cy, (z - cz) * sq) <= r + 0.25) m.set(x, y, z, c, step);
      }
    },
    line(x0, y0, z0, x1, y1, z1, c, step) {
      const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), Math.abs(z1 - z0), 1);
      for (let i = 0; i <= n; i++) m.set(x0 + ((x1 - x0) * i) / n, y0 + ((y1 - y0) * i) / n, z0 + ((z1 - z0) * i) / n, c, step);
    },
  };
  return m;
}

// ---------- Renk paletleri ----------
const P = {
  grass: ['#62cf5b', '#5cc955', '#68d561', '#57c251'],
  grassSide: ['#4fb64a', '#4aad45'],
  dirt: ['#9c6439', '#915a32', '#a46b3e', '#8a5530'],
  rock: ['#827c8a', '#8a8592', '#76717e', '#8f8a97'],
  wood: ['#c08447', '#b77b40', '#c98e51'],
  woodDark: ['#7d4c24', '#71431f', '#87542a'],
  bark: ['#6e4524', '#7a4d29', '#62401f', '#734a27'],
  leaf: ['#3fae4a', '#48b852', '#37a142', '#52c25b', '#2f9a3c'],
  roof: ['#e05238', '#d6482f', '#e85e44'],
  roofDark: ['#b83a26', '#c0402b'],
  stone: ['#bdb8c6', '#b0abba', '#c8c3d0', '#a6a1b0'],
  mortar: '#8f8a98',
  sand: ['#f2cf7a', '#ebc56c', '#f6d887', '#e5be66'],
  sandDark: ['#d9ad5a', '#cfa352'],
  white: ['#f4f6fb', '#eaedf4', '#ffffff'],
  ice: ['#c4ebff', '#aee0fb', '#d6f3ff', '#a2d8f6'],
  snow: ['#f4faff', '#eaf4fc', '#ffffff'],
  glass: '#8fe4ff', glassHi: '#d4f6ff',
  water: ['#3aa0f0', '#47acf6', '#3194e6'],
  metal: ['#9aa1b4', '#a8afc2', '#8d94a8'],
};

// ---------- Yüzen ada ----------
function addIsland(m, top = P.grass, side = P.grassSide, R = 15.5) {
  const topF = (x, y, z) => pick(top, x, y, z);
  m.disk(0, 0, R, 0, topF, -1);
  m.disk(0, 0, R, -1, (x, y, z) => pick(side, x, y, z), -1);
  m.disk(0, 0, R - 0.5, -2, (x, y, z) => pick(side, x, y, z), -1);
  // üstte neredeyse dik toprak yamacı, aşağıda giderek daralan kaya (alttan bakınca katmanlar görünsün)
  const layers = [[R - 0.3, P.dirt], [R - 0.6, P.dirt], [R - 0.9, P.dirt], [R - 1.3, P.dirt], [R - 1.8, P.rock], [R - 2.4, P.rock], [R - 3.1, P.rock], [R - 4, P.rock], [R - 5.1, P.rock], [R - 6.4, P.rock], [R - 8, P.rock], [R - 10, P.rock]];
  layers.forEach(([r, pal], i) => {
    const z = -3 - i;
    m.disk(0, 0, r, z, (x, y, zz) => pick(pal, x, y, zz), -1);
    for (let a = 0; a < Math.PI * 2; a += 0.35) {
      if (hash(Math.round(a * 10), i, 3) < 0.45) m.set(Math.cos(a) * (r + 0.8), Math.sin(a) * (r + 0.8), z, pick(pal, i, Math.round(a * 10), z), -1);
    }
  });
  for (let z = -15; z >= -21; z--) m.disk(0.3, -0.3, Math.max(0.2, (z + 22) * 0.6), z, (x, y, zz) => pick(P.rock, x, y, zz), -1);
  for (const [x, y, h] of [[9, 3, 3], [-7, 7, 3], [4, -10, 2], [-9, -5, 2]]) for (let k = 0; k < h; k++) m.set(x, y, -11 - k, pick(P.rock, x, y, k), -1);
}
function flowers(m, spots, colors = ['#ff6b8a', '#ffd23a', '#ffffff', '#b77bff', '#ff9a3a']) {
  for (const [x, y] of spots) { m.set(x, y, 1, '#3c9a40', -1); m.set(x, y, 2, pick(colors, x, y, 2), -1); }
}
function bush(m, x, y, r = 1.6, step = -1) { m.ball(x, y, 1.5, r, (a, b, c) => pick(P.leaf, a, b, c), step, 1.3); }
function rockPile(m, x, y) { m.set(x, y, 1, pick(P.rock, x, y, 1), -1); m.set(x + 1, y, 1, pick(P.rock, x + 1, y, 1), -1); m.set(x, y + 1, 1, pick(P.rock, x, y + 1, 1), -1); m.set(x, y, 2, pick(P.rock, x, y, 2), -1); }
function mushroom(m, x, y, step) { m.set(x, y, 1, '#f4ead8', step); m.set(x, y, 2, '#e2392f', step); m.set(x + 1, y, 2, '#e2392f', step); m.set(x, y + 1, 2, '#ffffff', step); }
// Pencere: duvar düzleminde (axis 'x' → x sabit, 'y' → y sabit) çerçeveli cam
function windowAt(m, axis, fixed, a0, z0, w, h, step, frame = '#6c411d') {
  for (let a = a0 - 1; a <= a0 + w; a++) for (let z = z0 - 1; z <= z0 + h; z++) {
    const edge = a === a0 - 1 || a === a0 + w || z === z0 - 1 || z === z0 + h;
    const mid = a === a0 + Math.floor((w - 1) / 2) && w > 2;
    const col = edge ? frame : mid ? frame : (z === z0 + h - 1 && a === a0 ? P.glassHi : P.glass);
    if (axis === 'x') m.set(fixed, a, z, col, step); else m.set(a, fixed, z, col, step);
  }
}
function lantern(m, x, y, z, step) {
  m.set(x, y, z, '#3a2a1a', step); m.set(x, y, z + 1, '#ffd23a', step); m.set(x, y, z + 2, '#3a2a1a', step);
}

// ---------- 1) Ağaç Ev ----------
function treeHouse(m) {
  addIsland(m);
  flowers(m, [[11, -3], [12, 2], [-10, 8], [-12, -4], [6, 12], [-3, -12], [9, 9], [-8, -10], [13, -6]]);
  bush(m, -11, 4, 1.8); bush(m, 10, -9, 1.6); rockPile(m, -9, -8); rockPile(m, 12, 6);
  const bark = (x, y, z) => ((x + y) % 3 === 0 ? pick(['#5a381c', '#62401f'], x, y, z) : pick(P.bark, x, y, z));
  // 0: kökler ve gövdenin altı
  for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1], [0.7, 0.7], [-0.7, 0.7], [0.7, -0.7], [-0.7, -0.7]]) {
    for (let k = 2; k <= 5; k++) m.set(-0.5 + dx * k, -0.5 + dy * k, k <= 3 ? 2 : 1, bark, 0);
  }
  m.box(-2, 1, -2, 1, 1, 10, bark, 0);
  // 1: dikmeler, kirişler ve platform
  for (const [x, y] of [[-8, -8], [6, -8], [-8, 6], [6, 6]]) m.box(x, x + 1, y, y + 1, 1, 9, (a, b, c) => pick(P.woodDark, a, b, c), 1);
  for (const [x0, y0, x1, y1] of [[-7, -7, -2, -2], [6, -7, 1, -2], [-7, 6, -2, 1], [6, 6, 1, 1]]) m.line(x0, y0, 5, x1, y1, 9, (a, b, c) => pick(P.woodDark, a, b, c), 1);
  m.box(-8, 7, -8, 7, 10, 10, (x, y, z) => (y % 3 === 0 ? pick(P.woodDark, x, y, z) : pick(P.wood, x, y, z)), 1);
  m.box(-2, 1, -2, 1, 10, 10, bark, 1);
  // 2: gövdenin üstü, duvarlar ve kapı
  m.box(-2, 1, -2, 1, 11, 26, bark, 2);
  const plank = (x, y, z) => (z % 2 ? pick(P.wood, x, y, z) : pick(['#d49a5c', '#cb9154'], x, y, z));
  m.ring(-6, 5, -6, 5, 11, 17, plank, 2);
  for (const [x, y] of [[-6, -6], [5, -6], [-6, 5], [5, 5]]) m.box(x, x, y, y, 11, 17, (a, b, c) => pick(P.woodDark, a, b, c), 2);
  for (let z = 11; z <= 15; z++) for (const y of [-1, 0, 1]) m.set(5, y, z, z === 15 ? '#5a3518' : '#6e4120', 2);
  m.set(5, 1, 13, '#ffd23a', 2);
  // 3: pencereler ve korkuluk
  windowAt(m, 'y', -6, -3, 13, 3, 3, 3); windowAt(m, 'y', 5, -3, 13, 3, 3, 3); windowAt(m, 'x', -6, -2, 13, 3, 3, 3);
  for (let i = -8; i <= 7; i++) for (const [x, y] of [[i, -8], [i, 7], [-8, i], [7, i]]) {
    if (x === 7 && Math.abs(y) <= 1) continue;
    if (i % 3 === 0) m.set(x, y, 11, pick(P.woodDark, x, y, 11), 3);
    m.set(x, y, 12, pick(P.wood, x, y, 12), 3);
  }
  // 4-5: beşik çatı (sırt x ekseni boyunca) ve baca
  const roofTile = (x, y, z) => ((z + Math.floor(x / 2)) % 2 ? pick(P.roof, x, y, z) : pick(P.roofDark, x, y, z));
  for (let k = 0; k <= 7; k++) {
    const step = k < 4 ? 4 : 5;
    const z = 18 + k;
    for (let x = -8; x <= 7; x++) { m.set(x, -8 + k, z, roofTile, step); m.set(x, 7 - k, z, roofTile, step); }
    if (k > 0) for (let y = -8 + k + 1; y <= 7 - k - 1; y++) { m.set(-7, y, z, plank, step); m.set(6, y, z, plank, step); }
  }
  m.box(-8, 7, -1, 0, 25, 25, (x, y, z) => pick(P.roofDark, x, y, z), 5);
  m.box(3, 4, -5, -4, 20, 28, (x, y, z) => ((z % 2) ? pick(P.stone, x, y, z) : P.mortar), 5);
  m.box(2, 5, -6, -3, 29, 29, '#7a7584', 5);
  m.fx.push({ kind: 'smoke', x: 3.5, y: -4.5, z: 30, step: 5 });
  // 6: yaprak kubbesi ve meyveler
  const leaf = (x, y, z) => (z > 33 && hash(x, y, z) > 0.5 ? '#6fd36a' : pick(P.leaf, x, y, z));
  m.ball(-0.5, -0.5, 32, 7, leaf, 6, 1.25);
  m.ball(-6, 3, 29, 4.2, leaf, 6, 1.2);
  m.ball(5, 3, 30, 4, leaf, 6, 1.2);
  m.ball(-3, -6, 29.5, 4, leaf, 6, 1.2);
  for (const [x, y, z] of [[4, 6, 30], [-7, 6, 29], [6, -3, 31], [-4, -9, 29], [2, 5, 35], [-8, 0, 31]]) m.set(x, y, z, '#e2392f', 6);
  // 7: merdiven, fenerler, patika, mantarlar ve salıncak
  for (let z = 1; z <= 10; z++) { m.set(9, -1, z, pick(P.woodDark, 9, -1, z), 7); m.set(9, 2, z, pick(P.woodDark, 9, 2, z), 7); if (z % 2 === 0) { m.set(9, 0, z, '#c98e51', 7); m.set(9, 1, z, '#c98e51', 7); } }
  for (const [x, y] of [[11, 0], [12, 1], [13, 0], [10, -1]]) m.set(x, y, 1, pick(['#cfcad6', '#bdb8c6'], x, y, 1), 7);
  lantern(m, -8, -8, 11, 7); lantern(m, 7, 7, 11, 7);
  mushroom(m, -10, -2, 7); mushroom(m, 4, 10, 7);
  for (let z = 4; z <= 9; z++) { m.set(-4, 9, z, '#d9c49a', 7); m.set(-1, 9, z, '#d9c49a', 7); }
  m.box(-4, -1, 9, 9, 3, 3, (x, y, z) => pick(P.wood, x, y, z), 7);
}

// ---------- 2) Deniz Feneri ----------
function lighthouse(m) {
  addIsland(m, ['#7fd29c', '#74c892', '#89dba6'], ['#5fb880', '#58af78']);
  m.disk(8, -8, 3.6, 0, (x, y, z) => pick(P.water, x, y, z), -1);
  m.set(7, -9, 1, '#4cbd56', -1); m.set(9, -7, 1, '#4cbd56', -1); m.set(9, -7, 2, '#ff8ab0', -1);
  flowers(m, [[-11, 6], [-6, 12], [12, 6], [-13, -2]], ['#ffffff', '#ffd23a']);
  // 0: kayalık yamaç
  m.cyl(0, 0, (z) => 8.5 - z * 0.9, 1, 5, (x, y, z) => pick(P.rock, x, y, z), 0);
  m.cyl(0, 0, 5.6, 6, 6, (x, y, z) => ((x + y) % 2 ? '#d8d3de' : '#c8c3d0'), 0);
  // 1-4: kule (yukarı doğru incelir, kırmızı-beyaz bantlar)
  const R = (z) => 5 - (z - 7) * 0.045;
  const band = (x, y, z) => (Math.floor((z - 7) / 6) % 2 ? pick(['#e2392f', '#d4302a', '#ea4638'], x, y, z) : pick(P.white, x, y, z));
  [[7, 12, 1], [13, 18, 2], [19, 24, 3], [25, 30, 4]].forEach(([z0, z1, s]) => m.cyl(0, 0, R, z0, z1, band, s));
  for (const [z, a] of [[10, 0], [16, 1.6], [22, 3.2], [28, 4.7]]) {
    const x = Math.round(Math.cos(a) * 4.9), y = Math.round(Math.sin(a) * 4.9), s = Math.min(4, Math.floor((z - 7) / 6) + 1);
    m.set(x, y, z, P.glass, s); m.set(x, y, z + 1, '#3a3f55', s);
  }
  m.set(5, 0, 7, '#5a3518', 1); m.set(5, 0, 8, '#5a3518', 1); m.set(5, 1, 7, '#5a3518', 1); m.set(5, 1, 8, '#5a3518', 1);
  // 5: balkon ve korkuluk
  m.disk(0, 0, 6, 31, (x, y, z) => pick(['#3a3f55', '#444a63'], x, y, z), 5);
  m.disk(0, 0, 6, 32, (x, y, z) => ((x + y) % 2 ? '#2c3044' : null), 5, 5.2);
  m.disk(0, 0, 6, 33, '#2c3044', 5, 5.2);
  // 6: fener odası
  for (let z = 32; z <= 36; z++) m.disk(0, 0, 3.4, z, (x, y, zz) => ((x === 0 || y === 0 || zz === 36) ? '#2c3044' : zz < 34 ? '#ffe680' : '#fff3b0'), 6, 2.2);
  m.cyl(0, 0, 2.2, 32, 35, '#fff6c8', 6);
  // 7: kubbe, tepe ve bekçi evi
  m.cyl(0, 0, (z) => 4 - (z - 37) * 0.9, 37, 40, (x, y, z) => pick(P.roof, x, y, z), 7);
  m.set(0, 0, 41, '#ffd23a', 7); m.set(0, 0, 42, '#3a3f55', 7); m.set(0, 0, 43, '#3a3f55', 7);
  m.box(6, 13, 2, 8, 1, 5, (x, y, z) => pick(P.white, x, y, z), 7);
  for (let k = 0; k <= 4; k++) for (let x = 5; x <= 14; x++) { m.set(x, 1 + k, 6 + k, pick(P.roof, x, 1 + k, 6 + k), 7); m.set(x, 9 - k, 6 + k, pick(P.roof, x, 9 - k, 6 + k), 7); }
  m.box(5, 14, 5, 5, 10, 10, (x, y, z) => pick(P.roofDark, x, y, z), 7);
  m.set(13, 4, 1, '#5a3518', 7); m.set(13, 4, 2, '#5a3518', 7); m.set(13, 4, 3, '#5a3518', 7);
  windowAt(m, 'x', 13, 6, 2, 2, 2, 7);
  m.box(10, 10, 7, 7, 8, 11, (x, y, z) => pick(P.stone, x, y, z), 7);
}

// ---------- 3) Piramit ----------
function pyramid(m) {
  addIsland(m, P.sand, P.sandDark);
  m.disk(-9, 9, 3.2, 0, (x, y, z) => pick(P.water, x, y, z), -1);
  for (const [px, py, h] of [[-12, 6, 8], [-6, 12, 7], [11, -9, 7]]) {
    for (let z = 1; z <= h; z++) m.set(px + (z > h - 3 ? 1 : 0), py, z, pick(P.bark, px, py, z), -1);
    const tx = px + 1, tz = h + 1;
    for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [-1, -1], [1, -1], [-1, 1]]) for (let k = 1; k <= 3; k++) m.set(tx + dx * k, py + dy * k, tz - (k > 2 ? 1 : 0), pick(P.leaf, tx + dx * k, py + dy * k, tz), -1);
    m.set(tx, py, tz, '#4cbd56', -1); m.set(tx, py, tz - 1, '#8a5a2b', -1);
  }
  const brick = (x, y, z) => ((x + y + (z % 2 ? 1 : 0)) % 4 === 0 ? pick(P.sandDark, x, y, z) : pick(P.sand, x, y, z + 7));
  const layer = (r, z0, z1, step) => { for (let z = z0; z <= z1; z++) m.box(-r, r, -r, r, z, z, brick, step); };
  layer(10, 1, 3, 0); layer(9, 4, 6, 1); layer(8, 7, 9, 2); layer(7, 10, 12, 2);
  layer(6, 13, 15, 3); layer(5, 16, 18, 4); layer(4, 19, 21, 4); layer(3, 22, 24, 5); layer(2, 25, 26, 5); layer(1, 27, 28, 5);
  // merdiven (ön yüz, +x) ve giriş
  for (let z = 1; z <= 24; z++) { const x = 11 - Math.ceil(z / 3); for (const y of [-1, 0, 1]) m.set(x, y, z, z % 3 === 0 ? '#e9c372' : '#f4d68a', 3); }
  m.box(10, 11, -2, 2, 1, 5, '#c99a4c', 3); m.box(11, 11, -1, 1, 1, 3, '#3b2a14', 3); m.box(11, 11, -2, 2, 5, 5, '#e8c06a', 3);
  // 6: altın tepe taşı
  m.box(-1, 0, -1, 0, 29, 29, '#ffd23a', 6); m.set(0, 0, 30, '#ffe680', 6); m.set(-1, -1, 30, '#ffe680', 6);
  // 7: dikilitaşlar
  for (const [x, y] of [[9, 11], [13, -1], [-12, -9]]) {
    m.box(x, x + 1, y, y + 1, 1, 9, (a, b, c) => (c % 3 === 0 ? '#c99a4c' : pick(P.sand, a, b, c)), 7);
    m.set(x, y, 10, '#ffd23a', 7); m.set(x + 1, y + 1, 10, '#ffd23a', 7);
  }
}

// ---------- 4) Roket Üssü ----------
function rocket(m) {
  addIsland(m, ['#9a95aa', '#a39eb3', '#8e89a0'], ['#7f7a90', '#77728a']);
  flowers(m, [[-12, 7], [12, -7]], ['#ffd23a']);
  // 0: rampa ve uyarı çizgileri
  m.cyl(0, 0, 8.5, 1, 1, (x, y, z) => (Math.hypot(x, y) > 7.4 ? ((Math.floor((Math.atan2(y, x) + Math.PI) * 3) % 2) ? '#ffd23a' : '#2c3044') : pick(['#5a5f78', '#646a84'], x, y, z)), 0);
  m.box(-2, 2, -2, 2, 1, 1, '#2a2e40', 0);
  // 1: kafes iskele (arkada) ve kol
  for (let z = 2; z <= 34; z++) for (const [x, y] of [[-9, -3], [-9, 2], [-6, -3], [-6, 2]]) m.set(x, y, z, '#e2392f', 1);
  for (let z = 4; z <= 34; z += 4) { m.box(-9, -6, -3, -3, z, z, '#c9312a', 1); m.box(-9, -6, 2, 2, z, z, '#c9312a', 1); m.box(-9, -9, -3, 2, z, z, '#c9312a', 1); }
  m.box(-5, -4, -1, 0, 26, 26, '#c9312a', 1);
  // 2-4: gövde (panel çizgileri, bantlar, pencereler)
  const body = (x, y, z) => (z % 6 === 0 ? pick(P.metal, x, y, z) : pick(P.white, x, y, z));
  m.cyl(0, 0, 3.6, 2, 10, body, 2);
  m.cyl(0, 0, 3.6, 11, 20, (x, y, z) => (z === 15 || z === 16 ? '#2c3044' : body(x, y, z)), 3);
  m.cyl(0, 0, 3.6, 21, 28, body, 4);
  for (const z of [22, 25]) { m.set(4, 0, z, P.glass, 4); m.set(4, 1, z, P.glass, 4); m.set(4, 0, z + 1, '#3a6cf0', 4); m.set(4, 1, z + 1, '#3a6cf0', 4); }
  for (let z = 6; z <= 9; z++) for (const y of [-1, 0, 1]) m.set(4, y, z, y === 0 ? '#ff3b55' : '#ffffff', 2);
  // 5: kanatçıklar
  for (const [dx, dy] of [[1, 0], [-1, 0], [0, 1], [0, -1]]) for (let k = 4; k <= 6; k++) for (let z = 2; z <= 9 - (k - 4) * 3; z++) m.set(dx * k, dy * k, z, pick(P.roof, k, dx, z), 5);
  // 6: burun konisi
  m.cyl(0, 0, (z) => 3.6 - (z - 29) * 0.6, 29, 34, (x, y, z) => pick(P.roof, x, y, z), 6);
  m.set(0, 0, 35, '#ffd23a', 6); m.set(0, 0, 36, '#cfd3dd', 6);
  // 7: yakıt tankları, kontrol binası ve anten
  m.ball(9, 8, 3, 2.6, (x, y, z) => pick(P.white, x, y, z), 7);
  m.ball(5, 11, 3, 2.3, (x, y, z) => pick(P.white, x, y, z), 7);
  m.box(7, 12, -11, -6, 1, 4, (x, y, z) => pick(['#d8dbe4', '#cfd3dd'], x, y, z), 7);
  windowAt(m, 'x', 12, -10, 2, 3, 2, 7, '#3a3f55');
  m.set(9, -8, 5, '#9aa1b4', 7); m.set(9, -8, 6, '#9aa1b4', 7); m.disk(9, -8, 1.6, 7, '#e8ebf3', 7);
  m.fx.push({ kind: 'steam', x: 0, y: 0, z: 1, step: 7 });
}

// ---------- 5) Buz Sarayı ----------
function icePalace(m) {
  addIsland(m, P.snow, ['#dcecf8', '#d2e6f5']);
  const ice = (x, y, z) => pick(P.ice, x, y, z);
  // 0: buz taban
  m.box(-9, 9, -9, 9, 1, 2, ice, 0);
  // 1: surlar, mazgallar ve kemerli kapı
  m.ring(-9, 9, -9, 9, 3, 8, ice, 1);
  for (let i = -9; i <= 9; i += 2) for (const [x, y] of [[i, -9], [i, 9], [-9, i], [9, i]]) m.set(x, y, 9, ice, 1);
  for (let z = 3; z <= 6; z++) for (let y = -2; y <= 1; y++) m.del(9, y, z);
  for (let y = -2; y <= 1; y++) m.set(9, y, 7, '#7cc8f0', 1);
  // 2-3: orta kule
  m.cyl(0, 0, 4.4, 3, 16, ice, 2);
  m.cyl(0, 0, 3.4, 17, 25, ice, 3);
  for (const z of [12, 20]) { const s = z > 16 ? 3 : 2; m.set(5, 0, z, '#ffffff', s); m.set(0, 5, z, '#ffffff', s); m.set(5, 0, z + 1, '#e8f6ff', s); }
  // 4: köşe kuleleri
  for (const [x, y] of [[-9, -9], [9, -9], [-9, 9], [9, 9]]) m.cyl(x, y, 2.4, 3, 14, ice, 4);
  // 5: soğan kubbeler
  const dome = (x, y, z0, r, step) => { m.ball(x, y, z0 + r * 0.7, r, (a, b, c) => pick(['#9b7bff', '#a88aff', '#8f6ef0'], a, b, c), step, 1.0); m.set(x, y, z0 + r * 1.8, '#e8dcff', step); m.set(x, y, z0 + r * 1.8 + 1, '#ffffff', step); };
  for (const [x, y] of [[-9, -9], [9, -9], [-9, 9], [9, 9]]) dome(x, y, 15, 2.6, 5);
  // 6: orta kubbe ve sivri uç
  dome(0, 0, 26, 3.8, 6);
  for (let z = 34; z <= 38; z++) m.set(0, 0, z, z === 38 ? '#ffffff' : '#c8b0ff', 6);
  // 7: kristaller ve kardan adam
  for (const [x, y, h] of [[12, -4, 5], [-12, 3, 4], [5, 12, 4], [-5, -12, 5], [11, 9, 3]]) for (let z = 1; z <= h; z++) { m.set(x, y, z, z === h ? '#ffffff' : '#9ae0ff', 7); if (z < h - 1) m.set(x + 1, y, z, '#b8ecff', 7); }
  m.ball(12, 5, 2, 1.9, '#ffffff', 7, 1); m.ball(12, 5, 4.6, 1.3, '#ffffff', 7, 1);
  m.set(13, 5, 5, '#ff8a2a', 7); m.set(13, 4, 5, '#1b1d3a', 7); m.set(13, 6, 5, '#1b1d3a', 7);
  m.set(12, 5, 6, '#2c3044', 7); m.set(12, 5, 7, '#2c3044', 7);
}

// ---------- 6) Kale ----------
function castle(m) {
  addIsland(m);
  flowers(m, [[13, 4], [-12, 8], [8, 12], [-13, -5]]);
  const st = (x, y, z) => (((x + y) % 4 === 0 && z % 2 === 0) || ((x + y) % 4 === 2 && z % 2 === 1) ? P.mortar : pick(P.stone, x, y, z));
  // 0-1: surlar
  m.ring(-10, 10, -10, 10, 1, 4, st, 0);
  m.ring(-10, 10, -10, 10, 5, 9, st, 1);
  for (let i = -10; i <= 10; i += 2) for (const [x, y] of [[i, -10], [i, 10], [-10, i], [10, i]]) m.set(x, y, 10, st, 1);
  // kapı (parmaklık) ve ahşap köprü
  for (let z = 1; z <= 6; z++) for (let y = -2; y <= 2; y++) m.set(10, y, z, z === 6 || Math.abs(y) === 2 ? '#7d4c24' : (y + z) % 2 ? '#3a3f55' : '#2a2e40', 1);
  m.box(11, 15, -2, 2, 1, 1, (x, y, z) => pick(P.wood, x, y, z), 1);
  // 2-3: yuvarlak köşe kuleleri
  for (const [x, y] of [[-10, -10], [10, -10], [-10, 10], [10, 10]]) m.cyl(x, y, 3.2, 1, 12, st, 2);
  for (const [x, y] of [[-10, -10], [10, -10], [-10, 10], [10, 10]]) {
    m.cyl(x, y, 3.6, 13, 13, st, 3);
    m.disk(x, y, 3.6, 14, (a, b, c) => ((a + b) % 2 ? st(a, b, c) : null), 3, 2.6);
    windowAt(m, 'x', x + 3, y, 8, 1, 2, 3, '#4a4458');
  }
  // 4-5: iç kale
  m.box(-5, 5, -5, 5, 1, 16, st, 4);
  for (const [axis, f] of [['x', 5], ['y', 5], ['x', -5]]) { windowAt(m, axis, f, -3, 7, 2, 3, 4, '#4a4458'); windowAt(m, axis, f, 2, 7, 2, 3, 4, '#4a4458'); }
  m.box(-3, 3, -3, 3, 17, 22, st, 5);
  for (let i = -5; i <= 5; i += 2) for (const [x, y] of [[i, -5], [i, 5], [-5, i], [5, i]]) m.set(x, y, 17, st, 5);
  windowAt(m, 'x', 3, -1, 18, 2, 3, 5, '#4a4458');
  // 6: konik mavi çatılar
  const blue = (x, y, z) => ((z % 2) ? pick(['#3a6cf0', '#4a7cff'], x, y, z) : '#2f5ad8');
  for (const [x, y] of [[-10, -10], [10, -10], [-10, 10], [10, 10]]) m.cyl(x, y, (z) => 3.8 - (z - 15) * 0.7, 15, 20, blue, 6);
  m.cyl(0, 0, (z) => 4.6 - (z - 23) * 0.62, 23, 30, blue, 6);
  // 7: bayraklar, sancaklar ve meşaleler
  const flag = (x, y, z0, h) => { for (let z = z0; z <= z0 + h; z++) m.set(x, y, z, '#cfd3dd', 7); m.box(x + 1, x + 3, y, y, z0 + h - 2, z0 + h, (a, b, c) => ((a + c) % 2 ? '#ff3b55' : '#e2304e'), 7); };
  flag(0, 0, 31, 5);
  for (const [x, y] of [[-10, -10], [10, -10], [-10, 10], [10, 10]]) flag(x, y, 21, 3);
  for (const y of [-5, 4]) for (let z = 4; z <= 8; z++) m.set(10, y, z, z % 2 ? '#e2304e' : '#ffd23a', 7);
  lantern(m, 11, -3, 4, 7); lantern(m, 11, 3, 4, 7);
}

export const BUILDINGS = [
  { id: 'treehouse', name: 'Ağaç Ev', make: treeHouse },
  { id: 'lighthouse', name: 'Deniz Feneri', make: lighthouse },
  { id: 'pyramid', name: 'Piramit', make: pyramid },
  { id: 'rocket', name: 'Roket Üssü', make: rocket },
  { id: 'icepalace', name: 'Buz Sarayı', make: icePalace },
  { id: 'castle', name: 'Kale', make: castle },
];
const modelCache = {};
function modelOf(i) {
  const b = BUILDINGS[i % BUILDINGS.length];
  if (!modelCache[b.id]) { const m = makeModel(); b.make(m); modelCache[b.id] = m; }
  return modelCache[b.id];
}

// ---------- Ön hesap: açıdan bağımsız her şey ----------
// Her açık yüz için köşe ortam gölgeleri ve temel renk bir kez hesaplanır.
const AO = [1, 0.87, 0.77, 0.65];
const FACES = [
  // n: normal, t1/t2: yüz düzlemindeki eksenler, c: köşe ofsetleri, s: köşelerin (t1,t2) yönleri
  { n: [0, 0, 1], t1: [1, 0, 0], t2: [0, 1, 0], c: [[0, 0, 1], [1, 0, 1], [1, 1, 1], [0, 1, 1]], s: [[-1, -1], [1, -1], [1, 1], [-1, 1]] },
  { n: [1, 0, 0], t1: [0, 1, 0], t2: [0, 0, 1], c: [[1, 0, 1], [1, 1, 1], [1, 1, 0], [1, 0, 0]], s: [[-1, 1], [1, 1], [1, -1], [-1, -1]] },
  { n: [-1, 0, 0], t1: [0, 1, 0], t2: [0, 0, 1], c: [[0, 0, 1], [0, 1, 1], [0, 1, 0], [0, 0, 0]], s: [[-1, 1], [1, 1], [1, -1], [-1, -1]] },
  { n: [0, 1, 0], t1: [1, 0, 0], t2: [0, 0, 1], c: [[0, 1, 1], [1, 1, 1], [1, 1, 0], [0, 1, 0]], s: [[-1, 1], [1, 1], [1, -1], [-1, -1]] },
  { n: [0, -1, 0], t1: [1, 0, 0], t2: [0, 0, 1], c: [[0, 0, 1], [1, 0, 1], [1, 0, 0], [0, 0, 0]], s: [[-1, 1], [1, 1], [1, -1], [-1, -1]] },
];
function prepare(list) {
  const occ = new Set(list.map((v) => K(v.x, v.y, v.z)));
  const has = (x, y, z) => occ.has(K(x, y, z));
  const items = [];
  for (const v of list) {
    const faces = [];
    FACES.forEach((F, fi) => {
      const [nx, ny, nz] = F.n;
      if (has(v.x + nx, v.y + ny, v.z + nz)) return;
      const bx = v.x + nx, by = v.y + ny, bz = v.z + nz;
      const ao = F.s.map(([s1, s2]) => {
        const a = has(bx + F.t1[0] * s1, by + F.t1[1] * s1, bz + F.t1[2] * s1);
        const b = has(bx + F.t2[0] * s2, by + F.t2[1] * s2, bz + F.t2[2] * s2);
        const c = has(bx + F.t1[0] * s1 + F.t2[0] * s2, by + F.t1[1] * s1 + F.t2[1] * s2, bz + F.t1[2] * s1 + F.t2[2] * s2);
        return AO[a && b ? 3 : a + b + c];
      });
      faces.push({ fi, ao });
    });
    if (faces.length) items.push({ v, faces, r: ((v.c >> 16) & 255) / 255, g: ((v.c >> 8) & 255) / 255, b: (v.c & 255) / 255, shade: 1, d: 0 });
  }
  return { items, occ, has };
}
const SUN = [-1, -0.5];
const LIGHT = [-0.32, 0.95];
// Gölge (açıya bağlı): üst yüzün güneş yönünde üstünde blok varsa gölgededir
function computeShadows(pre, ang) {
  const cs = Math.cos(ang), sn = Math.sin(ang);
  const sx = SUN[0] * cs + SUN[1] * sn, sy = -SUN[0] * sn + SUN[1] * cs;
  for (const it of pre.items) {
    it.shade = 1;
    if (!it.faces.some((f) => f.fi === 0)) continue;
    const { x, y, z } = it.v;
    for (let t = 1; t <= 34; t++) if (pre.has(x + Math.round(sx * t), y + Math.round(sy * t), z + 1 + t)) { it.shade = 0.72; break; }
  }
}

// ---------- GPU örgüsü ----------
const vertex = `
  in vec2 aPosition;
  in vec3 aColor;
  out vec3 vColor;
  uniform mat3 uProjectionMatrix;
  uniform mat3 uWorldTransformMatrix;
  uniform mat3 uTransformMatrix;
  void main() {
    mat3 mvp = uProjectionMatrix * uWorldTransformMatrix * uTransformMatrix;
    gl_Position = vec4((mvp * vec3(aPosition, 1.0)).xy, 0.0, 1.0);
    vColor = aColor;
  }
`;
const fragment = `
  in vec3 vColor;
  uniform float uAlpha;
  void main() { gl_FragColor = vec4(vColor * uAlpha, uAlpha); }
`;
function makeMesh() {
  const geometry = new Geometry({
    attributes: {
      aPosition: { buffer: new Float32Array(8), format: 'float32x2' },
      aColor: { buffer: new Float32Array(12), format: 'float32x3' },
    },
    indexBuffer: new Uint32Array(6),
  });
  const shader = Shader.from({ gl: { vertex, fragment }, resources: { meshUniforms: { uAlpha: { value: 1, type: 'f32' } } } });
  const mesh = new Mesh({ geometry, shader });
  mesh.cap = 0;
  mesh.setAlpha = (a) => { shader.resources.meshUniforms.uniforms.uAlpha = a; };
  return mesh;
}
// Örgüyü verilen açıya göre doldurur (görünen yüzler, uzaktan yakına sıralama, renkler)
function fillMesh(mesh, pre, ang, u) {
  const cs = Math.cos(ang), sn = Math.sin(ang);
  const sideK = [1, 1, 1, 1, 1];
  const sideVis = [true, false, false, false, false];
  for (let fi = 1; fi < 5; fi++) {
    const [nx, ny] = FACES[fi].n;
    const rx = nx * cs - ny * sn, ry = nx * sn + ny * cs;
    sideVis[fi] = rx + ry > 0.0001;
    sideK[fi] = 0.7 + 0.3 * Math.max(0, rx * LIGHT[0] + ry * LIGHT[1]);
  }
  const vis = pre.items;
  for (const it of vis) { const { x, y } = it.v; it.d = x * cs - y * sn + x * sn + y * cs; }
  vis.sort((a, b) => a.d - b.d || a.v.z - b.v.z);
  let nf = 0;
  for (const it of vis) for (const f of it.faces) if (sideVis[f.fi]) nf++;
  if (mesh.cap < nf) {
    mesh.cap = Math.ceil(nf * 1.3) + 64;
    mesh.pos = new Float32Array(mesh.cap * 8);
    mesh.col = new Float32Array(mesh.cap * 12);
    mesh.idx = new Uint32Array(mesh.cap * 6);
    for (let i = 0; i < mesh.cap; i++) { const b = i * 4, o = i * 6; mesh.idx[o] = b; mesh.idx[o + 1] = b + 1; mesh.idx[o + 2] = b + 2; mesh.idx[o + 3] = b; mesh.idx[o + 4] = b + 2; mesh.idx[o + 5] = b + 3; }
    mesh.geometry.getBuffer('aPosition').data = mesh.pos;
    mesh.geometry.getBuffer('aColor').data = mesh.col;
    mesh.geometry.indexBuffer.data = mesh.idx;
  }
  const pos = mesh.pos, col = mesh.col;
  let p = 0, q = 0;
  for (const it of vis) {
    const { x, y, z } = it.v;
    for (const f of it.faces) {
      if (!sideVis[f.fi]) continue;
      const F = FACES[f.fi];
      const k = f.fi === 0 ? 1.05 * it.shade : sideK[f.fi];
      for (let c = 0; c < 4; c++) {
        const o = F.c[c];
        const dx = x + o[0] - 0.5, dy = y + o[1] - 0.5;
        const xr = dx * cs - dy * sn, yr = dx * sn + dy * cs;
        pos[p++] = (xr - yr) * u;
        pos[p++] = (xr + yr) * u * 0.5 - (z + o[2]) * u;
        const kk = k * f.ao[c];
        col[q++] = Math.min(1, it.r * kk); col[q++] = Math.min(1, it.g * kk); col[q++] = Math.min(1, it.b * kk);
      }
    }
  }
  pos.fill(0, p);
  col.fill(0, q);
  mesh.geometry.getBuffer('aPosition').update();
  mesh.geometry.getBuffer('aColor').update();
}

// ---------- Sahne ----------
export function createIsland(app) {
  const layer = new Container();
  const root = new Container();
  const shadow = new Graphics();
  const fxLayer = new Container();
  shadow.visible = false;   // adanın altındaki yer gölgesi kullanılmıyor (kullanıcı isteği)
  layer.addChild(shadow, root, fxLayer);
  const mesh = makeMesh();
  root.addChild(mesh);
  // Sıradaki adımın yarı saydam önizlemesi (hologram): oyuncu ne inşa edeceğini görür
  const ghost = makeMesh();
  ghost.visible = false;
  root.addChild(ghost);
  let ghostOn = false, gpre = null;
  let u = 10, cur = -1, built = 0, rect = { x: 0, y: 0, w: 300, h: 300 }, t = 0;
  let ang = 0, vel = 0, dragging = false, dirty = false, lastX = 0, lastT = 0, settle = 0;
  let pre = null, bbox = null;
  const particles = [];
  const projPt = (x, y, z) => {
    const cs = Math.cos(ang), sn = Math.sin(ang), dx = x - 0.5, dy = y - 0.5;
    const xr = dx * cs - dy * sn, yr = dx * sn + dy * cs;
    return [(xr - yr) * u, (xr + yr) * u * 0.5 - z * u];
  };

  function fit() {
    const m = modelOf(cur);
    let maxR = 0, minZ = 0, maxZ = 0;
    for (const v of m.vox.values()) {
      const r = Math.hypot(v.x, v.y) + 0.75;
      if (r > maxR) maxR = r; if (v.z < minZ) minZ = v.z; if (v.z + 1 > maxZ) maxZ = v.z + 1;
    }
    // her açıda sığacak kutu: yatayda ±√2·r, dikeyde yükseklik + zemin elipsi
    const w = 2 * Math.SQRT2 * maxR, top = -maxZ - maxR * 0.71, bot = -minZ + maxR * 0.71;
    bbox = { w, top, bot };
    // Yan düğmelerin arasını daha iyi doldursun: genişliğin %10 fazlası, alttaki boşluğa doğru biraz aşağıda
    u = Math.max(2, Math.min((rect.w * 1.1) / w, (rect.h * 0.97) / (bot - top)));
    root.position.set(rect.x + rect.w / 2, rect.y + rect.h * 0.53 - ((top + bot) / 2) * u);
    fxLayer.position.copyFrom(root.position);
    shadow.clear();
    shadow.ellipse(0, 0, maxR * 0.9 * u, maxR * 0.22 * u).fill({ color: 0x000014, alpha: 0.26 });
    shadow.position.set(root.x, root.y + (bot + 2) * u);
  }
  function rebuild() {
    const m = modelOf(cur);
    pre = prepare([...m.vox.values()].filter((v) => v.step < built));
    computeShadows(pre, ang);
    fillMesh(mesh, pre, ang, u);
    rebuildGhost();
  }
  function rebuildGhost() {
    const m = modelOf(cur);
    const all = [...m.vox.values()];
    const next = all.filter((v) => v.step === built);
    if (!ghostOn || !next.length) { ghost.visible = false; gpre = null; return; }
    const keys = new Set(next.map((v) => K(v.x, v.y, v.z)));
    // Görünürlük için yapının tamamıyla birlikte hazırlanır, yalnız yeni parçanın yüzleri çizilir
    const pp = prepare(all.filter((v) => v.step <= built));
    gpre = { items: pp.items.filter((it) => keys.has(K(it.v.x, it.v.y, it.v.z))) };
    for (const it of gpre.items) it.shade = 1;
    fillMesh(ghost, gpre, ang, u);
    ghost.visible = true;
  }
  function api() {}
  api.layer = layer;
  api.ghost = (on) => { ghostOn = !!on; if (cur >= 0) rebuildGhost(); };
  api.layout = (r) => { rect = r; if (cur >= 0) { fit(); rebuild(); } };
  api.show = (index, steps) => {
    if (index !== cur) api.clearFx();
    cur = index; built = steps;
    fit(); rebuild();
  };
  api.attach = (el) => {
    el.addEventListener('pointerdown', (e) => {
      if (cur < 0) return;
      dragging = true; vel = 0; lastX = e.clientX; lastT = performance.now();
      el.setPointerCapture?.(e.pointerId);
    });
    el.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const now = performance.now(), dx = e.clientX - lastX;
      ang -= dx * 0.011;
      vel = (-dx * 0.011) / Math.max(0.008, (now - lastT) / 1000);
      lastX = e.clientX; lastT = now;
      dirty = true;
    });
    const end = () => { if (!dragging) return; dragging = false; if (performance.now() - lastT > 80) vel = 0; };
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
    el.addEventListener('lostpointercapture', end);
  };
  // Yeni adım: parça kat kat yukarıdan düşer ve oturur
  api.buildStep = async (index, step, onLand) => {
    cur = index; vel = 0; dragging = false;
    ghost.visible = false;
    const m = modelOf(cur);
    const all = [...m.vox.values()];
    const piece = all.filter((v) => v.step === step);
    const preAfter = prepare(all.filter((v) => v.step <= step));
    const pieceSet = new Set(piece.map((v) => K(v.x, v.y, v.z)));
    const zs = [...new Set(piece.map((v) => v.z))].sort((a, b) => a - b);
    const groups = [];
    for (let i = 0; i < zs.length; i += 3) groups.push(new Set(zs.slice(i, i + 3)));
    const drops = groups.map((zset, i) => {
      const sub = { items: preAfter.items.filter((it) => pieceSet.has(K(it.v.x, it.v.y, it.v.z)) && zset.has(it.v.z)) };
      for (const it of sub.items) it.shade = 1;
      const dm = makeMesh();
      fillMesh(dm, sub, ang, u);
      dm.setAlpha(0);
      dm.y = -u * 10;
      root.addChild(dm);
      const st = { a: 0 };
      tween(st, { a: 1 }, 0.25, Ease.outQuad, i * 0.08);
      const tick = () => { if (!dm.destroyed) { dm.setAlpha(st.a); if (st.a < 1) requestAnimationFrame(tick); } };
      requestAnimationFrame(tick);
      return tween(dm, { y: 0 }, 0.45, Ease.outBounce, i * 0.08).then(() => { dm.setAlpha(1); if (onLand) onLand(i); return dm; });
    });
    const meshes = await Promise.all(drops);
    built = step + 1;
    rebuild();
    for (const dm of meshes) dm.destroy();
    const cx = piece.reduce((s2, v) => s2 + v.x, 0) / piece.length, cy = piece.reduce((s2, v) => s2 + v.y, 0) / piece.length;
    const cz = Math.min(...piece.map((v) => v.z));
    const [px, py] = projPt(cx + 0.5, cy + 0.5, cz);
    for (let i = 0; i < 18; i++) {
      const pt = new Graphics().circle(0, 0, u * (0.5 + Math.random() * 0.7)).fill({ color: i % 3 ? 0xffffff : 0xffe680, alpha: 0.9 });
      pt.position.set(px, py);
      fxLayer.addChild(pt);
      const a = Math.random() * Math.PI * 2, d = u * (4 + Math.random() * 6);
      tween(pt, { x: px + Math.cos(a) * d, y: py + Math.sin(a) * d * 0.5 - u * Math.random() * 4, alpha: 0 }, 0.6 + Math.random() * 0.3, Ease.outCubic).then(() => pt.destroy());
    }
  };
  // Ölçüm: bir döndürme karesinin (yansıtma + sıralama + doldurma) ortalama süresi (ms)
  api.bench = (n = 20) => { const t0 = performance.now(); for (let i = 0; i < n; i++) fillMesh(mesh, pre, ang + i * 0.05, u); fillMesh(mesh, pre, ang, u); return { ms: (performance.now() - t0) / n, items: pre.items.length }; };
  api.celebrate = async () => {
    const k = root.scale.x;
    vel = 6.5;
    await tween(root.scale, { x: k * 1.06, y: k * 1.06 }, 0.18, Ease.outQuad);
    await tween(root.scale, { x: k, y: k }, 0.4, Ease.outBounce);
  };
  // Kutlama penceresi için tamamlanmış yapının resmi
  api.snapshot = (px = 360) => {
    const m = modelOf(cur);
    const pp = prepare([...m.vox.values()]);
    computeShadows(pp, 0.35);
    const dm = makeMesh();
    fillMesh(dm, pp, 0.35, px / bbox.w);
    const canvas = app.renderer.extract.canvas({ target: dm, resolution: 2 });
    dm.destroy();
    return canvas.toDataURL();
  };
  // Herhangi bir yapının tamamlanmış hâlinin resmi (takımada adacıkları için); tuval döner
  api.snapshotOf = (index, px = 300) => {
    const m = modelOf(index);
    let maxR = 0;
    for (const v of m.vox.values()) { const r = Math.hypot(v.x, v.y) + 0.75; if (r > maxR) maxR = r; }
    const pp = prepare([...m.vox.values()]);
    computeShadows(pp, 0.35);
    const dm = makeMesh();
    fillMesh(dm, pp, 0.35, px / (2 * Math.SQRT2 * maxR));
    const canvas = app.renderer.extract.canvas({ target: dm, resolution: 2 });
    dm.destroy();
    return canvas;
  };
  api.update = (dt) => {
    if (cur < 0 || !layer.visible || !pre) return;
    t += dt;
    if (!dragging && Math.abs(vel) > 0.02) {
      ang += vel * dt;
      vel *= Math.pow(0.05, dt);
      dirty = true;
    } else if (!dragging) vel = 0;
    if (dirty) { fillMesh(mesh, pre, ang, u); if (gpre && ghost.visible) fillMesh(ghost, gpre, ang, u); dirty = false; settle = 0.25; }
    else if (settle > 0) {
      settle -= dt;
      if (settle <= 0 && !dragging) { computeShadows(pre, ang); fillMesh(mesh, pre, ang, u); }
    }
    if (ghost.visible) ghost.setAlpha(0.22 + (Math.sin(t * 3) * 0.5 + 0.5) * 0.26);
    const bob = Math.sin(t * 1.1) * u * 0.6;
    root.pivot.y = -bob; fxLayer.pivot.y = -bob;
    shadow.scale.set(1 - Math.sin(t * 1.1) * 0.04);
    shadow.alpha = 0.85 - Math.sin(t * 1.1) * 0.1;
    const m = modelOf(cur);
    for (const f of m.fx) {
      if (f.step >= built) continue;
      const [x, y] = projPt(f.x + 0.5, f.y + 0.5, f.z);
      if (f.kind === 'smoke' || f.kind === 'steam') {
        f.acc = (f.acc || 0) + dt;
        if (f.acc > (f.kind === 'steam' ? 0.16 : 0.38)) {
          f.acc = 0;
          const pt = new Graphics().circle(0, 0, u * 1.1).fill({ color: f.kind === 'steam' ? 0xffffff : 0xdfe3ea, alpha: 0.75 });
          pt.position.set(x + (Math.random() - 0.5) * u * 2, y);
          fxLayer.addChild(pt);
          particles.push({ p: pt, vx: (Math.random() - 0.3) * u * 1.2 + (f.kind === 'steam' ? (Math.random() - 0.5) * u * 8 : 0), vy: f.kind === 'steam' ? -u * 0.8 : -u * 3.2, life: 0, max: f.kind === 'steam' ? 1.1 : 2.2, grow: f.kind === 'steam' ? 2.4 : 1.6 });
        }
      } else if (f.kind === 'glow' || f.kind === 'beacon') {
        if (!f.g || f.g.destroyed) {
          f.g = new Graphics();
          const s0 = f.size || 1;
          for (let i = 4; i >= 1; i--) f.g.circle(0, 0, u * i * 1.4 * s0).fill({ color: f.color, alpha: 0.08 });
          f.g.blendMode = 'add';
          fxLayer.addChild(f.g);
        }
        f.g.position.set(x, y - u * 0.5);
        f.g.alpha = 0.7 + Math.sin(t * (f.kind === 'beacon' ? 3 : 2)) * 0.3;
      }
    }
    for (let i = particles.length - 1; i >= 0; i--) {
      const qq = particles[i];
      qq.life += dt;
      if (qq.life > qq.max || qq.p.destroyed) { if (!qq.p.destroyed) qq.p.destroy(); particles.splice(i, 1); continue; }
      qq.p.x += qq.vx * dt; qq.p.y += qq.vy * dt;
      qq.p.scale.set(1 + (qq.life / qq.max) * qq.grow);
      qq.p.alpha = 0.75 * (1 - qq.life / qq.max);
    }
  };
  api.clearFx = () => {
    for (const qq of particles) if (!qq.p.destroyed) qq.p.destroy();
    particles.length = 0;
    for (const md of Object.values(modelCache)) for (const f of md.fx) if (f.g && !f.g.destroyed) { f.g.destroy(); f.g = null; }
  };
  return api;
}

// Patron savaşı gibi başka sahnelerin de aynı voksel motorunu kullanabilmesi için
export { makeModel, prepare, fillMesh, hash, pick, FACES, LIGHT };
