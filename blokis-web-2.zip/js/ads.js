// Reklam katmanı: iPhone'da Google AdMob (ödüllü video + geçiş reklamı), tarayıcıda test görünümü.
// Açılışta önce Google onay penceresi (UMP; yalnız gereken bölgelerde çıkar), sonra Apple'ın takip izni (ATT).
// Oyunun geri kalanı yalnızca Ads.init(), Ads.rewarded() ve Ads.interstitial() çağırır.
import { Sound } from './audio.js';

// TEST = true iken Google'ın test reklamları gösterilir (geliştirirken kendi reklamına tıklamak hesabı kapatabilir).
// App Store'a gönderilecek sürümde TEST = false yapılır.
const TEST = false;
// AdMob hesabı: iOS uygulaması ca-app-pub-1651168586635669~3432514867 (Info.plist GADApplicationIdentifier),
// Android uygulaması ca-app-pub-1651168586635669~2250888617 (AndroidManifest com.google.android.gms.ads.APPLICATION_ID)
const PLATFORM = (window.Capacitor && window.Capacitor.getPlatform && window.Capacitor.getPlatform()) || 'web';
const IDS = PLATFORM === 'android'
  ? { rewarded: 'ca-app-pub-1651168586635669/2059316924', interstitial: 'ca-app-pub-1651168586635669/9140650464' }
  : { rewarded: 'ca-app-pub-1651168586635669/1889077918', interstitial: 'ca-app-pub-1651168586635669/4546110979' };

const $ = (id) => document.getElementById(id);
const native = () => (window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform() && window.Capacitor.Plugins.AdMob) || null;

function mockAd(label, seconds) {
  return new Promise((resolve) => {
    const el = $('adMock');
    $('adMockText').textContent = label;
    let n = seconds;
    $('adMockCount').textContent = n;
    el.classList.add('show');
    const iv = setInterval(() => {
      n -= 1;
      $('adMockCount').textContent = n;
      if (n <= 0) {
        clearInterval(iv);
        el.classList.remove('show');
        resolve(true);
      }
    }, 1000);
  });
}

let ready = null, canAds = false, showing = false;   // showing: aynı anda tek reklam (çift ödül olmasın)
const loaded = { rewarded: false, interstitial: false };
const loading = { rewarded: null, interstitial: null };

// Reklamı önceden yükle (gösterim anında beklenmesin); aynı anda tek yükleme
function preload(kind) {
  const A = native();
  if (!A || !canAds || loaded[kind]) return Promise.resolve(loaded[kind]);
  if (loading[kind]) return loading[kind];
  const opts = { adId: IDS[kind] || 'test', isTesting: TEST || !IDS[kind] };
  const p = kind === 'rewarded' ? A.prepareRewardVideoAd(opts) : A.prepareInterstitial(opts);
  loading[kind] = p.then(() => (loaded[kind] = true)).catch(() => (loaded[kind] = false)).finally(() => { loading[kind] = null; });
  return loading[kind];
}
// Dinleyici ekle: eklenti tutamacı doğrudan ya da Promise olarak döndürebilir, ikisini de Promise'e çevir
const listen = (A, name, fn) => Promise.resolve(A.addListener(name, fn));
// Tek seferlik olay bekleme: ilk gelen olay kazanır, dinleyiciler temizlenir
function firstEvent(A, names) {
  return new Promise((resolve) => {
    const hs = [];
    let done = false;
    names.forEach((n) => listen(A, n, (d) => {
      if (done) return;
      done = true;
      hs.forEach((h) => h.remove());
      resolve({ name: n, data: d });
    }).then((h) => { if (done) h.remove(); else hs.push(h); }));
  });
}
const withTimeout = (p, ms) => Promise.race([p, new Promise((r) => setTimeout(() => r(false), ms))]);

let privacyReq = false;   // Avrupa'daki oyuncular izinlerini Ayarlar'dan değiştirebilmeli (AdMob şartı)
export const Ads = {
  // Ayarlar'daki "Reklam izinleri" bağlantısı yalnız gereken bölgelerde görünür
  get privacyOptions() { return privacyReq; },
  async showPrivacyOptions() {
    const A = native();
    if (!A) return;
    try { await A.showPrivacyOptionsForm(); } catch (e) { console.warn('Gizlilik seçenekleri açılamadı', e); }
  },
  onNoAd: null,   // reklam yüklenemezse oyuncuya kısa bilgi (main.js bağlar)
  // Açılışta bir kez: onay + takip izni + AdMob başlatma, ardından reklamları önceden yükle
  init() {
    if (ready) return ready;
    const A = native();
    if (!A) return (ready = Promise.resolve(false));
    ready = (async () => {
      try {
        // Onay adımı hata verirse (ör. AdMob'da onay mesajı yoksa) reklamlar yine de çalışır
        try {
          let info = await A.requestConsentInfo();
          if (info.isConsentFormAvailable && info.status === 'REQUIRED') info = await A.showConsentForm();
          canAds = info.canRequestAds !== false;
          privacyReq = info.privacyOptionsRequirementStatus === 'REQUIRED';
        } catch (e) {
          console.warn('Reklam onayı alınamadı', e);
          canAds = true;
        }
        // Apple'ın takip izni yalnız iPhone'da
        if (PLATFORM === 'ios') {
          const t = await A.trackingAuthorizationStatus();
          if (t.status === 'notDetermined') await A.requestTrackingAuthorization();
        }
        await A.initialize({ initializeForTesting: TEST, maxAdContentRating: 'General' });
        preload('rewarded');
        preload('interstitial');
        return true;
      } catch (e) {
        console.warn('AdMob başlatılamadı', e);
        canAds = false;
        return false;
      }
    })();
    return ready;
  },
  // Ödüllü video: sonuna kadar izlenip ödül kazanılırsa true
  async rewarded() {
    const A = native();
    if (!A) return mockAd('Ödüllü reklam oynatılıyor…', 3);
    if (showing) return false;
    showing = true;
    try { return await this._rewarded(A); } finally { showing = false; }
  },
  async _rewarded(A) {
    await this.init();
    if (!loaded.rewarded) await withTimeout(preload('rewarded'), 6000);
    if (!loaded.rewarded) { if (this.onNoAd) this.onNoAd('Şu an reklam yok, biraz sonra tekrar dene'); preload('rewarded'); return false; }
    loaded.rewarded = false;
    let earned = false;
    const end = firstEvent(A, ['onRewardedVideoAdDismissed', 'onRewardedVideoAdFailedToShow']);
    listen(A, 'onRewardedVideoAdReward', () => { earned = true; }).then((h) => end.then(() => h.remove()));
    Sound.suspend();
    // Gösterim hata verip kapanma olayı hiç gelmezse de beklemek biter (yoksa reklam kilidi oturum boyunca açılmaz)
    const failed = A.showRewardVideoAd().then(() => { earned = true; return new Promise(() => {}); },
      (e) => { console.warn('[reklam] gösterilemedi', e); return { name: 'failed' }; });
    const ev = await Promise.race([end, failed]);
    Sound.resume();
    preload('rewarded');
    return earned && ev.name === 'onRewardedVideoAdDismissed';
  },
  // Geçiş reklamı: hazırsa gösterilir, değilse oyun beklemeden devam eder
  async interstitial() {
    const A = native();
    if (!A) return mockAd('Geçiş reklamı', 2);
    if (showing) return false;
    showing = true;
    try { return await this._interstitial(A); } finally { showing = false; }
  },
  async _interstitial(A) {
    await this.init();
    if (!loaded.interstitial) { preload('interstitial'); return false; }
    loaded.interstitial = false;
    const end = firstEvent(A, ['interstitialAdDismissed', 'interstitialAdFailedToShow']);
    Sound.suspend();
    await Promise.race([end, A.showInterstitial().then(() => new Promise(() => {}), () => ({ name: 'failed' }))]);
    Sound.resume();
    preload('interstitial');
    return true;
  },
};
