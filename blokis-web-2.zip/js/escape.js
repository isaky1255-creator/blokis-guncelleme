// Blok Kaçışı: duvarlı bir kabın içindeki renkli blokları sürükleyip kendi renklerindeki kapılardan çıkar.
// Blok parmağı izler, boş hücrelerden adım adım geçer; kendi rengindeki AÇIK kapının önüne varıp itilince çıkar.
// Kilitli kapının sayacı her çıkışta 1 azalır, sıfırlanınca kapı açılır. Bütün bloklar çıkınca bölüm biter.
// Bu dosya hem oyunda (main.js) hem bölüm üretiminde (tools/bolum-tasarimi/kacis.mjs) kullanılır; ekrana bir şey çizmez.
//
// Bölüm: { w, h, mask: ['###..', …] ('#' = kabın içi), blocks: [{ r, c, s, col }], gates: [{ side, at, len, col, lock }] }
//   side: 'top' | 'bottom' | 'left' | 'right'  · at: kapının başladığı sütun (üst/alt) ya da satır (sol/sağ)
//   s: blok boyu (1 ya da 2)  · lock: kilit sayacı (0 = açık)

export const DIRS = { up: [-1, 0], down: [1, 0], left: [0, -1], right: [0, 1] };
const SIDE_OF = { up: 'top', down: 'bottom', left: 'left', right: 'right' };

export function inMask(lv, r, c) { return r >= 0 && c >= 0 && r < lv.h && c < lv.w && lv.mask[r][c] === '#'; }

// Oyun durumu: bloklar (kimlikli) ve kapı kilitleri
export function initState(lv) {
  return { blocks: lv.blocks.map((b, id) => ({ id, r: b.r, c: b.c, s: b.s || 1, col: b.col })), locks: lv.gates.map((g) => g.lock || 0), out: 0 };
}
function occupancy(lv, st, skip = -1) {
  const o = new Int16Array(lv.w * lv.h).fill(-1);
  for (const b of st.blocks) {
    if (b.id === skip) continue;
    for (let i = 0; i < b.s; i++) for (let j = 0; j < b.s; j++) o[(b.r + i) * lv.w + b.c + j] = b.id;
  }
  return o;
}

// Adım adım sürükleme: bloğu bir hücre kaydır. Döner: { r, c } (yeni yer), { gate } (o yöndeki açık, aynı renk kapıdan çıkar)
// ya da null (önü kapalı). Kapıdan çıkış için bloğun kabın kenarında, kapının tam önünde olması gerekir.
export function stepInfo(lv, st, id, dir) {
  const b = st.blocks.find((x) => x.id === id);
  if (!b) return null;
  const [dr, dc] = DIRS[dir];
  const occ = occupancy(lv, st, id);
  const lead = [];
  for (let i = 0; i < b.s; i++) lead.push(dr ? [dr > 0 ? b.r + b.s : b.r - 1, b.c + i] : [b.r + i, dc > 0 ? b.c + b.s : b.c - 1]);
  if (lead.every(([y, x]) => inMask(lv, y, x) && occ[y * lv.w + x] < 0)) return { r: b.r + dr, c: b.c + dc };
  const out = lead.every(([y, x]) => (dr < 0 && y < 0) || (dr > 0 && y >= lv.h) || (dc < 0 && x < 0) || (dc > 0 && x >= lv.w));
  if (!out) return null;
  const gi = gateFor(lv, st, b, SIDE_OF[dir], b.r, b.c);
  return gi >= 0 ? { gate: gi } : null;
}
// (r, c)'deki blok o kenardaki açık, kendi rengindeki kapının tam önünde mi? Kapının sırası ya da -1
function gateFor(lv, st, b, side, r, c) {
  return lv.gates.findIndex((g, k) => g.side === side && st.locks[k] === 0 && g.col === b.col
    && (side === 'top' || side === 'bottom' ? g.at <= c && c + b.s - 1 <= g.at + g.len - 1 : g.at <= r && r + b.s - 1 <= g.at + g.len - 1)
    && (side === 'top' ? r === 0 : side === 'bottom' ? r + b.s === lv.h : side === 'left' ? c === 0 : c + b.s === lv.w));
}
// Adımı uygula: yeni durum ve bilgi ({ r, c } ya da { gate })
export function applyStep(lv, st, id, dir) {
  const m = stepInfo(lv, st, id, dir);
  if (!m) return null;
  if (m.gate === undefined) return { st: { ...st, blocks: st.blocks.map((b) => (b.id === id ? { ...b, r: m.r, c: m.c } : b)) }, info: m };
  return { st: { blocks: st.blocks.filter((b) => b.id !== id), locks: st.locks.map((l) => Math.max(0, l - 1)), out: st.out + 1 }, info: m };
}

// Güçlendirici: blokları doğrudan kaldır (çıkmış sayılır, kilit sayaçları da o kadar düşer)
export function removeBlocks(st, ids) {
  const set = new Set(ids), n = st.blocks.filter((b) => set.has(b.id)).length;
  return { blocks: st.blocks.filter((b) => !set.has(b.id)), locks: st.locks.map((l) => Math.max(0, l - n)), out: st.out + n };
}

// Blok, öbürleri yerinde dururken boş hücrelerden geçip kendi rengindeki açık bir kapının önüne varabiliyor mu?
function canExit(lv, st, b, occ) {
  const s = b.s, W = lv.w;
  const ok = (r, c) => {
    for (let i = 0; i < s; i++) for (let j = 0; j < s; j++) {
      const y = r + i, x = c + j;
      if (!inMask(lv, y, x)) return false;
      const o = occ[y * W + x];
      if (o >= 0 && o !== b.id) return false;
    }
    return true;
  };
  const seen = new Uint8Array(lv.w * lv.h), q = [[b.r, b.c]];
  seen[b.r * W + b.c] = 1;
  while (q.length) {
    const [r, c] = q.pop();
    for (const side of ['top', 'bottom', 'left', 'right']) if (gateFor(lv, st, b, side, r, c) >= 0) return true;
    for (const [dr, dc] of [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
      const nr = r + dr, nc = c + dc;
      if (nr < 0 || nc < 0 || nr >= lv.h || nc >= lv.w || seen[nr * W + nc] || !ok(nr, nc)) continue;
      seen[nr * W + nc] = 1;
      q.push([nr, nc]);
    }
  }
  return false;
}
// Çözücü (sürükleme kuralı): her turda o an çıkabilen bütün bloklar çıkar (çıkış hiçbir zaman zarar vermez:
// yer açar, kilitleri düşürür). Kenara çekilip yol açma hamleleri sayılmaz; bu yüzden "çözülebilir" dediği her bölüm
// gerçekten çözülebilir. Döner: null ya da { layers (tur sayısı = zincir derinliği), first (başta çıkabilen blok sayısı) }
export function solveDrag(lv, st0 = initState(lv)) {
  let st = st0, layers = 0, first = -1;
  while (st.blocks.length) {
    const occ = occupancy(lv, st);
    const ex = st.blocks.filter((b) => canExit(lv, st, b, occ));
    if (first < 0) first = ex.length;
    if (!ex.length) return null;
    st = removeBlocks(st, ex.map((b) => b.id));
    layers++;
  }
  return { layers, first: Math.max(0, first) };
}

// Yenile: küçük blokların renklerini karıştırır; çözülebilir bir karışım arar. Bulamazsa tahta şu an çözülebiliyorsa
// aynen döner (karıştırma bölümü çözülemez bırakmasın); şu an da çözülemiyorsa son denemeyi döner
export function shuffleColors(lv, st, rnd = Math.random, tries = 200) {
  const small = st.blocks.filter((b) => b.s === 1);
  let out = null;
  for (let t = 0; t < tries; t++) {
    const cols = small.map((b) => b.col);
    for (let i = cols.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [cols[i], cols[j]] = [cols[j], cols[i]]; }
    const map = new Map(small.map((b, i) => [b.id, cols[i]]));
    out = { ...st, blocks: st.blocks.map((b) => (map.has(b.id) ? { ...b, col: map.get(b.id) } : b)) };
    if (solveDrag(lv, out)) return out;
  }
  return solveDrag(lv, st) ? st : out;
}

// ---------- Bölüm üretici ----------
function rng(seed) { let s = (seed >>> 0) || 1; return () => ((s = Math.imul(s ^ (s >>> 15), 2246822507) + 0x9e3779b9) >>> 0) / 4294967296; }
// Kap biçimleri (en fazla 7 genişlik, 8 yükseklik; '.' kabın dışı ya da içteki sütun/duvar)
export const SHAPES = {
  R5: ['#####', '#####', '#####', '#####', '#####'],
  R6: ['######', '######', '######', '######', '######', '######'],
  R7: ['#######', '#######', '#######', '#######', '#######', '#######', '#######'],
  R78: ['#######', '#######', '#######', '#######', '#######', '#######', '#######', '#######'],
  T: ['#######', '#######', '#######', '..###..', '..###..', '..###..', '..###..'],
  L: ['###....', '###....', '###....', '###....', '#######', '#######', '#######'],
  J: ['....###', '....###', '....###', '....###', '#######', '#######', '#######'],
  H: ['###.###', '###.###', '#######', '#######', '###.###', '###.###', '###.###'],
  U: ['##...##', '##...##', '##...##', '#######', '#######', '#######', '.#####.'],
  P: ['..###..', '..###..', '#######', '#######', '#######', '..###..', '..###..'],
  Z: ['####...', '####...', '#######', '#######', '#######', '...####', '...####'],
  O: ['#######', '#######', '##...##', '##...##', '##...##', '#######', '#######'],                 // ortası duvar
  PIL: ['#######', '#.###.#', '#######', '###.###', '#######', '#.###.#', '#######'],               // içte sütunlar
  PIL8: ['#######', '#######', '#.#.#.#', '#######', '#######', '#.#.#.#', '#######', '#######'],
  S8: ['#####..', '#####..', '#######', '#######', '#######', '#######', '..#####', '..#####'],
  X8: ['.#####.', '#######', '#######', '###.###', '###.###', '#######', '#######', '.#####.'],
  // Kare yerine: köşesi kesik / elmas / ev biçimleri (her bölümde farklı dış hat)
  K5: ['.###.', '#####', '#####', '#####', '.###.'],                                                   // sekizgen (öğretici)
  K6: ['.####.', '######', '######', '######', '######', '.####.'],
  D7: ['..###..', '.#####.', '#######', '#######', '#######', '.#####.', '..###..'],               // elmas
  K78: ['.#####.', '#######', '#######', '#######', '#######', '#######', '#######', '.#####.'],
  A78: ['...#...', '..###..', '.#####.', '#######', '#######', '#######', '#######', '#######'],   // ev / ok
  OK: ['.#####.', '#######', '##...##', '##...##', '##...##', '#######', '.#####.'],               // köşesi kesik, ortası duvar
  PILK: ['.#####.', '#.###.#', '#######', '###.###', '#######', '#.###.#', '.#####.'],
  PIL8K: ['.#####.', '#######', '#.#.#.#', '#######', '#######', '#.#.#.#', '#######', '.#####.'],
  OK2: ['..###..', '.#####.', '##...##', '##...##', '##...##', '.#####.', '..###..'],
};
const PAL = ['c0', 'c4', 'c3', 'c2', 'c5', 'c1', 'c6'];   // kırmızı, mavi, yeşil, sarı, mor, turuncu, camgöbeği
// opts: { shape, colors, fill, big, locks, lockMin, lockMax, minLayers, maxFirst, tries }
// Döner: hedefi tutan ilk bölüm, tutan yoksa en zor bulunan (her durumda çözülebilir) ya da null
// Taş engeller: kabın iç hücrelerine (dış sıra/sütuna değmeyen) yan yana gelmeyecek biçimde 'S' konur; çözücü ve
// üretici yalnız '#' hücreleri boş saydığı için taş duvar gibi davranır (oyunda çekiç/bomba kırabilir)
function withStones(mask, n, R) {
  const h = mask.length, w = mask[0].length, m = mask.map((row) => row.split(''));
  const cells = [];
  for (let r = 1; r < h - 1; r++) for (let c = 1; c < w - 1; c++) if (m[r][c] === '#') cells.push([r, c]);
  for (let k = 0; k < n && cells.length; k++) {
    const ok = cells.filter(([r, c]) => m[r][c] === '#' && ![[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]].some(([dr, dc]) => m[r + dr] && m[r + dr][c + dc] === 'S'));
    if (!ok.length) break;
    const [r, c] = ok[Math.floor(R() * ok.length)];
    m[r][c] = 'S';
  }
  return m.map((row) => row.join(''));
}
export function generate(seed, opts) {
  const R = rng(seed);
  let best = null, bestScore = -1;
  const mask = SHAPES[opts.shape];
  const h = mask.length, w = mask[0].length;
  for (let attempt = 0; attempt < (opts.tries || 3000); attempt++) {
    const lv = { w, h, mask: opts.stones ? withStones(mask, opts.stones, R) : mask, blocks: [], gates: [] };
    const cols = PAL.slice(0, opts.colors).sort(() => R() - 0.5);
    const bigCols = cols.slice(0, opts.big || 0);
    // Kapı adayları: kabın dış çerçeveye değen kenarları
    const cand = [];
    for (let c = 0; c < w; c++) { if (mask[0][c] === '#') cand.push({ side: 'top', at: c }); if (mask[h - 1][c] === '#') cand.push({ side: 'bottom', at: c }); }
    for (let r = 0; r < h; r++) { if (mask[r][0] === '#') cand.push({ side: 'left', at: r }); if (mask[r][w - 1] === '#') cand.push({ side: 'right', at: r }); }
    const used = new Set();
    let ok = true;
    for (const col of cols) {
      const len = bigCols.includes(col) ? 2 : 1;
      const fits = cand.filter((g) => {
        for (let i = 0; i < len; i++) {
          if (used.has(g.side + (g.at + i))) return false;
          const a = g.at + i;
          const inside = g.side === 'top' ? mask[0][a] === '#' : g.side === 'bottom' ? mask[h - 1][a] === '#' : g.side === 'left' ? mask[a] && mask[a][0] === '#' : mask[a] && mask[a][w - 1] === '#';
          if (!inside) return false;
        }
        return true;
      });
      if (!fits.length) { ok = false; break; }
      const g = fits[Math.floor(R() * fits.length)];
      for (let i = -1; i <= len; i++) used.add(g.side + (g.at + i));   // yan yana kapı olmasın
      lv.gates.push({ side: g.side, at: g.at, len, col, lock: 0 });
    }
    if (!ok) continue;
    // Bloklar: önce 2×2'ler, sonra 1×1'ler (renkler dengeli dağılır)
    const occ = new Set();
    const free = (r, c, s) => { for (let i = 0; i < s; i++) for (let j = 0; j < s; j++) { if (!inMask(lv, r + i, c + j) || occ.has((r + i) * w + c + j)) return false; } return true; };
    const put = (r, c, s, col) => { for (let i = 0; i < s; i++) for (let j = 0; j < s; j++) occ.add((r + i) * w + c + j); lv.blocks.push({ r, c, s, col }); };
    for (const col of bigCols) {
      let placed = false;
      for (let t = 0; t < 80 && !placed; t++) { const r = Math.floor(R() * (h - 1)), c = Math.floor(R() * (w - 1)); if (free(r, c, 2)) { put(r, c, 2, col); placed = true; } }
      if (!placed) { ok = false; break; }
    }
    if (!ok) continue;
    const cells = [];
    for (let r = 0; r < h; r++) for (let c = 0; c < w; c++) if (inMask(lv, r, c)) cells.push([r, c]);
    const target = Math.round(cells.length * opts.fill);
    const smallCols = cols.filter((c) => !bigCols.includes(c));
    const bag = [];
    for (const [r, c] of cells.sort(() => R() - 0.5)) {
      if (occ.size >= target) break;
      if (occ.has(r * w + c)) continue;
      if (!bag.length) bag.push(...smallCols.slice().sort(() => R() - 0.5));
      put(r, c, 1, bag.pop());
    }
    // Kilitli kapılar: bazı kapılar ancak N blok çıktıktan sonra açılır
    const total = lv.blocks.length;
    const lockable = lv.gates.map((g, i) => i).sort(() => R() - 0.5).slice(0, opts.locks || 0);
    for (const i of lockable) {
      const own = lv.blocks.filter((b) => b.col === lv.gates[i].col).length;
      lv.gates[i].lock = Math.max(2, Math.min(total - own, Math.round(total * (opts.lockMin + R() * (opts.lockMax - opts.lockMin)))));
    }
    if (!lv.gates.some((g) => !g.lock)) continue;
    const sol = solveDrag(lv);
    if (!sol) continue;
    // Puan: zincir derinliği ve az sayıda başlangıç çıkışı zorluk demek
    const score = Math.min(sol.layers, opts.minLayers + 2) * 10 - Math.max(0, sol.first - opts.maxFirst) * 6;
    if (score > bestScore) { bestScore = score; best = { ...lv, layers: sol.layers, first: sol.first }; }
    if (sol.layers >= opts.minLayers && sol.first <= opts.maxFirst) return best;
  }
  return best;
}
