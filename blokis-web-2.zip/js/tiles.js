// Klasik pahlı bloklar: düz üst yüz ve dört eğimli kenar (üst açık, sol orta-açık,
// sağ orta-koyu, alt koyu). Keskin, temiz ve okunaklı.

function hexToRgb(h) { return [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)]; }
function shade(h, k) {
  const c = hexToRgb(h);
  const t = k >= 0 ? 255 : 0, a = Math.abs(k);
  return `rgb(${Math.round(c[0] + (t - c[0]) * a)},${Math.round(c[1] + (t - c[1]) * a)},${Math.round(c[2] + (t - c[2]) * a)})`;
}

// Ana tema: ana ekran, harita ve sonsuz mod
export const BASE = { name: 'mavi', scene: null, bg: ['#202a5c', '#0f1433'], board: '#0e1330', line: '#1b2350', frame: '#34407a', block: '#3d5be0' };

// Dünyalar: her 30 bölüm bir dünya; kendi renkleri ve arka plan sahnesi
export const WORLD_SIZE = 30;
export const WORLDS = [
  { name: 'Orman', scene: 'forest', bg: ['#1c3d2c', '#08160f'], board: '#0a1811', line: '#163224', frame: '#2f6247', block: '#3cbf68' },
  { name: 'Okyanus', scene: 'ocean', bg: ['#123d62', '#06172a'], board: '#071628', line: '#122f4c', frame: '#2a608e', block: '#2c9ae8' },
  { name: 'Çöl', scene: 'desert', bg: ['#4d2b18', '#1c0d06'], board: '#190c06', line: '#33201a', frame: '#7d4c2d', block: '#f2a22e' },
  { name: 'Uzay', scene: 'space', bg: ['#2a1b4c', '#090619'], board: '#0c0920', line: '#211947', frame: '#4a3a88', block: '#9257e8' },
  { name: 'Buzul', scene: 'ice', bg: ['#26486a', '#0c1b2c'], board: '#0b1828', line: '#1b344f', frame: '#5886b0', block: '#58b6ec' },
  { name: 'Volkan', scene: 'volcano', bg: ['#4a1513', '#170505'], board: '#150606', line: '#2e1111', frame: '#7c2b24', block: '#ff5a3c' },
];
export const worldIndex = (n) => Math.min(WORLDS.length - 1, Math.floor(n / WORLD_SIZE));
export const worldOf = (n) => WORLDS[worldIndex(n)];

// Dünya sahnesi: arka planın alt ve üst kenarlarında silik siluetler (tahtayı bastırmaz)
export function paintScene(x, w, h, scene) {
  if (!scene) return;
  const rnd = (() => { let s = 7; return () => (s = (s * 9301 + 49297) % 233280) / 233280; })();
  x.save();
  const fillGrad = (y0, y1, c0, c1) => { const g = x.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, c0); g.addColorStop(1, c1); return g; };
  if (scene === 'forest') {
    for (const [layer, base, col] of [[0, 0.8, 'rgba(10,40,24,0.55)'], [1, 0.88, 'rgba(4,20,12,0.8)']]) {
      x.fillStyle = col;
      for (let i = -1; i < 9; i++) {
        const tx = (i + (layer ? 0.5 : 0)) * w / 7 + rnd() * 20, th = h * (0.14 + rnd() * 0.08) * (layer ? 1.15 : 1), tw = th * 0.45, ty = h * base;
        x.beginPath(); x.moveTo(tx, ty - th);
        for (let k = 1; k <= 3; k++) { x.lineTo(tx + tw * k / 3, ty - th + th * k / 3); x.lineTo(tx + tw * (k - 0.6) / 3, ty - th + th * k / 3); }
        x.lineTo(tx, ty - th);
        for (let k = 1; k <= 3; k++) { x.lineTo(tx - tw * k / 3, ty - th + th * k / 3); x.lineTo(tx - tw * (k - 0.6) / 3, ty - th + th * k / 3); }
        x.fill();
      }
      x.fillRect(0, h * base, w, h);
    }
    x.fillStyle = 'rgba(200,255,140,0.5)';
    for (let i = 0; i < 26; i++) { x.beginPath(); x.arc(rnd() * w, rnd() * h * 0.8, 1 + rnd() * 2, 0, 7); x.fill(); }
  } else if (scene === 'ocean') {
    for (let i = 0; i < 5; i++) {
      const g = x.createLinearGradient(0, 0, 0, h * 0.7);
      g.addColorStop(0, 'rgba(160,220,255,0.10)'); g.addColorStop(1, 'rgba(160,220,255,0)');
      x.fillStyle = g; const cx = w * (0.1 + i * 0.22);
      x.beginPath(); x.moveTo(cx - w * 0.03, 0); x.lineTo(cx + w * 0.05, 0); x.lineTo(cx + w * 0.16, h * 0.7); x.lineTo(cx - w * 0.02, h * 0.7); x.fill();
    }
    for (let k = 0; k < 3; k++) {
      x.fillStyle = `rgba(4,20,40,${0.35 + k * 0.2})`;
      const by = h * (0.82 + k * 0.05);
      x.beginPath(); x.moveTo(0, h);
      for (let px = 0; px <= w; px += w / 40) x.lineTo(px, by + Math.sin(px / w * Math.PI * (3 + k) + k) * h * 0.012);
      x.lineTo(w, h); x.fill();
    }
    x.strokeStyle = 'rgba(190,235,255,0.35)'; x.lineWidth = Math.max(1, w / 400);
    for (let i = 0; i < 22; i++) { x.beginPath(); x.arc(rnd() * w, rnd() * h, 2 + rnd() * 6, 0, 7); x.stroke(); }
  } else if (scene === 'desert') {
    const sun = x.createRadialGradient(w * 0.72, h * 0.16, 0, w * 0.72, h * 0.16, w * 0.4);
    sun.addColorStop(0, 'rgba(255,200,110,0.45)'); sun.addColorStop(0.25, 'rgba(255,170,80,0.2)'); sun.addColorStop(1, 'rgba(255,150,60,0)');
    x.fillStyle = sun; x.fillRect(0, 0, w, h);
    x.fillStyle = 'rgba(255,215,150,0.5)'; x.beginPath(); x.arc(w * 0.72, h * 0.16, w * 0.07, 0, 7); x.fill();
    for (const [base, col, amp] of [[0.8, 'rgba(70,32,14,0.6)', 0.04], [0.88, 'rgba(36,16,6,0.85)', 0.03]]) {
      x.fillStyle = col; x.beginPath(); x.moveTo(0, h);
      for (let px = 0; px <= w; px += w / 40) x.lineTo(px, h * base - Math.sin(px / w * Math.PI * 2 + base * 9) * h * amp);
      x.lineTo(w, h); x.fill();
    }
  } else if (scene === 'space') {
    for (let i = 0; i < 120; i++) { x.fillStyle = `rgba(255,255,255,${0.2 + rnd() * 0.6})`; const r = rnd() * 1.6 + 0.3; x.beginPath(); x.arc(rnd() * w, rnd() * h, r, 0, 7); x.fill(); }
    const px = w * 0.8, py = h * 0.13, pr = w * 0.12;
    const pg = x.createLinearGradient(px - pr, py - pr, px + pr, py + pr); pg.addColorStop(0, 'rgba(230,140,255,0.55)'); pg.addColorStop(1, 'rgba(80,30,140,0.4)');
    x.fillStyle = pg; x.beginPath(); x.arc(px, py, pr, 0, 7); x.fill();
    x.strokeStyle = 'rgba(255,210,255,0.4)'; x.lineWidth = pr * 0.08;
    x.beginPath(); x.ellipse(px, py, pr * 1.7, pr * 0.42, -0.35, 0, 7); x.stroke();
    x.fillStyle = 'rgba(160,200,255,0.3)'; x.beginPath(); x.arc(w * 0.12, h * 0.9, w * 0.06, 0, 7); x.fill();
  } else if (scene === 'ice') {
    for (const [base, col, cap] of [[0.84, 'rgba(60,100,140,0.5)', 'rgba(230,245,255,0.45)'], [0.9, 'rgba(18,40,64,0.85)', 'rgba(210,235,255,0.35)']]) {
      for (let i = -1; i < 6; i++) {
        const mx = (i + rnd() * 0.5) * w / 4, mh = h * (0.12 + rnd() * 0.08), mw = mh * 1.1, my = h * base;
        x.fillStyle = col; x.beginPath(); x.moveTo(mx - mw, my); x.lineTo(mx, my - mh); x.lineTo(mx + mw, my); x.fill();
        x.fillStyle = cap; x.beginPath(); x.moveTo(mx - mw * 0.28, my - mh * 0.72); x.lineTo(mx, my - mh); x.lineTo(mx + mw * 0.28, my - mh * 0.72); x.lineTo(mx + mw * 0.1, my - mh * 0.66); x.lineTo(mx - mw * 0.08, my - mh * 0.74); x.fill();
      }
      x.fillStyle = col; x.fillRect(0, h * base, w, h);
    }
    x.fillStyle = 'rgba(255,255,255,0.55)';
    for (let i = 0; i < 50; i++) { x.beginPath(); x.arc(rnd() * w, rnd() * h * 0.85, 0.8 + rnd() * 2, 0, 7); x.fill(); }
  } else if (scene === 'volcano') {
    x.fillStyle = fillGrad(h * 0.7, h, 'rgba(255,90,30,0)', 'rgba(255,90,30,0.35)'); x.fillRect(0, h * 0.7, w, h * 0.3);
    for (const [base, col] of [[0.86, 'rgba(40,8,6,0.75)'], [0.92, 'rgba(14,2,2,0.9)']]) {
      x.fillStyle = col; x.beginPath(); x.moveTo(0, h);
      for (let px = 0; px <= w; px += w / 14) x.lineTo(px, h * base - rnd() * h * 0.07);
      x.lineTo(w, h); x.fill();
    }
    for (let i = 0; i < 40; i++) { x.fillStyle = `rgba(255,${120 + (rnd() * 100) | 0},40,${0.3 + rnd() * 0.5})`; x.beginPath(); x.arc(rnd() * w, h * (0.3 + rnd() * 0.6), 0.8 + rnd() * 2, 0, 7); x.fill(); }
  }
  x.restore();
}

const WOOD = '#d8a466';

function bevelTile(ctx, S, color) {
  const b = Math.round(S * 0.13); // pah genişliği
  const p = (pts, fill) => {
    ctx.beginPath();
    pts.forEach(([x, y], i) => (i ? ctx.lineTo(x, y) : ctx.moveTo(x, y)));
    ctx.closePath();
    ctx.fillStyle = fill;
    ctx.fill();
  };
  // Dört kenar
  p([[0, 0], [S, 0], [S - b, b], [b, b]], shade(color, 0.32));
  p([[0, 0], [b, b], [b, S - b], [0, S]], shade(color, 0.12));
  p([[S, 0], [S, S], [S - b, S - b], [S - b, b]], shade(color, -0.18));
  p([[0, S], [b, S - b], [S - b, S - b], [S, S]], shade(color, -0.38));
  // Üst yüz: hafif ışık geçişi
  const g = ctx.createLinearGradient(b, b, S - b, S - b);
  g.addColorStop(0, shade(color, 0.08));
  g.addColorStop(1, shade(color, -0.04));
  ctx.fillStyle = g;
  ctx.fillRect(b, b, S - 2 * b, S - 2 * b);
  // İnce dış hat
  ctx.strokeStyle = shade(color, -0.55);
  ctx.lineWidth = Math.max(1, S * 0.015);
  ctx.strokeRect(ctx.lineWidth / 2, ctx.lineWidth / 2, S - ctx.lineWidth, S - ctx.lineWidth);
}

export function renderTile(color, S) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  bevelTile(cv.getContext('2d'), S, color);
  return cv;
}

// Kraliyet bloğu: özel bölümlerde taçların altındaki altın çerçeveli mor kadife blok
export function renderRoyal(S) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  bevelTile(x, S, '#7a2fd2');
  const b = S * 0.13, m = S * 0.05;
  const g = x.createRadialGradient(S / 2, S * 0.45, 0, S / 2, S / 2, S * 0.5);
  g.addColorStop(0, 'rgba(255,215,120,0.32)'); g.addColorStop(1, 'rgba(255,215,120,0)');
  x.fillStyle = g; x.fillRect(b, b, S - 2 * b, S - 2 * b);
  x.strokeStyle = '#ffd23a'; x.lineWidth = S * 0.04;
  x.strokeRect(b + m, b + m, S - 2 * (b + m), S - 2 * (b + m));
  x.strokeStyle = 'rgba(255,240,180,0.5)'; x.lineWidth = S * 0.015;
  x.strokeRect(b + m * 2, b + m * 2, S - 2 * (b + m * 2), S - 2 * (b + m * 2));
  return cv;
}

// Hedef bloğu: ahşap blok üstünde simge
export function renderWood(S) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  bevelTile(x, S, WOOD);
  // Ahşap damarları
  const b = S * 0.13;
  x.save();
  x.beginPath();
  x.rect(b, b, S - 2 * b, S - 2 * b);
  x.clip();
  x.strokeStyle = 'rgba(140,90,40,0.18)';
  x.lineWidth = S * 0.012;
  for (let i = 0; i < 6; i++) {
    x.beginPath();
    const y = b + (S - 2 * b) * (i + 0.5) / 6;
    x.moveTo(b, y);
    x.bezierCurveTo(S * 0.4, y - S * 0.03, S * 0.6, y + S * 0.03, S - b, y);
    x.stroke();
  }
  x.restore();
  return cv;
}

// ---------- Hedef simgeleri ----------
// kind: 'gem' (mavi elmas), 'star' (yıldız), 'heart' (kalp)
export function renderIcon(kind, S) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  const c = S / 2, r = S * 0.34;
  x.lineJoin = 'round';
  if (kind === 'gem') {
    // Kare kesim elmas: dört üçgen yüz + üst tabla
    const t = r * 0.42;
    const tri = (pts, fill) => { x.beginPath(); pts.forEach(([px, py], i) => (i ? x.lineTo(px, py) : x.moveTo(px, py))); x.closePath(); x.fillStyle = fill; x.fill(); };
    x.save();
    x.filter = `blur(${S * 0.025}px)`;
    tri([[c, c - r + S * 0.04], [c + r, c + S * 0.04], [c, c + r + S * 0.04], [c - r, c + S * 0.04]], 'rgba(0,20,60,0.4)');
    x.restore();
    tri([[c, c - r], [c + r, c], [c + t, c], [c, c - t]], '#7fe6ff');   // sağ üst
    tri([[c, c - r], [c, c - t], [c - t, c], [c - r, c]], '#c4f6ff');   // sol üst
    tri([[c - r, c], [c - t, c], [c, c + t], [c, c + r]], '#2aa8ef');   // sol alt
    tri([[c + r, c], [c, c + r], [c, c + t], [c + t, c]], '#1477d1');   // sağ alt
    tri([[c, c - t], [c + t, c], [c, c + t], [c - t, c]], '#4fcfff');   // tabla
    x.beginPath();
    x.moveTo(c, c - r); x.lineTo(c + r, c); x.lineTo(c, c + r); x.lineTo(c - r, c); x.closePath();
    x.strokeStyle = '#0d4f9a';
    x.lineWidth = S * 0.025;
    x.stroke();
    x.fillStyle = 'rgba(255,255,255,0.85)';
    x.beginPath(); x.moveTo(c - t * 0.55, c - t * 0.15); x.lineTo(c - t * 0.15, c - t * 0.55); x.lineTo(c - t * 0.05, c - t * 0.4); x.lineTo(c - t * 0.4, c - t * 0.05); x.closePath(); x.fill();
    return cv;
  }
  if (kind === 'crown') {
    // Altın taç: üç sivri uç, uçlarda toplar, alt bantta mücevherler
    const w = r * 1.08, top = c - r * 0.82, base = c + r * 0.62;
    const crownPath = () => {
      x.beginPath();
      x.moveTo(c - w, base); x.lineTo(c - w, c - r * 0.42); x.lineTo(c - w * 0.48, c + r * 0.02);
      x.lineTo(c, top); x.lineTo(c + w * 0.48, c + r * 0.02); x.lineTo(c + w, c - r * 0.42); x.lineTo(c + w, base); x.closePath();
    };
    x.save(); x.filter = `blur(${S * 0.025}px)`; x.translate(0, S * 0.04); crownPath(); x.fillStyle = 'rgba(40,20,0,0.45)'; x.fill(); x.restore();
    crownPath();
    const g = x.createLinearGradient(0, top, 0, base);
    g.addColorStop(0, '#fff3a0'); g.addColorStop(0.45, '#ffcf2a'); g.addColorStop(1, '#e08a00');
    x.fillStyle = g; x.fill();
    x.lineWidth = S * 0.035; x.lineJoin = 'round'; x.strokeStyle = '#7a4300'; x.stroke();
    // Alt bant
    const bh = r * 0.34;
    x.fillStyle = '#e8a010'; x.fillRect(c - w, base - bh, w * 2, bh);
    x.strokeRect(c - w, base - bh, w * 2, bh);
    // Uç topları
    for (const [px, py] of [[c - w, c - r * 0.42], [c, top], [c + w, c - r * 0.42]]) {
      x.beginPath(); x.arc(px, py, S * 0.045, 0, 7); x.fillStyle = '#ffe680'; x.fill(); x.stroke();
    }
    // Mücevherler
    const jy = base - bh / 2;
    for (const [px, col] of [[c - w * 0.55, '#3a9bff'], [c, '#ff3b55'], [c + w * 0.55, '#3a9bff']]) {
      x.beginPath(); x.arc(px, jy, S * (px === c ? 0.055 : 0.042), 0, 7); x.fillStyle = col; x.fill();
      x.lineWidth = S * 0.02; x.strokeStyle = '#5a2e00'; x.stroke();
      x.beginPath(); x.arc(px - S * 0.012, jy - S * 0.014, S * 0.014, 0, 7); x.fillStyle = 'rgba(255,255,255,0.85)'; x.fill();
    }
    // Parlama
    x.fillStyle = 'rgba(255,255,255,0.55)';
    x.beginPath(); x.moveTo(c - w * 0.8, c - r * 0.2); x.lineTo(c - w * 0.62, c - r * 0.05); x.lineTo(c - w * 0.62, base - bh - S * 0.02); x.lineTo(c - w * 0.8, base - bh - S * 0.02); x.fill();
    return cv;
  }
  const path = () => {
    x.beginPath();
    if (kind === 'star') {
      for (let i = 0; i < 10; i++) {
        const rr = i % 2 ? r * 0.45 : r * 1.05, a = (i / 10) * Math.PI * 2 - Math.PI / 2;
        x.lineTo(c + Math.cos(a) * rr, c + r * 0.08 + Math.sin(a) * rr);
      }
    } else {
      x.moveTo(c, c + r * 0.95);
      x.bezierCurveTo(c - r * 1.4, c, c - r * 0.9, c - r * 1.05, c, c - r * 0.45);
      x.bezierCurveTo(c + r * 0.9, c - r * 1.05, c + r * 1.4, c, c, c + r * 0.95);
    }
    x.closePath();
  };
  const [light, mid, dark, line] = kind === 'star' ? ['#fffbd0', '#ffd21f', '#e08a00', '#7a4300'] : ['#ffd6e2', '#ff4d7d', '#c2124a', '#6e0628'];
  x.save();
  x.filter = `blur(${S * 0.025}px)`;
  x.translate(0, S * 0.04);
  path();
  x.fillStyle = 'rgba(0,0,30,0.4)';
  x.fill();
  x.restore();
  path();
  const g = x.createLinearGradient(c - r, c - r, c + r * 0.6, c + r);
  g.addColorStop(0, light);
  g.addColorStop(0.45, mid);
  g.addColorStop(1, dark);
  x.fillStyle = g;
  x.fill();
  x.lineWidth = S * 0.04;
  x.strokeStyle = line;
  x.stroke();
  return cv;
}

// ---------- Engeller ----------
// Buz: bloğun üstünde buzlu cam; çatlak sürümü bir vuruş sonrası
export function renderIce(S, cracked = false) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  const g = x.createLinearGradient(0, 0, S, S);
  g.addColorStop(0, 'rgba(235,250,255,0.82)'); g.addColorStop(0.5, 'rgba(170,220,250,0.62)'); g.addColorStop(1, 'rgba(120,190,240,0.7)');
  x.fillStyle = g;
  x.beginPath(); x.roundRect(S * 0.04, S * 0.04, S * 0.92, S * 0.92, S * 0.1); x.fill();
  x.strokeStyle = 'rgba(255,255,255,0.95)'; x.lineWidth = S * 0.04; x.stroke();
  x.fillStyle = 'rgba(255,255,255,0.7)';
  x.beginPath(); x.moveTo(S * 0.18, S * 0.2); x.lineTo(S * 0.5, S * 0.14); x.lineTo(S * 0.2, S * 0.42); x.fill();
  if (cracked) {
    x.strokeStyle = 'rgba(40,90,140,0.85)'; x.lineWidth = S * 0.035; x.lineJoin = 'round';
    x.beginPath(); x.moveTo(S * 0.5, S * 0.5); x.lineTo(S * 0.2, S * 0.32); x.moveTo(S * 0.5, S * 0.5); x.lineTo(S * 0.82, S * 0.26);
    x.moveTo(S * 0.5, S * 0.5); x.lineTo(S * 0.66, S * 0.86); x.moveTo(S * 0.5, S * 0.5); x.lineTo(S * 0.16, S * 0.74); x.stroke();
  }
  return cv;
}

// Zincir: çapraz iki zincir ve ortada kilit; links = kalan halka sayısı (2 ya da 1)
export function renderChain(S, links = 2) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  const link = (cx, cy, ang) => {
    x.save(); x.translate(cx, cy); x.rotate(ang);
    x.lineWidth = S * 0.06; x.strokeStyle = '#3a3f4a'; x.beginPath(); x.ellipse(0, 0, S * 0.1, S * 0.06, 0, 0, 7); x.stroke();
    x.lineWidth = S * 0.035; x.strokeStyle = '#c9d0dc'; x.beginPath(); x.ellipse(0, 0, S * 0.1, S * 0.06, 0, 0, 7); x.stroke();
    x.restore();
  };
  const diag = (dir) => { for (let i = -2; i <= 2; i++) { const t = i * 0.17; link(S / 2 + t * S, S / 2 + dir * t * S, dir * Math.PI / 4 + (i % 2 ? Math.PI / 2 : 0)); } };
  diag(1);
  if (links > 1) diag(-1);
  // Kilit
  x.fillStyle = '#7a4a10'; x.beginPath(); x.roundRect(S * 0.34, S * 0.44, S * 0.32, S * 0.26, S * 0.05); x.fill();
  const lg = x.createLinearGradient(0, S * 0.42, 0, S * 0.7); lg.addColorStop(0, '#ffe27a'); lg.addColorStop(1, '#e09a10');
  x.fillStyle = lg; x.beginPath(); x.roundRect(S * 0.35, S * 0.43, S * 0.3, S * 0.24, S * 0.05); x.fill();
  x.strokeStyle = '#c9d0dc'; x.lineWidth = S * 0.05; x.beginPath(); x.arc(S / 2, S * 0.43, S * 0.09, Math.PI, 0); x.stroke();
  x.fillStyle = '#7a4a10'; x.beginPath(); x.arc(S / 2, S * 0.53, S * 0.03, 0, 7); x.fill();
  return cv;
}

// Yosun: gri taş blok, üstünü ve kenarlarını saran düzensiz yosun lekeleri, benekler ve yapraklar
export function renderMoss(S) {
  const cv = renderTile('#7b8494', S);
  const x = cv.getContext('2d');
  let seed = 23;
  const rnd = () => (seed = (seed * 9301 + 49297) % 233280) / 233280;
  // Taş dokusu: hafif çatlaklar
  x.strokeStyle = 'rgba(40,46,60,0.35)'; x.lineWidth = S * 0.015; x.lineCap = 'round';
  x.beginPath(); x.moveTo(S * 0.2, S * 0.72); x.lineTo(S * 0.34, S * 0.64); x.lineTo(S * 0.4, S * 0.78); x.moveTo(S * 0.66, S * 0.82); x.lineTo(S * 0.78, S * 0.7); x.stroke();
  // Yosun lekesi: birbirine kaynamış dairelerden oluşan düzensiz şekil
  const blob = [];
  for (let i = 0; i < 14; i++) blob.push([S * (0.14 + rnd() * 0.72), S * (0.12 + rnd() * 0.4), S * (0.09 + rnd() * 0.08)]);
  for (let i = 0; i < 5; i++) blob.push([S * (0.1 + rnd() * 0.8), S * (0.45 + rnd() * 0.25), S * (0.05 + rnd() * 0.05)]);
  x.save();
  x.beginPath(); x.roundRect(S * 0.05, S * 0.05, S * 0.9, S * 0.9, S * 0.14); x.clip();
  const path = (grow) => { x.beginPath(); for (const [cx, cy, r] of blob) { x.moveTo(cx + r + grow, cy); x.arc(cx, cy, r + grow, 0, 7); } };
  path(S * 0.025); x.fillStyle = '#1f4a1c'; x.fill();             // koyu kenar
  const g = x.createLinearGradient(0, S * 0.05, 0, S * 0.75);
  g.addColorStop(0, '#a6e05a'); g.addColorStop(0.55, '#5fae3a'); g.addColorStop(1, '#3d8a2c');
  path(0); x.fillStyle = g; x.fill();
  // Benekli doku
  for (let i = 0; i < 90; i++) {
    const [cx, cy, r] = blob[Math.floor(rnd() * blob.length)];
    const a = rnd() * 7, d = rnd() * r;
    x.fillStyle = rnd() < 0.5 ? 'rgba(220,255,150,0.55)' : 'rgba(30,80,20,0.45)';
    x.beginPath(); x.arc(cx + Math.cos(a) * d, cy + Math.sin(a) * d, S * (0.008 + rnd() * 0.012), 0, 7); x.fill();
  }
  // Damlayan yosun ipleri
  x.strokeStyle = '#4c9a33'; x.lineWidth = S * 0.025;
  for (const fx of [0.22, 0.47, 0.7]) { x.beginPath(); x.moveTo(S * fx, S * 0.5); x.quadraticCurveTo(S * (fx + 0.03), S * 0.62, S * (fx - 0.01), S * 0.72); x.stroke(); }
  x.restore();
  // Yapraklar
  const leaf = (cx, cy, a, l) => {
    x.save(); x.translate(cx, cy); x.rotate(a);
    const lg = x.createLinearGradient(0, 0, 0, -l); lg.addColorStop(0, '#6cc43e'); lg.addColorStop(1, '#d8ff8a');
    x.fillStyle = lg; x.beginPath(); x.ellipse(0, -l / 2, l * 0.3, l / 2, 0, 0, 7); x.fill();
    x.strokeStyle = 'rgba(30,90,20,0.9)'; x.lineWidth = S * 0.012; x.stroke();
    x.beginPath(); x.moveTo(0, 0); x.lineTo(0, -l * 0.85); x.stroke();
    x.restore();
  };
  leaf(S * 0.32, S * 0.26, -0.55, S * 0.17); leaf(S * 0.4, S * 0.24, 0.2, S * 0.13); leaf(S * 0.7, S * 0.2, 0.5, S * 0.15);
  // Çiy damlası
  x.fillStyle = 'rgba(255,255,255,0.9)'; x.beginPath(); x.arc(S * 0.6, S * 0.36, S * 0.03, 0, 7); x.fill();
  return cv;
}

// Kafes: simgeli bloğun üstüne oturan altın çubuklu kafes (yarı saydam koyu zemin + perçinler)
export function renderCage(S) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  const p = S * 0.07, w = S - p * 2;
  x.fillStyle = 'rgba(10,8,30,0.14)';
  x.beginPath(); x.roundRect(p, p, w, w, S * 0.12); x.fill();
  const bar = (x0, y0, x1, y1, t) => {
    x.lineCap = 'round';
    x.strokeStyle = '#4a2a00'; x.lineWidth = t + S * 0.03; x.beginPath(); x.moveTo(x0, y0); x.lineTo(x1, y1); x.stroke();
    const g = x.createLinearGradient(x0 - t, y0 - t, x1 + t, y1 + t);
    g.addColorStop(0, '#fff3b0'); g.addColorStop(0.45, '#ffc93a'); g.addColorStop(1, '#c97a06');
    x.strokeStyle = g; x.lineWidth = t; x.beginPath(); x.moveTo(x0, y0); x.lineTo(x1, y1); x.stroke();
  };
  const t = S * 0.05;
  for (const f of [0.36, 0.64]) bar(S * f, p + t * 0.4, S * f, S - p - t * 0.4, t * 0.8);
  bar(p + t * 0.4, S * 0.5, S - p - t * 0.4, S * 0.5, t * 0.8);
  // Dış çerçeve
  x.lineWidth = S * 0.09; x.strokeStyle = '#4a2a00'; x.beginPath(); x.roundRect(p, p, w, w, S * 0.12); x.stroke();
  const fg = x.createLinearGradient(0, 0, S, S); fg.addColorStop(0, '#fff3b0'); fg.addColorStop(0.5, '#ffc93a'); fg.addColorStop(1, '#b86a00');
  x.lineWidth = S * 0.055; x.strokeStyle = fg; x.beginPath(); x.roundRect(p, p, w, w, S * 0.12); x.stroke();
  // Perçinler
  for (const fx of [0.36, 0.64]) for (const fy of [0.5]) {
    x.fillStyle = '#7a4300'; x.beginPath(); x.arc(S * fx, S * fy, S * 0.045, 0, 7); x.fill();
    x.fillStyle = '#fff6c8'; x.beginPath(); x.arc(S * fx - S * 0.01, S * fy - S * 0.01, S * 0.02, 0, 7); x.fill();
  }
  // Parıltı
  x.strokeStyle = 'rgba(255,255,255,0.75)'; x.lineWidth = S * 0.02; x.lineCap = 'round';
  x.beginPath(); x.moveTo(S * 0.16, S * 0.2); x.lineTo(S * 0.3, S * 0.12); x.stroke();
  return cv;
}

// Renkli blok: kendi renginde parlak blok + ortada beyaz halka içinde boya damlası (aynı renk ister)
export function renderNeed(color, S) {
  const cv = renderTile(color, S);
  const x = cv.getContext('2d');
  const c = S / 2, r = S * 0.24;
  x.fillStyle = 'rgba(0,0,30,0.28)'; x.beginPath(); x.arc(c, c + S * 0.03, r * 1.08, 0, 7); x.fill();
  const rg = x.createLinearGradient(0, c - r, 0, c + r); rg.addColorStop(0, '#ffffff'); rg.addColorStop(1, '#dfe4f0');
  x.fillStyle = rg; x.beginPath(); x.arc(c, c, r, 0, 7); x.fill();
  // Damla
  const d = r * 0.62;
  x.beginPath();
  x.moveTo(c, c - d * 1.05);
  x.bezierCurveTo(c + d * 0.25, c - d * 0.55, c + d * 0.78, c - d * 0.05, c + d * 0.78, c + d * 0.32);
  x.arc(c, c + d * 0.32, d * 0.78, 0, Math.PI);
  x.bezierCurveTo(c - d * 0.78, c - d * 0.05, c - d * 0.25, c - d * 0.55, c, c - d * 1.05);
  x.closePath();
  x.fillStyle = color; x.fill();
  x.strokeStyle = 'rgba(0,0,30,0.45)'; x.lineWidth = S * 0.02; x.stroke();
  x.fillStyle = 'rgba(255,255,255,0.75)'; x.beginPath(); x.ellipse(c - d * 0.32, c + d * 0.15, d * 0.13, d * 0.24, -0.4, 0, 7); x.fill();
  return cv;
}

// Saatli bomba bloğu: koyu blok üstünde fitilli bomba (sayı ayrıca yazılır)
export function renderBombBlock(S) {
  const cv = renderTile('#4a4f63', S);
  const x = cv.getContext('2d');
  const c = S / 2, r = S * 0.27;
  x.fillStyle = 'rgba(0,0,20,0.35)'; x.beginPath(); x.arc(c, c + S * 0.06, r, 0, 7); x.fill();
  const g = x.createRadialGradient(c - r * 0.4, c - r * 0.3, r * 0.1, c, c + S * 0.03, r);
  g.addColorStop(0, '#5b6275'); g.addColorStop(1, '#14161f');
  x.fillStyle = g; x.beginPath(); x.arc(c, c + S * 0.03, r, 0, 7); x.fill();
  x.fillStyle = '#2b2f3a'; x.fillRect(c + r * 0.35, c - r * 1.05, r * 0.5, r * 0.4);
  x.strokeStyle = '#d9b27a'; x.lineWidth = S * 0.03; x.beginPath(); x.moveTo(c + r * 0.6, c - r * 1.05); x.quadraticCurveTo(c + r * 0.9, c - r * 1.6, c + r * 1.3, c - r * 1.4); x.stroke();
  x.fillStyle = '#ffcf3a'; x.beginPath(); x.arc(c + r * 1.32, c - r * 1.42, S * 0.045, 0, 7); x.fill();
  return cv;
}

// ---------- Hazine kazısı ----------
// Toprak zemin: blok değil, tahtanın tabanı (üstüne parça konur). Düz, mat, kumlu; kat 2 daha koyu ve taşlı.
export function renderDirt(S, layer = 1, seed = 1) {
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  let s = seed * 977 + layer * 131;
  const rnd = () => (s = (s * 9301 + 49297) % 233280) / 233280;
  const m = S * 0.035, R = S * 0.12;
  const [top, bot, edge] = layer > 1 ? ['#8e5c34', '#5f3a1f', '#3b2210'] : ['#e2b46c', '#c18a45', '#7e5326'];
  const g = x.createLinearGradient(0, m, 0, S - m);
  g.addColorStop(0, top); g.addColorStop(1, bot);
  x.beginPath(); x.roundRect(m, m, S - 2 * m, S - 2 * m, R);
  x.fillStyle = g; x.fill();
  x.save(); x.clip();
  // Kum taneleri
  for (let i = 0; i < S * 0.9; i++) {
    const px = rnd() * S, py = rnd() * S, r = S * (0.008 + rnd() * 0.014);
    x.fillStyle = rnd() < 0.5 ? (layer > 1 ? 'rgba(30,14,4,0.35)' : 'rgba(120,70,20,0.3)') : (layer > 1 ? 'rgba(200,150,100,0.22)' : 'rgba(255,240,200,0.4)');
    x.beginPath(); x.arc(px, py, r, 0, 7); x.fill();
  }
  // Çakıllar
  const pebbles = layer > 1 ? 4 : 2;
  for (let i = 0; i < pebbles; i++) {
    const px = S * (0.2 + rnd() * 0.6), py = S * (0.2 + rnd() * 0.6), rx = S * (0.05 + rnd() * 0.05), ry = rx * (0.6 + rnd() * 0.3);
    x.fillStyle = layer > 1 ? '#3e2a1c' : '#9a6a38';
    x.beginPath(); x.ellipse(px, py + S * 0.01, rx, ry, rnd() * 3, 0, 7); x.fill();
    x.fillStyle = layer > 1 ? '#7d6250' : '#d9b07a';
    x.beginPath(); x.ellipse(px - rx * 0.15, py - ry * 0.15, rx * 0.8, ry * 0.75, 0, 0, 7); x.fill();
  }
  if (layer > 1) {
    // Çatlaklar: sert kaya katmanı
    x.strokeStyle = 'rgba(25,10,2,0.55)'; x.lineWidth = S * 0.025; x.lineCap = 'round'; x.lineJoin = 'round';
    x.beginPath(); x.moveTo(S * 0.15, S * 0.3); x.lineTo(S * 0.38, S * 0.42); x.lineTo(S * 0.46, S * 0.68); x.lineTo(S * 0.7, S * 0.78);
    x.moveTo(S * 0.38, S * 0.42); x.lineTo(S * 0.62, S * 0.3); x.lineTo(S * 0.85, S * 0.36); x.stroke();
  }
  // İç gölge: zemin hafif çukur görünür
  const ig = x.createLinearGradient(0, m, 0, S * 0.3);
  ig.addColorStop(0, 'rgba(0,0,0,0.28)'); ig.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = ig; x.fillRect(0, 0, S, S * 0.3);
  x.restore();
  x.beginPath(); x.roundRect(m, m, S - 2 * m, S - 2 * m, R);
  x.strokeStyle = edge; x.lineWidth = S * 0.03; x.stroke();
  x.beginPath(); x.moveTo(m + R, S - m - S * 0.025); x.lineTo(S - m - R, S - m - S * 0.025);
  x.strokeStyle = layer > 1 ? 'rgba(255,200,150,0.15)' : 'rgba(255,240,200,0.45)'; x.lineWidth = S * 0.02; x.stroke();
  return cv;
}

// Gömülü hazine: w×h kare kaplar. mode: 'hole' kazılmış çukur, 'item' eşya, 'icon' tek kareye sığan hedef simgesi.
export const TREASURE = { chest: [2, 2], crown: [2, 2], vase: [1, 2], key: [2, 1] };
export function renderTreasure(kind, S, mode = 'item') {
  const [w, h] = TREASURE[kind];
  const hole = mode !== 'icon';
  const cv = document.createElement('canvas');
  const W = hole ? w * S : S, H = hole ? h * S : S;
  cv.width = W; cv.height = H;
  const x = cv.getContext('2d');
  x.lineJoin = 'round'; x.lineCap = 'round';
  if (mode === 'hole') {
    // Kazılmış çukur: koyu toprak, iç gölge
    const m = S * 0.05;
    x.beginPath(); x.roundRect(m, m, W - 2 * m, H - 2 * m, S * 0.16);
    const g = x.createRadialGradient(W / 2, H / 2, 0, W / 2, H / 2, Math.max(W, H) * 0.6);
    g.addColorStop(0, '#4a2d18'); g.addColorStop(1, '#24140a');
    x.fillStyle = g; x.fill();
    x.save(); x.clip();
    x.shadowColor = 'rgba(0,0,0,0.8)'; x.shadowBlur = S * 0.18; x.shadowOffsetY = S * 0.06;
    x.lineWidth = S * 0.12; x.strokeStyle = '#000'; x.stroke();
    x.restore();
    x.strokeStyle = '#6b4424'; x.lineWidth = S * 0.03;
    x.beginPath(); x.roundRect(m, m, W - 2 * m, H - 2 * m, S * 0.16); x.stroke();
    return cv;
  }
  // Eşya kendi kutusunda çizilir; simgede tek kareye sığdırılır
  const k = hole ? 1 : 1 / Math.max(w, h);
  x.save();
  x.translate(hole ? 0 : (S - w * S * k) / 2, hole ? 0 : (S - h * S * k) / 2);
  x.scale(k, k);
  const IW = w * S, IH = h * S;
  // Gölge
  x.save(); x.filter = `blur(${S * 0.05}px)`; x.fillStyle = 'rgba(0,0,0,0.5)';
  x.beginPath(); x.ellipse(IW / 2, IH * 0.86, IW * 0.38, IH * 0.08, 0, 0, 7); x.fill(); x.restore();
  const gold = (y0, y1) => { const g = x.createLinearGradient(0, y0, 0, y1); g.addColorStop(0, '#fff3a6'); g.addColorStop(0.45, '#ffcc2a'); g.addColorStop(1, '#d98400'); return g; };
  if (kind === 'chest') {
    const l = IW * 0.12, r = IW * 0.88, t = IH * 0.2, mid = IH * 0.46, b = IH * 0.84;
    // Gövde
    const wood = x.createLinearGradient(0, mid, 0, b); wood.addColorStop(0, '#b0602a'); wood.addColorStop(1, '#6e3412');
    x.beginPath(); x.roundRect(l, mid, r - l, b - mid, S * 0.06); x.fillStyle = wood; x.fill();
    x.lineWidth = S * 0.05; x.strokeStyle = '#3c1a06'; x.stroke();
    // Kapak (kubbeli)
    const lid = x.createLinearGradient(0, t, 0, mid); lid.addColorStop(0, '#d47a38'); lid.addColorStop(1, '#8a4318');
    x.beginPath(); x.moveTo(l, mid); x.lineTo(l, t + IH * 0.1); x.quadraticCurveTo(IW / 2, t - IH * 0.08, r, t + IH * 0.1); x.lineTo(r, mid); x.closePath();
    x.fillStyle = lid; x.fill(); x.stroke();
    // Tahta çizgileri
    x.strokeStyle = 'rgba(60,25,5,0.5)'; x.lineWidth = S * 0.025;
    x.beginPath(); x.moveTo(l, IH * 0.65); x.lineTo(r, IH * 0.65); x.stroke();
    // Altın bantlar
    for (const bx of [l + IW * 0.1, r - IW * 0.1 - IW * 0.09]) {
      x.fillStyle = gold(t, b); x.fillRect(bx, t + IH * 0.02, IW * 0.09, b - t - IH * 0.02);
      x.strokeStyle = '#7a4300'; x.lineWidth = S * 0.025; x.strokeRect(bx, t + IH * 0.02, IW * 0.09, b - t - IH * 0.02);
    }
    x.fillStyle = gold(mid - IH * 0.03, mid + IH * 0.03); x.fillRect(l, mid - IH * 0.03, r - l, IH * 0.06);
    x.strokeRect(l, mid - IH * 0.03, r - l, IH * 0.06);
    // Kilit
    x.beginPath(); x.roundRect(IW / 2 - IW * 0.08, mid - IH * 0.07, IW * 0.16, IH * 0.18, S * 0.04);
    x.fillStyle = gold(mid - IH * 0.07, mid + IH * 0.11); x.fill(); x.lineWidth = S * 0.035; x.stroke();
    x.fillStyle = '#3c1a06'; x.beginPath(); x.arc(IW / 2, mid + IH * 0.005, IW * 0.022, 0, 7); x.fill();
    x.fillRect(IW / 2 - IW * 0.01, mid, IW * 0.02, IH * 0.06);
    // Parlama
    x.fillStyle = 'rgba(255,255,255,0.35)';
    x.beginPath(); x.ellipse(l + IW * 0.2, t + IH * 0.1, IW * 0.08, IH * 0.03, -0.3, 0, 7); x.fill();
  } else if (kind === 'crown') {
    const cw = IW * 0.36, c = IW / 2, top = IH * 0.18, base = IH * 0.78, bh = IH * 0.14;
    const path = () => { x.beginPath(); x.moveTo(c - cw, base); x.lineTo(c - cw, IH * 0.34); x.lineTo(c - cw * 0.48, IH * 0.52); x.lineTo(c, top); x.lineTo(c + cw * 0.48, IH * 0.52); x.lineTo(c + cw, IH * 0.34); x.lineTo(c + cw, base); x.closePath(); };
    path(); x.fillStyle = gold(top, base); x.fill(); x.lineWidth = S * 0.06; x.strokeStyle = '#7a4300'; x.stroke();
    x.fillStyle = '#e8a010'; x.fillRect(c - cw, base - bh, cw * 2, bh); x.lineWidth = S * 0.045; x.strokeRect(c - cw, base - bh, cw * 2, bh);
    for (const [px, py] of [[c - cw, IH * 0.34], [c, top], [c + cw, IH * 0.34]]) { x.beginPath(); x.arc(px, py, S * 0.09, 0, 7); x.fillStyle = '#ffe680'; x.fill(); x.stroke(); }
    for (const [px, col, rr] of [[c - cw * 0.55, '#3a9bff', 0.08], [c, '#ff3b55', 0.11], [c + cw * 0.55, '#3a9bff', 0.08]]) {
      x.beginPath(); x.arc(px, base - bh / 2, S * rr, 0, 7); x.fillStyle = col; x.fill(); x.lineWidth = S * 0.035; x.strokeStyle = '#5a2e00'; x.stroke();
      x.beginPath(); x.arc(px - S * 0.025, base - bh / 2 - S * 0.03, S * 0.028, 0, 7); x.fillStyle = 'rgba(255,255,255,0.85)'; x.fill();
    }
    x.fillStyle = 'rgba(255,255,255,0.5)';
    x.beginPath(); x.moveTo(c - cw * 0.82, IH * 0.42); x.lineTo(c - cw * 0.64, IH * 0.52); x.lineTo(c - cw * 0.64, base - bh - S * 0.04); x.lineTo(c - cw * 0.82, base - bh - S * 0.04); x.fill();
  } else if (kind === 'vase') {
    const c = IW / 2;
    const path = () => {
      x.beginPath();
      x.moveTo(c - IW * 0.16, IH * 0.1); x.lineTo(c + IW * 0.16, IH * 0.1);
      x.lineTo(c + IW * 0.12, IH * 0.2);
      x.bezierCurveTo(c + IW * 0.46, IH * 0.3, c + IW * 0.44, IH * 0.66, c + IW * 0.16, IH * 0.8);
      x.lineTo(c + IW * 0.2, IH * 0.88); x.lineTo(c - IW * 0.2, IH * 0.88); x.lineTo(c - IW * 0.16, IH * 0.8);
      x.bezierCurveTo(c - IW * 0.44, IH * 0.66, c - IW * 0.46, IH * 0.3, c - IW * 0.12, IH * 0.2);
      x.closePath();
    };
    // Kulplar
    x.strokeStyle = '#7a2e12'; x.lineWidth = S * 0.07;
    x.beginPath(); x.moveTo(c - IW * 0.13, IH * 0.2); x.bezierCurveTo(c - IW * 0.42, IH * 0.18, c - IW * 0.42, IH * 0.34, c - IW * 0.3, IH * 0.36); x.stroke();
    x.beginPath(); x.moveTo(c + IW * 0.13, IH * 0.2); x.bezierCurveTo(c + IW * 0.42, IH * 0.18, c + IW * 0.42, IH * 0.34, c + IW * 0.3, IH * 0.36); x.stroke();
    path();
    const g = x.createLinearGradient(c - IW * 0.4, 0, c + IW * 0.4, 0); g.addColorStop(0, '#f08a4a'); g.addColorStop(0.45, '#d8582a'); g.addColorStop(1, '#8e2e10');
    x.fillStyle = g; x.fill(); x.lineWidth = S * 0.05; x.strokeStyle = '#4a1606'; x.stroke();
    // Desen bantları
    x.save(); path(); x.clip();
    x.fillStyle = '#2a1408'; x.fillRect(0, IH * 0.42, IW, IH * 0.04); x.fillRect(0, IH * 0.6, IW, IH * 0.04);
    x.fillStyle = '#ffcf5a';
    for (let i = 0; i < 6; i++) { const px = c - IW * 0.36 + i * IW * 0.144; x.beginPath(); x.moveTo(px, IH * 0.475); x.lineTo(px + IW * 0.06, IH * 0.565); x.lineTo(px - IW * 0.06, IH * 0.565); x.closePath(); x.fill(); }
    x.fillStyle = 'rgba(255,255,255,0.3)'; x.beginPath(); x.ellipse(c - IW * 0.14, IH * 0.34, IW * 0.05, IH * 0.1, 0.2, 0, 7); x.fill();
    x.restore();
  } else if (kind === 'key') {
    const cy = IH / 2;
    x.lineWidth = S * 0.045; x.strokeStyle = '#7a4300';
    // Sap
    x.beginPath(); x.roundRect(IW * 0.36, cy - IH * 0.07, IW * 0.5, IH * 0.14, IH * 0.05); x.fillStyle = gold(cy - IH * 0.07, cy + IH * 0.07); x.fill(); x.stroke();
    // Dişler
    for (const [px, d] of [[0.7, 0.22], [0.8, 0.16]]) { x.beginPath(); x.rect(IW * px, cy, IW * 0.06, IH * d); x.fillStyle = gold(cy, cy + IH * d); x.fill(); x.stroke(); }
    // Baş halka
    x.beginPath(); x.arc(IW * 0.26, cy, IH * 0.3, 0, 7); x.fillStyle = gold(cy - IH * 0.3, cy + IH * 0.3); x.fill(); x.lineWidth = S * 0.05; x.stroke();
    x.beginPath(); x.arc(IW * 0.26, cy, IH * 0.13, 0, 7); x.fillStyle = '#5a3008'; x.fill(); x.stroke();
    x.beginPath(); x.arc(IW * 0.26, cy - IH * 0.21, IH * 0.06, 0, 7); x.fillStyle = '#ff3b55'; x.fill(); x.lineWidth = S * 0.025; x.stroke();
    x.fillStyle = 'rgba(255,255,255,0.55)'; x.beginPath(); x.ellipse(IW * 0.2, cy - IH * 0.12, IW * 0.03, IH * 0.06, -0.6, 0, 7); x.fill();
  }
  x.restore();
  return cv;
}

// ---------- Güç blokları ----------
// Büyük patlatmadan doğan güçler: roket (satır/sütun), bomba (5×5), yıldırım küresi (rastgele bloklara yıldırım)
// part: 'full' kare + simge, 'tile' yalnız kare, 'icon' yalnız simge (oyunda simge ayrı canlandırılır)
// [açık, ana, koyu, neon iç ışık]
const POWER_PAL = { rocket: ['#bfe6ff', '#2f86ff', '#0b2c86', '#7cc4ff'], bomb: ['#ffd6a0', '#ff5a26', '#7a1206', '#ff9a4a'], bolt: ['#ecd8ff', '#8f44ff', '#2a0a78', '#c79bff'], prop: ['#c4ffe0', '#19c46c', '#04532c', '#6dffb0'] };
function rr(x, X, Y, w, h, r) { x.beginPath(); x.roundRect(X, Y, w, h, r); }
export function renderPower(kind, S, part = 'full') {
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  const c = S / 2, P = POWER_PAL[kind];
  x.lineJoin = 'round'; x.lineCap = 'round';
  if (part !== 'icon') {
    // Cam kapsül: krom çerçeve → koyu cam iç → güç renginde neon iç ışık → çapraz cam yansıması
    const m = S * 0.045, R = S * 0.22, t = S * 0.055;
    rr(x, m, m + S * 0.02, S - 2 * m, S - 2 * m, R); x.fillStyle = 'rgba(0,0,20,0.6)'; x.fill();
    const ch = x.createLinearGradient(0, m, 0, S - m);
    ch.addColorStop(0, '#ffffff'); ch.addColorStop(0.25, '#c9d3ea'); ch.addColorStop(0.55, '#6f7aa0'); ch.addColorStop(0.8, '#c3cbe2'); ch.addColorStop(1, '#4a5378');
    rr(x, m, m, S - 2 * m, S - 2 * m, R); x.fillStyle = ch; x.fill();
    const body = x.createRadialGradient(c, S * 0.55, S * 0.05, c, c, S * 0.5);
    body.addColorStop(0, P[1]); body.addColorStop(0.6, P[2]); body.addColorStop(1, '#05061a');
    rr(x, m + t, m + t, S - 2 * (m + t), S - 2 * (m + t), R - t); x.fillStyle = body; x.fill();
    x.save(); rr(x, m + t, m + t, S - 2 * (m + t), S - 2 * (m + t), R - t); x.clip();
    x.shadowColor = P[3]; x.shadowBlur = S * 0.08; x.strokeStyle = P[3]; x.lineWidth = S * 0.025;
    rr(x, m + t + S * 0.005, m + t + S * 0.005, S - 2 * (m + t) - S * 0.01, S - 2 * (m + t) - S * 0.01, R - t); x.stroke();
    x.shadowBlur = 0;
    x.globalCompositeOperation = 'lighter';
    const ref = x.createLinearGradient(0, 0, S, S);
    ref.addColorStop(0, 'rgba(255,255,255,0.28)'); ref.addColorStop(0.42, 'rgba(255,255,255,0.08)'); ref.addColorStop(0.43, 'rgba(255,255,255,0)'); ref.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = ref; x.fillRect(0, 0, S, S);
    x.restore();
    x.strokeStyle = 'rgba(255,255,255,0.8)'; x.lineWidth = S * 0.01;
    rr(x, m + S * 0.012, m + S * 0.012, S - 2 * m - S * 0.024, S - 2 * m - S * 0.024, R - S * 0.012); x.stroke();
    if (part === 'tile') return cv;
  }
  const ink = '#10164a', lw = S * 0.028;
  // Simge kareyi doldursun: merkeze göre büyütülür
  x.save(); x.translate(c, c); x.scale(1.16, 1.16); x.translate(-c, -c);
  if (kind === 'rocket') drawRocketPair(x, S, c, ink, lw);
  else if (kind === 'bomb') drawBomb(x, S, c, ink, lw);
  else if (kind === 'prop') drawPropeller(x, S, c, ink, lw);
  else drawBoltOrb(x, S, c, ink, lw);
  x.restore();
  return cv;
}
// Sayaçlı bomba (özel bölüm engeli): güç bombasıyla aynı bomba, ama çelik çerçeve + koyu kırmızı "tehlike" zemin, üstünde sayı
export function renderTimerBomb(S, n, urgent = false, font = 'system-ui') {
  const cv = document.createElement('canvas');
  cv.width = cv.height = S;
  const x = cv.getContext('2d');
  const c = S / 2, m1 = S * 0.03, m2 = S * 0.075, m3 = S * 0.125;
  rr(x, m1, m1, S - 2 * m1, S - 2 * m1, S * 0.2); x.fillStyle = '#120c34'; x.fill();
  const steel = x.createLinearGradient(0, m2, 0, S - m2);
  steel.addColorStop(0, '#f2f5fb'); steel.addColorStop(0.4, '#a9b2c8'); steel.addColorStop(1, '#4f566e');
  rr(x, m2, m2, S - 2 * m2, S - 2 * m2, S * 0.16); x.fillStyle = steel; x.fill();
  const body = x.createRadialGradient(c, c * 0.8, S * 0.04, c, c, S * 0.48);
  body.addColorStop(0, urgent ? '#ff6a5a' : '#c8343a'); body.addColorStop(0.6, '#7a0e18'); body.addColorStop(1, '#2a0408');
  rr(x, m3, m3, S - 2 * m3, S - 2 * m3, S * 0.12); x.fillStyle = body; x.fill();
  x.save(); rr(x, m3, m3, S - 2 * m3, S - 2 * m3, S * 0.12); x.clip();
  // Uyarı şeritleri
  x.strokeStyle = 'rgba(255,200,40,0.16)'; x.lineWidth = S * 0.06;
  for (let i = -3; i < 6; i++) { x.beginPath(); x.moveTo(i * S * 0.2, S); x.lineTo(i * S * 0.2 + S, 0); x.stroke(); }
  const gloss = x.createLinearGradient(0, m3, 0, c);
  gloss.addColorStop(0, 'rgba(255,255,255,0.3)'); gloss.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = gloss; x.beginPath(); x.ellipse(c, m3, S * 0.42, S * 0.24, 0, 0, Math.PI); x.fill();
  x.restore();
  x.save(); x.translate(c, c); x.scale(1.1, 1.1); x.translate(-c, -c);
  x.lineJoin = 'round'; x.lineCap = 'round';
  drawBomb(x, S, c, '#10164a', S * 0.028);
  x.restore();
  if (n === null) return cv;   // normal bölümde sayı ayrı yazı olarak üstüne konur
  // Sayı bombanın üstünde
  x.font = `900 ${Math.round(S * 0.36)}px ${font}`; x.textAlign = 'center'; x.textBaseline = 'middle';
  x.lineJoin = 'round'; x.lineWidth = S * 0.09; x.strokeStyle = '#14161f';
  x.strokeText(String(n), c - S * 0.02, c + S * 0.08);
  x.fillStyle = urgent ? '#ff5a6a' : '#ffffff'; x.fillText(String(n), c - S * 0.02, c + S * 0.08);
  return cv;
}
function metal(x, y0, y1) {
  const g = x.createLinearGradient(0, y0, 0, y1);
  g.addColorStop(0, '#ffffff'); g.addColorStop(0.35, '#e8eefb'); g.addColorStop(0.7, '#a9b6d6'); g.addColorStop(1, '#6f7ca6');
  return g;
}
// Tek roket (sağa bakar): gövde L0 → L1, sivri burun nl uzunluğunda, yükseklik 2h
function drawRocket(x, S, ink, lw, L0, L1, h, nl = h * 1.6) {
  const tip = L1 + nl;
  const finG = x.createLinearGradient(0, -h * 2.4, 0, h * 2.4);
  finG.addColorStop(0, '#ff9090'); finG.addColorStop(0.5, '#ff2d48'); finG.addColorStop(1, '#a00a22');
  // Geriye doğru kanatlar (üst ve alt)
  for (const sg of [-1, 1]) {
    x.beginPath();
    x.moveTo(L0 + (L1 - L0) * 0.55, sg * h * 0.9);
    x.quadraticCurveTo(L0 + (L1 - L0) * 0.3, sg * h * 1.5, L0 + S * 0.01, sg * h * 2.2);
    x.lineTo(L0 - S * 0.035, sg * h * 2.2);
    x.lineTo(L0, sg * h * 0.9);
    x.closePath();
    x.fillStyle = finG; x.fill(); x.strokeStyle = ink; x.lineWidth = lw; x.stroke();
  }
  // Gövde + sivri burun tek parça
  const shape = () => {
    x.beginPath();
    x.moveTo(L0, -h * 0.85);
    x.quadraticCurveTo(L0, -h, L0 + h * 0.2, -h);
    x.lineTo(L1, -h);
    x.quadraticCurveTo(L1 + nl * 0.55, -h, tip, 0);
    x.quadraticCurveTo(L1 + nl * 0.55, h, L1, h);
    x.lineTo(L0 + h * 0.2, h);
    x.quadraticCurveTo(L0, h, L0, h * 0.85);
    x.closePath();
  };
  shape(); x.fillStyle = metal(x, -h, h); x.fill();
  x.save(); shape(); x.clip();
  const nose = x.createLinearGradient(0, -h, 0, h); nose.addColorStop(0, '#ff8a8a'); nose.addColorStop(0.5, '#ff2d48'); nose.addColorStop(1, '#9a0820');
  x.fillStyle = nose; x.fillRect(L1, -h * 1.2, nl + h, h * 2.4);
  x.fillStyle = '#ff2d48'; x.fillRect(L0 + (L1 - L0) * 0.12, -h * 1.2, (L1 - L0) * 0.1, h * 2.4);   // kırmızı bant
  x.fillStyle = 'rgba(255,255,255,0.8)'; x.fillRect(L0, -h * 0.72, tip - L0, h * 0.22);           // parlama
  x.fillStyle = 'rgba(0,0,40,0.18)'; x.fillRect(L0, h * 0.4, tip - L0, h * 0.6);                  // alt gölge
  x.restore();
  shape(); x.strokeStyle = ink; x.lineWidth = lw; x.stroke();
  x.beginPath(); x.moveTo(L1, -h); x.quadraticCurveTo(L1 + h * 0.15, 0, L1, h); x.strokeStyle = ink; x.lineWidth = lw * 0.7; x.stroke();
  // Pencere
  const wx = L0 + (L1 - L0) * 0.62, wr = h * 0.48;
  const win = x.createRadialGradient(wx - wr * 0.3, -wr * 0.3, wr * 0.1, wx, 0, wr);
  win.addColorStop(0, '#e6fbff'); win.addColorStop(0.5, '#5ad0ff'); win.addColorStop(1, '#1a5fc0');
  x.beginPath(); x.arc(wx, 0, wr * 1.3, 0, 7); x.fillStyle = '#8c98bd'; x.fill(); x.strokeStyle = ink; x.lineWidth = lw * 0.7; x.stroke();
  x.beginPath(); x.arc(wx, 0, wr, 0, 7); x.fillStyle = win; x.fill();
  x.fillStyle = 'rgba(255,255,255,0.9)'; x.beginPath(); x.arc(wx - wr * 0.35, -wr * 0.35, wr * 0.25, 0, 7); x.fill();
}
function drawRocketPair(x, S, c, ink, lw) {
  x.save(); x.translate(c, c);
  // Ortadaki alev
  const fl = x.createRadialGradient(0, 0, 0, 0, 0, S * 0.13);
  fl.addColorStop(0, '#ffffff'); fl.addColorStop(0.35, '#fff07a'); fl.addColorStop(0.7, '#ff8a1a'); fl.addColorStop(1, 'rgba(255,90,20,0)');
  x.fillStyle = fl; x.beginPath(); x.arc(0, 0, S * 0.13, 0, 7); x.fill();
  for (const dir of [1, -1]) { x.save(); x.scale(dir, 1); drawRocket(x, S, ink, lw, S * 0.06, S * 0.25, S * 0.085, S * 0.12); x.restore(); }
  // Hız çizgileri
  x.strokeStyle = 'rgba(255,255,255,0.6)'; x.lineWidth = S * 0.012;
  for (const [y0, l] of [[-S * 0.2, 0.08], [S * 0.2, 0.06]]) { x.beginPath(); x.moveTo(-S * 0.1, y0); x.lineTo(-S * (0.1 + l), y0); x.moveTo(S * 0.1, y0); x.lineTo(S * (0.1 + l), y0); x.stroke(); }
  x.restore();
}
function drawBomb(x, S, c, ink, lw) {
  const r = S * 0.25, bx = c - S * 0.02, by = c + S * 0.06;
  // Gölge
  x.save(); x.filter = `blur(${S * 0.02}px)`; x.fillStyle = 'rgba(20,0,0,0.45)'; x.beginPath(); x.ellipse(bx + S * 0.02, by + r * 0.95, r * 0.85, r * 0.25, 0, 0, 7); x.fill(); x.restore();
  // Küre
  const g = x.createRadialGradient(bx - r * 0.38, by - r * 0.42, r * 0.06, bx, by, r * 1.05);
  g.addColorStop(0, '#8a90ad'); g.addColorStop(0.3, '#3a3e58'); g.addColorStop(0.75, '#14151f'); g.addColorStop(1, '#05060a');
  x.beginPath(); x.arc(bx, by, r, 0, 7); x.fillStyle = g; x.fill(); x.strokeStyle = '#000'; x.lineWidth = lw; x.stroke();
  // Kenar ışığı (alt sağ)
  x.save(); x.beginPath(); x.arc(bx, by, r, 0, 7); x.clip();
  x.strokeStyle = 'rgba(120,170,255,0.35)'; x.lineWidth = S * 0.03; x.beginPath(); x.arc(bx - r * 0.08, by - r * 0.08, r, 0.1, 1.5); x.stroke();
  x.restore();
  // Parlamalar
  x.fillStyle = 'rgba(255,255,255,0.75)'; x.beginPath(); x.ellipse(bx - r * 0.42, by - r * 0.45, r * 0.22, r * 0.12, -0.7, 0, 7); x.fill();
  x.fillStyle = 'rgba(255,255,255,0.4)'; x.beginPath(); x.arc(bx - r * 0.12, by - r * 0.68, r * 0.06, 0, 7); x.fill();
  // Kapak (perçinli)
  x.save(); x.translate(bx + r * 0.52, by - r * 0.72); x.rotate(0.62);
  const cap = x.createLinearGradient(0, -r * 0.2, 0, r * 0.2); cap.addColorStop(0, '#c9cfe0'); cap.addColorStop(0.5, '#6d7390'); cap.addColorStop(1, '#3a3f58');
  rr(x, -r * 0.3, -r * 0.2, r * 0.6, r * 0.36, r * 0.08); x.fillStyle = cap; x.fill(); x.strokeStyle = '#000'; x.lineWidth = lw * 0.8; x.stroke();
  x.fillStyle = '#e6eaf6'; for (const px of [-0.17, 0, 0.17]) { x.beginPath(); x.arc(px * r, -r * 0.02, r * 0.045, 0, 7); x.fill(); }
  x.restore();
  // Fitil (örgülü ip)
  const fx0 = bx + r * 0.72, fy0 = by - r * 0.98, fx1 = bx + r * 1.12, fy1 = by - r * 1.5;
  x.strokeStyle = '#4a2a0a'; x.lineWidth = S * 0.05;
  x.beginPath(); x.moveTo(fx0, fy0); x.quadraticCurveTo(bx + r * 0.75, by - r * 1.55, fx1, fy1); x.stroke();
  x.strokeStyle = '#e0b070'; x.lineWidth = S * 0.032;
  x.beginPath(); x.moveTo(fx0, fy0); x.quadraticCurveTo(bx + r * 0.75, by - r * 1.55, fx1, fy1); x.stroke();
  x.strokeStyle = '#8a5a20'; x.lineWidth = S * 0.01; x.setLineDash([S * 0.02, S * 0.02]);
  x.beginPath(); x.moveTo(fx0, fy0); x.quadraticCurveTo(bx + r * 0.75, by - r * 1.55, fx1, fy1); x.stroke(); x.setLineDash([]);
  // Kıvılcım
  const sg = x.createRadialGradient(fx1, fy1, 0, fx1, fy1, S * 0.13);
  sg.addColorStop(0, '#ffffff'); sg.addColorStop(0.3, '#fff27a'); sg.addColorStop(0.6, 'rgba(255,150,30,0.7)'); sg.addColorStop(1, 'rgba(255,90,0,0)');
  x.fillStyle = sg; x.beginPath(); x.arc(fx1, fy1, S * 0.13, 0, 7); x.fill();
  x.fillStyle = '#ffffff'; x.beginPath();
  for (let i = 0; i < 16; i++) { const a = (i / 16) * Math.PI * 2, rr2 = i % 2 ? S * 0.025 : S * 0.085; x.lineTo(fx1 + Math.cos(a) * rr2, fy1 + Math.sin(a) * rr2); }
  x.closePath(); x.fill();
}
// Pervane: üç kavisli kanat (kırmızı-turuncu, beyaz uçlu), metal göbek, dönüş izi
function drawPropeller(x, S, c, ink, lw) {
  const R = S * 0.31;
  x.save(); x.translate(c, c);
  // Dönüş izi: kanat uçlarının çizdiği yarı saydam halka parçaları
  x.strokeStyle = 'rgba(255,255,255,0.35)'; x.lineWidth = S * 0.018;
  for (let i = 0; i < 3; i++) { const a = (i / 3) * Math.PI * 2 - 0.2; x.beginPath(); x.arc(0, 0, R * 1.04, a + 0.55, a + 1.35); x.stroke(); }
  // Gölge
  x.save(); x.filter = `blur(${S * 0.02}px)`; x.fillStyle = 'rgba(0,30,10,0.4)';
  for (let i = 0; i < 3; i++) { x.save(); x.rotate((i / 3) * Math.PI * 2); x.translate(S * 0.015, S * 0.03); blade(); x.fill(); x.restore(); }
  x.restore();
  function blade() {
    x.beginPath();
    x.moveTo(-R * 0.13, -R * 0.12);
    x.bezierCurveTo(-R * 0.42, -R * 0.55, -R * 0.38, -R * 0.98, R * 0.02, -R * 1.02);
    x.bezierCurveTo(R * 0.36, -R * 1.0, R * 0.42, -R * 0.62, R * 0.17, -R * 0.1);
    x.closePath();
  }
  for (let i = 0; i < 3; i++) {
    x.save(); x.rotate((i / 3) * Math.PI * 2 + 0.25);
    const g = x.createLinearGradient(-R * 0.4, -R, R * 0.4, -R * 0.2);
    g.addColorStop(0, '#ffb0a0'); g.addColorStop(0.35, '#ff4a3a'); g.addColorStop(1, '#a8121c');
    blade(); x.fillStyle = g; x.fill();
    // Beyaz uç bandı
    x.save(); blade(); x.clip();
    x.fillStyle = '#ffffff'; x.beginPath(); x.ellipse(0, -R * 1.0, R * 0.5, R * 0.2, 0, 0, 7); x.fill();
    x.fillStyle = '#ffcf1a'; x.fillRect(-R * 0.5, -R * 0.83, R, R * 0.07);
    x.fillStyle = 'rgba(255,255,255,0.55)'; x.beginPath(); x.ellipse(-R * 0.12, -R * 0.55, R * 0.06, R * 0.3, 0.25, 0, 7); x.fill();
    x.restore();
    blade(); x.strokeStyle = ink; x.lineWidth = lw; x.stroke();
    x.restore();
  }
  // Göbek
  const hr = R * 0.3;
  const hg = x.createRadialGradient(-hr * 0.35, -hr * 0.4, hr * 0.1, 0, 0, hr);
  hg.addColorStop(0, '#ffffff'); hg.addColorStop(0.45, '#c9d2ea'); hg.addColorStop(1, '#5d6890');
  x.beginPath(); x.arc(0, 0, hr, 0, 7); x.fillStyle = hg; x.fill(); x.strokeStyle = ink; x.lineWidth = lw; x.stroke();
  const cg = x.createRadialGradient(-hr * 0.15, -hr * 0.2, 0, 0, 0, hr * 0.5);
  cg.addColorStop(0, '#fff3a0'); cg.addColorStop(1, '#e8a010');
  x.beginPath(); x.arc(0, 0, hr * 0.48, 0, 7); x.fillStyle = cg; x.fill(); x.strokeStyle = ink; x.lineWidth = lw * 0.7; x.stroke();
  x.fillStyle = 'rgba(255,255,255,0.9)'; x.beginPath(); x.arc(-hr * 0.4, -hr * 0.45, hr * 0.16, 0, 7); x.fill();
  x.restore();
}
function drawBoltOrb(x, S, c, ink, lw) {
  const r = S * 0.29;
  // Cam küre
  const g = x.createRadialGradient(c - r * 0.3, c - r * 0.35, r * 0.05, c, c, r);
  g.addColorStop(0, '#ffffff'); g.addColorStop(0.25, '#c6f6ff'); g.addColorStop(0.6, '#5f86ff'); g.addColorStop(1, '#2a0c86');
  x.beginPath(); x.arc(c, c, r, 0, 7); x.fillStyle = g; x.fill();
  // İçte plazma kıvrımları
  x.save(); x.beginPath(); x.arc(c, c, r * 0.96, 0, 7); x.clip();
  x.globalCompositeOperation = 'lighter';
  x.strokeStyle = 'rgba(180,240,255,0.55)'; x.lineWidth = S * 0.014;
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2 + 0.4;
    x.beginPath(); x.moveTo(c, c);
    x.bezierCurveTo(c + Math.cos(a) * r * 0.4, c + Math.sin(a + 0.8) * r * 0.4, c + Math.cos(a + 0.5) * r * 0.7, c + Math.sin(a) * r * 0.7, c + Math.cos(a + 0.3) * r, c + Math.sin(a + 0.3) * r);
    x.stroke();
  }
  x.restore();
  x.beginPath(); x.arc(c, c, r, 0, 7); x.strokeStyle = '#1a0a5a'; x.lineWidth = lw; x.stroke();
  // Şimşek: arkada ışık, altın gövde, beyaz çekirdek
  const glow = x.createRadialGradient(c, c, 0, c, c, r * 0.9);
  glow.addColorStop(0, 'rgba(255,240,140,0.85)'); glow.addColorStop(1, 'rgba(255,200,40,0)');
  x.fillStyle = glow; x.beginPath(); x.arc(c, c, r * 0.9, 0, 7); x.fill();
  const bolt = () => {
    x.beginPath();
    x.moveTo(c + S * 0.06, c - r * 0.92); x.lineTo(c - S * 0.12, c + S * 0.03); x.lineTo(c - S * 0.005, c + S * 0.03);
    x.lineTo(c - S * 0.06, c + r * 0.92); x.lineTo(c + S * 0.13, c - S * 0.05); x.lineTo(c + S * 0.01, c - S * 0.05); x.closePath();
  };
  const bg = x.createLinearGradient(c - S * 0.1, c - r, c + S * 0.1, c + r);
  bg.addColorStop(0, '#fffbd0'); bg.addColorStop(0.45, '#ffd21f'); bg.addColorStop(1, '#e07a00');
  bolt(); x.fillStyle = bg; x.fill(); x.strokeStyle = '#6a3a00'; x.lineWidth = lw * 0.9; x.stroke();
  x.save(); bolt(); x.clip();
  x.strokeStyle = 'rgba(255,255,255,0.9)'; x.lineWidth = S * 0.02;
  x.beginPath(); x.moveTo(c + S * 0.045, c - r * 0.75); x.lineTo(c - S * 0.07, c + S * 0.01); x.stroke();
  x.restore();
  // Cam parlaması
  x.fillStyle = 'rgba(255,255,255,0.8)'; x.beginPath(); x.ellipse(c - r * 0.45, c - r * 0.5, r * 0.22, r * 0.11, -0.75, 0, 7); x.fill();
  // Yıldızcıklar
  x.fillStyle = '#ffffff';
  for (const [px, py, k] of [[c + r * 0.85, c - r * 0.8, 1], [c - r * 0.95, c + r * 0.6, 0.7]]) {
    x.beginPath(); for (let i = 0; i < 8; i++) { const a = (i / 8) * Math.PI * 2, rr2 = (i % 2 ? 0.012 : 0.05) * S * k; x.lineTo(px + Math.cos(a) * rr2, py + Math.sin(a) * rr2); } x.closePath(); x.fill();
  }
}

// Uçan tek roket (sağa bakar) ve arkasında alev
export function renderRocket(S) {
  const cv = document.createElement('canvas');
  cv.width = S * 2; cv.height = S;
  const x = cv.getContext('2d');
  x.lineJoin = 'round'; x.lineCap = 'round';
  // Alev
  const fg = x.createLinearGradient(0, 0, S * 0.6, 0); fg.addColorStop(0, 'rgba(255,90,20,0)'); fg.addColorStop(0.6, '#ff8a1a'); fg.addColorStop(1, '#fff3a0');
  x.fillStyle = fg; x.beginPath(); x.moveTo(S * 0.6, S * 0.5 - S * 0.14); x.quadraticCurveTo(S * 0.08, S * 0.5, S * 0.6, S * 0.5 + S * 0.14); x.closePath(); x.fill();
  x.translate(S * 0.5, S * 0.5);
  drawRocket(x, S * 1.6, '#10164a', S * 0.045, S * 0.1, S * 0.72, S * 0.15, S * 0.26);
  return cv;
}

// ---------- Özel bölüm (kaydırma) blokları ----------
// Seçilen tasarım: jöle (yuvarlak köşe, parlak cam yansıması, simgesiz). Cam küp (simgeli) yedek olarak duruyor.
const cvsS = (S) => { const c = document.createElement('canvas'); c.width = c.height = S; return c; };
const rrS = (x, X, Y, w, h, r) => { x.beginPath(); x.roundRect(X, Y, w, h, r); };
function rgbS(hex) { const n = parseInt(hex.slice(1), 16); return [n >> 16, (n >> 8) & 255, n & 255]; }
function shadeS(hex, k) {
  let [r, g, b] = rgbS(hex);
  if (k >= 0) { r += (255 - r) * k; g += (255 - g) * k; b += (255 - b) * k; } else { r *= 1 + k; g *= 1 + k; b *= 1 + k; }
  return `rgb(${r | 0},${g | 0},${b | 0})`;
}
const SYM = { '#ff4757': 'heart', '#ffcf1a': 'star', '#2ed573': 'leaf', '#1e90ff': 'drop', '#a55eea': 'diamond' };
// Simge yolu: merkez (cx, cy), boy k
function symPath(x, s, cx, cy, k) {
  x.beginPath();
  if (s === 'heart') { x.moveTo(cx, cy + k * 0.95); x.bezierCurveTo(cx - k * 1.55, cy - k * 0.15, cx - k * 0.75, cy - k * 1.25, cx, cy - k * 0.42); x.bezierCurveTo(cx + k * 0.75, cy - k * 1.25, cx + k * 1.55, cy - k * 0.15, cx, cy + k * 0.95); }
  else if (s === 'star') { for (let i = 0; i < 10; i++) { const a = -Math.PI / 2 + (i / 10) * Math.PI * 2, r = i % 2 ? k * 0.5 : k * 1.1; x.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r); } }
  else if (s === 'leaf') { x.moveTo(cx - k * 0.85, cy + k * 0.85); x.bezierCurveTo(cx - k * 1.05, cy - k * 0.55, cx + k * 0.15, cy - k * 1.1, cx + k * 0.95, cy - k * 0.95); x.bezierCurveTo(cx + k * 1.05, cy + k * 0.2, cx + k * 0.1, cy + k * 1.05, cx - k * 0.85, cy + k * 0.85); }
  else if (s === 'drop') { x.moveTo(cx, cy - k * 1.1); x.bezierCurveTo(cx + k * 0.45, cy - k * 0.45, cx + k * 0.9, cy - k * 0.05, cx + k * 0.82, cy + k * 0.42); x.arc(cx, cy + k * 0.3, k * 0.83, 0.15, Math.PI - 0.15); x.bezierCurveTo(cx - k * 0.9, cy - k * 0.05, cx - k * 0.45, cy - k * 0.45, cx, cy - k * 1.1); }
  else { x.moveTo(cx, cy - k * 1.05); x.lineTo(cx + k * 0.85, cy - k * 0.05); x.lineTo(cx, cy + k * 1.05); x.lineTo(cx - k * 0.85, cy - k * 0.05); }
  x.closePath();
}

// C · Cam küp: koyu renkli cam, büyük kubbe yansıması, simge camın içine oyulmuş (gömme kabartma)
function cubeTile(col, S) {
  const c = cvsS(S), x = c.getContext('2d'), m = S * 0.04, R = S * 0.2, W = S - 2 * m;
  x.save(); x.filter = `blur(${S * 0.02}px)`; rrS(x, m, m + S * 0.035, W, W, R); x.fillStyle = 'rgba(0,0,25,0.45)'; x.fill(); x.restore();
  rrS(x, m, m, W, W, R); x.fillStyle = shadeS(col, -0.6); x.fill();
  const t = S * 0.03;
  const body = x.createLinearGradient(0, m, 0, S - m);
  body.addColorStop(0, shadeS(col, 0.25)); body.addColorStop(0.45, col); body.addColorStop(1, shadeS(col, -0.4));
  rrS(x, m + t, m + t, W - 2 * t, W - 2 * t, R - t); x.fillStyle = body; x.fill();
  x.save(); rrS(x, m + t, m + t, W - 2 * t, W - 2 * t, R - t); x.clip();
  // İç parıltı (merkezden)
  const gl = x.createRadialGradient(S / 2, S * 0.62, 0, S / 2, S * 0.62, S * 0.45);
  gl.addColorStop(0, shadeS(col, 0.3)); gl.addColorStop(1, 'rgba(0,0,0,0)');
  x.globalCompositeOperation = 'lighter'; x.globalAlpha = 0.5; x.fillStyle = gl; x.fillRect(0, 0, S, S); x.globalAlpha = 1; x.globalCompositeOperation = 'source-over';
  // Oyulmuş simge: koyu iç, alt-sağda ışık kenarı, üst-solda gölge
  const s = SYM[col], cx = S / 2, cy = S * 0.55, k = S * 0.21;
  x.save(); x.translate(S * 0.012, S * 0.016); symPath(x, s, cx, cy, k); x.fillStyle = shadeS(col, 0.55); x.fill(); x.restore();
  symPath(x, s, cx, cy, k); x.fillStyle = shadeS(col, -0.42); x.fill();
  x.save(); symPath(x, s, cx, cy, k); x.clip(); x.translate(S * 0.02, S * 0.025); symPath(x, s, cx, cy, k); x.lineWidth = S * 0.05; x.strokeStyle = 'rgba(0,0,20,0.45)'; x.stroke(); x.restore();
  // Kubbe yansıması
  const dome = x.createLinearGradient(0, m, 0, S * 0.5);
  dome.addColorStop(0, 'rgba(255,255,255,0.6)'); dome.addColorStop(1, 'rgba(255,255,255,0.02)');
  x.fillStyle = dome; x.beginPath(); x.ellipse(S / 2, m + t, W * 0.48, S * 0.36, 0, 0, Math.PI); x.fill();
  x.restore();
  x.strokeStyle = 'rgba(255,255,255,0.55)'; x.lineWidth = S * 0.012;
  rrS(x, m + t * 0.6, m + t * 0.6, W - 1.2 * t, W - 1.2 * t, R - t * 0.6); x.stroke();
  return c;
}

// A · Jöle: yuvarlak köşe, dikey geçiş, büyük parlak üst yansıma, altta iç gölge
function jellyTile(col, S) {
  const c = cvsS(S), x = c.getContext('2d'), m = S * 0.035, R = S * 0.22;
  rrS(x, m, m, S - 2 * m, S - 2 * m, R); x.fillStyle = shadeS(col, -0.5); x.fill();
  const g = x.createLinearGradient(0, m, 0, S - m);
  g.addColorStop(0, shadeS(col, 0.28)); g.addColorStop(0.5, col); g.addColorStop(1, shadeS(col, -0.28));
  const t = S * 0.035;
  rrS(x, m + t, m + t, S - 2 * (m + t), S - 2 * (m + t), R - t); x.fillStyle = g; x.fill();
  x.save(); rrS(x, m + t, m + t, S - 2 * (m + t), S - 2 * (m + t), R - t); x.clip();
  const sh = x.createLinearGradient(0, S * 0.62, 0, S - m); sh.addColorStop(0, 'rgba(0,0,0,0)'); sh.addColorStop(1, 'rgba(0,0,30,0.28)');
  x.fillStyle = sh; x.fillRect(0, S * 0.62, S, S);
  x.restore();
  return c;
}
// Özel bölüm de normal bölümlerdeki pahlı bloğu kullanır (jöle ve cam küp yedek olarak duruyor)
export function renderSymbolTile(col, S) {
  // Yuvarlak köşeli pahlı blok: dört eğimli kenar köşelerde köşegen boyunca kusursuz birleşir,
  // dış hat da yuvarlak köşeyi izler (kırpma yok). Renk tonları normal bloğun aynısı.
  const c = cvsS(S), x = c.getContext('2d');
  const m = S * 0.04, w = S - 2 * m, R = w * 0.16, b = w * 0.13, lw = Math.max(1, w * 0.015);
  const outer = () => rrS(x, m, m, w, w, R);
  const inner = () => rrS(x, m + b, m + b, w - 2 * b, w - 2 * b, Math.max(w * 0.035, R - b));
  // Dış hat rengi zemin
  outer(); x.fillStyle = shade(col, -0.55); x.fill();
  // Pah halkası: dış (hat içi) ile iç yüz arası; dört üçgen köşegenlerde birleşir
  x.save();
  rrS(x, m + lw, m + lw, w - 2 * lw, w - 2 * lw, R - lw); x.clip();
  const cx = S / 2, e = 0.6;
  const tri = (pts, fill) => { x.beginPath(); pts.forEach(([px, py], i) => (i ? x.lineTo(px, py) : x.moveTo(px, py))); x.closePath(); x.fillStyle = fill; x.fill(); };
  tri([[-e, -e], [S + e, -e], [cx, cx]], shade(col, 0.32));
  tri([[-e, -e], [cx, cx], [-e, S + e]], shade(col, 0.12));
  tri([[S + e, -e], [S + e, S + e], [cx, cx]], shade(col, -0.18));
  tri([[-e, S + e], [cx, cx], [S + e, S + e]], shade(col, -0.38));
  x.restore();
  // Üst yüz
  const g = x.createLinearGradient(m + b, m + b, S - m - b, S - m - b);
  g.addColorStop(0, shade(col, 0.08)); g.addColorStop(1, shade(col, -0.04));
  inner(); x.fillStyle = g; x.fill();
  // Yüz kenarında ince ayrım çizgisi (köşelerle birlikte yumuşak)
  inner(); x.strokeStyle = 'rgba(0,0,0,0.08)'; x.lineWidth = Math.max(0.6, w * 0.006); x.stroke();
  return c;
}
