// Oyun ekonomisi: altın, güçlendirici envanteri, günlük ödül serisi ve bölüm sandıkları.
// Her şey cihazda saklanır (Store).
import { Store } from './platform.js';

export const BOOSTERS = {
  hammer: { name: 'Çekiç', price: 80, desc: 'Seçtiğin tek bloğu kırar.', hint: 'Kırılacak bloğu seç' },
  bomb: { name: 'Bomba', price: 150, desc: 'Seçtiğin yere düşer, 3×3 alandaki tüm blokları patlatır.', hint: 'Bombanın düşeceği yeri seç' },
  shuffle: { name: 'Yenile', price: 100, desc: 'Alttaki 3 parçayı yenileriyle değiştirir.' },
};
export const BOOSTER_KEYS = Object.keys(BOOSTERS);

// İlk açılışta hoş geldin hediyesi: 50 altın ve her güçlendiriciden bir tane (ekonomi sıkı: reklam ödülleri değerli kalsın)
export const Wallet = {
  get coins() { return Store.num('coins', 50); },
  addCoins(n) { Store.set('coins', this.coins + n); },
  spend(n) {
    if (this.coins < n) return false;
    Store.set('coins', this.coins - n);
    return true;
  },
  count(k) { return Store.num('b_' + k, 1); },
  addBooster(k, n = 1) { Store.set('b_' + k, this.count(k) + n); },
  useBooster(k) {
    const c = this.count(k);
    if (c <= 0) return false;
    Store.set('b_' + k, c - 1);
    return true;
  },
};

// ---------- Günlük ödül: 7 günlük seri, bir gün kaçarsa baştan başlar ----------
export const DAILY = [
  { coins: 10 }, { coins: 15 }, { booster: 'hammer' }, { coins: 20 },
  { booster: 'bomb' }, { coins: 30 }, { coins: 50, booster: 'shuffle' },
];
const dayKey = (d) => `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;

// day: bu seride kaç gün toplandı (0-7); canClaim: bugün toplanabilir mi
export function dailyState() {
  const today = dayKey(new Date());
  const last = Store.get('daily_last', '');
  let day = Store.num('daily_day', 0);
  if (last === today) return { canClaim: false, day };
  const yesterday = dayKey((() => { const d = new Date(); d.setDate(d.getDate() - 1); return d; })())   // takvimde bir gün geri (yaz saati geçişinde 24 sa iki gün öncesine düşebiliyordu);
  if (last !== yesterday || day >= DAILY.length) day = 0;
  return { canClaim: true, day };
}

export function claimDaily() {
  const st = dailyState();
  if (!st.canClaim) return null;
  const r = DAILY[st.day];
  if (r.coins) Wallet.addCoins(r.coins);
  if (r.booster) Wallet.addBooster(r.booster);
  Store.set('daily_last', dayKey(new Date()));
  Store.set('daily_day', st.day + 1);
  return { reward: r, index: st.day };
}

// ---------- Bölüm ödülü ve sandık ----------
export const CHEST_EVERY = 5;

// İlk kez geçilen bölüm yıldız başına daha çok altın verir; tekrar oynamada yalnız yeni yıldızlar sayılır
export function levelCoins(stars, prevStars, firstTime) {
  if (firstTime) return 5 + stars * 5;
  return stars > prevStars ? (stars - prevStars) * 5 : 0;
}

// Sandık: altın + rastgele bir güçlendirici
export function openChest() {
  const coins = 15 + Math.floor(Math.random() * 3) * 5;
  const booster = BOOSTER_KEYS[Math.floor(Math.random() * BOOSTER_KEYS.length)];
  Wallet.addCoins(coins);
  Wallet.addBooster(booster);
  return { coins, booster };
}

// ---------- Günlük görevler: her gün 3 görev (kolay, orta, zor) ----------
const MISSION_POOL = [
  { id: 'lines', n: [10, 18, 28], text: (n) => `${n} satır patlat` },
  { id: 'combo', n: [3, 5, 8], text: (n) => `${n} kez kombo yap` },
  { id: 'icons', n: [10, 18, 28], text: (n) => `${n} hedef simgesi topla` },
  { id: 'levels', n: [1, 2, 4], text: (n) => `${n} bölüm geç` },
  { id: 'place', n: [25, 45, 70], text: (n) => `${n} parça yerleştir` },
  { id: 'multi', n: [1, 3, 5], text: (n) => `Tek hamlede 2+ satır patlat (${n} kez)` },
  { id: 'fire', n: [1, 2, 3], text: (n) => (n > 1 ? `Ateş moduna gir (${n} kez)` : 'Ateş moduna gir') },
  { id: 'endless', n: [800, 2000, 3500], max: true, text: (n) => `Sonsuz modda ${n.toLocaleString('tr-TR')} puan yap` },
  { id: 'booster', n: [1, 2, 3], text: (n) => `${n} güçlendirici kullan` },
];
export const MISSION_REWARD = [10, 20, 30];

function seeded(seed) { let s = seed % 233280; return () => (s = (s * 9301 + 49297) % 233280) / 233280; }

export const Missions = {
  load() {
    const key = dayKey(new Date());
    let st = null;
    try { st = JSON.parse(Store.get('missions', 'null')); } catch { st = null; }
    if (!st || st.day !== key) {
      const d = new Date();
      const r = seeded(d.getFullYear() * 400 + d.getMonth() * 32 + d.getDate());
      const pool = MISSION_POOL.slice();
      for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
      st = { day: key, bonus: false, list: pool.slice(0, 3).map((m, tier) => ({ id: m.id, tier, n: m.n[tier], p: 0, claimed: false })) };
      Store.set('missions', JSON.stringify(st));
    }
    return st;
  },
  save(st) { Store.set('missions', JSON.stringify(st)); },
  text(m) { return MISSION_POOL.find((x) => x.id === m.id).text(m.n); },
  // İlerleme kaydet; yeni tamamlanan görevleri döndürür
  track(id, amount = 1) {
    const st = this.load();
    const done = [];
    for (const m of st.list) {
      if (m.id !== id || m.p >= m.n) continue;
      const def = MISSION_POOL.find((x) => x.id === id);
      m.p = Math.min(m.n, def.max ? Math.max(m.p, amount) : m.p + amount);
      if (m.p >= m.n) done.push(m);
    }
    this.save(st);
    return done;
  },
  claim(i) {
    const st = this.load();
    const m = st.list[i];
    if (!m || m.claimed || m.p < m.n) return 0;
    m.claimed = true;
    this.save(st);
    const coins = MISSION_REWARD[m.tier];
    Wallet.addCoins(coins);
    return coins;
  },
  bonusReady() { const st = this.load(); return !st.bonus && st.list.every((m) => m.claimed); },
  claimBonus() {
    const st = this.load();
    if (st.bonus || !st.list.every((m) => m.claimed)) return null;
    st.bonus = true;
    this.save(st);
    return openChest();
  },
  hasClaimable() { const st = this.load(); return st.list.some((m) => !m.claimed && m.p >= m.n) || this.bonusReady(); },
};

// ---------- Günlük bulmaca serisi ----------
// Her gün çözüldükçe seri büyür; ödül seriyle artar, her 7. günde sandık da verilir.
export const DailyPuzzle = {
  state() {
    const today = dayKey(new Date());
    const last = Store.get('dp_last', '');
    let streak = Store.num('dp_streak', 0);
    const yesterday = dayKey((() => { const d = new Date(); d.setDate(d.getDate() - 1); return d; })())   // takvimde bir gün geri (yaz saati geçişinde 24 sa iki gün öncesine düşebiliyordu);
    if (last !== today && last !== yesterday) streak = 0;   // seri bozuldu
    return { solvedToday: last === today, streak };
  },
  rewardFor(streak) { return 15 + 5 * Math.min(streak, 7); },
  complete() {
    const st = this.state();
    if (st.solvedToday) return null;
    const streak = st.streak + 1;
    Store.set('dp_last', dayKey(new Date()));
    Store.set('dp_streak', streak);
    const coins = this.rewardFor(streak);
    Wallet.addCoins(coins);
    return { coins, streak, chest: streak % 7 === 0 };
  },
};

// ---------- Canlar ----------
// En fazla 3 can. Can azaldığında 1 saatlik sayaç başlar; 1 saat dolunca canlar 3'e tamamlanır.
// Ödüllü reklam izlenirse canlar hemen dolar.
export const LIVES_MAX = 3;
export const LIFE_REFILL_MS = 60 * 60 * 1000;   // her saatte bir
export const LIFE_REFILL_N = 3;                 // +3 can (en fazla LIVES_MAX)
export const Lives = {
  state() {
    let n = Math.min(LIVES_MAX, Store.num('lives', LIVES_MAX));
    let at = Store.num('lives_at', 0);
    // Eski (3 saatlik) sayaç kaldıysa en çok 1 saate indirilir
    if (at && at - Date.now() > LIFE_REFILL_MS) { at = Date.now() + LIFE_REFILL_MS; Store.set('lives_at', at); }
    // Süre dolduysa +3 can; uzun süre girilmediyse geçen her saat için ayrıca +3 (dolunca sayaç durur)
    if (n < LIVES_MAX && at && Date.now() >= at) {
      while (n < LIVES_MAX && at && Date.now() >= at) { n = Math.min(LIVES_MAX, n + LIFE_REFILL_N); at = n < LIVES_MAX ? at + LIFE_REFILL_MS : 0; }
      Store.set('lives', n); Store.set('lives_at', at);
    }
    if (n >= LIVES_MAX) at = 0;
    return { n, refillAt: at };
  },
  get count() { return this.state().n; },
  lose() {
    const st = this.state();
    if (st.n <= 0) return st.n;
    Store.set('lives', st.n - 1);
    if (!st.refillAt) Store.set('lives_at', Date.now() + LIFE_REFILL_MS);
    return st.n - 1;
  },
  fill() { Store.set('lives', LIVES_MAX); Store.set('lives_at', 0); },
};

// ---------- Profil ----------
export const AVATARS = ['#ff5a6e', '#ffb02e', '#3ddc6a', '#2c9ae8', '#9257e8', '#ff6fc8', '#17c3d6', '#ff7a2a'];
export const Profile = {
  get() {
    try { const p = JSON.parse(Store.get('profile', 'null')); if (p && p.name) return p; } catch { /* bozuk */ }
    return null;
  },
  save(name, avatar) { Store.set('profile', JSON.stringify({ name, avatar })); },
  // Kullanıcı adı: 3-14 karakter, harf/rakam/boşluk/alt çizgi
  check(name) {
    const n = name.trim().replace(/\s+/g, ' ');
    if (n.length < 3) return { ok: false, msg: 'En az 3 karakter olmalı' };
    if (n.length > 14) return { ok: false, msg: 'En fazla 14 karakter olabilir' };
    if (!/^[\p{L}\p{N} _]+$/u.test(n)) return { ok: false, msg: 'Sadece harf, rakam ve boşluk kullan' };
    return { ok: true, name: n };
  },
  suggest() {
    const a = ['Hızlı', 'Usta', 'Parlak', 'Cesur', 'Neşeli', 'Akıllı', 'Şanslı', 'Efsane', 'Minik', 'Süper'];
    const b = ['Blok', 'Kare', 'Yıldız', 'Elmas', 'Kaplan', 'Şimşek', 'Kartal', 'Roket', 'Usta', 'Panda'];
    const r = (x) => x[Math.floor(Math.random() * x.length)];
    let s = `${r(a)} ${r(b)}`;
    if (s.split(' ')[0] === s.split(' ')[1]) s = `${r(a)} Blok`;
    return `${s} ${10 + Math.floor(Math.random() * 90)}`.slice(0, 14).trim();
  },
};

// ---------- Blok Adası: yapı taşları ve inşa ilerlemesi ----------
// Bölüm kazanınca yıldız başına bir yapı taşı gelir (tekrar oynayınca yalnız yeni yıldızlar).
// Her yapı 8 adımda biter; adım maliyeti yapıdan yapıya artar. Yapı bitince büyük ödül verilir.
export const Build = {
  get bricks() { return Store.num('bricks', 0); },
  addBricks(n) { Store.set('bricks', this.bricks + n); },
  state() {
    let st = null;
    try { st = JSON.parse(Store.get('build', 'null')); } catch { st = null; }
    return st || { b: 0, step: 0 };
  },
  save(st) { Store.set('build', JSON.stringify(st)); },
  cost(b) { return 3 + Math.min(4, Math.floor(b / 1.5)); },
  // Kazanılan bölüm için verilecek taş
  forLevel(stars, prevStars, firstTime, special) {
    const base = firstTime ? stars : Math.max(0, stars - prevStars);
    return base + (firstTime && special ? 2 : 0);
  },
  // Bir adım inşa et: başarılıysa { b, step, done } döner
  buildStep(steps) {
    const st = this.state();
    const c = this.cost(st.b);
    if (this.bricks < c) return null;
    Store.set('bricks', this.bricks - c);
    const step = st.step;
    st.step++;
    const done = st.step >= steps;
    const b = st.b;
    if (done) { st.b++; st.step = 0; }
    this.save(st);
    return { b, step, done };
  },
};
